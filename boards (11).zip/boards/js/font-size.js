window.App = window.App || {};

App.fontSize = (() => {

  const SIZES = ['small', 'default', 'large', 'xlarge', 'huge'];
  const NAMES = { small: 'Small', default: 'Normal', large: 'Large', xlarge: 'Extra large', huge: 'Huge' };

  App.textStyle.register({
    key: 'size',
    cssProp: 'font-size',
    varPrefix: '--fs-',
    values: ['default', ...SIZES.filter((s) => s !== 'default')],
    command: 'fontSize',
    marker: '7',
    isMarker: (el, style) => /font-size:\s*(-webkit-)?xxx-large/.test(style) || el.getAttribute('size') === '7',
  });

  const current = (editor) => App.textStyle.current(editor, 'size');
  const apply = (editor, size) => App.textStyle.apply(editor, 'size', size);

  function step(editor, dir) {
    const i = SIZES.indexOf(current(editor));
    const next = SIZES[Math.min(SIZES.length - 1, Math.max(0, i + dir))];
    if (next !== SIZES[i]) apply(editor, next);
  }

  return { SIZES, NAMES, current, apply, step };
})();
