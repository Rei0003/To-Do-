window.App = window.App || {};

App.pan = {
  init() {
    const viewport = document.getElementById('viewport');

    const KEEP_MENU = 'input, textarea, [contenteditable="true"], video, img, [data-context-menu]';
    let active = null;

    viewport.addEventListener('pointerdown', (e) => {
      if (e.pointerType !== 'mouse') return;
      if (e.button === 2 && e.target.closest(KEEP_MENU)) return;
      if (e.button !== 2 && e.button !== 1) return;

      active = {
        id: e.pointerId,
        x: e.clientX,
        y: e.clientY,
        left: viewport.scrollLeft,
        top: viewport.scrollTop,
      };
      viewport.setPointerCapture(e.pointerId);
      viewport.classList.add('is-panning');
      e.preventDefault();
    });

    viewport.addEventListener('pointermove', (e) => {
      if (!active || e.pointerId !== active.id) return;
      viewport.scrollLeft = active.left - (e.clientX - active.x);
      viewport.scrollTop = active.top - (e.clientY - active.y);
    });

    const end = (e) => {
      if (!active || e.pointerId !== active.id) return;
      active = null;
      viewport.classList.remove('is-panning');
    };
    viewport.addEventListener('pointerup', end);
    viewport.addEventListener('pointercancel', end);

    viewport.addEventListener('contextmenu', (e) => {
      if (!e.target.closest(KEEP_MENU)) e.preventDefault();
    });

    viewport.addEventListener('mousedown', (e) => {
      if (e.button === 1) e.preventDefault();
    });
  },
};
