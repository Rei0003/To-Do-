window.App = window.App || {};

App.access = (() => {
  let role = 'owner';
  let cards = new Set();
  let info = null;

  const STILL_WORK = [
    '.ap-play', '.file-main', '[data-file]', '.cal-nav', '.cal-today', '.cal-cell',
    '.draw-zoom button', '[data-draw-mode="hand"]', '[data-draw-action="more"]', '.bc-open', '.task-status[data-mine]',
  ].join(',');

  const canEditAll = () => role === 'owner' || role === 'edit';

  function canEditCard(id) {
    if (canEditAll()) return true;
    if (role !== 'cards') return false;
    const top = App.state.topOf(id);
    return !!top && cards.has(top.id);
  }

  function lock(el) {
    el.classList.add('is-locked');
    const apply = () => {
      el.querySelectorAll('[contenteditable="true"]').forEach((x) => { x.contentEditable = 'false'; });
      el.querySelectorAll('input, select, textarea').forEach((x) => {
        x.disabled = !x.matches('[data-mine]');
      });
      el.querySelectorAll('button').forEach((b) => { if (!b.matches(STILL_WORK)) b.disabled = true; });
    };
    apply();
    new MutationObserver(apply).observe(el, { childList: true, subtree: true });
  }

  return {

    set(a) {
      info = a || null;
      role = a?.role || 'owner';
      cards = new Set(a?.cards || []);
      document.body.dataset.access = role;
    },
    get role() { return role; },
    get info() { return info; },
    canEditAll,
    canManage: () => role === 'owner',
    readOnly: () => role === 'view',
    canEditCard,

    canAdd: (parentId) => canEditAll() || (role === 'cards' && !!parentId && canEditCard(parentId)),

    canDelete: (id) => canEditAll() || (role === 'cards' && !!App.state.getCard(id)?.parent && canEditCard(id)),
    allowedCards: () => [...cards],

    decorate(el, card) {
      if (!canEditCard(card.id)) lock(el);
      else if (role === 'cards') el.classList.add('is-yours');
    },
  };
})();
