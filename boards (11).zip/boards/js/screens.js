window.App = window.App || {};

App.screens = (() => {
  const BRAND = `<svg class="brand" viewBox="0 0 28 28" aria-hidden="true">
    <rect x="3" y="3" width="13" height="16" rx="2.5" fill="currentColor"/>
    <rect x="12" y="9" width="13" height="16" rx="2.5" fill="none" stroke="currentColor" stroke-width="2"/></svg>`;
  const TILE_COLORS = ['var(--c-blue)', 'var(--c-green)', 'var(--c-purple)', 'var(--c-pink)', 'var(--c-yellow)', 'var(--tc-orange)'];
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  function ago(seconds) {
    const d = Math.max(0, Date.now() / 1000 - seconds);
    if (d < 60) return 'just now';
    if (d < 3600) return `${Math.floor(d / 60)} min ago`;
    if (d < 86400) return `${Math.floor(d / 3600)} h ago`;
    if (d < 172800) return 'yesterday';
    return new Date(seconds * 1000).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
  }
  const colorFor = (id) => TILE_COLORS[[...String(id)].reduce((a, c) => a + c.charCodeAt(0), 0) % TILE_COLORS.length];

  function auth(el, { tab = 'login', server }) {
    el.innerHTML = `
      <div class="auth">
        <div class="auth-card">
          <div class="auth-brand">${BRAND}<span>Boards</span></div>
          ${server ? `
          <div class="auth-tabs" role="tablist">
            <button role="tab" data-tab="login">Log in</button>
            <button role="tab" data-tab="register">Create account</button>
          </div>
          <form class="auth-form" novalidate>
            <label class="auth-field" data-only="register"><span>Name</span>
              <input name="name" autocomplete="name" maxlength="60"></label>
            <label class="auth-field"><span>Email</span>
              <input name="email" type="email" autocomplete="email" required></label>
            <label class="auth-field"><span>Password</span>
              <input name="password" type="password" required minlength="8">
              <small data-only="register">At least 8 characters</small></label>
            <p class="auth-error" role="alert" hidden></p>
            <button class="btn-primary auth-submit" type="submit"></button>
          </form>
          ${App.session.allowGuest ? '<div class="auth-or"><span>or</span></div>' : ''}` : `
          <p class="auth-note"><strong>Accounts need the server.</strong> Start it (see the README: XAMPP, or
            <code>php -S localhost:8000 server.php</code>) and open the app through it to log in.</p>`}
          ${App.session.allowGuest ? `<button class="auth-local" data-local>
            <strong>Use without an account</strong>
            <span>Your boards are kept in this browser only</span>
          </button>` : ''}
        </div>
      </div>`;

    el.querySelector('[data-local]')?.addEventListener('click', () => {
      App.session.useLocal();
      location.hash = '#/boards';
    });
    if (!server) return;

    const form = el.querySelector('form');
    const error = el.querySelector('.auth-error');
    const submit = el.querySelector('.auth-submit');
    function setTab(t) {
      tab = t;
      el.querySelectorAll('[data-tab]').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.tab === t)));
      el.querySelectorAll('[data-only="register"]').forEach((x) => { x.hidden = t !== 'register'; });
      form.password.autocomplete = t === 'register' ? 'new-password' : 'current-password';
      submit.textContent = t === 'register' ? 'Create account' : 'Log in';
      error.hidden = true;
      (t === 'register' ? form.name : form.email).focus();
    }
    el.querySelectorAll('[data-tab]').forEach((b) => b.addEventListener('click', () => setTab(b.dataset.tab)));

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      error.hidden = true;
      const email = form.email.value.trim();
      const password = form.password.value;
      if (tab === 'register' && !form.name.value.trim()) return showError('Please enter your name.');
      if (!email || !email.includes('@')) return showError('Please enter your email address.');
      if (password.length < 8 && tab === 'register') return showError('The password needs at least 8 characters.');
      submit.disabled = true;
      submit.textContent = tab === 'register' ? 'Creating account…' : 'Logging in…';
      try {
        if (tab === 'register') {
          await App.session.register(form.name.value.trim(), email, password);
          await App.boards.create('My first board', App.state.starterBoard());
        } else {
          await App.session.login(email, password);
        }
        location.hash = '#/boards';
      } catch (err) {
        showError(err.message);
        submit.disabled = false;
        submit.textContent = tab === 'register' ? 'Create account' : 'Log in';
      }
    });
    function showError(msg) { error.textContent = msg; error.hidden = false; }
    setTab(tab);
  }

  let menu = null;
  function closeMenu() {
    menu?.remove();
    menu = null;
    document.removeEventListener('pointerdown', outside, true);
  }
  function outside(e) { if (menu && !menu.contains(e.target) && !e.target.closest('[data-account]')) closeMenu(); }
  function openAccountMenu(anchor) {
    if (menu) return closeMenu();
    App.tooltip?.hide();
    const u = App.session.user;
    menu = document.createElement('div');
    menu.className = 'account-menu draw-menu draw-panel';
    menu.innerHTML = u
      ? `<button class="account-who account-who-btn" data-m="profile"><span class="account-pic"></span>
           <span class="account-who-text"><strong>${esc(u.name)}</strong><span>${esc(u.email)}</span></span></button><hr>
         <button data-m="profile">Profile &amp; picture…</button>
         <button data-m="boards">All boards</button>
         <button data-m="team">Team activity</button>
         <button data-m="settings">Settings…</button>
         <button data-m="logout" class="is-danger">Log out</button>`
      : `<div class="account-who"><strong>Not logged in</strong><span>Boards are saved in this browser</span></div><hr>
         <button data-m="boards">All boards</button>
         <button data-m="settings">Settings…</button>
         ${App.session.server ? '<button data-m="login">Log in or create an account</button>' : ''}`;
    menu.addEventListener('click', async (e) => {
      const m = e.target.closest('[data-m]')?.dataset.m;
      if (!m) return;
      closeMenu();
      if (m === 'boards') location.hash = '#/boards';
      if (m === 'profile') App.profile.open();
      if (m === 'team') location.hash = '#/team';
      if (m === 'settings') App.settings.open();
      if (m === 'login') location.hash = '#/login';
      if (m === 'logout') {
        await App.storage.flush();
        await App.session.logout();
        location.hash = '#/login';
      }
    });
    if (u) menu.querySelector('.account-pic')?.append(App.people.avatar(u.email, 36));
    document.body.append(menu);
    const r = anchor.getBoundingClientRect();
    menu.style.top = `${r.bottom + 6}px`;
    menu.style.left = `${Math.max(8, Math.min(r.right - menu.offsetWidth, window.innerWidth - menu.offsetWidth - 8))}px`;
    document.addEventListener('pointerdown', outside, true);
  }

  function accountButton(btn) {
    const u = App.session.user;
    btn.dataset.account = '';
    btn.textContent = u ? (u.name.trim()[0] || '?').toUpperCase() : '';
    if (u?.avatar) {
      const img = document.createElement('img');
      img.alt = '';
      img.src = u.avatar;
      img.onerror = () => img.remove();
      btn.append(img);
    }
    btn.classList.toggle('is-local', !u);
    btn.setAttribute('aria-label', u ? `Account: ${u.name}` : 'Not logged in');
    btn.dataset.tooltip = u ? `${u.name}\n${u.email}` : 'Not logged in\n(boards are saved in this browser)';
    if (!btn.dataset.wired) {
      btn.dataset.wired = '1';
      btn.addEventListener('click', () => openAccountMenu(btn));
    }
  }

  async function home(el) {
    const u = App.session.user;
    el.innerHTML = `
      <div class="home">
        <header class="home-head">
          <a class="home-brand" href="#/boards" aria-label="All boards">${BRAND}<span>Boards</span></a>
          <span class="home-spacer"></span>
          ${u ? '<a class="file-btn home-team-link" href="#/team">Team activity</a>' : ''}
          <button class="theme-toggle home-theme" aria-label="Switch theme" data-tooltip="Light / dark">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/></svg></button>
          <button class="account-btn"></button>
        </header>
        <main class="home-body">
          <div class="home-title"><h1>Your boards</h1>
            <p>${u ? `Saved in your account · ${esc(u.email)}` : 'Saved in this browser'}</p></div>
          <div class="home-banners"></div>
          <section class="home-invites" hidden></section>
          <section class="home-tasks" hidden></section>
          <div class="board-grid" aria-busy="true"><p class="home-loading">Loading boards…</p></div>
        </main>
      </div>`;
    accountButton(el.querySelector('.account-btn'));
    el.querySelector('.home-theme').addEventListener('click', () => App.theme.toggle());

    const banners = el.querySelector('.home-banners');

    if (!u) {
      const b = document.createElement('div');
      b.className = 'home-banner';
      b.innerHTML = App.session.server
        ? '<p><strong>Not logged in.</strong> Boards are only saved in this browser. Create an account to use them on any computer.</p><a class="file-btn" href="#/login">Log in or create an account</a>'
        : '<p><strong>Boards are saved in this browser.</strong> To use accounts, open the app through the PHP server (see the README).</p>';
      banners.append(b);
    }

    const importKey = u ? `boards.imported.${u.id}` : null;
    if (u && !localStorage.getItem(importKey) && App.boards.localCount() > 0) {
      const b = document.createElement('div');
      b.className = 'home-banner home-banner--import';
      const n = App.boards.localCount();
      b.innerHTML = `<p><strong>This browser has ${n} board${n === 1 ? '' : 's'} from before you logged in.</strong> Copy them into your account (with their pictures and files)?</p>
        <div class="home-banner-actions"><button class="file-btn" data-imp="no">Not now</button><button class="confirm-pop-btn btn-primary" data-imp="yes">Copy to my account</button></div>`;
      b.addEventListener('click', async (e) => {
        const a = e.target.closest('[data-imp]')?.dataset.imp;
        if (a === 'no') { localStorage.setItem(importKey, 'skipped'); b.remove(); }
        if (a === 'yes') {
          b.innerHTML = '<p>Copying your boards… <span class="imp-progress"></span></p>';
          try {
            await App.boards.importLocalBoards((done, total) => { b.querySelector('.imp-progress').textContent = `${done} of ${total}`; });
            localStorage.setItem(importKey, 'done');
            home(el);
          } catch (err) {
            b.innerHTML = `<p>Copying stopped: ${esc(err.message)}</p>`;
          }
        }
      });
      banners.append(b);
    }

    if (u) showInvites(el.querySelector('.home-invites'), () => home(el));
    showMyTasks(el.querySelector('.home-tasks'));

    const grid = el.querySelector('.board-grid');
    let boards = [];
    let shared = [];
    try {
      ({ boards, shared } = await App.boards.list());
    } catch (err) {
      if (err.status === 401) { location.hash = '#/login'; return; }
      grid.innerHTML = `<p class="home-loading">Couldn’t load your boards: ${esc(err.message)}</p>`;
      return;
    }
    grid.removeAttribute('aria-busy');
    const ROLE = { edit: 'Can edit', view: 'Can view', cards: 'Can edit some cards' };
    const tiles = boards.map((b) => `
      <div class="board-tile" data-id="${esc(b.id)}" style="--tile:${colorFor(b.id)}">
        <a class="board-open" href="#/board/${esc(b.id)}">
          <span class="board-band"></span>
          <span class="board-name">${esc(b.title || 'Untitled board')}</span>
          <span class="board-meta">${b.cards ?? 0} card${b.cards === 1 ? '' : 's'} · edited ${ago(b.updated_at)}${b.members ? ` · shared with ${b.members}` : ''}</span>
        </a>
        <button class="board-more" aria-label="Board options" data-tooltip="Rename, duplicate, delete">
          <svg viewBox="0 0 16 16" fill="currentColor"><circle cx="3.5" cy="8" r="1.3"/><circle cx="8" cy="8" r="1.3"/><circle cx="12.5" cy="8" r="1.3"/></svg></button>
      </div>`).join('');
    grid.innerHTML = `
      <button class="board-tile board-new"><span class="board-plus">+</span><span>New board</span></button>
      ${tiles}`;

    if (shared.length) {
      const section = document.createElement('section');
      section.className = 'home-shared';
      section.innerHTML = `<h2>Shared with you</h2><div class="board-grid">${shared.map((b) => `
        <div class="board-tile is-shared" data-id="${esc(b.id)}" style="--tile:${colorFor(b.id)}">
          <a class="board-open" href="#/board/${esc(b.id)}">
            <span class="board-band"><span class="board-role">${ROLE[b.role] || ''}</span></span>
            <span class="board-name">${esc(b.title || 'Untitled board')}</span>
            <span class="board-meta">From ${esc(b.owner)} · edited ${ago(b.updated_at)}</span>
          </a>
          <button class="board-more" aria-label="Board options" data-tooltip="Leave board">
            <svg viewBox="0 0 16 16" fill="currentColor"><circle cx="3.5" cy="8" r="1.3"/><circle cx="8" cy="8" r="1.3"/><circle cx="12.5" cy="8" r="1.3"/></svg></button>
        </div>`).join('')}</div>`;
      grid.after(section);
      section.addEventListener('click', (e) => {
        const more = e.target.closest('.board-more');
        if (!more) return;
        const board = shared.find((b) => b.id === more.closest('.board-tile').dataset.id);
        App.confirmPopover.open(more, {
          title: `Leave “${board.title}”?`,
          message: `${board.owner} would have to invite you again.`,
          confirmLabel: 'Leave board',
          onConfirm: async () => {
            try { await App.boards.members.remove(board.id, App.session.user.email); home(el); } catch (err) { alertBanner(err.message); }
          },
        });
      });
    }

    grid.querySelector('.board-new').addEventListener('click', async () => {
      try {
        const b = await App.boards.create('Untitled board');
        location.hash = `#/board/${b.id}`;
      } catch (err) { alertBanner(err.message); }
    });

    grid.addEventListener('click', (e) => {
      const more = e.target.closest('.board-more');
      if (!more) return;
      const tile = more.closest('.board-tile');
      boardMenu(more, tile, boards.find((b) => b.id === tile.dataset.id));
    });

    function alertBanner(msg) {
      const b = document.createElement('div');
      b.className = 'home-banner home-banner--error';
      b.textContent = msg;
      banners.append(b);
      setTimeout(() => b.remove(), 6000);
    }

    function boardMenu(anchor, tile, board) {
      closeMenu();
      menu = document.createElement('div');
      menu.className = 'draw-menu draw-panel';
      menu.innerHTML = `<button data-b="open">Open</button><button data-b="rename">Rename</button>
        <button data-b="duplicate">Duplicate</button><hr><button data-b="delete" class="is-danger">Delete…</button>`;
      document.body.append(menu);
      const r = anchor.getBoundingClientRect();
      menu.style.top = `${r.bottom + 4}px`;
      menu.style.left = `${Math.min(r.left, window.innerWidth - menu.offsetWidth - 8)}px`;
      document.addEventListener('pointerdown', outside, true);
      menu.addEventListener('click', async (e) => {
        const a = e.target.closest('[data-b]')?.dataset.b;
        if (!a) return;
        closeMenu();
        try {
          if (a === 'open') location.hash = `#/board/${board.id}`;
          if (a === 'duplicate') { await App.boards.duplicate(board.id); home(el); }
          if (a === 'rename') renameTile(tile, board);
          if (a === 'delete') {
            App.confirmPopover.open(anchor, {
              title: `Delete “${board.title || 'Untitled board'}”?`,
              message: 'Everything on it is deleted too. This can’t be undone.',
              confirmLabel: 'Delete board',
              onConfirm: async () => {
                try { await App.boards.remove(board.id); home(el); } catch (err) { alertBanner(err.message); }
              },
            });
          }
        } catch (err) { alertBanner(err.message); }
      });
    }

    function renameTile(tile, board) {
      const name = tile.querySelector('.board-name');
      const input = document.createElement('input');
      input.className = 'board-rename';
      input.value = board.title || '';
      input.maxLength = 200;
      name.replaceWith(input);
      input.focus();
      input.select();
      let done = false;
      const finish = async (keep) => {
        if (done) return;
        done = true;
        const title = input.value.trim() || 'Untitled board';
        if (keep && title !== board.title) {
          try { await App.boards.rename(board.id, title); } catch (err) { alertBanner(err.message); }
        }
        home(el);
      };
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') finish(true);
        if (e.key === 'Escape') finish(false);
      });
      input.addEventListener('blur', () => finish(true));

      input.addEventListener('click', (e) => e.preventDefault());
    }
  }

  async function showInvites(section, refresh) {
    let invites = [];
    try { invites = (await App.api.request('GET', 'invitations.php')).invitations; } catch { return; }
    section.hidden = !invites.length;
    if (!invites.length) return;
    const ROLE = { edit: 'Can edit', view: 'Can view', cards: 'Can edit some cards' };
    section.innerHTML = `<h2>Invitations <span class="home-count">${invites.length}</span></h2><ul class="invite-list"></ul>`;
    const ul = section.querySelector('ul');
    invites.forEach((inv) => {
      const li = document.createElement('li');
      li.className = 'invite';
      li.innerHTML = `
        <span class="invite-pic"></span>
        <span class="invite-text"><strong></strong> invited you to <strong class="invite-board"></strong>
          <small>${ROLE[inv.role] || ''}${inv.member_role ? ` · ${esc(inv.member_role.name)}` : ''}</small></span>
        <span class="invite-actions">
          <button class="file-btn" data-inv="decline">Decline</button>
          <button class="confirm-pop-btn btn-primary" data-inv="accept">Accept</button>
        </span>
        <p class="invite-msg" role="status" hidden></p>`;
      li.querySelector('.invite-text strong').textContent = inv.owner.name;
      li.querySelector('.invite-board').textContent = inv.title;
      const pic = document.createElement('span');
      pic.className = 'person-avatar';
      pic.style.setProperty('--ps', '34px');
      pic.style.setProperty('--pc', '#2F6FD6');
      pic.textContent = (inv.owner.name || '?')[0].toUpperCase();
      if (inv.owner.avatar) { const img = document.createElement('img'); img.src = inv.owner.avatar; img.alt = ''; pic.classList.add('has-pic'); pic.append(img); }
      li.querySelector('.invite-pic').append(pic);
      li.addEventListener('click', async (e) => {
        const act = e.target.closest('[data-inv]')?.dataset.inv;
        if (!act) return;
        li.querySelectorAll('button').forEach((b) => { b.disabled = true; });
        try {
          await App.api.request('POST', `invitations.php?board=${inv.board}&action=${act}`);
          if (act === 'accept') location.hash = `#/board/${inv.board}`;
          else refresh();
        } catch (err) {
          const m = li.querySelector('.invite-msg');
          m.textContent = err.message;
          m.hidden = false;
          li.querySelectorAll('button').forEach((b) => { b.disabled = false; });
        }
      });
      ul.append(li);
    });
  }

  const PRIORITY_RANK = { urgent: 0, high: 1, medium: 2, low: 3 };
  const PRIORITY_NAME = { urgent: 'Urgent', high: 'High', medium: 'Medium', low: 'Low' };
  let taskView = { tab: 'active', sort: 'due', priority: 'all' };

  async function loadMyTasks() {
    if (App.session.mode === 'server') return (await App.api.request('GET', 'boards.php?mytasks=1')).tasks;
    const out = [];
    const { boards } = await App.boards.list();

    const ids = new Set(boards.map((b) => b.id));
    try { JSON.parse(localStorage.getItem('boards.index') || '[]').forEach((b) => ids.add(b.id)); } catch {  }
    for (const id of ids) {
      let res;
      try { res = await App.boards.get(id); } catch { continue; }
      (res.data.cards || []).filter((c) => c.type === 'todo').forEach((card) => (card.items || []).forEach((item) => {
        out.push({
          board: id, board_title: res.data.title || 'Untitled board', card: card.id, list: card.title || '',
          item: item.id, text: item.text || '', description: item.description || '', due: item.due || null,
          priority: item.priority || null, status: App.taskStatus.of(item), done_at: item.done_at || null, can_edit: true,
        });
      }));
    }
    return out;
  }

  async function setTaskStage(t, to) {
    if (App.session.mode === 'server') return App.boards.toggleTask(t.board, t.card, t.item, to === 'done', to);
    const { data } = await App.boards.get(t.board);
    const item = data.cards.find((c) => c.id === t.card)?.items?.find((i) => i.id === t.item);
    if (!item) throw new Error('Task not found');
    App.taskStatus.set(item, to);
    if (to === 'done') item.done_at = Math.floor(Date.now() / 1000);
    await App.boards.save(t.board, data);
  }

  async function showMyTasks(section) {
    let tasks = [];
    try { tasks = await loadMyTasks(); } catch { section.hidden = true; return; }
    section.hidden = false;
    const draw = () => {
      const active = tasks.filter((t) => t.status !== 'done');
      const done = tasks.filter((t) => t.status === 'done');
      let list = taskView.tab === 'active' ? active : done;
      if (taskView.priority !== 'all') list = list.filter((t) => (t.priority || 'none') === taskView.priority || (taskView.priority === 'high' && t.priority === 'urgent'));
      const byDue = (a, b) => (a.due || '9999').localeCompare(b.due || '9999');
      const byPriority = (a, b) => (PRIORITY_RANK[a.priority] ?? 9) - (PRIORITY_RANK[b.priority] ?? 9);
      const sorters = {
        due: (a, b) => byDue(a, b) || byPriority(a, b),
        priority: (a, b) => byPriority(a, b) || byDue(a, b),
        board: (a, b) => a.board_title.localeCompare(b.board_title) || byDue(a, b),
        done: (a, b) => (b.done_at || 0) - (a.done_at || 0),
      };
      list = list.slice().sort(sorters[taskView.tab === 'done' && taskView.sort === 'due' ? 'done' : taskView.sort]);
      section.innerHTML = `
        <div class="mt-head">
          <h2>My tasks</h2>
          <div class="dash-tabs" role="tablist" aria-label="Which tasks">
            <button role="tab" data-mt-tab="active" aria-selected="${taskView.tab === 'active'}">Active <span>${active.length}</span></button>
            <button role="tab" data-mt-tab="done" aria-selected="${taskView.tab === 'done'}">Completed <span>${done.length}</span></button>
          </div>
          <span class="mt-spacer"></span>
          <label class="mt-control">Sort by
            <select data-mt="sort">
              <option value="due">${taskView.tab === 'done' ? 'Finished (newest)' : 'Deadline'}</option>
              <option value="priority">Priority</option>
              <option value="board">Board</option>
            </select></label>
          <label class="mt-control">Priority
            <select data-mt="priority">
              <option value="all">All</option><option value="high">High</option><option value="medium">Medium</option>
              <option value="low">Low</option><option value="none">No priority</option>
            </select></label>
        </div>
        ${list.length ? '<ul class="task-list"></ul>' : `<p class="mt-empty">${tasks.length
          ? (taskView.tab === 'active' ? 'Nothing to do here. 🎉' : 'No completed tasks here yet.')
          : 'No tasks yet. Add a To-do list to a board and its tasks show up here.'}</p>`}`;
      section.querySelector('[data-mt="sort"]').value = taskView.sort;
      section.querySelector('[data-mt="priority"]').value = taskView.priority;
      const ul = section.querySelector('ul');
      list.forEach((t) => {
        const li = document.createElement('li');
        li.className = `task-row${t.status === 'done' ? ' is-done' : ''}${t.status === 'doing' ? ' is-doing' : ''}`;
        li.innerHTML = `
          <a class="task-link" href="#/board/${esc(t.board)}">
            <span class="task-text"></span>
            <span class="task-desc" hidden></span>
            <span class="task-where"></span>
          </a>`;
        li.querySelector('.task-text').textContent = t.text || 'Untitled task';
        if (t.description) {
          const d = li.querySelector('.task-desc');
          d.textContent = t.description;
          d.hidden = false;
        }
        li.querySelector('.task-where').textContent = `${t.list || 'To-do list'} · ${t.board_title}`;
        if (t.status === 'doing') li.querySelector('.task-where').prepend(App.taskStatus.chip('doing'));
        if (t.priority && t.priority !== 'none') {
          const p = document.createElement('span');
          p.className = 'mt-priority';
          p.dataset.level = t.priority;
          p.textContent = PRIORITY_NAME[t.priority];
          li.querySelector('.task-link').after(p);
        }
        if (t.due) {
          const chip = document.createElement('span');
          chip.className = 'due-chip';
          chip.dataset.status = t.status === 'done' ? 'later' : App.dueDate.status(t.due);
          chip.textContent = App.dueDate.label(t.due);
          li.append(chip);
        }
        const btn = App.taskStatus.button(t.status, {
          onChange: async (to) => {
            await setTaskStage(t, to);
            t.status = to;
            if (to === 'done') t.done_at = Math.floor(Date.now() / 1000);
            setTimeout(draw, 500);
            return true;
          },
        });
        btn.disabled = !t.can_edit;
        li.prepend(btn);
        ul.append(li);
      });
    };
    section.addEventListener('click', (e) => {
      const tab = e.target.closest('[data-mt-tab]')?.dataset.mtTab;
      if (tab) { taskView.tab = tab; draw(); }
    });
    section.addEventListener('change', (e) => {
      const k = e.target.dataset.mt;
      if (k) { taskView[k] = e.target.value; draw(); }
    });
    draw();
  }

  return { auth, home, accountButton, closeMenu, BRAND };
})();
