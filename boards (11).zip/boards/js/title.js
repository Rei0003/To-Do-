window.App = window.App || {};

App.title = {
  init() {
    const input = document.getElementById('board-title');
    const sync = () => { document.title = `${input.value || 'Untitled'} – Boards`; };
    this.refresh = () => { input.value = App.state.get().title || ''; sync(); };

    this.refresh();

    input.addEventListener('input', () => {
      App.state.setTitle(input.value);
      sync();
    });
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') input.blur();
    });
  },
};
