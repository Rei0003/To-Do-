window.App = window.App || {};

App.drag = (() => {
  let active = null;

  function begin(cardEl, e) {
    active = {
      el: cardEl,
      id: cardEl.dataset.id,
      type: cardEl.dataset.type,
      startX: e.clientX,
      startY: e.clientY,
      originX: cardEl.offsetLeft,
      originY: cardEl.offsetTop,
      target: null,
    };

    if (App.selection?.has(active.id) && App.selection.size() > 1) {
      active.group = App.selection.ids()
        .map((id) => document.querySelector(`#canvas > .card[data-id="${id}"]`))
        .filter((el) => el && el !== cardEl)
        .map((el) => ({ el, x: el.offsetLeft, y: el.offsetTop }));
      active.group.forEach((g) => g.el.classList.add('is-dragging-along'));
    }
    cardEl.style.zIndex = App.state.bringToFront(active.id);
    cardEl.classList.add('is-dragging');
    try { cardEl.setPointerCapture(e.pointerId); } catch {  }
  }

  function attach(canvas) {
    canvas.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      const cardEl = e.target.closest('.card');
      if (!cardEl || cardEl.classList.contains('is-locked')) return;

      cardEl.style.zIndex = App.state.bringToFront(cardEl.dataset.id);

      const handle = e.target.closest('[data-drag-handle]');
      if (!handle || e.target.closest('button')) return;

      begin(cardEl, e);
      e.preventDefault();
    });

    canvas.addEventListener('pointermove', (e) => {
      if (!active) return;
      const x = Math.max(0, active.originX + e.clientX - active.startX);
      const y = Math.max(0, active.originY + e.clientY - active.startY);
      active.el.style.left = `${x}px`;
      active.el.style.top = `${y}px`;
      App.wires.schedule();

      if (active.group) {

        const dx = x - active.originX;
        const dy = y - active.originY;
        active.group.forEach((g) => {
          g.el.style.left = `${Math.max(0, g.x + dx)}px`;
          g.el.style.top = `${Math.max(0, g.y + dy)}px`;
        });
        return;
      }

      active.target = App.nesting.findTarget(e, active.type, active.el);
      App.nesting.highlight(active.target);
      active.el.classList.toggle('is-over-nest', !!active.target);
    });

    const end = () => {
      if (!active) return;
      const { el, id, target, group } = active;
      active = null;
      el.classList.remove('is-dragging', 'is-over-nest');
      App.nesting.highlight(null);

      if (group) {
        group.forEach((g) => {
          g.el.classList.remove('is-dragging-along');
          App.state.updateCard(g.el.dataset.id, { x: g.el.offsetLeft, y: g.el.offsetTop });
        });
      }

      if (target) App.state.nestCard(id, target.card.dataset.id, target.item);
      else App.state.updateCard(id, { x: el.offsetLeft, y: el.offsetTop });
    };
    canvas.addEventListener('pointerup', end);
    canvas.addEventListener('pointercancel', end);
  }

  return { attach, begin };
})();
