window.App = window.App || {};

App.storage = (() => {
  const DELAY = 800;
  let target = null;
  let pending = null;
  let timer = 0;
  let saving = false;
  let paused = false;
  const listeners = new Set();
  let status = 'saved';

  function setStatus(s, detail) {
    status = s;
    listeners.forEach((fn) => fn(s, detail));
  }

  async function flush({ keepalive = false, force = false } = {}) {
    clearTimeout(timer);
    if (!target || !pending || saving) return;
    const data = pending;
    pending = null;
    saving = true;
    setStatus('saving');
    try {
      const res = await App.boards.save(target.id, data, target.rev, { force, keepalive });
      if (res && typeof res.rev === 'number') target.rev = res.rev;
      setStatus(pending ? 'saving' : 'saved');
    } catch (err) {
      if (err.data?.conflict) {
        pending = data;
        setStatus('conflict', err.data.board);
      } else if (err.name === 'QuotaExceededError' || /quota/i.test(err.message)) {
        setStatus('error', 'This browser’s storage is full. Remove some boards, or log in to save boards on the server.');
      } else {
        pending = pending || data;
        setStatus('error', err.offline ? 'Offline — your changes will be saved when you’re back online.' : err.message);
        timer = setTimeout(flush, 5000);
      }
    } finally {
      saving = false;
      if (pending && status !== 'conflict') timer = setTimeout(flush, DELAY);
    }
  }

  window.addEventListener('pagehide', () => { if (pending) flush({ keepalive: true }); });
  document.addEventListener('visibilitychange', () => { if (document.hidden && pending) flush({ keepalive: true }); });
  window.addEventListener('beforeunload', (e) => {
    if (pending || saving) { flush({ keepalive: true }); e.preventDefault(); }
  });

  return {

    save(data) {
      if (!target || paused || App.access?.readOnly()) return;
      pending = data;
      if (App.session.mode === 'local') { flush(); return; }
      setStatus('unsaved');
      clearTimeout(timer);
      timer = setTimeout(flush, DELAY);
    },
    load: () => null,

    setTarget(id, rev) {
      target = id ? { id, rev } : null;
      pending = null;
      setStatus('saved');
    },

    pause(on) { paused = on; },
    flush,
    keepMine: () => flush({ force: true }),
    hasUnsaved: () => !!pending || saving,
    onStatus: (fn) => listeners.add(fn),
    get status() { return status; },
    get rev() { return target?.rev; },
    get boardId() { return target?.id; },
  };
})();
