window.App = window.App || {};

App.duplicate = (() => {
  const OFFSET = 32;

  const clone = (obj) => JSON.parse(JSON.stringify(obj));

  async function copyStoredFile(card) {

    await App.cardTypes[card.type]?.onDuplicate?.(card);
    if (!card.mediaId) return;
    try { card.mediaId = await App.mediaStore.copy(card.mediaId); } catch { card.mediaId = null; }
  }

  async function copyChildren(fromId, toId) {
    for (const child of App.state.allChildrenOf(fromId)) {
      const c = clone(child);
      delete c.id;
      delete c.z;
      c.parent = toId;
      await copyStoredFile(c);
      const added = App.state.addCard(c);
      if (added) await copyChildren(child.id, added.id);
    }
  }

  async function cards(ids) {
    const newIds = [];
    for (const id of ids) {
      const src = App.state.getCard(id);
      if (!src || src.parent) continue;

      const copy = clone(src);
      delete copy.id;
      delete copy.z;
      copy.x = (src.x || 0) + OFFSET;
      copy.y = (src.y || 0) + OFFSET;
      await copyStoredFile(copy);
      const added = App.state.addCard(copy);
      if (!added) continue;
      await copyChildren(id, added.id);
      newIds.push(added.id);
    }
    return newIds;
  }

  return { cards };
})();
