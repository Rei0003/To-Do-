window.App = window.App || {};

App.nesting = (() => {
  const ICONS = {
    out: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3h4v4M13 3L7.5 8.5M11 9.5V13H3V5h3.5"/></svg>',
    remove: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>',
    grip: '<svg viewBox="0 0 12 12" fill="currentColor"><circle cx="4" cy="3" r="1"/><circle cx="8" cy="3" r="1"/><circle cx="4" cy="6" r="1"/><circle cx="8" cy="6" r="1"/><circle cx="4" cy="9" r="1"/><circle cx="8" cy="9" r="1"/></svg>',
  };

  const containerOf = (el) => el?.closest?.('.attachment[data-id], .card');
  const typeOf = (container) => {
    const data = container && App.state.getCard(container.dataset.id);
    return data ? { data, def: App.cardTypes[data.type] } : null;
  };

  const accepts = (container, type) => !!typeOf(container)?.def?.accepts?.includes(type);

  function targetFrom(el, type, exclude) {
    let container = containerOf(el);
    while (container) {
      if (container !== exclude && !exclude?.contains(container) && accepts(container, type)) {
        const { data, def } = typeOf(container);
        let row = el.closest('[data-attach-item]');
        if (row && containerOf(row) !== container) row = null;
        let item = row?.dataset.attachItem || null;
        if (!item && def.defaultItem) item = def.defaultItem(data);
        const label = row?.dataset.attachLabel || (item && def.itemLabel ? def.itemLabel(item, data) : null);
        return { card: container, row, item, label };
      }
      container = containerOf(container.parentElement);
    }
    return null;
  }

  function findTarget(e, type, exclude) {
    const under = document.elementFromPoint(e.clientX, e.clientY);
    return under ? targetFrom(under, type, exclude) : null;
  }

  const dropTargetOf = (eventTarget, type) => targetFrom(eventTarget, type, null);

  function highlight(target) {
    document.querySelectorAll('.is-nest-target, .is-nest-target-row').forEach((el) =>
      el.classList.remove('is-nest-target', 'is-nest-target-row'));
    if (!target) return;
    target.card.classList.add('is-nest-target');
    target.card.dataset.nestLabel = target.label ? `Attach to ${target.label}` : 'Drop to attach';
    target.row?.classList.add('is-nest-target-row');
  }

  function besideParent(parentId) {
    const top = App.state.topOf(parentId);
    const parentEl = top && document.querySelector(`#canvas > .card[data-id="${top.id}"]`);
    if (!parentEl) return { x: 80, y: 80 };
    return { x: parentEl.offsetLeft + parentEl.offsetWidth + 48, y: parentEl.offsetTop };
  }

  function removeChild(child) {
    App.cardTypes[child.type]?.onRemove?.(child);
    App.state.removeCard(child.id);
  }

  function renderAttachments(card, container, itemId = null) {
    const children = App.state.childrenOf(card.id, itemId);
    container.hidden = children.length === 0;

    children.forEach((child) => {
      const wrap = document.createElement('div');
      wrap.className = `attachment attachment--${child.type}`;
      wrap.dataset.id = child.id;
      wrap.innerHTML = `
        <div class="attachment-bar">
          <span class="attachment-grip" data-attach-handle data-tooltip="Drag out onto the board">${ICONS.grip}</span>
          <span class="attachment-actions">
            <button class="card-btn" data-attach-action="out" aria-label="Move to board" data-tooltip="Move to board">${ICONS.out}</button>
            <button class="card-btn" data-attach-action="remove" aria-label="Delete attachment" data-tooltip="Delete">${ICONS.remove}</button>
          </span>
        </div>
        <div class="attachment-body"></div>`;

      App.cardTypes[child.type]?.render(child, wrap.querySelector('.attachment-body'));

      wrap.querySelector('[data-attach-action="out"]').addEventListener('click', () => {
        const { x, y } = besideParent(card.id);
        App.state.unnestCard(child.id, x, y);
      });
      wrap.querySelector('[data-attach-action="remove"]').addEventListener('click', () => {
        App.tooltip?.hide();
        removeChild(child);
      });

      const grip = wrap.querySelector('[data-attach-handle]');
      grip.addEventListener('pointerdown', (e) => {
        if (e.button !== 0) return;
        e.preventDefault();
        e.stopPropagation();
        const start = { x: e.clientX, y: e.clientY };

        const onMove = (ev) => {
          if (Math.hypot(ev.clientX - start.x, ev.clientY - start.y) < 6) return;
          cleanup();
          const p = App.board.toCanvasPoint(ev.clientX, ev.clientY);
          App.state.unnestCard(child.id, Math.max(0, p.x - 40), Math.max(0, p.y - 12));
          const el = document.querySelector(`.card[data-id="${child.id}"]`);
          if (el) App.drag.begin(el, ev);
        };
        const cleanup = () => {
          window.removeEventListener('pointermove', onMove);
          window.removeEventListener('pointerup', cleanup);
        };
        window.addEventListener('pointermove', onMove);
        window.addEventListener('pointerup', cleanup);
      });

      container.append(wrap);
    });
  }

  function removeChildrenOf(cardId) {
    App.state.descendantsOf(cardId).forEach((child) => App.cardTypes[child.type]?.onRemove?.(child));
  }

  return { accepts, findTarget, dropTargetOf, highlight, renderAttachments, removeChildrenOf };
})();
