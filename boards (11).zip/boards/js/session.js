window.App = window.App || {};

App.session = (() => {
  const MODE_KEY = 'boards.mode';
  let user = null;
  let server = false;
  let mode = 'local';
  let allowGuest = true;
  const listeners = new Set();

  function setMode(next) {
    mode = next;
    App.mediaStore.useServer(mode === 'server');
    listeners.forEach((fn) => fn({ mode, user }));
  }

  async function start() {
    server = await App.api.available();
    if (server) {
      try {
        const me = await App.api.request('GET', 'auth.php?action=me');
        user = me.user;
        if (typeof me.allow_guest === 'boolean') allowGuest = me.allow_guest;
      } catch { user = null; }
    }
    setMode(user ? 'server' : 'local');
    return { server, user, choseLocal: localStorage.getItem(MODE_KEY) === 'local' };
  }

  async function register(name, email, password) {
    user = (await App.api.request('POST', 'auth.php?action=register', { name, email, password })).user;
    localStorage.removeItem(MODE_KEY);
    setMode('server');
    return user;
  }

  async function login(email, password) {
    user = (await App.api.request('POST', 'auth.php?action=login', { email, password })).user;
    localStorage.removeItem(MODE_KEY);
    setMode('server');
    return user;
  }

  async function logout() {
    try { await App.api.request('POST', 'auth.php?action=logout'); } catch {  }
    user = null;
    setMode('local');
  }

  function updateUser(next) {
    user = next;
    listeners.forEach((fn) => fn({ mode, user }));
  }

  function useLocal() {
    localStorage.setItem(MODE_KEY, 'local');
    setMode('local');
  }

  return {
    start,
    register,
    get allowGuest() { return !server || allowGuest; },
    login,
    logout,
    useLocal,
    updateUser,
    onChange: (fn) => listeners.add(fn),
    get user() { return user; },
    get mode() { return mode; },
    get server() { return server; },
  };
})();
