window.App = window.App || {};

App.taskStatus = (() => {
  const ORDER = ['todo', 'doing', 'done'];
  const LABELS = { todo: 'To do', doing: 'In progress', done: 'Done' };
  const ICONS = {
    todo: '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="6.2" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>',
    doing: '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="6.2" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M8 3.6a4.4 4.4 0 0 1 0 8.8z" fill="currentColor"/></svg>',
    done: '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="7" fill="currentColor"/><path d="M4.8 8.2l2.2 2.2 4.2-4.6" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  };

  const of = (item) => (ORDER.includes(item?.status) ? item.status : item?.done ? 'done' : 'todo');
  const next = (s) => ORDER[(ORDER.indexOf(s) + 1) % ORDER.length];
  function set(item, status) {
    item.status = status;
    item.done = status === 'done';
  }

  function paint(btn, status) {
    btn.dataset.status = status;
    btn.innerHTML = ICONS[status];
    btn.setAttribute('aria-label', `Status: ${LABELS[status]}. Click for ${LABELS[next(status)]}`);
    btn.dataset.tooltip = `Stage: ${LABELS[status]}\nClick to mark “${LABELS[next(status)]}”`;
  }

  let menu = null;
  function closeMenu() {
    menu?.remove();
    menu = null;
    document.removeEventListener('pointerdown', outside, true);
  }
  function outside(e) { if (menu && !menu.contains(e.target)) closeMenu(); }
  function openMenu(anchor, current, onPick) {
    closeMenu();
    App.tooltip?.hide();
    menu = document.createElement('div');
    menu.className = 'draw-menu draw-panel status-menu';
    menu.setAttribute('role', 'menu');
    menu.innerHTML = ORDER.map((s) => `<button role="menuitemradio" aria-checked="${s === current}" data-s="${s}">
      <span class="task-status" data-status="${s}">${ICONS[s]}</span><span>${LABELS[s]}</span>${s === current ? '<span class="draw-menu-check">✓</span>' : ''}</button>`).join('');
    menu.addEventListener('click', (e) => {
      const s = e.target.closest('[data-s]')?.dataset.s;
      if (s) { closeMenu(); onPick(s); }
    });
    document.body.append(menu);
    const r = anchor.getBoundingClientRect();
    menu.style.top = `${Math.min(r.bottom + 4, window.innerHeight - menu.offsetHeight - 8)}px`;
    menu.style.left = `${Math.min(r.left, window.innerWidth - menu.offsetWidth - 8)}px`;
    document.addEventListener('pointerdown', outside, true);
  }

  function button(status, { onChange, mine = false } = {}) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'task-status';
    btn.dataset.contextMenu = '';
    if (mine) btn.dataset.mine = '';
    paint(btn, status);
    const change = async (to) => {
      const from = btn.dataset.status;
      if (to === from) return;
      paint(btn, to);
      try {
        if ((await onChange?.(to, from)) === false) paint(btn, from);
      } catch { paint(btn, from); }
    };
    btn.addEventListener('click', (e) => {
      if (e.shiftKey) { openMenu(btn, btn.dataset.status, change); return; }
      change(next(btn.dataset.status));
    });
    btn.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!btn.disabled) openMenu(btn, btn.dataset.status, change);
    });
    btn.setStatus = (s) => paint(btn, s);
    btn.choose = change;
    return btn;
  }

  function chip(status) {
    const el = document.createElement('span');
    el.className = 'status-chip';
    el.textContent = LABELS.doing;
    el.hidden = status !== 'doing';
    return el;
  }

  return { ORDER, LABELS, ICONS, of, next, set, button, chip, paint, openMenu };
})();
