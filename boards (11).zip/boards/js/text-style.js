window.App = window.App || {};

App.textStyle = (() => {
  const props = {};
  let pending = {};

  function register(def) {
    props[def.key] = def;
  }

  function parse(el) {
    const style = el.getAttribute('style') || '';
    const out = {};
    Object.values(props).forEach((def) => {
      const m = style.match(new RegExp(`(?:^|;)\\s*${def.cssProp}:\\s*var\\(${def.varPrefix}([a-z]+)\\)`));
      let value = m && def.values.includes(m[1]) ? m[1] : null;
      if (!value && def.isMarker(el, style)) value = pending[def.key] ?? null;
      else if (!value && def.readCustom) value = def.readCustom(el, style);
      if (value && value !== def.values[0]) out[def.key] = value;
    });
    return out;
  }

  function makeSpan(values) {
    const parts = Object.entries(values)
      .filter(([key]) => props[key])
      .map(([key, v]) => (String(v).startsWith('#')
        ? `${props[key].cssProp}: ${v}`
        : `${props[key].cssProp}: var(${props[key].varPrefix}${v})`));
    if (!parts.length) return null;
    const span = document.createElement('span');
    span.setAttribute('style', parts.join('; '));
    return span;
  }

  function normalize(root) {
    root.querySelectorAll('span, font').forEach((el) => {
      const clean = makeSpan(parse(el));
      if (!clean) return el.replaceWith(...el.childNodes);
      if (el.tagName === 'SPAN') return el.setAttribute('style', clean.getAttribute('style'));
      clean.append(...el.childNodes);
      el.replaceWith(clean);
    });
  }

  function saveSelection(root) {
    const range = window.getSelection().getRangeAt(0);
    const before = document.createRange();
    before.selectNodeContents(root);
    before.setEnd(range.startContainer, range.startOffset);
    const start = before.toString().length;
    return { start, end: start + range.toString().length };
  }

  function restoreSelection(root, { start, end }) {
    const range = document.createRange();
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let pos = 0;
    let node;
    let startSet = false;
    while ((node = walker.nextNode())) {
      const next = pos + node.length;
      if (!startSet && start <= next) { range.setStart(node, start - pos); startSet = true; }
      if (startSet && end <= next) { range.setEnd(node, end - pos); break; }
      pos = next;
    }
    if (!startSet) return;
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  }

  function apply(editor, key, value) {
    const def = props[key];
    pending = { [key]: value };
    document.execCommand('styleWithCSS', false, true);
    document.execCommand(def.command, false, def.marker);
    document.execCommand('styleWithCSS', false, false);
    const saved = saveSelection(editor);
    normalize(editor);
    restoreSelection(editor, saved);
    pending = {};
    editor.dispatchEvent(new Event('input', { bubbles: true }));
  }

  function current(editor, key) {
    const node = window.getSelection().anchorNode;
    let el = node?.nodeType === 1 ? node : node?.parentElement;
    while (el && el !== editor) {
      if (el.tagName === 'SPAN') {
        const value = parse(el)[key];
        if (value) return value;
      }
      el = el.parentElement;
    }
    return props[key].values[0];
  }

  return { register, parse, makeSpan, normalize, apply, current };
})();
