window.App = window.App || {};

App.state = (() => {
  const listeners = new Set();
  const cardListeners = new Set();
  const uid = () => Math.random().toString(36).slice(2, 10);

  function starterBoard() {
    return {
      title: 'My first board',
      cards: [
        {
          id: uid(), type: 'note', x: 96, y: 72, z: 1, color: 'yellow',
          text: 'Drag cards by their top edge.\nDouble-click empty space to add a note.',
        },
        {
          id: uid(), type: 'todo', x: 392, y: 72, z: 2, color: 'none',
          title: 'This week',
          items: [
            { id: uid(), text: 'Sketch the board layout', done: true },
            { id: uid(), text: 'Add a column card type', done: false, priority: 'high' },
          ],
        },
      ],
    };
  }

  function normalize(d) {
    const out = d && Array.isArray(d.cards) ? d : { title: 'Untitled board', cards: [] };
    out.connections = out.connections || [];

    out.connections.forEach((w) => {
      if (!w.v) { w.from.side = 'auto'; w.v = 2; }
    });
    return out;
  }

  let data = normalize({ title: '', cards: [], connections: [] });

  const save = () => App.storage.save(data);

  const may = {
    all: () => !App.access || App.access.canEditAll(),
    card: (id) => !App.access || App.access.canEditCard(id),
    add: (parent) => !App.access || App.access.canAdd(parent || null),
    remove: (id) => !App.access || App.access.canDelete(id),
  };
  const notify = () => listeners.forEach((fn) => fn(data));
  const getCard = (id) => data.cards.find((c) => c.id === id);
  const topZ = () => data.cards.reduce((max, c) => Math.max(max, c.z || 0), 0);

  return {
    uid,
    starterBoard,

    load(next) {
      data = normalize(next);
      notify();
    },
    get: () => data,
    getCard,

    subscribe(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },

    setTitle(title) {
      if (!may.all()) return;
      data.title = title;
      save();
    },

    addCard(card) {
      if (!may.add(card.parent)) return null;
      const full = { id: uid(), z: topZ() + 1, color: 'none', ...card };
      data.cards.push(full);
      save();
      notify();
      return full;
    },

    updateCard(id, patch) {
      if (!may.card(id)) return;
      const card = getCard(id);
      if (!card) return;
      Object.assign(card, patch);
      save();
      cardListeners.forEach((fn) => fn(id));
    },

    onCardChange(fn) {
      cardListeners.add(fn);
      return () => cardListeners.delete(fn);
    },

    removeCard(id) {
      if (!may.remove(id)) return;
      const gone = new Set([id]);
      let grew = true;
      while (grew) {
        grew = false;
        data.cards.forEach((c) => {
          if (c.parent && gone.has(c.parent) && !gone.has(c.id)) { gone.add(c.id); grew = true; }
        });
      }
      data.cards = data.cards.filter((c) => !gone.has(c.id));
      data.connections = data.connections.filter((w) => !gone.has(w.from.card) && !gone.has(w.to.card));
      save();
      notify();
    },

    childrenOf: (parentId, itemId = null) =>
      data.cards.filter((c) => c.parent === parentId && (c.parentItem || null) === itemId),
    allChildrenOf: (parentId) => data.cards.filter((c) => c.parent === parentId),

    descendantsOf(parentId) {
      const out = [];
      const walk = (pid) => data.cards.forEach((c) => {
        if (c.parent === pid) { out.push(c); walk(c.id); }
      });
      walk(parentId);
      return out;
    },

    topOf(id) {
      let c = getCard(id);
      while (c?.parent) c = getCard(c.parent);
      return c;
    },

    nestCard(id, parentId, itemId = null) {
      if (!may.all()) return;
      const card = getCard(id);
      if (!card || id === parentId || !getCard(parentId)) return;

      for (let p = getCard(parentId); p; p = p.parent ? getCard(p.parent) : null) {
        if (p.id === id) return;
      }
      card.parent = parentId;
      if (itemId) card.parentItem = itemId;
      else delete card.parentItem;

      data.connections = data.connections.filter((w) =>
        !((w.from.card === id && w.to.card === parentId) || (w.from.card === parentId && w.to.card === id)));
      save();
      notify();
    },

    unnestCard(id, x, y) {
      if (!may.all()) return;
      const card = getCard(id);
      if (!card) return;
      delete card.parent;
      delete card.parentItem;
      Object.assign(card, { x: Math.round(x), y: Math.round(y), z: topZ() + 1 });
      save();
      notify();
    },

    addConnection(from, to) {
      if (!may.all()) return null;
      const key = (end) => `${end.card}/${end.item || ''}`;
      const [a, b] = [key(from), key(to)];
      if (a === b) return null;
      const exists = data.connections.some((w) => {
        const [x, y] = [key(w.from), key(w.to)];
        return (x === a && y === b) || (x === b && y === a);
      });
      if (exists) return null;
      const conn = { id: uid(), from, to, color: 'none', v: 2 };
      data.connections.push(conn);
      save();
      notify();
      return conn;
    },

    updateConnection(id, patch) {
      if (!may.all()) return;
      const conn = data.connections.find((w) => w.id === id);
      if (!conn) return;
      Object.assign(conn, patch);
      save();
      notify();
    },

    releaseTaskChildren(cardId, itemId) {
      if (!may.all()) return;
      const kids = data.cards.filter((c) => c.parent === cardId && c.parentItem === itemId);
      if (!kids.length) return;
      kids.forEach((c) => delete c.parentItem);
      save();
      notify();
    },

    removeTaskConnections(cardId, itemId) {
      if (!may.all()) return;
      const hit = (end) => end.card === cardId && end.item === itemId;
      const before = data.connections.length;
      data.connections = data.connections.filter((w) => !hit(w.from) && !hit(w.to));
      if (data.connections.length === before) return;
      save();
      notify();
    },

    removeConnection(id) {
      if (!may.all()) return;
      data.connections = data.connections.filter((w) => w.id !== id);
      save();
      notify();
    },

    bringToFront(id) {
      const card = getCard(id);
      if (!card) return 0;
      const top = topZ();
      if (card.z !== top) card.z = top + 1;
      save();
      return card.z;
    },

    clear() {
      if (!may.all()) return;
      data.cards = [];
      data.connections = [];
      save();
      notify();
    },
  };
})();
