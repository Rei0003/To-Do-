window.App = window.App || {};

App.taskDetails = (() => {
  const MAX_TITLE = 300;
  const MAX_DESC = 2000;
  let modal = null;
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  function close() {
    modal?.remove();
    modal = null;
    document.removeEventListener('keydown', onKey, true);
  }
  function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } }

  function open(item, { onSave, listName } = {}) {
    close();
    App.tooltip?.hide();
    const [dueDate, dueTime] = (item.due || '').split('T');
    const people = App.people.available ? App.people.all() : [];
    modal = document.createElement('div');
    modal.className = 'fv td-modal';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-label', 'Task details');
    modal.innerHTML = `
      <form class="td-window" novalidate>
        <header class="members-head">
          <h2>Task details</h2>
          <button type="button" class="fv-close" data-td="close" aria-label="Close">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg></button>
        </header>
        ${listName ? `<p class="td-where">In <strong>${esc(listName)}</strong></p>` : ''}
        <label class="td-field"><span>Title <em>(required)</em></span>
          <input name="title" maxlength="${MAX_TITLE}" autocomplete="off" aria-describedby="td-title-err">
          <small class="td-error" id="td-title-err" hidden></small></label>
        <label class="td-field"><span>Description</span>
          <textarea name="description" rows="4" maxlength="${MAX_DESC}" placeholder="Details, links, notes…" aria-describedby="td-desc-count"></textarea>
          <small class="td-count" id="td-desc-count"></small></label>
        <div class="td-row">
          <label class="td-field"><span>Due date</span><input name="date" type="date" aria-describedby="td-due-err"></label>
          <label class="td-field"><span>Time <em>(optional)</em></span><input name="time" type="time"></label>
        </div>
        <small class="td-error" id="td-due-err" hidden></small>
        <div class="td-row">
          <label class="td-field"><span>Priority</span>
            <select name="priority">
              <option value="none">No priority</option>
              ${App.priority.LEVELS.filter((l) => l.id !== 'none').map((l) => `<option value="${l.id}">${l.label}</option>`).join('')}
            </select></label>
          <label class="td-field"><span>Stage</span>
            <select name="status">${App.taskStatus.ORDER.map((s) => `<option value="${s}">${App.taskStatus.LABELS[s]}</option>`).join('')}</select></label>
        </div>
        ${people.length ? `<label class="td-field"><span>Assigned to</span>
          <select name="assignee"><option value="">Nobody</option>
            ${people.map((p) => `<option value="${esc(p.email)}">${esc(App.people.isMe(p.email) ? `${p.name || p.email} (you)` : (p.name || p.email))}${p.memberRole ? ` · ${esc(p.memberRole.name)}` : ''}</option>`).join('')}
          </select></label>` : ''}
        <div class="td-actions">
          <button type="button" class="file-btn" data-td="close">Cancel</button>
          <button type="submit" class="confirm-pop-btn btn-primary">Save</button>
        </div>
      </form>`;
    const form = modal.querySelector('form');
    form.title.value = item.text || '';
    form.description.value = item.description || '';
    form.date.value = dueDate || '';
    form.time.value = dueTime || '';
    form.priority.value = item.priority || 'none';
    form.status.value = App.taskStatus.of(item);
    if (form.assignee) form.assignee.value = (item.assignee || '').toLowerCase();

    const count = modal.querySelector('.td-count');
    const showCount = () => { count.textContent = `${form.description.value.length} / ${MAX_DESC}`; };
    form.description.addEventListener('input', showCount);
    showCount();

    const showError = (id, msg, field) => {
      const el = modal.querySelector(`#${id}`);
      el.textContent = msg;
      el.hidden = !msg;
      field?.setAttribute('aria-invalid', msg ? 'true' : 'false');
      field?.classList.toggle('is-invalid', !!msg);
    };

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const title = form.title.value.trim();
      let ok = true;

      if (!title) { showError('td-title-err', 'Please give the task a title.', form.title); ok = false; }
      else if (title.length > MAX_TITLE) { showError('td-title-err', `The title can be ${MAX_TITLE} characters at most.`, form.title); ok = false; }
      else showError('td-title-err', '', form.title);
      if (form.time.value && !form.date.value) { showError('td-due-err', 'Pick a date for this time (or clear the time).', form.date); ok = false; }
      else if (form.date.value && !/^\d{4}-\d{2}-\d{2}$/.test(form.date.value)) { showError('td-due-err', 'That date isn’t valid.', form.date); ok = false; }
      else showError('td-due-err', '', form.date);
      if (!ok) { modal.querySelector('.is-invalid')?.focus(); return; }
      onSave?.({
        text: title,
        description: form.description.value.trim().slice(0, MAX_DESC),
        due: form.date.value ? (form.time.value ? `${form.date.value}T${form.time.value}` : form.date.value) : null,
        priority: form.priority.value === 'none' ? null : form.priority.value,
        status: form.status.value,
        assignee: form.assignee ? (form.assignee.value || null) : undefined,
      });
      close();
    });

    form.title.addEventListener('input', () => { if (form.title.value.trim()) showError('td-title-err', '', form.title); });
    const dueFixed = () => { if (form.date.value || !form.time.value) showError('td-due-err', '', form.date); };
    form.date.addEventListener('input', dueFixed);
    form.time.addEventListener('input', dueFixed);
    modal.addEventListener('click', (e) => {
      if (e.target === modal || e.target.closest('[data-td="close"]')) close();
    });
    document.addEventListener('keydown', onKey, true);
    document.body.append(modal);
    form.title.focus();
    form.title.select();
  }

  return { open, close };
})();
