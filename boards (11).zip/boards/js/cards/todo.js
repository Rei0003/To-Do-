window.App = window.App || {};

App.cardTypes.todo = {
  label: 'To-do list',
  accepts: ['media', 'note', 'todo', 'drawing', 'calendar', 'table', 'chart', 'file', 'board', 'shape', 'link'],
  resizable: true,
  minWidth: 220,
  maxWidth: 900,
  defaults: () => ({ title: '', titleHtml: '', items: [] }),

  render(card, body) {
    const save = () => App.state.updateCard(card.id, { items: card.items });

    const addInput = document.createElement('input');
    addInput.className = 'todo-add';
    addInput.placeholder = 'Add a task, press Enter';

    const title = App.richText.create({
      className: 'todo-title',
      placeholder: 'List title',
      multiline: false,
      html: card.titleHtml ?? App.richText.fromText(card.title),
      onChange: (titleHtml, text) => App.state.updateCard(card.id, { titleHtml, title: text }),
      onEnter: () => addInput.focus(),
    });

    const progress = document.createElement('div');
    progress.className = 'todo-progress';
    progress.innerHTML = '<span class="is-done-part"></span><span class="is-doing-part"></span>';

    const list = document.createElement('ul');
    list.className = 'todo-list';

    function refreshProgress() {
      const total = card.items.length;
      const done = card.items.filter((i) => App.taskStatus.of(i) === 'done').length;
      const doing = card.items.filter((i) => App.taskStatus.of(i) === 'doing').length;
      progress.hidden = total === 0;
      progress.children[0].style.width = total ? `${(done / total) * 100}%` : '0';
      progress.children[1].style.width = total ? `${(doing / total) * 100}%` : '0';
      progress.title = total ? `${done} done · ${doing} in progress · ${total - done - doing} to do` : '';
    }

    function itemRow(item) {
      const li = document.createElement('li');
      li.className = 'todo-item';
      li.dataset.itemId = item.id;
      li.dataset.attachItem = item.id;
      li.dataset.attachLabel = 'this task';

      const showStage = () => {
        const s = App.taskStatus.of(item);
        li.classList.toggle('is-done', s === 'done');
        li.classList.toggle('is-doing', s === 'doing');
        stageChip.hidden = s !== 'doing';
      };
      const stageChip = App.taskStatus.chip(App.taskStatus.of(item));
      const check = App.taskStatus.button(App.taskStatus.of(item), {
        onChange: async (to, from) => {
          App.taskStatus.set(item, to);
          showStage();
          refreshProgress();
          if (!App.access || App.access.canEditCard(card.id)) { save(); return true; }

          try {
            await App.boards.toggleTask(App.storage.boardId, card.id, item.id, to === 'done', to);
            return true;
          } catch {
            App.taskStatus.set(item, from);
            showStage();
            refreshProgress();
            return false;
          }
        },
      });

      const markMine = () => {
        if (App.people.isMe(item.assignee)) check.dataset.mine = '';
        else delete check.dataset.mine;
      };
      markMine();
      showStage();

      const text = App.richText.create({
        className: 'todo-text',
        placeholder: 'Task',
        multiline: false,
        html: item.html ?? App.richText.fromText(item.text),
        onChange: (html, plain) => { item.html = html; item.text = plain; save(); },
        onEnter: () => addInput.focus(),
      });

      const prioMark = document.createElement('span');
      prioMark.className = 'prio-mark';
      prioMark.innerHTML = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 14V2.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M4 3h7.5L9.8 6l1.7 3H4z" fill="currentColor"/></svg>';
      const showPriority = () => {
        prioMark.dataset.level = item.priority || 'none';
        prioMark.title = item.priority && item.priority !== 'none' ? `${item.priority[0].toUpperCase()}${item.priority.slice(1)} priority` : '';
      };
      showPriority();
      const flag = App.priority.createButton(item, () => { showPriority(); save(); });

      const due = App.dueDate.forTask(item, save);

      const PERSON = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><circle cx="8" cy="5.5" r="2.6"/><path d="M3 13.5c.8-2.4 2.7-3.6 5-3.6s4.2 1.2 5 3.6"/></svg>';
      const chip = document.createElement('button');
      chip.className = 'assignee-chip';
      const assignBtn = document.createElement('button');
      assignBtn.className = 'card-btn assign-btn';
      assignBtn.setAttribute('aria-label', 'Assign this task');
      assignBtn.dataset.tooltip = 'Assign to someone';
      assignBtn.innerHTML = PERSON;
      const showAssignee = () => {
        App.people.paintChip(chip, item.assignee || null);
        assignBtn.classList.toggle('has-assignee', !!item.assignee);
        assignBtn.hidden = !App.people.available;
        li.classList.toggle('is-mine', App.people.isMe(item.assignee));
        markMine();
      };
      const pickAssignee = (anchor) => App.people.openPicker(anchor, item.assignee, (email) => {
        if (email) item.assignee = email;
        else delete item.assignee;
        showAssignee();
        save();
      });
      assignBtn.addEventListener('click', () => pickAssignee(assignBtn));
      chip.addEventListener('click', () => { if (App.people.available) pickAssignee(chip); });
      showAssignee();

      const meta = document.createElement('div');
      meta.className = 'todo-meta';
      meta.append(stageChip, prioMark, chip, due.chip);
      const main = document.createElement('div');
      main.className = 'todo-main';

      const desc = document.createElement('p');
      desc.className = 'todo-desc';
      desc.textContent = item.description || '';
      desc.hidden = !item.description;
      main.append(text, desc, meta);

      const remove = document.createElement('button');
      remove.className = 'card-btn';
      remove.setAttribute('aria-label', 'Delete task');
      remove.dataset.tooltip = 'Delete task';
      remove.innerHTML = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>';
      remove.addEventListener('click', () => {
        card.items = card.items.filter((i) => i.id !== item.id);
        li.remove();
        save();
        refreshProgress();
        App.state.removeTaskConnections(card.id, item.id);
        App.state.releaseTaskChildren(card.id, item.id);
      });

      const taskAttachments = document.createElement('div');
      taskAttachments.className = 'attachments task-attachments';
      App.nesting.renderAttachments(card, taskAttachments, item.id);

      const detailsBtn = document.createElement('button');
      detailsBtn.className = 'card-btn details-btn';
      detailsBtn.setAttribute('aria-label', 'Edit task details');
      detailsBtn.dataset.tooltip = 'Details: title, description, due date…';
      detailsBtn.innerHTML = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M3 4h10M3 8h10M3 12h6"/></svg>';
      detailsBtn.addEventListener('click', () => {
        App.taskDetails.open(item, {
          listName: card.title,
          onSave: (c) => {
            item.text = c.text;
            item.html = App.richText.fromText(c.text);
            if (c.description) item.description = c.description; else delete item.description;
            if (c.due) item.due = c.due; else delete item.due;
            if (c.priority) item.priority = c.priority; else delete item.priority;
            App.taskStatus.set(item, c.status);
            if (c.assignee !== undefined) { if (c.assignee) item.assignee = c.assignee; else delete item.assignee; }
            save();
            li.replaceWith(itemRow(item));
            refreshProgress();
          },
        });
      });

      const stageBtn = document.createElement('button');
      stageBtn.className = 'card-btn stage-btn';
      stageBtn.setAttribute('aria-label', 'Choose the stage: To do, In progress or Done');
      stageBtn.dataset.tooltip = 'Stage: To do · In progress · Done';
      stageBtn.innerHTML = App.taskStatus.ICONS.doing;
      stageBtn.addEventListener('click', () => {
        App.taskStatus.openMenu(stageBtn, App.taskStatus.of(item), (s) => check.choose(s));
      });

      const actions = document.createElement('div');
      actions.className = 'todo-actions';
      actions.append(detailsBtn, stageBtn, assignBtn, due.button, flag, remove);
      li.append(check, main, actions, taskAttachments);
      App.wires.addTaskPorts(li, item.id);
      return li;
    }

    addInput.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter') return;
      const value = addInput.value.trim();
      if (!value) return;
      const item = { id: App.state.uid(), text: value, html: App.richText.fromText(value), done: false };
      card.items.push(item);
      list.append(itemRow(item));
      addInput.value = '';
      save();
      refreshProgress();
    });

    const attachments = document.createElement('div');
    attachments.className = 'attachments';
    App.nesting.renderAttachments(card, attachments);

    card.items.forEach((item) => list.append(itemRow(item)));
    refreshProgress();
    body.append(title, progress, list, addInput, attachments);
  },

  focus(el) {
    el.querySelector('.todo-title')?.focus();
  },
};
