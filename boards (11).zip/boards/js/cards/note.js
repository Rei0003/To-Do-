window.App = window.App || {};

App.cardTypes.note = {
  label: 'Note',
  accepts: ['media', 'note', 'todo', 'drawing', 'calendar', 'table', 'chart', 'file', 'board', 'shape', 'link'],
  resizable: true,
  minWidth: 200,
  maxWidth: 1000,
  defaults: () => ({ text: '', html: '' }),

  render(card, body) {
    const editor = App.richText.create({
      className: 'note-text',
      placeholder: 'Write something…',
      html: card.html ?? App.richText.fromText(card.text),
      onChange: (html, text) => App.state.updateCard(card.id, { html, text }),
    });

    const attachments = document.createElement('div');
    attachments.className = 'attachments';
    App.nesting.renderAttachments(card, attachments);
    body.append(editor, attachments);
  },

  focus(el) {
    el.querySelector('.note-text')?.focus();
  },
};
