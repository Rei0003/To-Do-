window.App = window.App || {};

App.board = (() => {
  let canvas;
  let viewport;

  function renderCard(card) {
    const type = App.cardTypes[card.type];
    if (!type) return null;
    const { el, body } = App.createCardShell(card);
    type.render(card, body);
    App.access?.decorate(el, card);
    return el;
  }

  function emptyState() {
    const el = document.createElement('div');
    el.className = 'empty-state';
    el.innerHTML = '<strong>This board is empty</strong>Drag a note, to-do list or media card in from the left, or double-click anywhere to add a note.';
    return el;
  }

  function render(data) {
    const topLevel = data.cards.filter((c) => !c.parent);
    const ids = new Set(topLevel.map((c) => c.id));

    const childKey = (id) => App.state.descendantsOf(id).map((c) => `${c.id}>${c.parent}:${c.parentItem || ''}`).join(',');
    const existing = new Map([...canvas.querySelectorAll(':scope > .card')].map((el) => [el.dataset.id, el]));

    canvas.querySelector('.empty-state')?.remove();
    existing.forEach((el, id) => { if (!ids.has(id)) el.remove(); });

    topLevel.forEach((card) => {
      const el = existing.get(card.id);
      const key = childKey(card.id);
      if (el && el.dataset.children === key) return;
      const fresh = renderCard(card);
      if (!fresh) return;
      fresh.dataset.children = key;
      if (el) el.replaceWith(fresh);
      else canvas.append(fresh);
    });

    if (!topLevel.length) canvas.append(emptyState());
  }

  function toCanvasPoint(clientX, clientY) {
    const rect = canvas.getBoundingClientRect();
    return { x: clientX - rect.left, y: clientY - rect.top };
  }

  function visibleCenter() {
    return {
      x: viewport.scrollLeft + viewport.clientWidth / 2 - 130,
      y: viewport.scrollTop + viewport.clientHeight / 2 - 80,
    };
  }

  function addCard(type, point = visibleCenter(), extra = {}) {
    const def = App.cardTypes[type];
    if (!def) return null;
    const start = { ...def.defaults(), ...extra };

    const room = viewport.clientWidth - 24;
    if (!extra.width && start.width && start.width > room && room > 0) {
      start.width = Math.max(def.minWidth || 180, room);
      if (start.height && def.resizable === 'both') start.height = Math.round(start.height * (start.width / def.defaults().width));
    }
    const left = Math.min(Math.round(point.x), viewport.scrollLeft + viewport.clientWidth - (start.width || 260) - 12);
    const card = App.state.addCard({
      type,
      x: Math.max(0, Math.round(left)),
      y: Math.max(0, Math.round(point.y)),
      ...start,
    });
    if (!card) return null;
    const el = canvas.querySelector(`.card[data-id="${card.id}"]`);
    if (el) def.focus?.(el);
    return card;
  }

  function init() {
    canvas = document.getElementById('canvas');
    viewport = document.getElementById('viewport');

    render(App.state.get());
    App.state.subscribe(render);
    App.drag.attach(canvas);
    App.resize.attach(canvas);
    App.wires.init();

    canvas.addEventListener('dblclick', (e) => {
      if (e.target !== canvas) return;
      const p = toCanvasPoint(e.clientX, e.clientY);
      addCard('note', { x: p.x - 20, y: p.y - 14 });
    });
  }

  function clear() {
    canvas.querySelectorAll(':scope > .card, .empty-state').forEach((el) => el.remove());
  }

  return { init, addCard, toCanvasPoint, clear };
})();
