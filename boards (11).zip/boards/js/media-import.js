window.App = window.App || {};

App.mediaImport = {
  init() {
    const canvas = document.getElementById('canvas');
    const hasFiles = (e) => e.dataTransfer?.types.includes('Files');
    const hasLink = (e) => e.dataTransfer?.types.includes('text/uri-list');
    const inTextField = (e) => e.target.closest?.('input, textarea, [contenteditable="true"]');

    window.addEventListener('dragover', (e) => {
      if (hasFiles(e) || (hasLink(e) && !inTextField(e))) e.preventDefault();
    });
    window.addEventListener('drop', (e) => {
      if (hasFiles(e) || (hasLink(e) && !inTextField(e))) e.preventDefault();
    });

    canvas.addEventListener('dragover', (e) => {
      if (!(hasFiles(e) || (hasLink(e) && !inTextField(e)))) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
    });

    canvas.addEventListener('drop', (e) => {
      if (!hasFiles(e) && inTextField(e)) return;
      const p = App.board.toCanvasPoint(e.clientX, e.clientY);

      const target = App.nesting.dropTargetOf(e.target, 'media');
      const parent = target?.card.dataset.id;
      const item = target?.item;

      if (hasFiles(e)) {
        e.preventDefault();
        [...e.dataTransfer.files].forEach((file, i) => {
          const point = { x: p.x - 20 + i * 28, y: p.y - 14 + i * 28 };

          const type = App.cardTypes.media.kindOf(file) ? 'media' : 'file';
          const t = App.nesting.dropTargetOf(e.target, type);
          App.mediaImport.addFromFile(file, point, t?.card.dataset.id, t?.item);
        });
      } else if (hasLink(e)) {

        e.preventDefault();
        const url = e.dataTransfer.getData('text/uri-list').split('\n').find((l) => l && !l.startsWith('#'));
        App.mediaImport.addFromLink(url, { x: p.x - 20, y: p.y - 14 }, parent, item);
      }
    });

    document.addEventListener('paste', (e) => {
      if (inTextField(e)) return;
      const files = [...(e.clipboardData?.files || [])];
      if (files.length) {
        e.preventDefault();
        files.forEach((file) => App.mediaImport.addFromFile(file));
        return;
      }
      const text = (e.clipboardData?.getData('text/plain') || '').trim();
      const link = App.mediaLinks.parse(text);
      if (link && !link.guessed) {
        e.preventDefault();
        App.mediaImport.addFromLink(link.url);
      } else if (link && App.cardTypes.link.normalize(text) === link.url) {
        e.preventDefault();
        App.mediaImport.addFromLink(link.url);
      }
    });
  },

  nestData(parent, parentItem) {
    return { ...(parent && { parent }), ...(parent && parentItem && { parentItem }) };
  },

  async addFromFile(file, point, parent = null, parentItem = null) {
    if (App.access && !App.access.canAdd(parent)) return;
    const kind = App.cardTypes.media.kindOf(file);
    try {
      const mediaId = await App.mediaStore.put(file);
      if (kind) {
        App.board.addCard('media', point, { mediaId, kind, name: file.name, ...this.nestData(parent, parentItem) });
      } else {
        App.board.addCard('file', point, {
          mediaId, name: file.name, size: file.size, fileType: file.type, ...this.nestData(parent, parentItem),
        });
      }
    } catch (err) {
      alert(`“${file.name}” couldn’t be added. It may be too large for browser storage.`);
    }
  },

  addFromLink(text, point, parent = null, parentItem = null) {
    if (App.access && !App.access.canAdd(parent)) return;
    const link = App.mediaLinks.parse(text);
    if (!link) return;

    if (link.guessed) {
      App.board.addCard('link', point, { url: link.url, preview: null, ...this.nestData(parent, parentItem) });
      return;
    }
    App.board.addCard('media', point, {
      ...link, name: App.mediaLinks.domainOf(link.url), ...this.nestData(parent, parentItem),
    });
  },
};
