window.App = window.App || {};

App.boards = (() => {

  const INDEX = 'boards.index';
  const DATA = (id) => `boards.board.${id}`;
  const OLD_KEY = 'boards.v1';

  const read = (k, fallback) => { try { return JSON.parse(localStorage.getItem(k)) ?? fallback; } catch { return fallback; } };
  const write = (k, v) => localStorage.setItem(k, JSON.stringify(v));
  const now = () => Math.floor(Date.now() / 1000);
  const countCards = (data) => (data.cards || []).filter((c) => !c.parent).length;

  function mediaIdsIn(data) {
    const ids = new Set();
    (data?.cards || []).forEach((c) => { if (c.mediaId) ids.add(c.mediaId); });
    return ids;
  }

  function layoutPreview(data) {
    const H = { note: 110, todo: 170, media: 190, calendar: 300, table: 150, chart: 320, file: 110, board: 150 };
    return (data?.cards || []).filter((c) => !c.parent).slice(0, 40)
      .map((c) => [c.x || 0, c.y || 0, c.width || 260, c.height || H[c.type] || 120, c.type, c.color || '']);
  }
  const boardIdsIn = (data) => (data?.cards || []).filter((c) => c.type === 'board' && c.boardId).map((c) => c.boardId);

  const local = {

    ensureFirst() {
      if (localStorage.getItem(INDEX)) return;
      const old = read(OLD_KEY, null);
      const data = old && Array.isArray(old.cards) ? old : App.state.starterBoard();
      const id = App.state.uid();
      write(DATA(id), data);

      write(INDEX, [{ id, title: data.title || 'My first board', cards: countCards(data), created_at: now(), updated_at: now(), starter: !old }]);
      if (old) localStorage.setItem(`${OLD_KEY}.backup`, localStorage.getItem(OLD_KEY));
      localStorage.removeItem(OLD_KEY);
    },
    async list() {
      local.ensureFirst();

      return read(INDEX, []).filter((b) => !b.parent).sort((a, b) => b.updated_at - a.updated_at);
    },
    async get(id) {
      const data = read(DATA(id), null);
      if (!data) { const e = new Error('Board not found.'); e.status = 404; throw e; }
      const index = read(INDEX, []);
      const board = index.find((b) => b.id === id) || { id };

      const path = [];
      for (let p = board.parent, i = 0; p && i < 20; i++) {
        const e = index.find((b) => b.id === p);
        if (!e) break;
        path.unshift({ id: e.id, title: e.title });
        p = e.parent;
      }
      return { board: { ...board, path }, data, rev: 0 };
    },
    async create(title, data, parent = null) {
      const id = App.state.uid();
      const d = data || { title, cards: [], connections: [] };
      d.title = title || d.title || 'Untitled board';
      write(DATA(id), d);
      const entry = { id, title: d.title, cards: countCards(d), created_at: now(), updated_at: now(), parent: parent || null };
      write(INDEX, [entry, ...read(INDEX, [])]);
      return entry;
    },
    async summaries(ids) {
      const index = read(INDEX, []);
      const out = {};
      ids.forEach((id) => {
        const e = index.find((b) => b.id === id);
        out[id] = e ? { id, title: e.title, cards: e.cards, updated_at: e.updated_at, preview: layoutPreview(read(DATA(id), null)) } : null;
      });
      return out;
    },
    async save(id, data) {
      write(DATA(id), data);
      write(INDEX, read(INDEX, []).map((b) => (b.id === id
        ? { ...b, title: data.title || 'Untitled board', cards: countCards(data), updated_at: now(), starter: false } : b)));
      return { rev: 0 };
    },
    async rename(id, title) {
      const data = read(DATA(id), null);
      if (data) { data.title = title; await local.save(id, data); }
    },

    async duplicate(id, parent) {
      const entry = read(INDEX, []).find((b) => b.id === id);
      const { data } = await local.get(id);
      const copy = JSON.parse(JSON.stringify(data));
      const intoParent = parent !== undefined ? parent : (entry?.parent || null);
      const title = intoParent ? (data.title || 'Untitled board') : `${data.title || 'Untitled board'} (copy)`;
      const created = await local.create(title, copy, intoParent);
      for (const c of copy.cards) {

        if (c.mediaId) c.mediaId = (await App.mediaStore.local.copy(c.mediaId).catch(() => null)) || c.mediaId;

        if (c.type === 'board' && c.boardId && read(DATA(c.boardId), null)) c.boardId = (await local.duplicate(c.boardId, created.id)).id;
      }
      await local.save(created.id, copy);
      return created;
    },
    async remove(id) {
      const { data } = await local.get(id).catch(() => ({ data: null }));

      read(INDEX, []).filter((b) => b.parent === id).forEach((b) => local.remove(b.id));
      localStorage.removeItem(DATA(id));
      write(INDEX, read(INDEX, []).filter((b) => b.id !== id));

      const others = new Set();
      read(INDEX, []).forEach((b) => mediaIdsIn(read(DATA(b.id), null)).forEach((m) => others.add(m)));
      mediaIdsIn(data).forEach((m) => { if (!others.has(m)) App.mediaStore.local.remove(m).catch(() => {}); });
    },

    count: () => (read(INDEX, []) || []).filter((b) => !b.starter).length,
  };

  const api = (...a) => App.api.request(...a);
  const server = {
    list: async () => api('GET', 'boards.php'),
    async get(id) {
      const res = await api('GET', `boards.php?id=${id}`);
      const { data: inner, ...board } = res.board || {};
      const data = res.data ?? inner;

      if (!data || !Array.isArray(data.cards)) throw new Error('This board couldn’t be loaded. Please try again.');
      return { board, data, rev: board.rev };
    },
    create: async (title, data, parent = null) => (await api('POST', 'boards.php', { title, data, parent })).board,
    summaries: async (ids) => (await api('GET', `boards.php?ids=${ids.join(',')}`)).boards,

    save: async (id, data, rev, { force, keepalive } = {}) => (await api('PUT', `boards.php?id=${id}`, { data, rev, force }, { keepalive })).board,
    rename: async (id, title) => (await api('PATCH', `boards.php?id=${id}`, { title })).board,
    duplicate: async (id, parent) => (await api('POST', `boards.php?id=${id}&action=duplicate${parent ? `&parent=${parent}` : ''}`)).board,
    remove: async (id) => api('DELETE', `boards.php?id=${id}`),
  };

  const repo = () => (App.session.mode === 'server' ? server : local);

  async function importLocalBoards(onProgress) {
    const boards = (await local.list()).filter((b) => !b.starter);
    let done = 0;
    async function importOne(localId, parent) {
      const { data } = await local.get(localId);
      const copy = JSON.parse(JSON.stringify(data));
      const created = await server.create(copy.title || 'Untitled board', { title: copy.title, cards: [], connections: [] }, parent);
      for (const c of copy.cards) {
        if (c.mediaId) {
          const blob = await App.mediaStore.local.getBlob(c.mediaId).catch(() => null);
          if (blob) c.mediaId = await App.mediaStore.put(new File([blob], c.name || 'file', { type: blob.type || c.fileType || '' }));
        }
        if (c.type === 'board' && c.boardId) {
          try { c.boardId = (await importOne(c.boardId, created.id)).id; } catch {  }
        }
      }
      return server.save(created.id, copy, created.rev);
    }
    for (const b of boards) {
      await importOne(b.id, null);
      done++;
      onProgress?.(done, boards.length);
    }
    return done;
  }

  const members = {
    list: (id) => api('GET', `members.php?board=${id}`),

    invite: (id, payload) => api('POST', `members.php?board=${id}`, payload),
    remove: (id, email) => api('DELETE', `members.php?board=${id}&email=${encodeURIComponent(email)}`),
  };

  return {

    assigned: async () => (App.session.mode === 'server' ? (await api('GET', 'boards.php?assigned=1')).tasks : []),
    toggleTask: (boardId, card, item, done, status) => api('POST', `boards.php?id=${boardId}&action=task`, { card, item, done, status: status || (done ? 'done' : 'todo') }),

    async list() {
      const res = await repo().list();
      return Array.isArray(res) ? { boards: res, shared: [] } : { boards: res.boards || [], shared: res.shared || [] };
    },
    members,
    get: (id) => repo().get(id),
    create: (title, data, parent) => repo().create(title, data, parent),
    summaries: (ids) => repo().summaries(ids),
    save: (id, data, rev, opts) => repo().save(id, data, rev, opts),
    rename: (id, title) => repo().rename(id, title),
    duplicate: (id, parent) => repo().duplicate(id, parent),
    remove: (id) => repo().remove(id),
    localCount: () => (localStorage.getItem(OLD_KEY) ? 1 : 0) + local.count(),
    importLocalBoards,
  };
})();
