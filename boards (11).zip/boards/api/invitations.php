<?php

require __DIR__ . '/db.php';
require_same_site();
$uid = require_user();
$pdo = db();
$email = strtolower(user_email($uid));

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $st = $pdo->prepare("SELECT m.board_id, m.role, m.member_role, m.created_at, b.title, b.user_id AS owner_id, u.name AS owner_name, u.avatar AS owner_avatar
        FROM board_members m JOIN boards b ON b.id = m.board_id JOIN users u ON u.id = b.user_id
        WHERE m.email = ? AND m.status = 'pending' ORDER BY m.created_at DESC");
    $st->execute([$email]);
    $out = [];
    foreach ($st->fetchAll() as $r) {
        $role = null;
        if ($r['member_role']) {
            foreach (roles_of_owner((int)$r['owner_id']) as $x) if ($x['id'] === $r['member_role']) $role = role_out($x);
        }
        $out[] = [
            'board' => $r['board_id'], 'title' => $r['title'], 'role' => $r['role'], 'member_role' => $role,
            'owner' => ['name' => $r['owner_name'], 'avatar' => avatar_url($r['owner_id'], $r['owner_avatar'])],
            'invited_at' => (int)$r['created_at'],
        ];
    }
    reply(['invitations' => $out]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $boardId = preg_replace('/[^a-f0-9]/', '', (string)($_GET['board'] ?? ''));
    $action = $_GET['action'] ?? '';
    if (!in_array($action, ['accept', 'decline'], true)) fail('Choose accept or decline.');
    $st = $pdo->prepare("SELECT status FROM board_members WHERE board_id = ? AND email = ?");
    $st->execute([$boardId, $email]);
    $status = $st->fetchColumn();
    if ($status === false) fail('That invitation no longer exists.', 404);
    if ($status !== 'pending') fail($status === 'accepted' ? 'You already joined this board.' : 'You already declined this invitation.', 409);
    $pdo->prepare('UPDATE board_members SET status = ? WHERE board_id = ? AND email = ?')
        ->execute([$action === 'accept' ? 'accepted' : 'declined', $boardId, $email]);
    reply(['ok' => true, 'status' => $action === 'accept' ? 'accepted' : 'declined']);
}

fail('Unknown request.', 405);
