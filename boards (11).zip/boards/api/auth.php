<?php

require __DIR__ . '/db.php';
require_same_site();

$action = $_GET['action'] ?? 'me';
$pdo = db();

function user_out(array $u): array {
    return ['id' => (int)$u['id'], 'name' => $u['name'], 'email' => $u['email'], 'avatar' => avatar_url($u['id'], $u['avatar'] ?? null)];
}

function log_in(array $user): void {
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$user['id'];
}

if ($action === 'me') {
    $uid = current_user_id();
    if (!$uid) reply(['user' => null, 'allow_guest' => !empty($CONFIG['allow_guest'])]);
    $st = $pdo->prepare('SELECT id, name, email, avatar FROM users WHERE id = ?');
    $st->execute([$uid]);
    $u = $st->fetch();
    reply(['user' => $u ? user_out($u) : null]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('Use POST.', 405);

if ($action === 'logout') {
    $_SESSION = [];
    session_destroy();
    reply(['ok' => true]);
}

$body = json_body();
$email = strtolower(trim((string)($body['email'] ?? '')));
$password = (string)($body['password'] ?? '');

if ($action === 'register') {
    $name = trim((string)($body['name'] ?? ''));
    if ($name === '' || text_len($name) > 60) fail('Please enter your name (up to 60 characters).');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) fail('Please enter a valid email address.');
    if (strlen($password) < 8) fail('The password needs at least 8 characters.');
    if (strlen($password) > 200) fail('That password is too long.');

    $st = $pdo->prepare('SELECT 1 FROM users WHERE email = ?');
    $st->execute([$email]);
    if ($st->fetch()) fail('There is already an account with this email. Try logging in.', 409);

    $st = $pdo->prepare('INSERT INTO users (email, name, password_hash, created_at) VALUES (?, ?, ?, ?)');
    $st->execute([$email, $name, password_hash($password, PASSWORD_DEFAULT), time()]);
    $user = ['id' => (int)$pdo->lastInsertId(), 'name' => $name, 'email' => $email];
    log_in($user);
    reply(['user' => user_out($user)], 201);
}

if ($action === 'login') {

    $pdo->prepare('DELETE FROM login_attempts WHERE at < ?')->execute([time() - 900]);
    $st = $pdo->prepare('SELECT COUNT(*) FROM login_attempts WHERE email = ?');
    $st->execute([$email]);
    if ((int)$st->fetchColumn() >= 5) fail('Too many wrong passwords. Please wait a few minutes and try again.', 429);

    $st = $pdo->prepare('SELECT * FROM users WHERE email = ?');
    $st->execute([$email]);
    $user = $st->fetch();
    if (!$user || !password_verify($password, $user['password_hash'])) {
        $pdo->prepare('INSERT INTO login_attempts (email, at) VALUES (?, ?)')->execute([$email, time()]);
        fail('Wrong email or password.', 401);
    }
    $pdo->prepare('DELETE FROM login_attempts WHERE email = ?')->execute([$email]);
    if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
        $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
            ->execute([password_hash($password, PASSWORD_DEFAULT), $user['id']]);
    }
    log_in($user);
    gc_files((int)$user['id']);
    reply(['user' => user_out($user)]);
}

fail('Unknown action.', 404);
