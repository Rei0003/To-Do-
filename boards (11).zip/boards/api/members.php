<?php

require __DIR__ . '/db.php';
require_same_site();
$uid = require_user();
$pdo = db();
$boardId = preg_replace('/[^a-f0-9]/', '', (string)($_GET['board'] ?? ''));
$acc = board_access($boardId, $uid);
if (!$acc) fail('Board not found.', 404);
$isOwner = $acc['role'] === 'owner';

function member_list(string $boardId): array {

    $owner = db()->prepare('SELECT user_id FROM boards WHERE id = ?');
    $owner->execute([$boardId]);
    $roles = [];
    foreach (roles_of_owner((int)$owner->fetchColumn()) as $r) $roles[$r['id']] = role_out($r);
    $st = db()->prepare('SELECT m.email, m.role, m.cards, m.hide_others, m.member_role, m.status, u.name, u.id AS uid, u.avatar FROM board_members m
        LEFT JOIN users u ON u.email = m.email WHERE m.board_id = ? ORDER BY m.created_at');
    $st->execute([$boardId]);
    return array_map(fn($m) => [
        'email' => $m['email'],
        'name' => $m['name'],
        'avatar' => avatar_url($m['uid'], $m['avatar']),
        'role' => $m['role'],
        'cards' => json_decode($m['cards'], true) ?: [],
        'hide' => (bool)$m['hide_others'],
        'member_role' => $roles[$m['member_role'] ?? ''] ?? null,
        'status' => $m['status'] ?? 'accepted',
    ], $st->fetchAll());
}

function inherited_members(array $board, int $uid): array {
    $out = [];
    foreach (array_reverse(board_path($board, $uid)) as $p) {
        foreach (member_list($p['id']) as $m) {
            if (!isset($out[$m['email']])) $out[$m['email']] = $m + ['from' => $p['title']];
        }
    }
    return array_values($out);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    reply([
        'owner' => ['name' => $acc['board']['owner_name'], 'email' => $acc['board']['owner_email'],
                    'avatar' => avatar_url($acc['board']['user_id'], $acc['board']['owner_avatar'] ?? null)],
        'members' => member_list($boardId),
        'inherited' => inherited_members($acc['board'], $uid),
        'roles' => array_map('role_out', roles_of_owner((int)$acc['board']['user_id'])),
        'you' => $acc['role'],

        'inherited_from' => ($p = board_path($acc['board'], $uid)) ? end($p)['title'] : null,
    ]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$isOwner) fail('Only the board’s owner can invite people.', 403);
    $body = json_body();
    $email = strtolower(trim((string)($body['email'] ?? '')));
    $role = (string)($body['role'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) fail('Please enter a valid email address.');
    if ($email === strtolower($acc['board']['owner_email'])) fail('That’s you — you already own this board.');
    if (!in_array($role, ['edit', 'view', 'cards'], true)) fail('Choose what they can do.');
    $cards = array_values(array_unique(array_filter(array_map('strval', (array)($body['cards'] ?? [])), fn($c) => preg_match('/^[\w-]{1,40}$/', $c))));
    if ($role === 'cards' && !$cards) fail('Choose at least one card they can edit.');
    $hide = $role === 'cards' && !empty($body['hide']) ? 1 : 0;

    $memberRole = isset($body['member_role']) && $body['member_role'] !== '' ? (string)$body['member_role'] : null;
    if ($memberRole !== null && !in_array($memberRole, array_column(roles_of_owner((int)$acc['board']['user_id']), 'id'), true)) {
        fail('That role doesn’t exist any more.');
    }

    $exists = $pdo->prepare('SELECT status FROM board_members WHERE board_id = ? AND email = ?');
    $exists->execute([$boardId, $email]);
    $current = $exists->fetchColumn();
    if ($current !== false) {

        $status = $current === 'declined' && !empty($body['reinvite']) ? 'pending' : $current;
        $pdo->prepare('UPDATE board_members SET role = ?, cards = ?, hide_others = ?, member_role = ?, status = ? WHERE board_id = ? AND email = ?')
            ->execute([$role, json_encode($cards), $hide, $memberRole, $status, $boardId, $email]);
    } else {
        $pdo->prepare("INSERT INTO board_members (board_id, email, role, cards, hide_others, member_role, status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)")
            ->execute([$boardId, $email, $role, json_encode($cards), $hide, $memberRole, time()]);
    }
    $hasAccount = $pdo->prepare('SELECT 1 FROM users WHERE email = ?');
    $hasAccount->execute([$email]);
    reply(['members' => member_list($boardId), 'registered' => (bool)$hasAccount->fetch()]);
}

if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $email = strtolower(trim((string)($_GET['email'] ?? '')));
    $self = $email === strtolower(user_email($uid));
    if (!$isOwner && !$self) fail('Only the board’s owner can remove people.', 403);
    $pdo->prepare('DELETE FROM board_members WHERE board_id = ? AND email = ?')->execute([$boardId, $email]);
    reply(['members' => $isOwner ? member_list($boardId) : []]);
}

fail('Unknown request.', 405);
