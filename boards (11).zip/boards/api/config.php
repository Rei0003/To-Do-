<?php

$config = [

    'db_dsn'  => 'sqlite:' . __DIR__ . '/data/boards.sqlite',
    'db_user' => null,
    'db_pass' => null,

    'uploads_dir' => __DIR__ . '/uploads',

    'allow_guest' => false,

    'max_board_bytes' => 25 * 1024 * 1024,
    'max_file_bytes'  => 200 * 1024 * 1024,
];

return $config;
