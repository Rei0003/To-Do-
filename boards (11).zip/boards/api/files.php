<?php

require __DIR__ . '/db.php';
require_same_site();
$uid = require_user();
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = $_FILES['file'] ?? null;
    if (!$f) fail('No file was sent. It may be bigger than the server allows (post_max_size = ' . ini_get('post_max_size') . ').', 413);
    if ($f['error'] === UPLOAD_ERR_INI_SIZE || $f['error'] === UPLOAD_ERR_FORM_SIZE) {
        fail('This file is bigger than the server allows (upload_max_filesize = ' . ini_get('upload_max_filesize') . ').', 413);
    }
    if ($f['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) fail('The upload didn’t work. Please try again.');
    if ($f['size'] > $CONFIG['max_file_bytes']) fail('This file is too big.', 413);

    $name = text_cut(preg_replace('/[\x00-\x1f\/\\\\]+/', '', basename((string)$f['name'])) ?: 'file', 255);

    $type = (string)($_POST['type'] ?? $f['type'] ?? '');
    if (!preg_match('~^[\w.+-]+/[\w.+-]+$~', $type)) {
        $type = function_exists('mime_content_type') ? (mime_content_type($f['tmp_name']) ?: 'application/octet-stream') : 'application/octet-stream';
    }
    $id = random_id(16);
    if (!move_uploaded_file($f['tmp_name'], user_dir($uid) . '/' . $id)) fail('The server couldn’t store the file.', 500);
    $pdo->prepare('INSERT INTO files (id, user_id, name, type, size, created_at) VALUES (?, ?, ?, ?, ?, ?)')
        ->execute([$id, $uid, $name, $type, (int)$f['size'], time()]);
    reply(['id' => $id, 'name' => $name, 'type' => $type, 'size' => (int)$f['size']], 201);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $id = preg_replace('/[^a-f0-9]/', '', (string)($_GET['id'] ?? ''));
    $st = $pdo->prepare('SELECT * FROM files WHERE id = ?');
    $st->execute([$id]);
    $file = $st->fetch();

    if (!$file || !can_read_file($uid, $file)) fail('File not found.', 404);
    $path = user_dir((int)$file['user_id']) . '/' . $file['id'];
    if (!is_file($path)) fail('File not found.', 404);

    $safe = preg_match('~^(image/(png|jpeg|gif|webp|avif|bmp|svg\+xml)|video/[\w.+-]+|audio/[\w.+-]+|application/pdf|text/plain)$~', $file['type']);
    $type = $safe ? $file['type'] : 'application/octet-stream';
    $size = filesize($path);
    header('Content-Type: ' . $type);
    header('X-Content-Type-Options: nosniff');
    header("Content-Security-Policy: default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; sandbox");
    header('Content-Disposition: ' . ($safe ? 'inline' : 'attachment') . "; filename*=UTF-8''" . rawurlencode($file['name']));
    header('Cache-Control: private, max-age=31536000, immutable');
    header('Accept-Ranges: bytes');

    $start = 0;
    $end = $size - 1;
    if (isset($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/', $_SERVER['HTTP_RANGE'], $m)) {
        if ($m[1] === '' && $m[2] !== '') { $start = max(0, $size - (int)$m[2]); }
        else { $start = (int)$m[1]; if ($m[2] !== '') $end = min($end, (int)$m[2]); }
        if ($start > $end || $start >= $size) { header("Content-Range: bytes */$size"); http_response_code(416); exit; }
        http_response_code(206);
        header("Content-Range: bytes $start-$end/$size");
    }
    header('Content-Length: ' . ($end - $start + 1));
    $fp = fopen($path, 'rb');
    fseek($fp, $start);
    $left = $end - $start + 1;
    while ($left > 0 && !feof($fp)) {
        $chunk = fread($fp, (int)min(65536, $left));
        echo $chunk;
        $left -= strlen($chunk);
        flush();
    }
    fclose($fp);
    exit;
}

fail('Unknown request.', 405);
