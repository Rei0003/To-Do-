<?php

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if (preg_match('~^/api/(data|uploads)(/|$)|^/api/(config|db)\.php$|\.sql$~', $path)) {
    http_response_code(403);
    exit('Forbidden');
}

$types = ['html' => 'text/html; charset=UTF-8', 'js' => 'application/javascript; charset=UTF-8', 'css' => 'text/css; charset=UTF-8'];
$file = __DIR__ . ($path === '/' ? '/index.html' : $path);
$ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
$real = realpath($file);
if (isset($types[$ext]) && $real && str_starts_with($real, realpath(__DIR__)) && is_file($real)) {
    header('Content-Type: ' . $types[$ext]);
    header('Cache-Control: no-cache');
    readfile($real);
    return true;
}
return false;
