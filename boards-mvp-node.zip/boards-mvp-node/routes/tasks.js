const express = require('express');
const { get, all, run, now } = require('../database');
const { fail, text, requireLogin, boardAccess, requireAccess, boardPeople, cardBoard, touchBoard } = require('../helpers');

const router = express.Router();
router.use(requireLogin);

function findTask(taskId) {
  const task = get('SELECT * FROM tasks WHERE id = ?', taskId);
  if (!task) fail(404, 'Task not found.');
  return task;
}

router.get('/', (req, res) => {
  const rows = all(`SELECT t.*, c.title AS list_title, c.board_id, b.title AS board_title
    FROM tasks t JOIN cards c ON c.id = t.card_id JOIN boards b ON b.id = c.board_id
    WHERE t.assignee_id = ? OR (t.assignee_id IS NULL AND b.owner_id = ?)`, req.userId, req.userId);
  res.json({ tasks: rows.filter((task) => boardAccess(task.board_id, req.userId)) });
});

router.post('/', (req, res) => {
  const cardId = Number(req.body.card_id);
  const boardId = cardBoard(cardId);
  requireAccess(boardId, req.userId, true);
  const title = text(req.body, 'title', 200, true);
  const position = get('SELECT COALESCE(MAX(position), 0) + 1 AS next FROM tasks WHERE card_id = ?', cardId).next;

  const result = run('INSERT INTO tasks (card_id, title, position, created_at) VALUES (?, ?, ?, ?)', cardId, title, position, now());
  touchBoard(boardId);
  res.status(201).json({ task: findTask(result.lastInsertRowid) });
});

router.patch('/:id', (req, res) => {
  const taskId = Number(req.params.id);
  const task = findTask(taskId);
  const boardId = cardBoard(task.card_id);
  const access = requireAccess(boardId, req.userId);
  const body = req.body;

  const onlyDone = Object.keys(body).length === 1 && 'done' in body;
  const isMine = task.assignee_id === req.userId;
  if (access === 'view' && !(isMine && onlyDone)) fail(403, 'You can only view this board.');

  if ('title' in body) task.title = text(body, 'title', 200, true);
  if ('description' in body) task.description = text(body, 'description', 2000);

  if ('due' in body) {
    const due = String(body.due ?? '').trim();
    if (due && !/^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2})?$/.test(due)) fail(400, 'That due date isn’t valid.');
    task.due = due || null;
  }

  if ('priority' in body) {
    if (!['low', 'medium', 'high'].includes(body.priority)) fail(400, 'Choose Low, Medium or High.');
    task.priority = body.priority;
  }

  if ('assignee_id' in body) {
    const assigneeId = body.assignee_id ? Number(body.assignee_id) : null;
    const allowed = boardPeople(boardId).map((person) => person.id);
    if (assigneeId && !allowed.includes(assigneeId)) fail(400, 'That person isn’t on this board.');
    task.assignee_id = assigneeId;
  }

  if ('done' in body) {
    const done = body.done ? 1 : 0;
    if (done && !task.done) task.done_at = now();
    if (!done) task.done_at = null;
    task.done = done;
  }

  run('UPDATE tasks SET title = ?, description = ?, due = ?, priority = ?, assignee_id = ?, done = ?, done_at = ? WHERE id = ?',
    task.title, task.description, task.due, task.priority, task.assignee_id, task.done, task.done_at, taskId);
  touchBoard(boardId);
  res.json({ task: findTask(taskId) });
});

router.delete('/:id', (req, res) => {
  const task = findTask(Number(req.params.id));
  const boardId = cardBoard(task.card_id);
  requireAccess(boardId, req.userId, true);
  run('DELETE FROM tasks WHERE id = ?', task.id);
  touchBoard(boardId);
  res.json({ ok: true });
});

module.exports = router;
