const express = require('express');
const { get, run, now } = require('../database');
const { fail, text, hashPassword, checkPassword } = require('../helpers');

const router = express.Router();

router.get('/me', (req, res) => {
  const user = req.session.userId ? get('SELECT id, name, email FROM users WHERE id = ?', req.session.userId) : null;
  res.json({ user });
});

router.post('/register', (req, res) => {
  const name = text(req.body, 'name', 60, true);
  const email = text(req.body, 'email', 190, true).toLowerCase();
  const password = String(req.body.password ?? '');

  if (!/^\S+@\S+\.\S+$/.test(email)) fail(400, 'Please enter a valid email address.');
  if (password.length < 8) fail(400, 'The password needs at least 8 characters.');
  if (get('SELECT 1 FROM users WHERE email = ?', email)) fail(409, 'There is already an account with this email.');

  const result = run('INSERT INTO users (name, email, password_hash, created_at) VALUES (?, ?, ?, ?)',
    name, email, hashPassword(password), now());
  req.session.userId = Number(result.lastInsertRowid);
  res.status(201).json({ user: { id: req.session.userId, name, email } });
});

router.post('/login', (req, res) => {
  const email = text(req.body, 'email', 190, true).toLowerCase();
  const user = get('SELECT * FROM users WHERE email = ?', email);
  if (!user || !checkPassword(String(req.body.password ?? ''), user.password_hash)) {
    fail(401, 'Wrong email or password.');
  }

  req.session.regenerate(() => {
    req.session.userId = user.id;
    res.json({ user: { id: user.id, name: user.name, email: user.email } });
  });
});

router.post('/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

module.exports = router;
