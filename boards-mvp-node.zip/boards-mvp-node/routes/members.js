const express = require('express');
const { get, all, run, now } = require('../database');
const { fail, text, requireAccess, requireOwner, findBoard } = require('../helpers');

const router = express.Router({ mergeParams: true });

function validAccess(body) {
  const access = body.access || 'edit';
  if (!['edit', 'view'].includes(access)) fail(400, 'Choose Can edit or Can view.');
  return access;
}

router.get('/', (req, res) => {
  const boardId = Number(req.params.id);
  requireAccess(boardId, req.userId);
  const board = findBoard(boardId);
  const owner = get('SELECT id, name, email FROM users WHERE id = ?', board.owner_id);
  const members = all(`SELECT u.id, u.name, u.email, m.access, m.status FROM board_members m
    JOIN users u ON u.id = m.user_id WHERE m.board_id = ? ORDER BY m.invited_at`, boardId);
  res.json({ owner, members });
});

router.post('/', (req, res) => {
  const boardId = Number(req.params.id);
  requireOwner(boardId, req.userId);
  const email = text(req.body, 'email', 190, true).toLowerCase();
  const access = validAccess(req.body);

  const invited = get('SELECT id FROM users WHERE email = ?', email);
  if (!invited) fail(400, 'There is no account with this email. Only registered users can be invited.');
  if (invited.id === req.userId) fail(400, 'This is your own board.');

  const existing = get('SELECT status FROM board_members WHERE board_id = ? AND user_id = ?', boardId, invited.id);
  if (existing) {
    const status = existing.status === 'declined' ? 'pending' : existing.status;
    run('UPDATE board_members SET access = ?, status = ? WHERE board_id = ? AND user_id = ?', access, status, boardId, invited.id);
  } else {
    run("INSERT INTO board_members (board_id, user_id, access, status, invited_at) VALUES (?, ?, ?, 'pending', ?)",
      boardId, invited.id, access, now());
  }
  res.json({ ok: true });
});

router.post('/answer', (req, res) => {
  const boardId = Number(req.params.id);
  const answer = req.body.answer;
  if (!['accept', 'decline'].includes(answer)) fail(400, 'Choose accept or decline.');

  const invitation = get("SELECT 1 FROM board_members WHERE board_id = ? AND user_id = ? AND status = 'pending'", boardId, req.userId);
  if (!invitation) fail(404, 'This invitation no longer exists.');
  run('UPDATE board_members SET status = ? WHERE board_id = ? AND user_id = ?',
    answer === 'accept' ? 'accepted' : 'declined', boardId, req.userId);
  res.json({ ok: true });
});

router.patch('/:userId', (req, res) => {
  const boardId = Number(req.params.id);
  requireOwner(boardId, req.userId);
  run('UPDATE board_members SET access = ? WHERE board_id = ? AND user_id = ?', validAccess(req.body), boardId, Number(req.params.userId));
  res.json({ ok: true });
});

router.delete('/:userId', (req, res) => {
  const boardId = Number(req.params.id);
  const memberId = Number(req.params.userId);
  if (memberId !== req.userId) requireOwner(boardId, req.userId);
  run('DELETE FROM board_members WHERE board_id = ? AND user_id = ?', boardId, memberId);
  run('UPDATE tasks SET assignee_id = NULL WHERE assignee_id = ? AND card_id IN (SELECT id FROM cards WHERE board_id = ?)', memberId, boardId);
  res.json({ ok: true });
});

module.exports = router;
