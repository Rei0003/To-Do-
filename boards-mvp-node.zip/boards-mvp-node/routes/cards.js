const express = require('express');
const { get, run, now } = require('../database');
const { fail, text, requireLogin, requireAccess, findBoard, cardBoard, touchBoard } = require('../helpers');

const router = express.Router();
router.use(requireLogin);

router.post('/', (req, res) => {
  const boardId = Number(req.body.board_id);
  requireAccess(boardId, req.userId, true);

  const type = req.body.type;
  if (!['note', 'todo', 'board'].includes(type)) fail(400, 'Unknown card type.');

  let childBoardId = null;
  let title = '';
  if (type === 'board') {
    const board = findBoard(boardId);
    title = 'New board';
    const child = run('INSERT INTO boards (owner_id, parent_id, title, created_at, updated_at) VALUES (?, ?, ?, ?, ?)',
      board.owner_id, boardId, title, now(), now());
    childBoardId = Number(child.lastInsertRowid);
  }

  const x = Math.max(0, Math.round(Number(req.body.x) || 0));
  const y = Math.max(0, Math.round(Number(req.body.y) || 0));
  const result = run('INSERT INTO cards (board_id, type, x, y, title, child_board_id) VALUES (?, ?, ?, ?, ?, ?)',
    boardId, type, x, y, title, childBoardId);
  touchBoard(boardId);
  res.status(201).json({ card: get('SELECT * FROM cards WHERE id = ?', result.lastInsertRowid) });
});

router.patch('/:id', (req, res) => {
  const cardId = Number(req.params.id);
  const boardId = cardBoard(cardId);
  requireAccess(boardId, req.userId, true);

  const card = get('SELECT * FROM cards WHERE id = ?', cardId);
  const body = req.body;
  const x = 'x' in body ? Math.max(0, Math.round(Number(body.x) || 0)) : card.x;
  const y = 'y' in body ? Math.max(0, Math.round(Number(body.y) || 0)) : card.y;
  const title = 'title' in body ? text(body, 'title', 200) : card.title;
  const note = 'text' in body ? text(body, 'text', 5000) : card.text;

  run('UPDATE cards SET x = ?, y = ?, title = ?, text = ? WHERE id = ?', x, y, title, note, cardId);
  if (card.child_board_id && 'title' in body) {
    run('UPDATE boards SET title = ? WHERE id = ?', title || 'Untitled board', card.child_board_id);
  }
  touchBoard(boardId);
  res.json({ ok: true });
});

router.delete('/:id', (req, res) => {
  const cardId = Number(req.params.id);
  const boardId = cardBoard(cardId);
  requireAccess(boardId, req.userId, true);

  const card = get('SELECT child_board_id FROM cards WHERE id = ?', cardId);
  run('DELETE FROM cards WHERE id = ?', cardId);
  if (card.child_board_id) run('DELETE FROM boards WHERE id = ?', card.child_board_id);
  touchBoard(boardId);
  res.json({ ok: true });
});

module.exports = router;
