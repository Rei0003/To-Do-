const express = require('express');
const { get, all, run, now } = require('../database');
const { fail, text, requireLogin, findBoard, boardAccess, requireAccess, requireOwner, boardPeople } = require('../helpers');

const router = express.Router();
router.use(requireLogin);

router.get('/', (req, res) => {
  const own = all(`SELECT id, title, updated_at FROM boards
    WHERE owner_id = ? AND parent_id IS NULL ORDER BY updated_at DESC`, req.userId);

  const shared = all(`SELECT b.id, b.title, b.updated_at, m.access, u.name AS owner_name
    FROM board_members m JOIN boards b ON b.id = m.board_id JOIN users u ON u.id = b.owner_id
    WHERE m.user_id = ? AND m.status = 'accepted' ORDER BY b.updated_at DESC`, req.userId);

  const invitations = all(`SELECT b.id, b.title, m.access, u.name AS owner_name
    FROM board_members m JOIN boards b ON b.id = m.board_id JOIN users u ON u.id = b.owner_id
    WHERE m.user_id = ? AND m.status = 'pending' ORDER BY m.invited_at DESC`, req.userId);

  res.json({ own, shared, invitations });
});

router.get('/:id', (req, res) => {
  const boardId = Number(req.params.id);
  const access = requireAccess(boardId, req.userId);
  const board = findBoard(boardId);

  const path = [];
  for (let parentId = board.parent_id; parentId; ) {
    const parent = findBoard(parentId);
    if (!boardAccess(parent.id, req.userId)) break;
    path.unshift({ id: parent.id, title: parent.title });
    parentId = parent.parent_id;
  }

  const cards = all('SELECT * FROM cards WHERE board_id = ? ORDER BY id', boardId);
  const tasks = all(`SELECT t.*, u.name AS assignee_name FROM tasks t
    JOIN cards c ON c.id = t.card_id LEFT JOIN users u ON u.id = t.assignee_id
    WHERE c.board_id = ? ORDER BY t.position`, boardId);

  res.json({
    board: { id: board.id, title: board.title, parent_id: board.parent_id, access },
    path,
    cards,
    tasks,
    people: boardPeople(boardId),
    me: req.userId,
  });
});

router.post('/', (req, res) => {
  const title = text(req.body, 'title', 200) || 'Untitled board';
  const result = run('INSERT INTO boards (owner_id, title, created_at, updated_at) VALUES (?, ?, ?, ?)',
    req.userId, title, now(), now());
  res.status(201).json({ id: Number(result.lastInsertRowid) });
});

router.patch('/:id', (req, res) => {
  const boardId = Number(req.params.id);
  requireAccess(boardId, req.userId, true);
  const title = text(req.body, 'title', 200, true);
  run('UPDATE boards SET title = ?, updated_at = ? WHERE id = ?', title, now(), boardId);
  run('UPDATE cards SET title = ? WHERE child_board_id = ?', title, boardId);
  res.json({ ok: true });
});

router.delete('/:id', (req, res) => {
  const boardId = Number(req.params.id);
  const board = requireOwner(boardId, req.userId);
  if (board.parent_id) fail(400, 'Delete this board from its card on the board above.');
  run('DELETE FROM boards WHERE id = ?', boardId);
  res.json({ ok: true });
});

router.use('/:id/members', require('./members'));

module.exports = router;
