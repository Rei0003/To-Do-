const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
const db = new DatabaseSync(path.join(__dirname, 'data', 'boards.sqlite'));
db.exec('PRAGMA foreign_keys = ON');
db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));

function get(sql, ...params) {
  return db.prepare(sql).get(...params) || null;
}

function all(sql, ...params) {
  return db.prepare(sql).all(...params);
}

function run(sql, ...params) {
  return db.prepare(sql).run(...params);
}

function now() {
  return Math.floor(Date.now() / 1000);
}

module.exports = { get, all, run, now };
