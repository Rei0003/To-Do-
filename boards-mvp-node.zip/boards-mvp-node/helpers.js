const crypto = require('node:crypto');
const { get, all, run, now } = require('./database');

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function fail(status, message) {
  throw new HttpError(status, message);
}

function text(body, key, max, required = false) {
  const value = String(body[key] ?? '').trim();
  if (required && value === '') fail(400, `Please fill in the ${key}.`);
  if ([...value].length > max) fail(400, `The ${key} can be ${max} characters at most.`);
  return value;
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function checkPassword(password, stored) {
  const [salt, hash] = stored.split(':');
  const attempt = crypto.scryptSync(password, salt, 64);
  return crypto.timingSafeEqual(attempt, Buffer.from(hash, 'hex'));
}

function requireLogin(req, res, next) {
  if (!req.session.userId) fail(401, 'Please log in.');
  req.userId = req.session.userId;
  next();
}

function findBoard(boardId) {
  return get('SELECT * FROM boards WHERE id = ?', boardId);
}

function boardAccess(boardId, userId) {
  const board = findBoard(boardId);
  if (!board) return null;
  if (board.owner_id === userId) return 'owner';

  const member = get("SELECT access FROM board_members WHERE board_id = ? AND user_id = ? AND status = 'accepted'", boardId, userId);
  if (member) return member.access;

  if (board.parent_id) return boardAccess(board.parent_id, userId);
  return null;
}

function requireAccess(boardId, userId, mustEdit = false) {
  const access = boardAccess(boardId, userId);
  if (!access) fail(404, 'Board not found.');
  if (mustEdit && access === 'view') fail(403, 'You can only view this board.');
  return access;
}

function requireOwner(boardId, userId) {
  const board = findBoard(boardId);
  if (!board || board.owner_id !== userId) fail(403, 'Only the board’s owner can do that.');
  return board;
}

function boardPeople(boardId) {
  const board = findBoard(boardId);
  const people = [get('SELECT id, name, email FROM users WHERE id = ?', board.owner_id)];
  for (let current = board; current; current = current.parent_id ? findBoard(current.parent_id) : null) {
    people.push(...all(`SELECT u.id, u.name, u.email FROM board_members m JOIN users u ON u.id = m.user_id
      WHERE m.board_id = ? AND m.status = 'accepted'`, current.id));
  }
  const unique = new Map(people.map((person) => [person.id, person]));
  return [...unique.values()];
}

function cardBoard(cardId) {
  const card = get('SELECT board_id FROM cards WHERE id = ?', cardId);
  if (!card) fail(404, 'Card not found.');
  return card.board_id;
}

function touchBoard(boardId) {
  run('UPDATE boards SET updated_at = ? WHERE id = ?', now(), boardId);
}

module.exports = {
  HttpError, fail, text, hashPassword, checkPassword, requireLogin,
  findBoard, boardAccess, requireAccess, requireOwner, boardPeople, cardBoard, touchBoard,
};
