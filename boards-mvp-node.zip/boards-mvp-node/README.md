# Boards (MVP, Node.js)

A small visual planner: boards with notes, to-do lists and boards inside boards, shared with a team.
It has exactly what the *Planotājs* requirements ask for, and nothing else.
The server is written in Node.js with Express; the database is SQLite (built into Node).

## Running it

You need **Node.js 22.13 or newer** (download the LTS version from nodejs.org).

1. Open a terminal in this folder.
2. Run `npm install` once. It downloads the two packages the server uses (Express and express-session).
3. Run `npm start`.
4. Open `http://localhost:3000`.

The database (`data/boards.sqlite`) is created automatically the first time. Logins are kept in the
server's memory, so after restarting the server everyone logs in again.

## Requirements and where they are

| Requirement | In the app |
| --- | --- |
| 2.1 Register with name, email and password; unique email; hashed password; log in and out | Sign-in screen, `routes/auth.js` (passwords hashed with `crypto.scrypt`) |
| 2.1 No access without logging in | `requireLogin` in `helpers.js` runs before every board, card and task route |
| 2.2 Create, edit, delete tasks; done / not done | To-do cards: add a task, tick the circle, **Details** (≡) to edit, × to delete |
| 2.2 Title, description, deadline, priority Low / Medium / High | The task **Details** window |
| 2.2 See active and completed tasks | **My tasks** on *Your boards*: Active / Completed |
| 2.3 Dashboard after login, separate active / completed, filter or sort | **My tasks**: tabs, *Sort by* deadline or priority, *Priority* filter |
| 2.4 Projects, invite registered users, accept or decline, several members | Boards; **Share** (owner) invites by email; invitations on *Your boards* with Accept / Decline |
| 2.4 Shared tasks, assign to a member, see according to rights | *Assigned to* in task details; access *Can edit* or *Can view* |
| 3 Security | Hashed passwords, server-side checks on every request, access checked per board (`boardAccess` in `helpers.js`) |
| 5 Clear interface, form validation, responsive | Error messages on every form; works on phones; light and dark mode |

## Files

| File | What it does |
| --- | --- |
| `package.json` | The project's name, start command and the two packages it needs |
| `server.js` | Starts the web server: sessions, routes, the `public` folder, error answers |
| `database.js` | Opens the SQLite database, creates the tables, small query helpers |
| `schema.sql` | The database tables |
| `helpers.js` | Shared rules: errors, input checks, password hashing, login check, board access |
| `routes/auth.js` | Register, log in, log out |
| `routes/boards.js` | List, open, create, rename and delete boards |
| `routes/members.js` | Invite, accept or decline, change access, remove |
| `routes/cards.js` | Add, move, edit and delete cards |
| `routes/tasks.js` | My tasks; add, edit, finish and delete tasks |
| `public/index.html` | The page: sign-in, *Your boards* and the board screen |
| `public/css/` | The look: `base.css`, `screens.css`, `board.css`, `cards.css` |
| `public/js/` | The browser side: `api.js`, `ui.js`, `login.js`, `home.js`, `board.js`, `cards.js`, `task-details.js`, `members.js`, `app.js` |

## Server addresses

| Address | Does |
| --- | --- |
| `GET /api/auth/me`, `POST /api/auth/register`, `/login`, `/logout` | Accounts |
| `GET /api/boards`, `POST /api/boards` | Your boards and invitations; new board |
| `GET`, `PATCH`, `DELETE /api/boards/:id` | Open, rename, delete a board |
| `GET`, `POST /api/boards/:id/members` | List members; invite someone |
| `POST /api/boards/:id/members/answer` | Accept or decline an invitation |
| `PATCH`, `DELETE /api/boards/:id/members/:userId` | Change access; remove someone |
| `POST /api/cards`, `PATCH`, `DELETE /api/cards/:id` | Add, change, delete cards |
| `GET`, `POST /api/tasks`, `PATCH`, `DELETE /api/tasks/:id` | My tasks; add, change, delete tasks |
