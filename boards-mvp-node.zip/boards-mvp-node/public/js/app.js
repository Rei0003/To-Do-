const app = {
  user: null,

  async start() {
    const result = await api.get('auth/me');
    app.user = result.user;
    setupBoardScreen();
    window.addEventListener('hashchange', app.route);
    app.route();
  },

  show(screenId) {
    document.querySelectorAll('.screen').forEach((screen) => { screen.hidden = screen.id !== screenId; });
  },

  route() {
    document.querySelectorAll('.modal').forEach((modal) => modal.remove());
    if (!app.user) {
      app.show('login-screen');
      showLogin();
      return;
    }

    const boardMatch = location.hash.match(/^#\/board\/(\d+)/);
    if (boardMatch) {
      app.show('board-screen');
      ui.setupAccountButton(document.querySelector('#board-screen .account-btn'));
      openBoard(Number(boardMatch[1]));
      return;
    }

    clearInterval(boardView.timer);
    app.show('home-screen');
    showHome();
  },
};

app.start();
