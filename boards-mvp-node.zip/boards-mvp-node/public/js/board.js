const boardView = { id: null, data: null, dragging: false, timer: null };

async function openBoard(boardId) {
  boardView.id = boardId;
  clearInterval(boardView.timer);
  boardView.timer = setInterval(refreshIfIdle, 5000);
  try {
    await loadBoard();
  } catch (error) {
    alert(error.message);
    location.hash = '#/boards';
  }
}

async function loadBoard() {
  boardView.data = await api.get(`boards/${boardView.id}`);
  renderBoard();
}

function refreshIfIdle() {
  const screenHidden = document.getElementById('board-screen').hidden;
  const typing = document.activeElement?.matches('input, textarea, select');
  const modalOpen = document.querySelector('.modal');
  if (!screenHidden && !typing && !modalOpen && !boardView.dragging) loadBoard().catch(() => {});
}

function canEditBoard() {
  return boardView.data.board.access !== 'view';
}

function renderBoard() {
  const { board, path, cards, tasks } = boardView.data;
  const canEdit = canEditBoard();

  const title = document.getElementById('board-title');
  title.value = board.title;
  title.disabled = !canEdit;
  document.getElementById('access-badge').hidden = canEdit;
  document.getElementById('members-btn').hidden = board.access !== 'owner';
  document.querySelector('.toolbar').hidden = !canEdit;
  document.getElementById('board-screen').classList.toggle('read-only', !canEdit);

  const parent = path[path.length - 1];
  document.getElementById('back-link').href = parent ? `#/board/${parent.id}` : '#/boards';
  document.getElementById('breadcrumbs').innerHTML = path
    .map((step) => `<a href="#/board/${step.id}">${ui.escape(step.title)}</a><span class="crumb-sep">›</span>`)
    .join('');

  const canvas = document.getElementById('canvas');
  canvas.innerHTML = cards.length ? '' : '<p class="empty-state"><strong>This board is empty</strong>Add a note, a to-do list or a board from the left.</p>';
  cards.forEach((card) => {
    const cardTasks = tasks.filter((task) => Number(task.card_id) === Number(card.id));
    let element;
    if (card.type === 'note') element = noteCard(card, canEdit);
    if (card.type === 'todo') element = todoCard(card, cardTasks, canEdit);
    if (card.type === 'board') element = boardCard(card, canEdit);
    if (canEdit) makeDraggable(element, card);
    canvas.append(element);
  });
}

function makeDraggable(element, card) {
  const bar = element.querySelector('.card-bar');
  bar.addEventListener('pointerdown', (event) => {
    if (event.target.closest('button')) return;
    event.preventDefault();
    boardView.dragging = true;
    bar.setPointerCapture(event.pointerId);
    const start = { x: event.clientX, y: event.clientY, left: card.x, top: card.y };

    const move = (moveEvent) => {
      card.x = Math.max(0, start.left + moveEvent.clientX - start.x);
      card.y = Math.max(0, start.top + moveEvent.clientY - start.y);
      element.style.left = `${card.x}px`;
      element.style.top = `${card.y}px`;
    };
    const stop = async () => {
      bar.removeEventListener('pointermove', move);
      bar.removeEventListener('pointerup', stop);
      boardView.dragging = false;
      await api.patch(`cards/${card.id}`, { x: Math.round(card.x), y: Math.round(card.y) });
    };
    bar.addEventListener('pointermove', move);
    bar.addEventListener('pointerup', stop);
  });
}

function freeSpot() {
  const viewport = document.getElementById('viewport');
  const taken = [...document.querySelectorAll('#canvas .card')].map((card) => ({
    left: card.offsetLeft, top: card.offsetTop, right: card.offsetLeft + card.offsetWidth, bottom: card.offsetTop + card.offsetHeight,
  }));
  const overlaps = (x, y) => taken.some((card) => x < card.right + 20 && x + 300 > card.left - 20 && y < card.bottom + 20 && y + 220 > card.top - 20);

  const startX = viewport.scrollLeft + 60;
  const startY = viewport.scrollTop + 50;
  for (let row = 0; row < 20; row++) {
    for (let column = 0; column < 6; column++) {
      const x = startX + column * 320;
      const y = startY + row * 240;
      if (!overlaps(x, y)) return { x, y };
    }
  }
  return { x: startX, y: startY };
}

async function addCard(type) {
  const spot = freeSpot();
  await api.post('cards', { board_id: boardView.id, type, x: spot.x, y: spot.y });
  await loadBoard();
}

function setupBoardScreen() {
  const screen = document.getElementById('board-screen');
  screen.querySelector('.brand-link').append(ui.brand());
  screen.querySelector('.theme-slot').replaceWith(ui.themeButton());
  screen.querySelectorAll('.tool').forEach((tool) => tool.addEventListener('click', () => addCard(tool.dataset.type)));
  document.getElementById('members-btn').addEventListener('click', () => openMembers(boardView.id));

  const title = document.getElementById('board-title');
  let timer = null;
  title.addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(() => api.patch(`boards/${boardView.id}`, { title: title.value.trim() || 'Untitled board' }), 500);
  });
}
