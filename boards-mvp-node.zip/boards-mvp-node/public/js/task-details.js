function openTaskDetails(task, people, canEdit, onSaved) {
  const [dueDate, dueTime] = (task.due || '').split('T');
  const modal = ui.element(`
    <div class="modal">
      <form class="modal-box" novalidate>
        <header class="modal-head"><h2>Task details</h2><button class="icon-btn" type="button" data-close aria-label="Close">×</button></header>
        <label class="field"><span>Title <em>(required)</em></span><input name="title" maxlength="200"></label>
        <p class="field-error" data-error="title" hidden></p>
        <label class="field"><span>Description</span><textarea name="description" rows="4" maxlength="2000"></textarea></label>
        <div class="field-row">
          <label class="field"><span>Due date</span><input name="date" type="date"></label>
          <label class="field"><span>Time <em>(optional)</em></span><input name="time" type="time"></label>
        </div>
        <p class="field-error" data-error="due" hidden></p>
        <div class="field-row">
          <label class="field"><span>Priority</span>
            <select name="priority"><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></label>
          <label class="field"><span>Assigned to</span>
            <select name="assignee"><option value="">Nobody</option>
              ${people.map((person) => `<option value="${person.id}">${ui.escape(person.name)}</option>`).join('')}
            </select></label>
        </div>
        <p class="field-error" data-error="server" hidden></p>
        <footer class="modal-actions">
          <button class="btn-plain" type="button" data-close>Cancel</button>
          <button class="btn-primary" type="submit">Save</button>
        </footer>
      </form>
    </div>`);

  const form = modal.querySelector('form');
  form.title.value = task.title;
  form.description.value = task.description || '';
  form.date.value = dueDate || '';
  form.time.value = dueTime || '';
  form.priority.value = task.priority;
  form.assignee.value = task.assignee_id || '';
  form.querySelectorAll('input, textarea, select').forEach((field) => { field.disabled = !canEdit; });
  form.querySelector('[type="submit"]').hidden = !canEdit;

  const showError = (name, message) => {
    const box = form.querySelector(`[data-error="${name}"]`);
    box.textContent = message;
    box.hidden = !message;
  };
  const close = () => modal.remove();

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const title = form.title.value.trim();
    showError('title', title ? '' : 'Please give the task a title.');
    showError('due', form.time.value && !form.date.value ? 'Pick a date for this time (or clear the time).' : '');
    if (!title || (form.time.value && !form.date.value)) return;

    const due = form.date.value ? form.date.value + (form.time.value ? 'T' + form.time.value : '') : '';
    try {
      await api.patch(`tasks/${task.id}`, {
        title,
        description: form.description.value.trim(),
        due,
        priority: form.priority.value,
        assignee_id: form.assignee.value ? Number(form.assignee.value) : null,
      });
      close();
      onSaved();
    } catch (error) {
      showError('server', error.message);
    }
  });

  modal.addEventListener('click', (event) => {
    if (event.target === modal || event.target.closest('[data-close]')) close();
  });
  document.body.append(modal);
  form.title.focus();
}
