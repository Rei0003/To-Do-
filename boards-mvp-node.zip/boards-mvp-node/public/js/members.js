async function openMembers(boardId) {
  const modal = ui.element(`
    <div class="modal">
      <div class="modal-box members-box">
        <header class="modal-head"><h2>Share this board</h2><button class="icon-btn" type="button" data-close aria-label="Close">×</button></header>
        <form class="invite-form" novalidate>
          <input name="email" type="email" placeholder="Email address" aria-label="Email address">
          <select name="access" aria-label="Access"><option value="edit">Can edit</option><option value="view">Can view</option></select>
          <button class="btn-primary" type="submit">Invite</button>
        </form>
        <p class="message" hidden></p>
        <ul class="people-list"></ul>
      </div>
    </div>`);
  document.body.append(modal);

  const message = modal.querySelector('.message');
  const say = (text, isError = false) => {
    message.textContent = text;
    message.hidden = !text;
    message.classList.toggle('is-error', isError);
  };

  async function showPeople() {
    const { owner, members } = await api.get(`boards/${boardId}/members`);
    const list = modal.querySelector('.people-list');
    list.innerHTML = `<li class="person"><span class="person-name"><strong>${ui.escape(owner.name)}</strong><small>${ui.escape(owner.email)}</small></span><span class="person-role">Owner</span></li>`;

    members.forEach((member) => {
      const status = { pending: 'Invited · waiting for an answer', declined: 'Declined the invitation', accepted: member.email }[member.status];
      const item = ui.element(`
        <li class="person">
          <span class="person-name"><strong>${ui.escape(member.name)}</strong><small class="status-${member.status}">${ui.escape(status)}</small></span>
          <select aria-label="Access"><option value="edit">Can edit</option><option value="view">Can view</option></select>
          <button class="icon-btn" type="button" aria-label="Remove">×</button>
        </li>`);
      const access = item.querySelector('select');
      access.value = member.access;
      access.addEventListener('change', () => api.patch(`boards/${boardId}/members/${member.id}`, { access: access.value }));
      item.querySelector('button').addEventListener('click', async () => {
        await api.remove(`boards/${boardId}/members/${member.id}`);
        showPeople();
      });
      list.append(item);
    });
  }

  modal.querySelector('.invite-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.target;
    const email = form.email.value.trim();
    if (!/^\S+@\S+\.\S+$/.test(email)) return say('Please enter a valid email address.', true);
    try {
      await api.post(`boards/${boardId}/members`, { email, access: form.access.value });
      form.email.value = '';
      say(`Invitation sent to ${email}. They get access once they accept it.`);
      showPeople();
    } catch (error) {
      say(error.message, true);
    }
  });

  modal.addEventListener('click', (event) => {
    if (event.target === modal || event.target.closest('[data-close]')) {
      modal.remove();
      loadBoard();
    }
  });
  showPeople();
  modal.querySelector('input').focus();
}
