const ui = {
  escape(text) {
    const div = document.createElement('div');
    div.textContent = text ?? '';
    return div.innerHTML;
  },

  element(markup) {
    const template = document.createElement('template');
    template.innerHTML = markup.trim();
    return template.content.firstElementChild;
  },

  copyTemplate(id) {
    return document.getElementById(id).content.firstElementChild.cloneNode(true);
  },

  brand() {
    return this.copyTemplate('brand-icon');
  },

  themeButton() {
    const button = this.copyTemplate('theme-icon');
    button.addEventListener('click', () => {
      const isDark = document.documentElement.dataset.theme
        ? document.documentElement.dataset.theme === 'dark'
        : matchMedia('(prefers-color-scheme: dark)').matches;
      const next = isDark ? 'light' : 'dark';
      document.documentElement.dataset.theme = next;
      localStorage.setItem('boards.theme', next);
    });
    return button;
  },

  setupAccountButton(button) {
    button.textContent = app.user.name.trim()[0].toUpperCase();
    button.setAttribute('aria-label', 'Account');
    button.onclick = (event) => {
      event.stopPropagation();
      ui.openAccountMenu(button);
    };
  },

  openAccountMenu(anchor) {
    ui.closeMenus();
    const menu = ui.element(`
      <div class="menu account-menu">
        <div class="account-who"><strong>${ui.escape(app.user.name)}</strong><span>${ui.escape(app.user.email)}</span></div>
        <hr>
        <button type="button" data-menu="boards">All boards</button>
        <button type="button" data-menu="logout">Log out</button>
      </div>`);
    document.body.append(menu);
    const place = anchor.getBoundingClientRect();
    menu.style.top = `${place.bottom + 6}px`;
    menu.style.right = `${window.innerWidth - place.right}px`;

    menu.addEventListener('click', async (event) => {
      const choice = event.target.closest('[data-menu]')?.dataset.menu;
      if (choice === 'boards') location.hash = '#/boards';
      if (choice === 'logout') {
        await api.post('auth/logout');
        app.user = null;
        location.hash = '#/login';
        app.route();
      }
      ui.closeMenus();
    });
  },

  closeMenus() {
    document.querySelectorAll('.menu').forEach((menu) => menu.remove());
  },

  dueState(due) {
    if (!due) return '';
    const now = new Date();
    const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    const day = due.slice(0, 10);
    if (day < today) return 'overdue';
    if (day === today) return 'today';
    return 'later';
  },

  dueLabel(due) {
    if (!due) return '';
    const [day, time] = due.split('T');
    const date = new Date(day + 'T00:00');
    const label = date.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
    return time ? `${label} ${time}` : label;
  },

  priorityLabel(priority) {
    return { low: 'Low', medium: 'Medium', high: 'High' }[priority] || 'Medium';
  },
};

document.addEventListener('click', () => ui.closeMenus());
