function cardFrame(card, canEdit) {
  const frame = ui.element(`
    <article class="card card-${card.type}" data-id="${card.id}" style="left:${card.x}px; top:${card.y}px">
      <div class="card-bar">
        <span class="card-grip"></span>
        ${canEdit ? '<button class="icon-btn card-delete" type="button" aria-label="Delete card">×</button>' : ''}
      </div>
      <div class="card-body"></div>
    </article>`);

  frame.querySelector('.card-delete')?.addEventListener('click', async () => {
    const question = card.type === 'board' ? 'Delete this board and everything inside it?' : 'Delete this card?';
    if (!confirm(question)) return;
    await api.remove(`cards/${card.id}`);
    loadBoard();
  });
  return frame;
}

function saveLater(card, field) {
  let timer = null;
  return (value) => {
    clearTimeout(timer);
    timer = setTimeout(() => api.patch(`cards/${card.id}`, { [field]: value }), 500);
  };
}

function noteCard(card, canEdit) {
  const frame = cardFrame(card, canEdit);
  const text = ui.element('<textarea class="note-text" placeholder="Write something…" maxlength="5000"></textarea>');
  text.value = card.text;
  text.disabled = !canEdit;

  const save = saveLater(card, 'text');
  const fitHeight = () => {
    text.style.height = 'auto';
    text.style.height = `${text.scrollHeight}px`;
  };
  text.addEventListener('input', () => {
    fitHeight();
    save(text.value);
  });
  frame.querySelector('.card-body').append(text);
  requestAnimationFrame(fitHeight);
  return frame;
}

function boardCard(card, canEdit) {
  const frame = cardFrame(card, canEdit);
  const body = frame.querySelector('.card-body');
  body.innerHTML = `
    <a class="board-open" href="#/board/${card.child_board_id}">
      <span class="board-preview"></span>
      <span class="board-go">Open board ›</span>
    </a>
    <input class="board-card-title" maxlength="200" aria-label="Board name">`;

  const title = body.querySelector('.board-card-title');
  title.value = card.title;
  title.disabled = !canEdit;
  const save = saveLater(card, 'title');
  title.addEventListener('input', () => save(title.value.trim() || 'Untitled board'));
  return frame;
}

function todoCard(card, tasks, canEdit) {
  const frame = cardFrame(card, canEdit);
  const body = frame.querySelector('.card-body');
  const doneCount = tasks.filter((task) => Number(task.done)).length;

  body.innerHTML = `
    <input class="todo-title" placeholder="List title" maxlength="200" aria-label="List title">
    <div class="todo-progress"><span style="width:${tasks.length ? (doneCount / tasks.length) * 100 : 0}%"></span></div>
    <ul class="todo-list"></ul>
    ${canEdit ? '<input class="todo-add" placeholder="Add a task, press Enter" maxlength="200">' : ''}`;

  const title = body.querySelector('.todo-title');
  title.value = card.title;
  title.disabled = !canEdit;
  const save = saveLater(card, 'title');
  title.addEventListener('input', () => save(title.value));

  tasks.forEach((task) => body.querySelector('.todo-list').append(taskRow(task, canEdit)));

  body.querySelector('.todo-add')?.addEventListener('keydown', async (event) => {
    const value = event.target.value.trim();
    if (event.key !== 'Enter' || !value) return;
    await api.post('tasks', { card_id: card.id, title: value });
    await loadBoard();
    document.querySelector(`.card[data-id="${card.id}"] .todo-add`)?.focus();
  });
  return frame;
}

function taskRow(task, canEdit) {
  const isMine = Number(task.assignee_id) === boardView.data.me;
  const row = ui.element(`
    <li class="todo-item ${Number(task.done) ? 'is-done' : ''}">
      <input type="checkbox" class="check" ${Number(task.done) ? 'checked' : ''} aria-label="Done">
      <div class="todo-main">
        <span class="todo-text">${ui.escape(task.title)}</span>
        ${task.description ? `<p class="todo-desc">${ui.escape(task.description)}</p>` : ''}
        <div class="todo-meta">
          <span class="chip priority-${task.priority}">${ui.priorityLabel(task.priority)}</span>
          ${task.due ? `<span class="chip due-${Number(task.done) ? 'later' : ui.dueState(task.due)}">${ui.dueLabel(task.due)}</span>` : ''}
          ${task.assignee_name ? `<span class="chip person">${ui.escape(isMine ? 'You' : task.assignee_name)}</span>` : ''}
        </div>
      </div>
      <div class="todo-actions">
        <button class="icon-btn" type="button" data-action="details" aria-label="Task details">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M3 4h10M3 8h10M3 12h6"/></svg></button>
        ${canEdit ? '<button class="icon-btn" type="button" data-action="delete" aria-label="Delete task">×</button>' : ''}
      </div>
    </li>`);

  const check = row.querySelector('.check');
  check.disabled = !canEdit && !isMine;
  check.addEventListener('change', async () => {
    await api.patch(`tasks/${task.id}`, { done: check.checked });
    loadBoard();
  });

  row.querySelector('[data-action="details"]').addEventListener('click', async () => {
    await loadBoard();
    const latest = boardView.data.tasks.find((item) => Number(item.id) === Number(task.id)) || task;
    openTaskDetails(latest, boardView.data.people, canEdit, loadBoard);
  });
  row.querySelector('[data-action="delete"]')?.addEventListener('click', async () => {
    await api.remove(`tasks/${task.id}`);
    loadBoard();
  });
  return row;
}
