const api = {
  async request(method, path, body) {
    const options = { method, credentials: 'same-origin', headers: {} };
    if (body) {
      options.headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(body);
    }

    const response = await fetch('api/' + path, options);
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data.error || 'Something went wrong. Please try again.');
      error.status = response.status;
      throw error;
    }
    return data;
  },

  get(path) {
    return this.request('GET', path);
  },

  post(path, body = {}) {
    return this.request('POST', path, body);
  },

  patch(path, body) {
    return this.request('PATCH', path, body);
  },

  remove(path, body) {
    return this.request('DELETE', path, body);
  },
};
