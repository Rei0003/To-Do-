const myTasksView = { tab: 'active', sort: 'due', priority: 'all' };

async function showHome() {
  const screen = document.getElementById('home-screen');
  const [boards, myTasks] = await Promise.all([api.get('boards'), api.get('tasks')]);

  screen.innerHTML = `
    <div class="home">
      <header class="home-head">
        <a class="home-brand" href="#/boards"><span class="brand-slot"></span><span>Boards</span></a>
        <span class="topbar-space"></span>
        <span class="theme-slot"></span>
        <button class="account-btn" type="button"></button>
      </header>
      <main class="home-body">
        <div class="home-title"><h1>Your boards</h1><p>Logged in as ${ui.escape(app.user.email)}</p></div>
        <section class="home-invites"></section>
        <section class="home-tasks"></section>
        <div class="board-grid own-boards"></div>
        <section class="home-joined"></section>
      </main>
    </div>`;
  screen.querySelector('.brand-slot').replaceWith(ui.brand());
  screen.querySelector('.theme-slot').replaceWith(ui.themeButton());
  ui.setupAccountButton(screen.querySelector('.account-btn'));

  renderInvitations(screen.querySelector('.home-invites'), boards.invitations);
  renderMyTasks(screen.querySelector('.home-tasks'), myTasks.tasks);
  renderOwnBoards(screen.querySelector('.own-boards'), boards.own);
  renderSharedBoards(screen.querySelector('.home-joined'), boards.shared);
}

function renderInvitations(section, invitations) {
  section.hidden = invitations.length === 0;
  section.innerHTML = `<h2>Invitations <span class="home-count">${invitations.length}</span></h2><ul class="invite-list"></ul>`;

  invitations.forEach((invitation) => {
    const item = ui.element(`
      <li class="invite">
        <span class="invite-text"><strong>${ui.escape(invitation.owner_name)}</strong> invited you to
          <strong>${ui.escape(invitation.title)}</strong>
          <small>${invitation.access === 'edit' ? 'Can edit' : 'Can view'}</small></span>
        <span class="invite-actions">
          <button class="btn-plain" type="button" data-answer="decline">Decline</button>
          <button class="btn-primary" type="button" data-answer="accept">Accept</button>
        </span>
      </li>`);
    item.addEventListener('click', async (event) => {
      const answer = event.target.closest('[data-answer]')?.dataset.answer;
      if (!answer) return;
      await api.post(`boards/${invitation.id}/members/answer`, { answer });
      if (answer === 'accept') location.hash = `#/board/${invitation.id}`;
      else showHome();
    });
    section.querySelector('ul').append(item);
  });
}

function sortTasks(tasks) {
  const priorityRank = { high: 0, medium: 1, low: 2 };
  const byDue = (a, b) => (a.due || '9999').localeCompare(b.due || '9999');
  const byPriority = (a, b) => priorityRank[a.priority] - priorityRank[b.priority];
  return [...tasks].sort((a, b) => (myTasksView.sort === 'due' ? byDue(a, b) || byPriority(a, b) : byPriority(a, b) || byDue(a, b)));
}

function renderMyTasks(section, tasks) {
  const active = tasks.filter((task) => !Number(task.done));
  const completed = tasks.filter((task) => Number(task.done));
  let shown = myTasksView.tab === 'active' ? active : completed;
  if (myTasksView.priority !== 'all') shown = shown.filter((task) => task.priority === myTasksView.priority);
  shown = sortTasks(shown);

  section.innerHTML = `
    <div class="tasks-head">
      <h2>My tasks</h2>
      <div class="tabs">
        <button type="button" data-tab="active" aria-selected="${myTasksView.tab === 'active'}">Active <span>${active.length}</span></button>
        <button type="button" data-tab="completed" aria-selected="${myTasksView.tab === 'completed'}">Completed <span>${completed.length}</span></button>
      </div>
      <span class="topbar-space"></span>
      <label class="control">Sort by
        <select data-control="sort"><option value="due">Deadline</option><option value="priority">Priority</option></select></label>
      <label class="control">Priority
        <select data-control="priority"><option value="all">All</option><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select></label>
    </div>
    <ul class="task-list"></ul>
    <p class="empty" ${shown.length ? 'hidden' : ''}>${tasks.length ? 'Nothing here.' : 'No tasks yet. Add a To-do list to a board.'}</p>`;
  section.querySelector('[data-control="sort"]').value = myTasksView.sort;
  section.querySelector('[data-control="priority"]').value = myTasksView.priority;

  shown.forEach((task) => {
    const row = ui.element(`
      <li class="task-row ${Number(task.done) ? 'is-done' : ''}">
        <input type="checkbox" class="check" ${Number(task.done) ? 'checked' : ''} aria-label="Done">
        <a class="task-link" href="#/board/${task.board_id}">
          <span class="task-text">${ui.escape(task.title)}</span>
          <span class="task-where">${ui.escape(task.list_title || 'To-do list')} · ${ui.escape(task.board_title)}</span>
        </a>
        <span class="chip priority-${task.priority}">${ui.priorityLabel(task.priority)}</span>
        ${task.due ? `<span class="chip due-${ui.dueState(task.due)}">${ui.dueLabel(task.due)}</span>` : ''}
      </li>`);
    row.querySelector('.check').addEventListener('change', async (event) => {
      await api.patch(`tasks/${task.id}`, { done: event.target.checked });
      task.done = event.target.checked ? 1 : 0;
      renderMyTasks(section, tasks);
    });
    section.querySelector('ul').append(row);
  });

  section.querySelectorAll('[data-tab]').forEach((tab) => tab.addEventListener('click', () => {
    myTasksView.tab = tab.dataset.tab;
    renderMyTasks(section, tasks);
  }));
  section.querySelectorAll('[data-control]').forEach((select) => select.addEventListener('change', () => {
    myTasksView[select.dataset.control] = select.value;
    renderMyTasks(section, tasks);
  }));
}

function boardTile(board, subtitle) {
  return ui.element(`
    <a class="board-tile" href="#/board/${board.id}">
      <div class="board-band"></div>
      <div class="board-name">${ui.escape(board.title)}</div>
      <div class="board-meta">${ui.escape(subtitle)}</div>
    </a>`);
}

function renderOwnBoards(grid, boards) {
  const newTile = ui.element('<button class="board-tile board-new" type="button"><span class="plus">+</span>New board</button>');
  newTile.addEventListener('click', async () => {
    const created = await api.post('boards', { title: 'Untitled board' });
    location.hash = `#/board/${created.id}`;
  });
  grid.append(newTile);

  boards.forEach((board) => {
    const tile = boardTile(board, 'Your board');
    const remove = ui.element('<button class="tile-delete" type="button" aria-label="Delete board">×</button>');
    remove.addEventListener('click', async (event) => {
      event.preventDefault();
      if (!confirm(`Delete “${board.title}” and everything on it?`)) return;
      await api.remove(`boards/${board.id}`);
      showHome();
    });
    tile.append(remove);
    grid.append(tile);
  });
}

function renderSharedBoards(section, boards) {
  section.hidden = boards.length === 0;
  section.innerHTML = '<h2>Shared with you</h2><div class="board-grid"></div>';
  boards.forEach((board) => {
    const subtitle = `${board.owner_name} · ${board.access === 'edit' ? 'Can edit' : 'Can view'}`;
    section.querySelector('.board-grid').append(boardTile(board, subtitle));
  });
}
