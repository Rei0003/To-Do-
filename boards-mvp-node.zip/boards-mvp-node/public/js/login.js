function showLogin() {
  const screen = document.getElementById('login-screen');
  let mode = 'login';

  screen.innerHTML = `
    <div class="auth">
      <form class="auth-card" novalidate>
        <div class="auth-brand"><span class="brand-slot"></span><span>Boards</span></div>
        <div class="auth-tabs" role="tablist">
          <button type="button" data-mode="login" aria-selected="true">Log in</button>
          <button type="button" data-mode="register" aria-selected="false">Create account</button>
        </div>
        <label class="auth-field name-field" hidden><span>Name</span><input name="name" autocomplete="name"></label>
        <label class="auth-field"><span>Email</span><input name="email" type="email" autocomplete="email"></label>
        <label class="auth-field"><span>Password</span><input name="password" type="password" autocomplete="current-password">
          <small class="password-hint" hidden>At least 8 characters</small></label>
        <p class="auth-error" role="alert" hidden></p>
        <button class="btn-primary auth-submit" type="submit">Log in</button>
      </form>
    </div>`;
  screen.querySelector('.brand-slot').replaceWith(ui.brand());

  const form = screen.querySelector('form');
  const errorBox = screen.querySelector('.auth-error');
  const showError = (message) => {
    errorBox.textContent = message;
    errorBox.hidden = !message;
  };

  screen.querySelectorAll('[data-mode]').forEach((tab) => {
    tab.addEventListener('click', () => {
      mode = tab.dataset.mode;
      screen.querySelectorAll('[data-mode]').forEach((other) => other.setAttribute('aria-selected', String(other === tab)));
      screen.querySelector('.name-field').hidden = mode === 'login';
      screen.querySelector('.password-hint').hidden = mode === 'login';
      form.querySelector('.auth-submit').textContent = mode === 'login' ? 'Log in' : 'Create account';
      showError('');
    });
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const password = form.password.value;

    if (mode === 'register' && !name) return showError('Please enter your name.');
    if (!/^\S+@\S+\.\S+$/.test(email)) return showError('Please enter a valid email address.');
    if (mode === 'register' && password.length < 8) return showError('The password needs at least 8 characters.');
    if (!password) return showError('Please enter your password.');

    try {
      const result = await api.post(`auth/${mode}`, { name, email, password });
      app.user = result.user;
      location.hash = '#/boards';
      app.route();
    } catch (error) {
      showError(error.message);
    }
  });

  form.email.focus();
}
