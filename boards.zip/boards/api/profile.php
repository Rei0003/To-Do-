<?php
// profile.php — your own profile: name and profile picture.
//   GET    profile.php                      you
//   POST   profile.php   (form field "avatar": an image)   new profile picture
//   PATCH  profile.php   { name }           change your name
//   DELETE profile.php                      remove your profile picture
require __DIR__ . '/db.php';
require_same_site();
$uid = require_user();
$pdo = db();

function me(int $uid): array {
    $st = db()->prepare('SELECT id, name, email, avatar FROM users WHERE id = ?');
    $st->execute([$uid]);
    $u = $st->fetch();
    return ['id' => (int)$u['id'], 'name' => $u['name'], 'email' => $u['email'], 'avatar' => avatar_url($u['id'], $u['avatar'])];
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') reply(['user' => me($uid)]);

if ($method === 'POST') {
    $f = $_FILES['avatar'] ?? null;
    if (!$f || $f['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) fail('The picture didn’t arrive. Please try again.');
    if ($f['size'] > 3 * 1024 * 1024) fail('That picture is too big (3 MB at most).', 413);
    // it must really be an image (not just named like one)
    $info = @getimagesize($f['tmp_name']);
    $types = [IMAGETYPE_PNG => 'image/png', IMAGETYPE_JPEG => 'image/jpeg', IMAGETYPE_WEBP => 'image/webp'];
    if (!$info || !isset($types[$info[2]])) fail('Please choose a PNG, JPG or WebP picture.');
    if ($info[0] > 4096 || $info[1] > 4096) fail('That picture is too large.');
    if (!move_uploaded_file($f['tmp_name'], avatar_path($uid))) fail('The picture couldn’t be saved.', 500);
    $pdo->prepare('UPDATE users SET avatar = ? WHERE id = ?')->execute([$types[$info[2]] . '|' . random_id(4), $uid]);
    reply(['user' => me($uid)]);
}

if ($method === 'PATCH') {
    $name = trim((string)(json_body()['name'] ?? ''));
    if ($name === '' || text_len($name) > 60) fail('Please enter your name (up to 60 characters).');
    $pdo->prepare('UPDATE users SET name = ? WHERE id = ?')->execute([$name, $uid]);
    reply(['user' => me($uid)]);
}

if ($method === 'DELETE') {
    @unlink(avatar_path($uid));
    $pdo->prepare('UPDATE users SET avatar = NULL WHERE id = ?')->execute([$uid]);
    reply(['user' => me($uid)]);
}

fail('Unknown request.', 405);
