<?php
// config.local.example.php — copy this file to config.local.php and fill it in.
// config.local.php holds your private settings (like your email password): don't share it or hand it in.
//
// GMAIL (free):
//   1. Turn on 2-Step Verification:  https://myaccount.google.com/security
//   2. Create an app password:       https://myaccount.google.com/apppasswords
//      (name it "Boards"; Google shows 16 letters like "abcd efgh ijkl mnop")
//   3. Put your Gmail address in 'from_email' and 'user', and the 16 letters in 'pass'.
//   4. Test it:  php api/mail-test.php you@gmail.com
return [
    'mail' => [
        'mode' => 'smtp',
        'from_email' => 'you@gmail.com',
        'from_name' => 'Boards',
        'smtp' => [
            'host' => 'smtp.gmail.com',
            'port' => 587,
            'secure' => 'tls',
            'user' => 'you@gmail.com',
            'pass' => 'abcd efgh ijkl mnop',
        ],
    ],
];
