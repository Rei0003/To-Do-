<?php
// auth.php — accounts: who am I, register, log in, log out.
//   GET  auth.php?action=me
//   POST auth.php?action=register_start   { name, email, password }   emails a 6-digit code
//   POST auth.php?action=register_verify  { email, code }              creates the account
//   POST auth.php?action=register_resend  { email }                    a new code
//   POST auth.php?action=register   { name, email, password }   (only when verify_email is off)
//   POST auth.php?action=login      { email, password }
//   POST auth.php?action=logout
require __DIR__ . '/db.php';
require __DIR__ . '/mailer.php';
require_same_site();

$action = $_GET['action'] ?? 'me';
$pdo = db();

function user_out(array $u): array {
    return ['id' => (int)$u['id'], 'name' => $u['name'], 'email' => $u['email'], 'avatar' => avatar_url($u['id'], $u['avatar'] ?? null)];
}

function log_in(array $user): void {
    session_regenerate_id(true); // a fresh session id after logging in
    $_SESSION['uid'] = (int)$user['id'];
}

if ($action === 'me') {
    $uid = current_user_id();
    if (!$uid) reply(['user' => null, 'verify_email' => !empty($CONFIG['verify_email'])]);
    $st = $pdo->prepare('SELECT id, name, email, avatar FROM users WHERE id = ?');
    $st->execute([$uid]);
    $u = $st->fetch();
    reply(['user' => $u ? user_out($u) : null]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('Use POST.', 405);

if ($action === 'logout') {
    $_SESSION = [];
    session_destroy();
    reply(['ok' => true]);
}

$body = json_body();
$email = strtolower(trim((string)($body['email'] ?? '')));
$password = (string)($body['password'] ?? '');

// ---------- registering with an emailed code ----------
const CODE_MINUTES = 15;   // a code works this long
const CODE_TRIES = 5;      // wrong guesses before a new code is needed
const RESEND_WAIT = 60;    // seconds between codes
const MAX_SENDS = 6;       // codes per sign-up (then start over later)

function check_signup_fields(string $name, string $email, string $password): void {
    if ($name === '' || text_len($name) > 60) fail('Please enter your name (up to 60 characters).');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) fail('Please enter a valid email address.');
    if (strlen($password) < 8) fail('The password needs at least 8 characters.');
    if (strlen($password) > 200) fail('That password is too long.');
}

// make a code, email it, and say how it went
function send_code(string $email, string $name): array {
    global $CONFIG;
    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $minutes = CODE_MINUTES;
    $text = "Hi $name,

Your Boards code is: $code

Type it on the sign-up page to finish creating your account. "
        . "It works for $minutes minutes.

If you didn't try to create a Boards account, you can ignore this email.";
    $safeName = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
    $html = "<div style=\"font-family:system-ui,Segoe UI,Arial,sans-serif;max-width:460px;margin:auto;color:#1e2227\">"
        . "<h2 style=\"margin:0 0 12px\">Confirm your email</h2><p>Hi $safeName,</p><p>Your Boards code is:</p>"
        . "<p style=\"font-size:32px;font-weight:800;letter-spacing:8px;margin:12px 0;padding:12px 16px;background:#f1f2f4;border-radius:10px;text-align:center\">$code</p>"
        . "<p>Type it on the sign-up page to finish creating your account. It works for $minutes minutes.</p>"
        . "<p style=\"color:#6b7280;font-size:13px\">If you didn't try to create a Boards account, you can ignore this email.</p></div>";
    $sent = send_mail($email, "Your Boards code: $code", $text, $html);
    if ($sent !== true) fail($sent, 502);
    $out = ['code_hash' => password_hash($code, PASSWORD_DEFAULT)];
    // development mode (no email set up): the sign-up screen shows the code
    if (($CONFIG['mail']['mode'] ?? 'log') === 'log') $out['dev_code'] = $code;
    return $out;
}

if ($action === 'register_start' || $action === 'register_resend') {
    $pdo->prepare('DELETE FROM pending_signups WHERE created_at < ?')->execute([time() - 86400]); // tidy old ones
    $now = time();
    if ($action === 'register_start') {
        if (empty($CONFIG['verify_email'])) fail('Use the normal sign-up.', 400);
        $name = trim((string)($body['name'] ?? ''));
        check_signup_fields($name, $email, $password);
        $st = $pdo->prepare('SELECT 1 FROM users WHERE email = ?');
        $st->execute([$email]);
        if ($st->fetch()) fail('There is already an account with this email. Try logging in.', 409);
        $st = $pdo->prepare('SELECT * FROM pending_signups WHERE email = ?');
        $st->execute([$email]);
        $old = $st->fetch();
        if ($old && $old['last_sent_at'] > $now - RESEND_WAIT) {
            fail('A code was just sent to this email. Please wait a minute before asking for another.', 429);
        }
        if ($old && $old['sends'] >= MAX_SENDS) fail('Too many codes for this email. Please try again tomorrow.', 429);
        $sent = send_code($email, $name);
        $pdo->prepare('DELETE FROM pending_signups WHERE email = ?')->execute([$email]);
        $pdo->prepare('INSERT INTO pending_signups (email, name, password_hash, code_hash, attempts, sends, expires_at, last_sent_at, created_at) VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?)')
            ->execute([$email, $name, password_hash($password, PASSWORD_DEFAULT), $sent['code_hash'], ($old['sends'] ?? 0) + 1, $now + CODE_MINUTES * 60, $now, $now]);
    } else {
        $st = $pdo->prepare('SELECT * FROM pending_signups WHERE email = ?');
        $st->execute([$email]);
        $old = $st->fetch();
        if (!$old) fail('Please fill in the sign-up form again.', 404);
        if ($old['last_sent_at'] > $now - RESEND_WAIT) fail('Please wait a minute before asking for another code.', 429);
        if ($old['sends'] >= MAX_SENDS) fail('Too many codes for this email. Please try again tomorrow.', 429);
        $sent = send_code($email, $old['name']);
        $pdo->prepare('UPDATE pending_signups SET code_hash = ?, attempts = 0, sends = sends + 1, expires_at = ?, last_sent_at = ? WHERE email = ?')
            ->execute([$sent['code_hash'], $now + CODE_MINUTES * 60, $now, $email]);
    }
    reply(['pending' => true, 'email' => $email, 'resend_in' => RESEND_WAIT, 'minutes' => CODE_MINUTES]
        + (isset($sent['dev_code']) ? ['dev_code' => $sent['dev_code']] : []));
}

if ($action === 'register_verify') {
    $code = preg_replace('/\D/', '', (string)($body['code'] ?? ''));
    $st = $pdo->prepare('SELECT * FROM pending_signups WHERE email = ?');
    $st->execute([$email]);
    $p = $st->fetch();
    if (!$p) fail('Please fill in the sign-up form again.', 404);
    if ($p['expires_at'] < time()) fail('That code has expired. Ask for a new one.', 410);
    if ($p['attempts'] >= CODE_TRIES) fail('Too many wrong codes. Ask for a new one.', 429);
    if (strlen($code) !== 6 || !password_verify($code, $p['code_hash'])) {
        $pdo->prepare('UPDATE pending_signups SET attempts = attempts + 1 WHERE email = ?')->execute([$email]);
        $left = CODE_TRIES - $p['attempts'] - 1;
        fail($left > 0 ? "That code isn’t right. $left tr" . ($left === 1 ? 'y' : 'ies') . ' left.' : 'Too many wrong codes. Ask for a new one.', 400);
    }
    // the email is real: create the account
    $exists = $pdo->prepare('SELECT 1 FROM users WHERE email = ?');
    $exists->execute([$email]);
    if ($exists->fetch()) { $pdo->prepare('DELETE FROM pending_signups WHERE email = ?')->execute([$email]); fail('There is already an account with this email. Try logging in.', 409); }
    $pdo->prepare('INSERT INTO users (email, name, password_hash, created_at) VALUES (?, ?, ?, ?)')
        ->execute([$email, $p['name'], $p['password_hash'], time()]);
    $pdo->prepare('DELETE FROM pending_signups WHERE email = ?')->execute([$email]);
    $user = ['id' => (int)$pdo->lastInsertId(), 'name' => $p['name'], 'email' => $email];
    log_in($user);
    reply(['user' => user_out($user)], 201);
}

if ($action === 'register') {
    if (!empty($CONFIG['verify_email'])) fail('Please confirm your email: sign up again to get a code.', 400);
    $name = trim((string)($body['name'] ?? ''));
    if ($name === '' || text_len($name) > 60) fail('Please enter your name (up to 60 characters).');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) fail('Please enter a valid email address.');
    if (strlen($password) < 8) fail('The password needs at least 8 characters.');
    if (strlen($password) > 200) fail('That password is too long.');

    $st = $pdo->prepare('SELECT 1 FROM users WHERE email = ?');
    $st->execute([$email]);
    if ($st->fetch()) fail('There is already an account with this email. Try logging in.', 409);

    $st = $pdo->prepare('INSERT INTO users (email, name, password_hash, created_at) VALUES (?, ?, ?, ?)');
    $st->execute([$email, $name, password_hash($password, PASSWORD_DEFAULT), time()]);
    $user = ['id' => (int)$pdo->lastInsertId(), 'name' => $name, 'email' => $email];
    log_in($user);
    reply(['user' => user_out($user)], 201);
}

if ($action === 'login') {
    // slow down password guessing: 5 wrong tries per 15 minutes per email
    $pdo->prepare('DELETE FROM login_attempts WHERE at < ?')->execute([time() - 900]);
    $st = $pdo->prepare('SELECT COUNT(*) FROM login_attempts WHERE email = ?');
    $st->execute([$email]);
    if ((int)$st->fetchColumn() >= 5) fail('Too many wrong passwords. Please wait a few minutes and try again.', 429);

    $st = $pdo->prepare('SELECT * FROM users WHERE email = ?');
    $st->execute([$email]);
    $user = $st->fetch();
    if (!$user || !password_verify($password, $user['password_hash'])) {
        $pdo->prepare('INSERT INTO login_attempts (email, at) VALUES (?, ?)')->execute([$email, time()]);
        fail('Wrong email or password.', 401);
    }
    $pdo->prepare('DELETE FROM login_attempts WHERE email = ?')->execute([$email]);
    if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
        $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
            ->execute([password_hash($password, PASSWORD_DEFAULT), $user['id']]);
    }
    log_in($user);
    gc_files((int)$user['id']);
    reply(['user' => user_out($user)]);
}

fail('Unknown action.', 404);
