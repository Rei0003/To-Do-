<?php
// link-preview.php?url=… — title, description, picture and icon of a web page, for link cards.
// The server fetches the page (browsers aren't allowed to read other websites). For safety it only
// goes to public websites (never this computer or your home/school network), follows at most 3
// redirects, reads at most 1 MB, and gives up after a few seconds. Results are cached for a week.
require __DIR__ . '/db.php';
require_same_site();
require_user();

$url = trim((string)($_GET['url'] ?? ''));
if (!preg_match('~^https?://~i', $url) || strlen($url) > 2000) fail('That doesn’t look like a web address.');
if (!function_exists('curl_init')) fail('Link previews need PHP’s curl extension (turn on "extension=curl" in php.ini).', 501);

// cached?
$hash = hash('sha256', $url);
$st = db()->prepare('SELECT data, fetched_at FROM link_previews WHERE url_hash = ?');
$st->execute([$hash]);
if (($row = $st->fetch()) && $row['fetched_at'] > time() - 7 * 86400 && empty($_GET['refresh'])) reply(json_decode($row['data'], true));

// ---------- only public addresses ----------
function public_ip(string $host): ?string {
    global $CONFIG;
    $ips = filter_var($host, FILTER_VALIDATE_IP) ? [$host] : (gethostbynamel($host) ?: []);
    foreach ($ips as $ip) {
        if (!empty($CONFIG['link_preview_allow_private'])) return $ip; // (testing only)
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return $ip;
    }
    return null;
}

function fetch_page(string $url, int $hops = 0): array {
    if ($hops > 3) fail('That link redirects too many times.');
    $p = parse_url($url);
    $scheme = strtolower($p['scheme'] ?? '');
    $host = $p['host'] ?? '';
    if (!in_array($scheme, ['http', 'https'], true) || $host === '') fail('That doesn’t look like a web address.');
    $port = (int)($p['port'] ?? ($scheme === 'https' ? 443 : 80));
    if (!in_array($port, [80, 443, 8080, 8443], true) && empty($GLOBALS['CONFIG']['link_preview_allow_private'])) fail('That address can’t be previewed.');
    $ip = public_ip(trim($host, '[]'));
    if (!$ip) fail('That address can’t be previewed (it isn’t a public website).');

    $body = '';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RESOLVE => ["$host:$port:$ip"],          // use the address we checked (no DNS tricks)
        CURLOPT_RETURNTRANSFER => false,
        CURLOPT_FOLLOWLOCATION => false,                 // redirects are checked one by one below
        CURLOPT_CONNECTTIMEOUT => 4,
        CURLOPT_TIMEOUT => 7,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; BoardsLinkPreview/1.0)',
        CURLOPT_HTTPHEADER => ['Accept: text/html,application/xhtml+xml', 'Accept-Language: en,lv;q=0.8'],
        CURLOPT_ENCODING => '',
        CURLOPT_WRITEFUNCTION => function ($ch, $chunk) use (&$body) {
            $body .= $chunk;
            return strlen($body) > 1024 * 1024 ? 0 : strlen($chunk); // stop after 1 MB
        },
    ]);
    if (defined('CURLOPT_PROTOCOLS')) curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);
    curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $type = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $next = curl_getinfo($ch, CURLINFO_REDIRECT_URL);
    $err = curl_errno($ch);
    curl_close($ch);
    if ($code >= 300 && $code < 400 && $next) return fetch_page($next, $hops + 1);
    if ($err && $err !== CURLE_WRITE_ERROR && !$body) fail('That page couldn’t be reached.', 502);
    if ($code >= 400 || !$code) fail("That page answered with an error ($code).", 502);
    return [$url, $type, $body];
}

[$final, $type, $html] = fetch_page($url);
$host = parse_url($final, PHP_URL_HOST);
$out = ['url' => $url, 'final' => $final, 'site' => preg_replace('/^www\./', '', (string)$host),
    'title' => null, 'description' => null, 'image' => null, 'icon' => null];

// make relative addresses absolute
$abs = function (?string $u) use ($final) {
    $u = trim((string)$u);
    if ($u === '' || str_starts_with($u, 'data:')) return null;
    if (preg_match('~^https?://~i', $u)) return $u;
    $p = parse_url($final);
    $base = $p['scheme'] . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '');
    if (str_starts_with($u, '//')) return $p['scheme'] . ':' . $u;
    if (str_starts_with($u, '/')) return $base . $u;
    return $base . rtrim(dirname($p['path'] ?? '/'), '/') . '/' . $u;
};
$clean = fn($s, $max) => $s === null ? null : text_cut(trim(preg_replace('/\s+/u', ' ', html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8'))), $max);

if (str_contains($type, 'image/')) {
    $out['image'] = $final;               // the link is a picture itself
    $out['title'] = basename(parse_url($final, PHP_URL_PATH) ?: $final);
} elseif (str_contains($type, 'html') || $type === '') {
    // pages in other encodings
    if (preg_match('~charset=["\']?([\w-]+)~i', $type . ' ' . substr($html, 0, 2048), $m) && strtolower($m[1]) !== 'utf-8' && function_exists('iconv')) {
        $html = @iconv($m[1], 'UTF-8//IGNORE', $html) ?: $html;
    }
    $doc = new DOMDocument();
    libxml_use_internal_errors(true);
    $doc->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NONET | LIBXML_NOWARNING | LIBXML_NOERROR);
    libxml_clear_errors();
    $meta = [];
    foreach ($doc->getElementsByTagName('meta') as $m) {
        $k = strtolower($m->getAttribute('property') ?: $m->getAttribute('name'));
        if ($k && !isset($meta[$k])) $meta[$k] = $m->getAttribute('content');
    }
    $titleTag = $doc->getElementsByTagName('title')->item(0);
    $out['title'] = $clean($meta['og:title'] ?? $meta['twitter:title'] ?? ($titleTag ? $titleTag->textContent : null), 200);
    $out['description'] = $clean($meta['og:description'] ?? $meta['twitter:description'] ?? $meta['description'] ?? null, 300);
    $out['image'] = $abs($meta['og:image'] ?? $meta['og:image:url'] ?? $meta['twitter:image'] ?? $meta['twitter:image:src'] ?? null);
    if (!empty($meta['og:site_name'])) $out['site_name'] = $clean($meta['og:site_name'], 80);
    // the site's icon: the biggest one listed, or /favicon.ico
    $best = null;
    $bestSize = -1;
    foreach ($doc->getElementsByTagName('link') as $l) {
        $rel = strtolower($l->getAttribute('rel'));
        if (!preg_match('/\b(icon|apple-touch-icon)\b/', $rel)) continue;
        $size = (int)($l->getAttribute('sizes') ?: (str_contains($rel, 'apple') ? 180 : 16));
        if ($size > $bestSize && $size <= 256) { $best = $l->getAttribute('href'); $bestSize = $size; }
    }
    $out['icon'] = $abs($best ?: '/favicon.ico');
}
$out['fetched_at'] = time();

db()->prepare('DELETE FROM link_previews WHERE url_hash = ? OR fetched_at < ?')->execute([$hash, time() - 30 * 86400]);
db()->prepare('INSERT INTO link_previews (url_hash, data, fetched_at) VALUES (?, ?, ?)')->execute([$hash, json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), time()]);
reply($out);
