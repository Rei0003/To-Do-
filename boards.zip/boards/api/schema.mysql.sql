-- schema.mysql.sql — only needed if you use MySQL instead of SQLite (see config.php).
-- In phpMyAdmin: create a database called "boards", open it, and run this in the SQL tab.
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(190) NOT NULL UNIQUE,
  name VARCHAR(60) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  avatar VARCHAR(64) NULL,             -- profile picture: "<mime>|<version>"
  created_at BIGINT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS boards (
  id VARCHAR(32) PRIMARY KEY,
  user_id INT NOT NULL,
  title VARCHAR(200) NOT NULL,
  data LONGTEXT NOT NULL,
  card_count INT NOT NULL DEFAULT 0,
  rev INT NOT NULL DEFAULT 1,
  parent_id VARCHAR(32) NULL,          -- a board inside another board
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  INDEX boards_user (user_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS files (
  id VARCHAR(64) PRIMARY KEY,
  user_id INT NOT NULL,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(150) NOT NULL,
  size BIGINT NOT NULL,
  created_at BIGINT NOT NULL,
  INDEX files_user (user_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS login_attempts (
  email VARCHAR(190) NOT NULL,
  at BIGINT NOT NULL,
  INDEX login_attempts_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS board_members (
  board_id VARCHAR(32) NOT NULL,
  email VARCHAR(190) NOT NULL,
  role VARCHAR(10) NOT NULL,
  cards MEDIUMTEXT NOT NULL,
  hide_others TINYINT NOT NULL DEFAULT 0,
  member_role VARCHAR(32) NULL,        -- a custom role (team_roles.id)
  created_at BIGINT NOT NULL,
  PRIMARY KEY (board_id, email),
  INDEX members_email (email),
  FOREIGN KEY (board_id) REFERENCES boards(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS comments (
  id VARCHAR(32) PRIMARY KEY,
  board_id VARCHAR(32) NOT NULL,
  user_id INT NOT NULL,
  parent_id VARCHAR(32) NULL,
  card_id VARCHAR(64) NULL,
  text TEXT NOT NULL,
  resolved TINYINT NOT NULL DEFAULT 0,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  INDEX comments_board (board_id),
  FOREIGN KEY (board_id) REFERENCES boards(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Already created the tables before boards could be nested? Run this once:
-- ALTER TABLE boards ADD COLUMN parent_id VARCHAR(32) NULL;
-- Profile pictures (run once if your tables are older):
-- ALTER TABLE users ADD COLUMN avatar VARCHAR(64) NULL;

CREATE TABLE IF NOT EXISTS team_roles (
  id VARCHAR(32) PRIMARY KEY,
  owner_id INT NOT NULL,
  name VARCHAR(40) NOT NULL,
  color VARCHAR(12) NOT NULL,
  access VARCHAR(10) NULL,
  created_at BIGINT NOT NULL,
  INDEX roles_owner (owner_id),
  FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
-- Older tables? Run once: ALTER TABLE board_members ADD COLUMN member_role VARCHAR(32) NULL;

CREATE TABLE IF NOT EXISTS pending_signups (
  email VARCHAR(190) PRIMARY KEY,
  name VARCHAR(60) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  code_hash VARCHAR(255) NOT NULL,
  attempts INT NOT NULL DEFAULT 0,
  sends INT NOT NULL DEFAULT 1,
  expires_at BIGINT NOT NULL,
  last_sent_at BIGINT NOT NULL,
  created_at BIGINT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
