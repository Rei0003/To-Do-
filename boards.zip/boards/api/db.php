<?php
// db.php — shared by every API file: settings, database, sessions, JSON replies, safety checks.
declare(strict_types=1);

$CONFIG = require __DIR__ . '/config.php';

// ---------- replies ----------
function reply($data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function fail(string $message, int $status = 400): void {
    reply(['error' => $message], $status);
}

// ---------- sessions (login stays in a secure cookie) ----------
session_name('boards_sid');
session_set_cookie_params([
    'lifetime' => 60 * 60 * 24 * 30,  // stay logged in for 30 days
    'path'     => '/',
    'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,               // scripts can't read the cookie
    'samesite' => 'Lax',
]);
session_start();

// any unexpected problem: a short JSON error (details go to the server's error log only)
set_exception_handler(function (Throwable $e) {
    error_log('Boards API: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) reply(['error' => 'Something went wrong on the server. Please try again.'], 500);
});

// ---------- database ----------
function db(): PDO {
    static $pdo = null;
    global $CONFIG;
    if ($pdo) return $pdo;
    try {
        if (str_starts_with($CONFIG['db_dsn'], 'sqlite:')) {
            $dir = dirname(substr($CONFIG['db_dsn'], 7));
            if (!is_dir($dir)) mkdir($dir, 0775, true);
        }
        $pdo = new PDO($CONFIG['db_dsn'], $CONFIG['db_user'], $CONFIG['db_pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    } catch (Throwable $e) {
        fail('The server can’t open its database. Check api/config.php.', 500);
    }
    if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite') {
        // wait a moment if another request is writing (instead of failing straight away).
        // (WAL mode would be faster but breaks on some disks, e.g. network or cloud-synced folders.)
        $pdo->exec('PRAGMA busy_timeout = 5000; PRAGMA foreign_keys = ON;');
        // tables are created automatically the first time (MySQL: run schema.mysql.sql instead)
        $pdo->exec('
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                created_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS boards (
                id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                title TEXT NOT NULL,
                data TEXT NOT NULL,
                card_count INTEGER NOT NULL DEFAULT 0,
                rev INTEGER NOT NULL DEFAULT 1,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            );
            CREATE INDEX IF NOT EXISTS boards_user ON boards(user_id);
            CREATE TABLE IF NOT EXISTS files (
                id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                name TEXT NOT NULL,
                type TEXT NOT NULL,
                size INTEGER NOT NULL,
                created_at INTEGER NOT NULL
            );
            CREATE INDEX IF NOT EXISTS files_user ON files(user_id);
            CREATE TABLE IF NOT EXISTS login_attempts (
                email TEXT NOT NULL,
                at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS board_members (
                board_id TEXT NOT NULL REFERENCES boards(id) ON DELETE CASCADE,
                email TEXT NOT NULL,
                role TEXT NOT NULL,                 -- edit | view | cards
                cards TEXT NOT NULL DEFAULT \'[]\',  -- for "cards": which cards they may edit
                hide_others INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL,
                PRIMARY KEY (board_id, email)
            );
            CREATE INDEX IF NOT EXISTS members_email ON board_members(email);
            CREATE TABLE IF NOT EXISTS comments (
                id TEXT PRIMARY KEY,
                board_id TEXT NOT NULL REFERENCES boards(id) ON DELETE CASCADE,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                parent_id TEXT,                     -- a reply: the comment it answers
                card_id TEXT,                       -- about a card (or null = the whole board)
                text TEXT NOT NULL,
                resolved INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            );
            CREATE INDEX IF NOT EXISTS comments_board ON comments(board_id);
            CREATE TABLE IF NOT EXISTS team_roles (
                id TEXT PRIMARY KEY,
                owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                name TEXT NOT NULL,
                color TEXT NOT NULL,
                access TEXT,                        -- suggested access when inviting with this role
                created_at INTEGER NOT NULL
            );
            CREATE INDEX IF NOT EXISTS roles_owner ON team_roles(owner_id);
            CREATE TABLE IF NOT EXISTS comment_reads (
                board_id TEXT NOT NULL,
                user_id INTEGER NOT NULL,
                seen_at INTEGER NOT NULL,       -- when they last looked at the comments
                PRIMARY KEY (board_id, user_id)
            );
            CREATE TABLE IF NOT EXISTS link_previews (
                url_hash TEXT PRIMARY KEY,
                data TEXT NOT NULL,
                fetched_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS pending_signups (
                email TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                code_hash TEXT NOT NULL,       -- the emailed code, hashed like a password
                attempts INTEGER NOT NULL DEFAULT 0,
                sends INTEGER NOT NULL DEFAULT 1,
                expires_at INTEGER NOT NULL,
                last_sent_at INTEGER NOT NULL,
                created_at INTEGER NOT NULL
            );
        ');
        // custom roles on invited people: add the column to older databases
        $mcols = array_column($pdo->query('PRAGMA table_info(board_members)')->fetchAll(), 'name');
        if (!in_array('member_role', $mcols, true)) $pdo->exec('ALTER TABLE board_members ADD COLUMN member_role TEXT');
        // boards inside boards: add the parent link to databases made before it existed
        $cols = array_column($pdo->query('PRAGMA table_info(boards)')->fetchAll(), 'name');
        // profile pictures: add the column to databases made before they existed
        $ucols = array_column($pdo->query('PRAGMA table_info(users)')->fetchAll(), 'name');
        if (!in_array('avatar', $ucols, true)) $pdo->exec('ALTER TABLE users ADD COLUMN avatar TEXT');
        if (!in_array('parent_id', $cols, true)) {
            $pdo->exec('ALTER TABLE boards ADD COLUMN parent_id TEXT');
            $pdo->exec('CREATE INDEX IF NOT EXISTS boards_parent ON boards(parent_id)');
        }
    }
    return $pdo;
}

// ---------- safety ----------
// Changes must come from our own page: browsers won't send this custom header from other
// websites without asking first, which blocks "cross-site request forgery".
function require_same_site(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET' && ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'boards') {
        fail('Request blocked.', 403);
    }
}

function current_user_id(): ?int {
    return isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : null;
}
function require_user(): int {
    $uid = current_user_id();
    if (!$uid) fail('Please log in.', 401);
    return $uid;
}

function json_body(): array {
    $raw = file_get_contents('php://input') ?: '';
    $data = json_decode($raw, true);
    if (!is_array($data)) fail('Invalid request.');
    return $data;
}

// text length / shortening that works with or without PHP's mbstring extension
function text_len(string $s): int {
    return function_exists('mb_strlen') ? mb_strlen($s) : preg_match_all('/./us', $s);
}
function text_cut(string $s, int $max): string {
    if (function_exists('mb_substr')) return mb_substr($s, 0, $max);
    preg_match('/^.{0,' . $max . '}/us', $s, $m);
    return $m[0] ?? '';
}

function random_id(int $bytes = 8): string {
    return bin2hex(random_bytes($bytes));
}

function user_dir(int $uid): string {
    global $CONFIG;
    $dir = $CONFIG['uploads_dir'] . '/' . $uid;
    if (!is_dir($dir)) mkdir($dir, 0775, true);
    return $dir;
}

// ---------- profile pictures ----------
// users.avatar = "<mime>|<version>" (the version changes with every new picture, so browsers can cache it)
function avatar_url($userId, $avatar): ?string {
    if (!$avatar || !$userId) return null;
    $version = explode('|', (string)$avatar)[1] ?? '1';
    return 'api/avatar.php?id=' . (int)$userId . '&v=' . rawurlencode($version);
}
function avatar_path(int $userId): string {
    global $CONFIG;
    $dir = $CONFIG['uploads_dir'] . '/avatars';
    if (!is_dir($dir)) mkdir($dir, 0775, true);
    return $dir . '/' . $userId;
}

// ---------- who may do what with a board ----------
function user_email(int $uid): string {
    static $cache = [];
    if (!isset($cache[$uid])) {
        $st = db()->prepare('SELECT email FROM users WHERE id = ?');
        $st->execute([$uid]);
        $cache[$uid] = (string)$st->fetchColumn();
    }
    return $cache[$uid];
}

/**
 * The requester's access to a board, or null if they have none.
 * role: owner | edit | view | cards   (cards = may only edit the listed cards)
 */
function board_access(string $boardId, int $uid, int $depth = 0): ?array {
    $st = db()->prepare('SELECT b.*, u.name AS owner_name, u.email AS owner_email, u.avatar AS owner_avatar FROM boards b JOIN users u ON u.id = b.user_id WHERE b.id = ?');
    $st->execute([$boardId]);
    $b = $st->fetch();
    if (!$b) return null;
    if ((int)$b['user_id'] === $uid) return ['board' => $b, 'role' => 'owner', 'cards' => [], 'hide' => false];
    $m = db()->prepare('SELECT * FROM board_members WHERE board_id = ? AND email = ?');
    $m->execute([$boardId, user_email($uid)]);
    $row = $m->fetch();
    if ($row) {
        return [
            'board' => $b,
            'role' => $row['role'],
            'cards' => json_decode($row['cards'], true) ?: [],
            'hide' => (bool)$row['hide_others'],
        ];
    }
    // a board inside another board: the same access as the parent board gives
    if (!empty($b['parent_id']) && $depth < 20) {
        $p = board_access($b['parent_id'], $uid, $depth + 1);
        if (!$p) return null;
        $role = $p['role'];
        if ($role === 'cards') {
            // only through a board card they may edit (edit inside); otherwise view, or nothing if hidden
            $pdata = json_decode($p['board']['data'], true);
            $byId = cards_by_id($pdata['cards'] ?? []);
            $allowed = false;
            $exists = false;
            foreach ($pdata['cards'] ?? [] as $c) {
                if (($c['type'] ?? '') === 'board' && ($c['boardId'] ?? '') === $boardId) {
                    $exists = true;
                    if (in_array(top_card_id($c, $byId), $p['cards'], true)) $allowed = true;
                }
            }
            if ($allowed) $role = 'edit';
            elseif ($exists && !$p['hide']) $role = 'view';
            else return null;
        }
        return ['board' => $b, 'role' => $role, 'cards' => [], 'hide' => false, 'inherited' => true];
    }
    return null;
}

// the boards a board sits in (top first), as far as this person can see them
function board_path(array $board, int $uid): array {
    $path = [];
    $pid = $board['parent_id'] ?? null;
    for ($i = 0; $pid && $i < 20; $i++) {
        $acc = board_access($pid, $uid);
        if (!$acc) break;
        array_unshift($path, ['id' => $acc['board']['id'], 'title' => $acc['board']['title']]);
        $pid = $acc['board']['parent_id'] ?? null;
    }
    return $path;
}

// every board inside a board (children, grandchildren…)
function descendant_ids(string $id): array {
    $out = [];
    $queue = [$id];
    $st = db()->prepare('SELECT id FROM boards WHERE parent_id = ?');
    while ($queue && count($out) < 2000) {
        $st->execute([array_shift($queue)]);
        foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $child) { $out[] = $child; $queue[] = $child; }
    }
    return $out;
}

// the card on the board (top level) that a card sits in
function top_card_id(array $card, array $byId): string {
    $seen = 0;
    while (!empty($card['parent']) && isset($byId[$card['parent']]) && $seen++ < 50) $card = $byId[$card['parent']];
    return (string)($card['id'] ?? '');
}
function cards_by_id(array $cards): array {
    $out = [];
    foreach ($cards as $c) if (is_array($c) && isset($c['id'])) $out[$c['id']] = $c;
    return $out;
}

// what a member with "cards + hide the others" is allowed to see
function visible_data(array $data, array $access): array {
    if ($access['role'] !== 'cards' || !$access['hide']) return $data;
    $allowed = array_flip($access['cards']);
    $byId = cards_by_id($data['cards'] ?? []);
    $keep = [];
    foreach ($data['cards'] ?? [] as $c) {
        if (isset($allowed[top_card_id($c, $byId)])) $keep[] = $c;
    }
    $ids = array_flip(array_column($keep, 'id'));
    $data['cards'] = $keep;
    $data['connections'] = array_values(array_filter($data['connections'] ?? [], fn($w) =>
        isset($ids[$w['from']['card'] ?? '']) && isset($ids[$w['to']['card'] ?? ''])));
    return $data;
}

/**
 * A "cards" member saved: take only their changes to the cards they may edit
 * (and things attached inside those). Everything else stays as it was.
 */
function merge_member_changes(array $stored, array $incoming, array $allowedIds): array {
    $allowed = array_flip($allowedIds);
    $oldById = cards_by_id($stored['cards'] ?? []);
    $newById = cards_by_id($incoming['cards'] ?? []);
    $result = [];
    foreach ($stored['cards'] ?? [] as $c) {
        $editable = isset($allowed[top_card_id($c, $oldById)]);
        if (!$editable) { $result[] = $c; continue; }
        if (isset($newById[$c['id']])) {
            $n = $newById[$c['id']];
            $n['parent'] = $c['parent'] ?? null;         // they can't move cards in or out
            if ($n['parent'] === null) unset($n['parent']);
            $result[] = $n;
        } elseif (empty($c['parent'])) {
            $result[] = $c;                              // they can't delete the shared card itself
        }                                                // (attachments inside it they may delete)
    }
    // new attachments added inside a card they may edit
    foreach ($incoming['cards'] ?? [] as $c) {
        if (!is_array($c) || !isset($c['id']) || isset($oldById[$c['id']]) || empty($c['parent'])) continue;
        if (isset($allowed[top_card_id($c, $newById)])) $result[] = $c;
    }
    $stored['cards'] = $result;
    return $stored;
}

// the board's comments this person may see (none about cards hidden from them)
function visible_comments(array $access): array {
    $st = db()->prepare('SELECT c.*, u.name AS author_name, u.email AS author_email, u.avatar AS author_avatar FROM comments c
        JOIN users u ON u.id = c.user_id WHERE c.board_id = ? ORDER BY c.created_at, c.id');
    $st->execute([$access['board']['id']]);
    $rows = $st->fetchAll();
    if ($access['role'] === 'cards' && $access['hide']) {
        $visible = array_flip(array_column(visible_data(json_decode($access['board']['data'], true), $access)['cards'], 'id'));
        $hiddenThreads = [];
        foreach ($rows as $r) if ($r['card_id'] && !isset($visible[$r['card_id']])) $hiddenThreads[$r['id']] = true;
        $rows = array_values(array_filter($rows, fn($r) =>
            !isset($hiddenThreads[$r['id']]) && !($r['parent_id'] && isset($hiddenThreads[$r['parent_id']]))));
    }
    return $rows;
}
function open_comment_count(array $access): int {
    return count(array_filter(visible_comments($access), fn($r) => !$r['parent_id'] && !$r['resolved']));
}
// when this person last opened the board's comments (0 = never)
function comments_seen_at(string $boardId, int $uid): int {
    $st = db()->prepare('SELECT seen_at FROM comment_reads WHERE board_id = ? AND user_id = ?');
    $st->execute([$boardId, $uid]);
    return (int)$st->fetchColumn();
}
// new comments and replies from other people since then
function unread_comment_count(array $access, int $uid): int {
    $seen = comments_seen_at($access['board']['id'], $uid);
    return count(array_filter(visible_comments($access), fn($r) => (int)$r['user_id'] !== $uid && (int)$r['created_at'] > $seen));
}

// ---------- custom roles (a board owner's own labels, like "Junior dev") ----------
const ROLE_COLORS = ['blue', 'green', 'purple', 'pink', 'orange', 'red', 'yellow', 'teal', 'gray'];
function roles_of_owner(int $ownerId): array {
    $st = db()->prepare('SELECT id, name, color, access FROM team_roles WHERE owner_id = ? ORDER BY created_at, name');
    $st->execute([$ownerId]);
    return $st->fetchAll();
}
function role_out(?array $r): ?array {
    return $r ? ['id' => $r['id'], 'name' => $r['name'], 'color' => $r['color'], 'access' => $r['access'] ?: null] : null;
}

// ---------- task history (for team stats) ----------
// The server stamps tasks itself when a board is saved, so the times can't be faked from a browser:
//   created_at · assigned_at (when the current assignee was set) · started_at (moved to "In progress")
//   · done_at + done_by (user id). A task's stage (status: todo / doing / done) and done stay in step.
function stamp_tasks(?array $old, array $new, int $uid): array {
    $now = time();
    $before = [];
    foreach ($old['cards'] ?? [] as $c) {
        if (($c['type'] ?? '') !== 'todo') continue;
        foreach ($c['items'] ?? [] as $it) if (isset($it['id'])) $before[$it['id']] = $it;
    }
    foreach ($new['cards'] as &$c) {
        if (($c['type'] ?? '') !== 'todo' || !is_array($c['items'] ?? null)) continue;
        foreach ($c['items'] as &$it) {
            if (!is_array($it) || !isset($it['id'])) continue;
            $o = $before[$it['id']] ?? null;
            $assignee = strtolower((string)($it['assignee'] ?? ''));
            // the stage decides "done" (older tasks only have done)
            $status = in_array($it['status'] ?? null, ['todo', 'doing', 'done'], true) ? $it['status'] : (!empty($it['done']) ? 'done' : 'todo');
            $it['status'] = $status;
            $it['done'] = $status === 'done';
            $done = $it['done'];
            $oldStatus = $o ? (in_array($o['status'] ?? null, ['todo', 'doing', 'done'], true) ? $o['status'] : (!empty($o['done']) ? 'done' : 'todo')) : null;
            // never trust stamps sent by the browser: start from what the server had
            foreach (['created_at', 'assigned_at', 'started_at', 'done_at', 'done_by'] as $k) unset($it[$k]);
            if ($status === 'doing' && $oldStatus !== 'doing') $it['started_at'] = $now;
            elseif ($status !== 'todo' && isset($o['started_at'])) $it['started_at'] = $o['started_at'];
            if (!$o) {
                $it['created_at'] = $now;
                if ($assignee !== '') $it['assigned_at'] = $now;
                if ($done) { $it['done_at'] = $now; $it['done_by'] = $uid; }
                continue;
            }
            if (isset($o['created_at'])) $it['created_at'] = $o['created_at'];
            $oldAssignee = strtolower((string)($o['assignee'] ?? ''));
            if ($assignee !== $oldAssignee) { if ($assignee !== '') $it['assigned_at'] = $now; }
            elseif (isset($o['assigned_at'])) $it['assigned_at'] = $o['assigned_at'];
            if ($done && empty($o['done'])) { $it['done_at'] = $now; $it['done_by'] = $uid; }
            elseif ($done) {
                if (isset($o['done_at'])) $it['done_at'] = $o['done_at'];
                if (isset($o['done_by'])) $it['done_by'] = $o['done_by'];
            }
        }
        unset($it);
    }
    unset($c);
    return $new;
}

// boards the user owns or has been invited to
function accessible_board_ids(int $uid): array {
    $st = db()->prepare('SELECT id FROM boards WHERE user_id = ? UNION SELECT board_id FROM board_members WHERE email = ?');
    $st->execute([$uid, user_email($uid)]);
    $ids = $st->fetchAll(PDO::FETCH_COLUMN);
    // plus the boards inside them
    foreach ($ids as $id) foreach (descendant_ids($id) as $d) $ids[] = $d;
    return array_values(array_unique($ids));
}

// may this user read this uploaded file? (theirs, or used on a board they can see)
function can_read_file(int $uid, array $file): bool {
    if ((int)$file['user_id'] === $uid) return true;
    foreach (accessible_board_ids($uid) as $bid) {
        $acc = board_access($bid, $uid);
        if (!$acc || !str_contains($acc['board']['data'], $file['id'])) continue;
        if ($acc['role'] === 'cards' && $acc['hide']) {
            $vis = json_encode(visible_data(json_decode($acc['board']['data'], true), $acc));
            if (!str_contains($vis, $file['id'])) continue;
        }
        return true;
    }
    return false;
}

// Remove uploaded files no board uses any more (files can be used on several boards —
// duplicated or shared ones — so they're only deleted once nothing points at them).
// New uploads get an hour's grace.
function gc_files(int $uid): void {
    $pdo = db();
    $old = $pdo->prepare('SELECT id FROM files WHERE user_id = ? AND created_at < ?');
    $old->execute([$uid, time() - 3600]);
    $used = $pdo->prepare('SELECT 1 FROM boards WHERE data LIKE ? LIMIT 1');
    $del = $pdo->prepare('DELETE FROM files WHERE id = ? AND user_id = ?');
    foreach ($old->fetchAll(PDO::FETCH_COLUMN) as $id) {
        $used->execute(['%' . $id . '%']);
        if ($used->fetchColumn()) continue;
        $del->execute([$id, $uid]);
        @unlink(user_dir($uid) . '/' . $id);
    }
}
