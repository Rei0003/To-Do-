<?php
// avatar.php?id=<user id>&v=<version> — someone's profile picture (for logged-in users).
require __DIR__ . '/db.php';
require_user();
$id = (int)($_GET['id'] ?? 0);
$st = db()->prepare('SELECT avatar FROM users WHERE id = ?');
$st->execute([$id]);
$avatar = $st->fetchColumn();
$path = avatar_path($id);
if (!$avatar || !is_file($path)) fail('No picture.', 404);
$mime = explode('|', $avatar)[0];
if (!in_array($mime, ['image/png', 'image/jpeg', 'image/webp'], true)) fail('No picture.', 404);
header('Content-Type: ' . $mime);
header('X-Content-Type-Options: nosniff');
header("Content-Security-Policy: default-src 'none'; sandbox");
header('Cache-Control: private, max-age=31536000, immutable'); // a new picture gets a new address
header('Content-Length: ' . filesize($path));
readfile($path);
