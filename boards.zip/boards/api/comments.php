<?php
// comments.php — a board's comments (everyone with access may comment, including viewers).
//   GET    comments.php?board=…                       all comments you may see
//   POST   comments.php?board=…   { text, card?, parent? }      new comment / reply
//   PATCH  comments.php?id=…      { text } (author)  or  { resolved } (author, owner, editors)
//   DELETE comments.php?id=…                          (author or the board's owner; replies go too)
require __DIR__ . '/db.php';
require_same_site();
$uid = require_user();
$pdo = db();
$method = $_SERVER['REQUEST_METHOD'];

function comment_out(array $r, int $uid): array {
    return [
        'id' => $r['id'], 'parent' => $r['parent_id'], 'card' => $r['card_id'], 'text' => $r['text'],
        'resolved' => (bool)$r['resolved'], 'created_at' => (int)$r['created_at'], 'updated_at' => (int)$r['updated_at'],
        'author' => ['name' => $r['author_name'], 'email' => $r['author_email'], 'avatar' => avatar_url($r['user_id'], $r['author_avatar'] ?? null)],
        'mine' => (int)$r['user_id'] === $uid,
    ];
}
function clean_text($t): string {
    $t = trim(str_replace("\r", '', (string)$t));
    if ($t === '') fail('Write something first.');
    if (text_len($t) > 4000) fail('That comment is too long (4000 characters at most).');
    return $t;
}
// a comment and the board it's on, if you can see it
function load_comment(string $id, int $uid): array {
    $st = db()->prepare('SELECT * FROM comments WHERE id = ?');
    $st->execute([$id]);
    $c = $st->fetch();
    $acc = $c ? board_access($c['board_id'], $uid) : null;
    if (!$c || !$acc || !in_array($c['id'], array_column(visible_comments($acc), 'id'), true)) fail('Comment not found.', 404);
    return [$c, $acc];
}

if ($method === 'GET' || $method === 'POST') {
    $boardId = preg_replace('/[^a-f0-9]/', '', (string)($_GET['board'] ?? ''));
    $acc = board_access($boardId, $uid);
    if (!$acc) fail('Board not found.', 404);

    if ($method === 'GET') {
        reply(['comments' => array_map(fn($r) => comment_out($r, $uid), visible_comments($acc))]);
    }

    $body = json_body();
    $text = clean_text($body['text'] ?? '');
    $parent = isset($body['parent']) ? preg_replace('/[^a-f0-9]/', '', (string)$body['parent']) : null;
    $card = isset($body['card']) && $body['card'] !== null ? (string)$body['card'] : null;
    if ($parent) {
        // replies go on top-level comments you can see, and share their card
        $p = array_values(array_filter(visible_comments($acc), fn($r) => $r['id'] === $parent && !$r['parent_id']));
        if (!$p) fail('That comment no longer exists.', 404);
        $card = $p[0]['card_id'];
    } elseif ($card !== null) {
        $cards = array_column(visible_data(json_decode($acc['board']['data'], true), $acc)['cards'], 'id');
        if (!in_array($card, $cards, true)) fail('That card isn’t on the board any more.');
    }
    $id = random_id();
    $now = time();
    $pdo->prepare('INSERT INTO comments (id, board_id, user_id, parent_id, card_id, text, resolved, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?)')
        ->execute([$id, $boardId, $uid, $parent, $card, $text, $now, $now]);
    $row = array_values(array_filter(visible_comments($acc), fn($r) => $r['id'] === $id))[0];
    reply(['comment' => comment_out($row, $uid)], 201);
}

$id = preg_replace('/[^a-f0-9]/', '', (string)($_GET['id'] ?? ''));
[$c, $acc] = load_comment($id, $uid);
$isAuthor = (int)$c['user_id'] === $uid;

if ($method === 'PATCH') {
    $body = json_body();
    if (array_key_exists('text', $body)) {
        if (!$isAuthor) fail('You can only edit your own comments.', 403);
        $pdo->prepare('UPDATE comments SET text = ?, updated_at = ? WHERE id = ?')->execute([clean_text($body['text']), time(), $id]);
    }
    if (array_key_exists('resolved', $body)) {
        if ($c['parent_id']) fail('Replies can’t be resolved on their own.');
        if (!$isAuthor && !in_array($acc['role'], ['owner', 'edit'], true)) fail('Only the author or an editor can resolve this.', 403);
        $pdo->prepare('UPDATE comments SET resolved = ? WHERE id = ?')->execute([$body['resolved'] ? 1 : 0, $id]);
    }
    $row = array_values(array_filter(visible_comments($acc), fn($r) => $r['id'] === $id))[0];
    reply(['comment' => comment_out($row, $uid)]);
}

if ($method === 'DELETE') {
    if (!$isAuthor && $acc['role'] !== 'owner') fail('You can only delete your own comments.', 403);
    $pdo->prepare('DELETE FROM comments WHERE id = ? OR parent_id = ?')->execute([$id, $id]);
    reply(['ok' => true]);
}

fail('Unknown request.', 405);
