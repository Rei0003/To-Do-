<?php
// mailer.php — sends email: to a log file (development), through an SMTP server, or with mail().
// send_mail($to, $subject, $text, $html) returns true, or an error message.
declare(strict_types=1);

function send_mail(string $to, string $subject, string $text, string $html) {
    global $CONFIG;
    $m = $CONFIG['mail'] ?? ['mode' => 'log'];
    $fromEmail = $m['from_email'] ?? 'no-reply@example.com';
    $fromName = $m['from_name'] ?? 'Boards';
    $boundary = 'b' . bin2hex(random_bytes(8));
    $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
    $headers = [
        'From: =?UTF-8?B?' . base64_encode($fromName) . "?= <$fromEmail>",
        "To: <$to>",
        "Subject: $encodedSubject",
        'Date: ' . date('r'),
        'Message-ID: <' . bin2hex(random_bytes(12)) . '@' . (explode('@', $fromEmail)[1] ?? 'localhost') . '>',
        'MIME-Version: 1.0',
        "Content-Type: multipart/alternative; boundary=\"$boundary\"",
    ];
    $body = "--$boundary\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
        . chunk_split(base64_encode($text))
        . "--$boundary\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
        . chunk_split(base64_encode($html))
        . "--$boundary--\r\n";

    if (($m['mode'] ?? 'log') === 'log') {
        $dir = __DIR__ . '/data';
        if (!is_dir($dir)) mkdir($dir, 0775, true);
        file_put_contents($dir . '/mail.log', "==== " . date('c') . " to $to: $subject\n$text\n\n", FILE_APPEND | LOCK_EX);
        return true;
    }
    if ($m['mode'] === 'mail') {
        $hdrs = array_filter($headers, fn($h) => !str_starts_with($h, 'To:') && !str_starts_with($h, 'Subject:'));
        return @mail($to, $encodedSubject, $body, implode("\r\n", $hdrs)) ? true : 'The server couldn’t send email (mail() failed).';
    }
    return smtp_send($m['smtp'] ?? [], $fromEmail, $to, implode("\r\n", $headers) . "\r\n\r\n" . $body);
}

// a small SMTP client: STARTTLS / SSL, AUTH LOGIN
function smtp_send(array $s, string $from, string $to, string $message) {
    $host = $s['host'] ?? '';
    $port = (int)($s['port'] ?? 587);
    $secure = $s['secure'] ?? 'tls';
    if ($host === '') return 'Email isn’t set up (no SMTP host in api/config.php).';
    $fp = @stream_socket_client(($secure === 'ssl' ? 'ssl://' : 'tcp://') . "$host:$port", $errno, $errstr, 15);
    if (!$fp) return "Couldn’t connect to the mail server ($errstr).";
    stream_set_timeout($fp, 15);
    $read = function () use ($fp) {
        $data = '';
        while (($line = fgets($fp, 515)) !== false) {
            $data .= $line;
            if (strlen($line) < 4 || $line[3] === ' ') break; // last line of the reply
        }
        return $data;
    };
    $cmd = function (string $c, array $ok) use ($fp, $read) {
        fwrite($fp, $c . "\r\n");
        $r = $read();
        if (!in_array((int)substr($r, 0, 3), $ok, true)) throw new RuntimeException(trim($r) ?: 'no reply');
        return $r;
    };
    try {
        $hello = explode('@', $from)[1] ?? 'localhost';
        if ((int)substr($read(), 0, 3) !== 220) throw new RuntimeException('The mail server didn’t greet us.');
        $cmd("EHLO $hello", [250]);
        if ($secure === 'tls') {
            $cmd('STARTTLS', [220]);
            if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new RuntimeException('Couldn’t start encryption.');
            $cmd("EHLO $hello", [250]);
        }
        if (!empty($s['user'])) {
            $cmd('AUTH LOGIN', [334]);
            $cmd(base64_encode($s['user']), [334]);
            $cmd(base64_encode((string)($s['pass'] ?? '')), [235]);
        }
        $cmd("MAIL FROM:<$from>", [250]);
        $cmd("RCPT TO:<$to>", [250, 251]);
        $cmd('DATA', [354]);
        // lines starting with "." get an extra "." (SMTP rule)
        $cmd(preg_replace('/^\./m', '..', $message) . "\r\n.", [250]);
        $cmd('QUIT', [221]);
        fclose($fp);
        return true;
    } catch (Throwable $e) {
        error_log('Boards mail: ' . $e->getMessage());
        @fclose($fp);
        return 'The email couldn’t be sent: ' . $e->getMessage();
    }
}
