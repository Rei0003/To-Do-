<?php
// roles.php — your custom roles ("Junior dev", "Designer", "Client"…), reusable on all your boards.
//   GET    roles.php                       your roles
//   GET    roles.php?board=…               the roles of that board's owner (to show badges)
//   POST   roles.php   { name, color, access? }    new role
//   PATCH  roles.php?id=…   { name?, color?, access? }
//   DELETE roles.php?id=…                  (people who had it simply have no role)
require __DIR__ . '/db.php';
require_same_site();
$uid = require_user();
$pdo = db();
$method = $_SERVER['REQUEST_METHOD'];

function clean_role(array $body, ?array $old = null): array {
    $name = trim((string)($body['name'] ?? ($old['name'] ?? '')));
    if ($name === '' || text_len($name) > 40) fail('Give the role a name (up to 40 characters).');
    $color = (string)($body['color'] ?? ($old['color'] ?? 'blue'));
    if (!in_array($color, ROLE_COLORS, true)) $color = 'blue';
    $access = array_key_exists('access', $body) ? $body['access'] : ($old['access'] ?? null);
    if (!in_array($access, ['edit', 'view', null], true)) $access = null;
    return [$name, $color, $access];
}

if ($method === 'GET') {
    $owner = $uid;
    if (!empty($_GET['board'])) {
        $acc = board_access(preg_replace('/[^a-f0-9]/', '', (string)$_GET['board']), $uid);
        if (!$acc) fail('Board not found.', 404);
        $owner = (int)$acc['board']['user_id'];
    }
    reply(['roles' => array_map('role_out', roles_of_owner($owner)), 'colors' => ROLE_COLORS]);
}

if ($method === 'POST') {
    [$name, $color, $access] = clean_role(json_body());
    $st = $pdo->prepare('SELECT 1 FROM team_roles WHERE owner_id = ? AND lower(name) = lower(?)');
    $st->execute([$uid, $name]);
    if ($st->fetch()) fail('You already have a role with that name.', 409);
    if (count(roles_of_owner($uid)) >= 50) fail('That’s a lot of roles — 50 at most.');
    $id = random_id();
    $pdo->prepare('INSERT INTO team_roles (id, owner_id, name, color, access, created_at) VALUES (?, ?, ?, ?, ?, ?)')
        ->execute([$id, $uid, $name, $color, $access, time()]);
    reply(['role' => role_out(['id' => $id, 'name' => $name, 'color' => $color, 'access' => $access]), 'roles' => array_map('role_out', roles_of_owner($uid))], 201);
}

$id = preg_replace('/[^a-f0-9]/', '', (string)($_GET['id'] ?? ''));
$st = $pdo->prepare('SELECT * FROM team_roles WHERE id = ? AND owner_id = ?');
$st->execute([$id, $uid]);
$old = $st->fetch();
if (!$old) fail('Role not found.', 404);

if ($method === 'PATCH') {
    [$name, $color, $access] = clean_role(json_body(), $old);
    $pdo->prepare('UPDATE team_roles SET name = ?, color = ?, access = ? WHERE id = ?')->execute([$name, $color, $access, $id]);
    reply(['roles' => array_map('role_out', roles_of_owner($uid))]);
}

if ($method === 'DELETE') {
    $pdo->prepare('UPDATE board_members SET member_role = NULL WHERE member_role = ?')->execute([$id]);
    $pdo->prepare('DELETE FROM team_roles WHERE id = ?')->execute([$id]);
    reply(['roles' => array_map('role_out', roles_of_owner($uid))]);
}

fail('Unknown request.', 405);
