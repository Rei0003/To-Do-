<?php
// boards.php — boards the logged-in user owns or was invited to.
//   GET    boards.php                    list: your boards + boards shared with you
//   GET    boards.php?id=…               one board with its data (what you're allowed to see)
//   GET    boards.php?id=…&rev_only=1    just its version number (to notice others' changes)
//   POST   boards.php                    create        { title?, data? }
//   PUT    boards.php?id=…               save          { data, rev, force? }
//   PATCH  boards.php?id=…               rename        { title }
//   POST   boards.php?id=…&action=duplicate          (owner)
//   DELETE boards.php?id=…                            (owner)
//   GET    boards.php?ids=a,b,…                       summaries + layout previews (for board cards)
//   POST   boards.php  { title, data?, parent? }      parent = create it inside that board
//   POST   boards.php?id=…&action=duplicate&parent=…  copy a board with everything inside it
//   GET    boards.php?assigned=1                       open tasks assigned to you, on every board you can see
//   POST   boards.php?id=…&action=task  { card, item, done }   tick a task off (also allowed for
//          the person it's assigned to, even with view-only access)
require __DIR__ . '/db.php';
require_same_site();
$uid = require_user();
$pdo = db();
$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? preg_replace('/[^a-f0-9]/', '', (string)$_GET['id']) : null;

function clean_title($t): string {
    $t = trim((string)$t);
    return $t === '' ? 'Untitled board' : text_cut($t, 200);
}

// check board data and count its cards
function check_data($data): array {
    global $CONFIG;
    if (!is_array($data) || !isset($data['cards']) || !is_array($data['cards'])) fail('That board data isn’t valid.');
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false || strlen($json) > $CONFIG['max_board_bytes']) fail('This board is too big to save.', 413);
    $count = 0;
    foreach ($data['cards'] as $c) if (is_array($c) && empty($c['parent'])) $count++;
    return [$json, $count];
}

function need_access(string $id, int $uid, array $roles): array {
    $acc = board_access($id, $uid);
    if (!$acc) fail('Board not found.', 404);
    if (!in_array($acc['role'], $roles, true)) {
        fail($acc['role'] === 'view' ? 'You can only view this board.' : 'You don’t have permission to do that on this board.', 403);
    }
    return $acc;
}

function members_count(string $id): int {
    $st = db()->prepare('SELECT COUNT(*) FROM board_members WHERE board_id = ?');
    $st->execute([$id]);
    return (int)$st->fetchColumn();
}

function summary(array $b, array $acc = null): array {
    $out = [
        'id' => $b['id'], 'title' => $b['title'], 'cards' => (int)$b['card_count'], 'rev' => (int)$b['rev'],
        'created_at' => (int)$b['created_at'], 'updated_at' => (int)$b['updated_at'],
    ];
    if ($acc) {
        $out['access'] = [
            'role' => $acc['role'],
            'cards' => $acc['cards'],
            'hide' => $acc['hide'],
            'owner' => ['name' => $acc['board']['owner_name'], 'email' => $acc['board']['owner_email']],
        ];
        $out['members'] = members_count($b['id']);
        $out['comments'] = unread_comment_count($acc, $GLOBALS['uid']); // new since you last looked
        $out['parent'] = $b['parent_id'] ?? null;
        $out['path'] = board_path($b, $GLOBALS['uid']);
    }
    return $out;
}

function reload(string $id, int $uid): array {
    $acc = board_access($id, $uid);
    return summary($acc['board'], $acc);
}

// a tiny map of a board's top-level cards, for the preview on its board card
function layout_preview(array $data): array {
    $heights = ['note' => 110, 'todo' => 170, 'media' => 190, 'calendar' => 300, 'table' => 150, 'chart' => 320, 'file' => 110, 'board' => 150];
    $out = [];
    foreach ($data['cards'] ?? [] as $c) {
        if (!empty($c['parent']) || count($out) >= 40) continue;
        $w = (int)($c['width'] ?? 260);
        $h = (int)($c['height'] ?? ($heights[$c['type'] ?? ''] ?? 120));
        $out[] = [(int)($c['x'] ?? 0), (int)($c['y'] ?? 0), $w, $h, (string)($c['type'] ?? ''), (string)($c['color'] ?? '')];
    }
    return $out;
}

// ---------- summaries for board cards ----------
if ($method === 'GET' && isset($_GET['ids'])) {
    $out = [];
    foreach (array_slice(explode(',', (string)$_GET['ids']), 0, 100) as $bid) {
        $bid = preg_replace('/[^a-f0-9]/', '', $bid);
        $acc = $bid ? board_access($bid, $uid) : null;
        if (!$acc) { $out[$bid] = null; continue; }
        $data = visible_data(json_decode($acc['board']['data'], true), $acc);
        $out[$bid] = [
            'id' => $bid, 'title' => $acc['board']['title'], 'cards' => (int)$acc['board']['card_count'],
            'updated_at' => (int)$acc['board']['updated_at'], 'preview' => layout_preview($data),
        ];
    }
    reply(['boards' => $out]);
}

// ---------- tasks assigned to me ----------
if ($method === 'GET' && !empty($_GET['assigned'])) {
    $me = strtolower(user_email($uid));
    $tasks = [];
    foreach (accessible_board_ids($uid) as $bid) {
        $acc = board_access($bid, $uid);
        if (!$acc) continue;
        if (!str_contains(strtolower($acc['board']['data']), $me)) continue; // quick skip
        $data = visible_data(json_decode($acc['board']['data'], true), $acc);
        foreach ($data['cards'] ?? [] as $card) {
            if (($card['type'] ?? '') !== 'todo') continue;
            foreach ($card['items'] ?? [] as $item) {
                if (empty($item['done']) && strtolower((string)($item['assignee'] ?? '')) === $me) {
                    $tasks[] = [
                        'board' => $bid, 'board_title' => $acc['board']['title'],
                        'card' => $card['id'], 'list' => (string)($card['title'] ?? ''),
                        'item' => $item['id'], 'text' => (string)($item['text'] ?? ''),
                        'due' => $item['due'] ?? null, 'priority' => $item['priority'] ?? null,
                        'status' => in_array($item['status'] ?? null, ['todo', 'doing'], true) ? $item['status'] : 'todo',
                    ];
                }
            }
        }
    }
    // soonest due first, then the rest
    usort($tasks, fn($a, $b) => [$a['due'] === null, $a['due']] <=> [$b['due'] === null, $b['due']]);
    reply(['tasks' => $tasks]);
}

// ---------- tick a task off ----------
if ($method === 'POST' && $id && ($_GET['action'] ?? '') === 'task') {
    $acc = board_access($id, $uid);
    if (!$acc) fail('Board not found.', 404);
    $body = json_body();
    $data = json_decode($acc['board']['data'], true);
    $me = strtolower(user_email($uid));
    $found = false;
    foreach ($data['cards'] as &$card) {
        if (($card['id'] ?? null) !== ($body['card'] ?? null) || ($card['type'] ?? '') !== 'todo') continue;
        // may they? full editors, people who may edit this list, or the person it's assigned to
        $canEdit = in_array($acc['role'], ['owner', 'edit'], true)
            || ($acc['role'] === 'cards' && in_array(top_card_id($card, cards_by_id($data['cards'])), $acc['cards'], true));
        foreach ($card['items'] as &$item) {
            if (($item['id'] ?? null) !== ($body['item'] ?? null)) continue;
            $mine = strtolower((string)($item['assignee'] ?? '')) === $me;
            if (!$canEdit && !$mine) fail('Only the person this task is assigned to can tick it off.', 403);
            if (!$canEdit && $acc['role'] === 'cards' && $acc['hide']) {
                $visible = array_column(visible_data($data, $acc)['cards'], 'id');
                if (!in_array($card['id'], $visible, true)) fail('Task not found.', 404);
            }
            // the stage (To do / In progress / Done) — or just done, from older pages
            $status = in_array($body['status'] ?? null, ['todo', 'doing', 'done'], true) ? $body['status'] : (!empty($body['done']) ? 'done' : 'todo');
            $item['status'] = $status;
            $item['done'] = $status === 'done';
            $found = true;
        }
        unset($item);
    }
    unset($card);
    if (!$found) fail('Task not found.', 404);
    $data = stamp_tasks(json_decode($acc['board']['data'], true), $data, $uid);
    [$json, $count] = check_data($data);
    $pdo->prepare('UPDATE boards SET data = ?, rev = rev + 1, updated_at = ? WHERE id = ?')->execute([$json, time(), $id]);
    reply(['board' => reload($id, $uid)]);
}

// ---------- list ----------
if ($method === 'GET' && !$id) {
    $st = $pdo->prepare('SELECT b.id, b.title, b.card_count, b.rev, b.created_at, b.updated_at,
        (SELECT COUNT(*) FROM board_members m WHERE m.board_id = b.id) AS members
        FROM boards b WHERE b.user_id = ? AND b.parent_id IS NULL ORDER BY b.updated_at DESC');
    $st->execute([$uid]);
    $own = array_map(fn($b) => summary($b) + ['members' => (int)$b['members']], $st->fetchAll());

    $st = $pdo->prepare('SELECT b.id, b.title, b.card_count, b.rev, b.created_at, b.updated_at, m.role, u.name AS owner_name
        FROM board_members m JOIN boards b ON b.id = m.board_id JOIN users u ON u.id = b.user_id
        WHERE m.email = ? ORDER BY b.updated_at DESC');
    $st->execute([user_email($uid)]);
    $shared = array_map(fn($b) => summary($b) + ['role' => $b['role'], 'owner' => $b['owner_name']], $st->fetchAll());
    reply(['boards' => $own, 'shared' => $shared]);
}

// ---------- one board ----------
if ($method === 'GET') {
    $acc = need_access($id, $uid, ['owner', 'edit', 'view', 'cards']);
    if (!empty($_GET['rev_only'])) reply(['rev' => (int)$acc['board']['rev'], 'comments' => unread_comment_count($acc, $uid)]);
    $data = $acc['board']['data'];
    if ($acc['role'] === 'cards' && $acc['hide']) {
        $data = json_encode(visible_data(json_decode($data, true), $acc), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    // the data is stored as JSON already, so it's sent as it is
    echo '{"board":' . json_encode(summary($acc['board'], $acc), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ',"data":' . $data . '}';
    exit;
}

// ---------- create ----------
if ($method === 'POST' && !$id) {
    $body = json_body();
    $title = clean_title($body['title'] ?? '');
    $data = $body['data'] ?? ['title' => $title, 'cards' => [], 'connections' => []];
    $data['title'] = $title;
    check_data($data);
    $data = stamp_tasks(null, $data, $uid);
    [$json, $count] = check_data($data);
    $owner = $uid;
    $parent = null;
    if (!empty($body['parent'])) {
        // a board inside a board belongs to the parent's owner (so sharing passes down)
        $parent = preg_replace('/[^a-f0-9]/', '', (string)$body['parent']);
        $pacc = need_access($parent, $uid, ['owner', 'edit']);
        $owner = (int)$pacc['board']['user_id'];
    }
    $newId = random_id();
    $now = time();
    $pdo->prepare('INSERT INTO boards (id, user_id, title, data, card_count, rev, created_at, updated_at, parent_id) VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?)')
        ->execute([$newId, $owner, $title, $json, $count, $now, $now, $parent]);
    reply(['board' => reload($newId, $uid)], 201);
}

// ---------- save ----------
if ($method === 'PUT') {
    $acc = need_access($id, $uid, ['owner', 'edit', 'cards']);
    $b = $acc['board'];
    $body = json_body();
    $incoming = $body['data'] ?? null;
    check_data($incoming);

    if ($acc['role'] === 'cards') {
        // only their cards change, so there's nothing to clash with: merge into the latest version
        $data = merge_member_changes(json_decode($b['data'], true), $incoming, $acc['cards']);
    } else {
        // someone (another tab, computer or person) saved a newer version in the meantime?
        if (empty($body['force']) && (int)($body['rev'] ?? 0) !== (int)$b['rev']) {
            reply(['error' => 'This board was changed somewhere else.', 'conflict' => true, 'board' => summary($b, $acc)], 409);
        }
        $data = $incoming;
    }
    $data = stamp_tasks(json_decode($b['data'], true), $data, $uid); // when tasks were assigned / done, and by whom
    [$json, $count] = check_data($data);
    $title = clean_title($data['title'] ?? $b['title']);
    $pdo->prepare('UPDATE boards SET title = ?, data = ?, card_count = ?, rev = rev + 1, updated_at = ? WHERE id = ?')
        ->execute([$title, $json, $count, time(), $id]);
    reply(['board' => reload($id, $uid)]);
}

// ---------- rename ----------
if ($method === 'PATCH') {
    $acc = need_access($id, $uid, ['owner', 'edit']);
    $title = clean_title(json_body()['title'] ?? '');
    $data = json_decode($acc['board']['data'], true);
    $data['title'] = $title;
    [$json] = check_data($data);
    $pdo->prepare('UPDATE boards SET title = ?, data = ?, rev = rev + 1, updated_at = ? WHERE id = ?')
        ->execute([$title, $json, time(), $id]);
    reply(['board' => reload($id, $uid)]);
}

// ---------- duplicate (with every board inside it) ----------
// copy one board (and the boards inside it, with their board cards pointing at the new copies)
function copy_board_tree(string $id, ?string $newParent, string $title = null): string {
    $pdo = db();
    $st = $pdo->prepare('SELECT * FROM boards WHERE id = ?');
    $st->execute([$id]);
    $b = $st->fetch();
    $data = json_decode($b['data'], true);
    $newId = random_id();
    if ($title !== null) { $data['title'] = $title; $b['title'] = $title; }
    // children first, so the board cards can point at the copies
    foreach ($data['cards'] as &$c) {
        if (($c['type'] ?? '') === 'board' && !empty($c['boardId'])) {
            $exists = $pdo->prepare('SELECT 1 FROM boards WHERE id = ? AND parent_id = ?');
            $exists->execute([$c['boardId'], $id]);
            if ($exists->fetch()) $c['boardId'] = copy_board_tree($c['boardId'], $newId);
        }
    }
    unset($c);
    [$json, $count] = check_data($data);
    $now = time();
    // uploaded files are shared by the copies (they're only deleted once nothing uses them)
    $pdo->prepare('INSERT INTO boards (id, user_id, title, data, card_count, rev, created_at, updated_at, parent_id) VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?)')
        ->execute([$newId, $b['user_id'], $b['title'], $json, $count, $now, $now, $newParent]);
    return $newId;
}

if ($method === 'POST' && ($_GET['action'] ?? '') === 'duplicate') {
    $acc = need_access($id, $uid, ['owner', 'edit']);
    $parent = isset($_GET['parent']) ? preg_replace('/[^a-f0-9]/', '', (string)$_GET['parent']) : ($acc['board']['parent_id'] ?? null);
    if ($parent) need_access($parent, $uid, ['owner', 'edit']);
    elseif ($acc['role'] !== 'owner') fail('Only the owner can duplicate this board.', 403);
    $newId = copy_board_tree($id, $parent ?: null, $parent ? null : clean_title($acc['board']['title'] . ' (copy)'));
    reply(['board' => reload($newId, $uid)], 201);
}

// ---------- delete (the owner — or, for a board inside a board, anyone who may edit the parent) ----------
if ($method === 'DELETE') {
    $acc = need_access($id, $uid, ['owner', 'edit']);
    if ($acc['role'] !== 'owner') {
        $parent = $acc['board']['parent_id'] ?? null;
        if (!$parent) fail('Only the owner can delete this board.', 403);
        need_access($parent, $uid, ['owner', 'edit']);
    }
    // the board and every board inside it
    foreach (array_merge([$id], descendant_ids($id)) as $bid) {
        $pdo->prepare('DELETE FROM board_members WHERE board_id = ?')->execute([$bid]);
        $pdo->prepare('DELETE FROM comments WHERE board_id = ?')->execute([$bid]);
        $pdo->prepare('DELETE FROM boards WHERE id = ?')->execute([$bid]);
    }
    gc_files((int)$acc['board']['user_id']);
    reply(['ok' => true]);
}

fail('Unknown request.', 405);
