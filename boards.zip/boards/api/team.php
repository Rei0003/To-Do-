<?php
// team.php — how the people on your boards are doing with their tasks.
//   GET team.php?board=…   that board and the boards inside it (owner and full editors)
//   GET team.php           every board you own
// Per person: tasks completed, turnaround (assigned — or created — until done: average, median,
// fastest, slowest), share done on time, open and overdue tasks, and their latest completed tasks.
require __DIR__ . '/db.php';
require_same_site();
$uid = require_user();
$pdo = db();

$boardIds = [];
$memberBoards = [];
$scope = '';
if (!empty($_GET['board'])) {
    $id = preg_replace('/[^a-f0-9]/', '', (string)$_GET['board']);
    $acc = board_access($id, $uid);
    if (!$acc) fail('Board not found.', 404);
    if (!in_array($acc['role'], ['owner', 'edit'], true)) fail('Only the owner and editors can see team activity.', 403);
    $boardIds = array_merge([$id], descendant_ids($id));
    $memberBoards = [$id];
    foreach (board_path($acc['board'], $uid) as $p) $memberBoards[] = $p['id']; // people invited to boards it sits in
    $scope = $acc['board']['title'];
} else {
    $st = $pdo->prepare('SELECT id FROM boards WHERE user_id = ?');
    $st->execute([$uid]);
    $boardIds = $st->fetchAll(PDO::FETCH_COLUMN);
    $memberBoards = $boardIds;
    $scope = 'All your boards';
}

// everyone involved: the owner(s), invited people, assignees, and whoever ticked tasks off
$people = [];
$person = function (string $email) use (&$people) {
    $email = strtolower($email);
    if (!isset($people[$email])) {
        $people[$email] = ['email' => $email, 'done' => 0, 'open' => 0, 'overdue' => 0, 'turnaround' => [],
            'with_due' => 0, 'on_time' => 0, 'recent' => [], 'invited' => false];
    }
    return $email;
};
$userById = [];
$userEmail = function (int $id) use ($pdo, &$userById) {
    if (!isset($userById[$id])) {
        $st = $pdo->prepare('SELECT email FROM users WHERE id = ?');
        $st->execute([$id]);
        $userById[$id] = strtolower((string)$st->fetchColumn());
    }
    return $userById[$id];
};

$roleVotes = []; // email -> [role id => how many boards they have it on]
if ($memberBoards) {
    $in = implode(',', array_fill(0, count($memberBoards), '?'));
    $st = $pdo->prepare("SELECT email, member_role FROM board_members WHERE board_id IN ($in)");
    $st->execute($memberBoards);
    foreach ($st->fetchAll() as $m) {
        $people[$person($m['email'])]['invited'] = true;
        if ($m['member_role']) $roleVotes[strtolower($m['email'])][$m['member_role']] = ($roleVotes[strtolower($m['email'])][$m['member_role']] ?? 0) + 1;
    }
}
// the roles of the owner(s) of these boards
$roleById = [];
$owners = $boardIds ? $pdo->query('SELECT DISTINCT user_id FROM boards WHERE id IN (' . implode(',', array_map([$pdo, 'quote'], $boardIds)) . ')')->fetchAll(PDO::FETCH_COLUMN) : [];
foreach ($owners as $o) foreach (roles_of_owner((int)$o) as $r) $roleById[$r['id']] = role_out($r);
$person(user_email($uid));

// end of the due moment (a date without a time = the end of that day)
$dueTs = function (string $due): ?int {
    $t = strtotime(str_contains($due, 'T') ? str_replace('T', ' ', $due) : $due . ' 23:59:59');
    return $t ?: null;
};

$now = time();
$sinceTracking = null;
$untracked = 0;
$boardRow = $pdo->prepare('SELECT title, data FROM boards WHERE id = ?');
foreach ($boardIds as $bid) {
    $boardRow->execute([$bid]);
    $row = $boardRow->fetch();
    if (!$row) continue;
    $data = json_decode($row['data'], true);
    foreach ($data['cards'] ?? [] as $card) {
        if (($card['type'] ?? '') !== 'todo') continue;
        foreach ($card['items'] ?? [] as $it) {
            $assignee = strtolower((string)($it['assignee'] ?? ''));
            if (!empty($it['done'])) {
                if (empty($it['done_by']) || empty($it['done_at'])) { $untracked++; continue; } // finished before tracking began
                $who = $person($userEmail((int)$it['done_by']));
                $p = &$people[$who];
                $p['done']++;
                $start = ($assignee === $who && !empty($it['assigned_at'])) ? $it['assigned_at'] : ($it['created_at'] ?? null);
                $turn = $start && $it['done_at'] >= $start ? $it['done_at'] - $start : null;
                if ($turn !== null) $p['turnaround'][] = $turn;
                if (!empty($it['due']) && ($d = $dueTs($it['due']))) {
                    $p['with_due']++;
                    if ($it['done_at'] <= $d) $p['on_time']++;
                }
                $p['recent'][] = ['text' => (string)($it['text'] ?? ''), 'list' => (string)($card['title'] ?? ''),
                    'board' => $row['title'], 'board_id' => $bid, 'done_at' => (int)$it['done_at'], 'turnaround' => $turn];
                unset($p);
                $sinceTracking = $sinceTracking === null ? (int)$it['done_at'] : min($sinceTracking, (int)$it['done_at']);
            } elseif ($assignee !== '') {
                $p = &$people[$person($assignee)];
                $p['open']++;
                if (!empty($it['due']) && ($d = $dueTs($it['due'])) && $d < $now) $p['overdue']++;
                unset($p);
            }
        }
    }
}

// names and pictures
$out = [];
$lookup = $pdo->prepare('SELECT id, name, avatar FROM users WHERE email = ?');
foreach ($people as $p) {
    $lookup->execute([$p['email']]);
    $u = $lookup->fetch();
    $t = $p['turnaround'];
    sort($t);
    $n = count($t);
    usort($p['recent'], fn($a, $b) => $b['done_at'] <=> $a['done_at']);
    $out[] = [
        'email' => $p['email'],
        'name' => $u['name'] ?? null,
        'avatar' => $u ? avatar_url($u['id'], $u['avatar']) : null,
        'you' => $p['email'] === strtolower(user_email($uid)),
        'invited' => $p['invited'],
        'done' => $p['done'],
        'open' => $p['open'],
        'overdue' => $p['overdue'],
        'turnaround' => $n ? [
            'average' => (int)round(array_sum($t) / $n),
            'median' => (int)($n % 2 ? $t[intdiv($n, 2)] : ($t[$n / 2 - 1] + $t[$n / 2]) / 2),
            'fastest' => $t[0],
            'slowest' => $t[$n - 1],
            'count' => $n,
        ] : null,
        'on_time' => $p['with_due'] ? ['done' => $p['on_time'], 'with_due' => $p['with_due']] : null,
        'recent' => array_slice($p['recent'], 0, 6),
        // their role here (the one they have on most of these boards)
        'member_role' => isset($roleVotes[$p['email']]) ? ($roleById[array_search(max($roleVotes[$p['email']]), $roleVotes[$p['email']])] ?? null) : null,
        '_turns' => $t,
    ];
}

// totals per role
$byRole = [];
foreach ($out as $p) {
    $key = $p['member_role']['id'] ?? '';
    if (!isset($byRole[$key])) $byRole[$key] = ['role' => $p['member_role'], 'people' => 0, 'done' => 0, 'open' => 0, 'overdue' => 0, 'turns' => []];
    $byRole[$key]['people']++;
    $byRole[$key]['done'] += $p['done'];
    $byRole[$key]['open'] += $p['open'];
    $byRole[$key]['overdue'] += $p['overdue'];
    $byRole[$key]['turns'] = array_merge($byRole[$key]['turns'], $p['_turns']);
}
$roles = [];
foreach ($byRole as $r) {
    $n = count($r['turns']);
    $roles[] = ['role' => $r['role'], 'people' => $r['people'], 'done' => $r['done'], 'open' => $r['open'], 'overdue' => $r['overdue'],
        'average' => $n ? (int)round(array_sum($r['turns']) / $n) : null];
}
usort($roles, fn($a, $b) => [$a['role'] === null, -$a['done']] <=> [$b['role'] === null, -$b['done']]);
foreach ($out as &$p) unset($p['_turns']);
unset($p);
// most active first; you last
usort($out, fn($a, $b) => [$a['you'], -$a['done'], -$a['open']] <=> [$b['you'], -$b['done'], -$b['open']]);
reply(['scope' => $scope, 'people' => $out, 'roles' => $roles, 'boards' => count($boardIds), 'untracked' => $untracked]);
