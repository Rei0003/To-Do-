<?php
// mail-test.php — checks your email settings and sends a test email.
// Run it in a terminal from the boards folder:   php api/mail-test.php you@example.com
// (It only works from the command line, never from a browser.)
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Run this from the command line.'); }
$CONFIG = require __DIR__ . '/config.php';
require __DIR__ . '/mailer.php';

$to = $argv[1] ?? '';
$ok = fn($t) => print("  ✔ $t\n");
$bad = function ($t, $fix = '') { print("  ✘ $t\n" . ($fix ? "    → $fix\n" : '')); exit(1); };
echo "\nBoards email check\n";

if (!filter_var($to, FILTER_VALIDATE_EMAIL)) $bad('No address to send to.', 'Run:  php api/mail-test.php you@gmail.com');
$m = $CONFIG['mail'] ?? [];
$mode = $m['mode'] ?? 'log';
if ($mode === 'log') {
    $bad('Email is still in development mode (mode = log).', is_file(__DIR__ . '/config.local.php')
        ? "Set 'mode' => 'smtp' in api/config.local.php."
        : 'Copy api/config.local.example.php to api/config.local.php and fill it in.');
}
$ok("Mode: $mode");
if ($mode === 'smtp') {
    $s = $m['smtp'] ?? [];
    if (empty($s['host'])) $bad('No SMTP host.', "Fill in 'host' (Gmail: smtp.gmail.com).");
    if (empty($s['user']) || empty($s['pass']) || str_contains((string)$s['pass'], 'abcd efgh')) {
        $bad('The username or app password is missing.', 'Put your Gmail address in user and the 16-letter app password in pass.');
    }
    $ok("Server: {$s['host']}:{$s['port']} ({$s['secure']}) as {$s['user']}");
    if (in_array($s['secure'] ?? '', ['tls', 'ssl'], true) && !extension_loaded('openssl')) {
        $bad('PHP\'s openssl extension is off (needed for Gmail).', 'In php.ini (XAMPP: C:\\xampp\\php\\php.ini) remove the ; before "extension=openssl", then restart Apache.');
    }
    $ok('openssl is available');
    if (($m['from_email'] ?? '') !== $s['user'] && str_contains($s['host'], 'gmail')) {
        echo "  ! from_email differs from your Gmail address — Gmail will send it from {$s['user']} anyway.\n";
    }
}
echo "  … sending a test email to $to\n";
$result = send_mail($to, 'Boards test email', "It works! Boards can send email now.\n\nNew accounts will get their codes by email.",
    '<p style="font-family:system-ui,Arial,sans-serif">It works! <b>Boards</b> can send email now.</p>');
if ($result !== true) {
    $hint = str_contains($result, '535') || str_contains($result, 'Username and Password')
        ? 'Gmail refused the login: use an app password (not your normal password), and check user is your full Gmail address.'
        : (str_contains($result, 'connect') ? 'Check your internet connection, and that port 587 isn\'t blocked (some school networks block it).' : '');
    $bad($result, $hint);
}
$ok("Sent! Check $to (and the spam folder).");
echo "\nDone — registering will now email the code instead of showing it on screen.\n\n";
