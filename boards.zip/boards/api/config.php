<?php
// config.php — settings for the Boards server.
// Your own private settings (like your email password) go in config.local.php instead —
// copy config.local.example.php to config.local.php. Anything set there replaces what's here.
$config = [
    // Database. SQLite needs no setup (the file is created automatically).
    // For MySQL (e.g. XAMPP's phpMyAdmin): create a database, run schema.mysql.sql, then use
    //   'db_dsn' => 'mysql:host=localhost;dbname=boards;charset=utf8mb4', 'db_user' => 'root', 'db_pass' => '',
    'db_dsn'  => 'sqlite:' . __DIR__ . '/data/boards.sqlite',
    'db_user' => null,
    'db_pass' => null,

    // Uploaded files (images, audio, PDFs…). Keep this folder private (see .htaccess / server.php).
    'uploads_dir' => __DIR__ . '/uploads',

    // Checking email addresses when people register (a 6-digit code is emailed to them).
    'verify_email' => true,

    // Sending email:
    //   'log'  — development: emails are written to api/data/mail.log and the sign-up screen
    //            shows the code (so it works without any email setup). Don't use on a real website.
    //   'smtp' — real email through a mail server (fill in 'smtp' below). Gmail: turn on 2-step
    //            verification, create an "app password", host smtp.gmail.com, port 587, secure 'tls'.
    //   'mail' — PHP's own mail() (only if your server is set up for it).
    'mail' => [
        'mode' => 'log',
        'from_email' => 'no-reply@example.com',
        'from_name' => 'Boards',
        'smtp' => [
            'host' => 'smtp.gmail.com',
            'port' => 587,
            'secure' => 'tls',      // 'tls' (port 587), 'ssl' (port 465) or '' (no encryption)
            'user' => '',           // e.g. you@gmail.com
            'pass' => '',           // the app password
        ],
    ],

    'max_board_bytes' => 25 * 1024 * 1024,   // one board's data
    'max_file_bytes'  => 200 * 1024 * 1024,  // one uploaded file (PHP's own upload limits apply too)
];

// private settings (not part of the project you share)
if (is_file(__DIR__ . '/config.local.php')) {
    $config = array_replace_recursive($config, require __DIR__ . '/config.local.php');
}
return $config;
