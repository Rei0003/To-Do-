// media-links.js — understands links to images, videos, YouTube and Vimeo
window.App = window.App || {};

App.mediaLinks = (() => {
  const IMAGE_EXT = /\.(png|jpe?g|gif|webp|avif|svg|bmp|ico)$/i;
  const VIDEO_EXT = /\.(mp4|webm|ogv|mov|m4v)$/i;
  const AUDIO_EXT = /\.(mp3|wav|m4a|aac|flac|opus|oga|ogg|weba)$/i;

  // open.spotify.com/track/ID (also /intl-xx/…, albums, playlists, episodes, shows)
  function spotify(u) {
    if (u.hostname !== 'open.spotify.com') return null;
    const m = u.pathname.match(/\/(track|album|playlist|episode|show|artist)\/([A-Za-z0-9]+)/);
    return m ? { type: m[1], id: m[2] } : null;
  }

  function youTubeId(u) {
    const host = u.hostname.replace(/^(www\.|m\.|music\.)/, '');
    if (host === 'youtu.be') return u.pathname.slice(1).split('/')[0];
    if (host === 'youtube.com' || host === 'youtube-nocookie.com') {
      if (u.searchParams.get('v')) return u.searchParams.get('v');
      const m = u.pathname.match(/^\/(?:shorts|embed|live)\/([\w-]+)/);
      if (m) return m[1];
    }
    return null;
  }

  function vimeoId(u) {
    const host = u.hostname.replace(/^www\./, '');
    if (host !== 'vimeo.com' && host !== 'player.vimeo.com') return null;
    return u.pathname.match(/(\d{6,})/)?.[1] || null;
  }

  /**
   * text -> { url, kind, embed?, guessed? } or null if it isn't an http(s) link.
   * kind: 'image' | 'video' | 'audio' | 'youtube' | 'vimeo' | 'spotify' | 'soundcloud'
   * guessed: true when we couldn't tell from the link and are trying it as an image
   */
  function parse(text) {
    let u;
    try { u = new URL(String(text).trim()); } catch { return null; }
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
    const url = u.href;

    const yt = youTubeId(u);
    if (yt) {
      const start = parseInt(u.searchParams.get('t') || u.searchParams.get('start') || '0', 10);
      return { url, kind: 'youtube', embed: `https://www.youtube-nocookie.com/embed/${yt}${start ? `?start=${start}` : ''}` };
    }
    const sp = spotify(u);
    if (sp) return { url, kind: 'spotify', embed: `https://open.spotify.com/embed/${sp.type}/${sp.id}`, tall: sp.type !== 'track' && sp.type !== 'episode' };
    const host = u.hostname.replace(/^(www\.|m\.)/, '');
    if (host === 'soundcloud.com' && u.pathname.split('/').filter(Boolean).length >= 2) {
      return { url, kind: 'soundcloud', embed: `https://w.soundcloud.com/player/?url=${encodeURIComponent(url)}&visual=false&show_comments=false` };
    }

    const vm = vimeoId(u);
    if (vm) return { url, kind: 'vimeo', embed: `https://player.vimeo.com/video/${vm}` };

    if (IMAGE_EXT.test(u.pathname)) return { url, kind: 'image' };
    if (VIDEO_EXT.test(u.pathname)) return { url, kind: 'video' };
    if (AUDIO_EXT.test(u.pathname)) return { url, kind: 'audio' };
    return { url, kind: 'image', guessed: true };
  }

  // short label for a link, e.g. "youtube.com"
  const domainOf = (url) => {
    try { return new URL(url).hostname.replace(/^www\./, ''); } catch { return url; }
  };

  return { parse, domainOf };
})();
