// duplicate.js — make copies of cards (with everything inside them).
// Copies get their own stored image/video files, so deleting one never breaks the other.
window.App = window.App || {};

App.duplicate = (() => {
  const OFFSET = 32; // copies appear a little down and to the right

  const clone = (obj) => JSON.parse(JSON.stringify(obj));

  // give a copied media card its own copy of the stored file
  async function copyStoredFile(card) {
    if (!card.mediaId) return;
    try { card.mediaId = await App.mediaStore.copy(card.mediaId); } catch { card.mediaId = null; }
  }

  // attachments inside a card (and inside those), copied under the new parent
  async function copyChildren(fromId, toId) {
    for (const child of App.state.allChildrenOf(fromId)) {
      const c = clone(child);
      delete c.id;
      delete c.z;
      c.parent = toId;
      await copyStoredFile(c);
      const added = App.state.addCard(c);
      await copyChildren(child.id, added.id);
    }
  }

  /**
   * Duplicate top-level cards (and whatever is attached inside them).
   * Returns the ids of the new cards.
   */
  async function cards(ids) {
    const newIds = [];
    for (const id of ids) {
      const src = App.state.getCard(id);
      if (!src || src.parent) continue;

      const copy = clone(src);
      delete copy.id;
      delete copy.z;
      copy.x = (src.x || 0) + OFFSET;
      copy.y = (src.y || 0) + OFFSET;
      await copyStoredFile(copy);
      const added = App.state.addCard(copy);

      await copyChildren(id, added.id);
      newIds.push(added.id);
    }
    return newIds;
  }

  return { cards };
})();
