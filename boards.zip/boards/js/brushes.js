// brushes.js — brushes for canvases.
// "Pen" draws a smooth line. Every other brush stamps a brush tip (a small greyscale image)
// along the line, like in Photoshop/Krita: spacing, flow, scatter and jitter shape the look.
// Imported brushes: any PNG/JPG becomes a tip (transparent parts — or light parts of an
// image without transparency — don't paint). Brushes can be exported/imported as .json files.
// Custom brushes are saved in the browser and shared by every canvas.
window.App = window.App || {};

App.brushes = (() => {
  const KEY = 'boards.brushes';
  const TIP = 64;          // built-in tip resolution
  const MAX_IMPORT = 128;  // imported tips are scaled down to this (keeps storage small)

  // ---------- settings every stamp brush has ----------
  const DEFAULTS = {
    kind: 'stamp',
    spacing: 0.25,     // gap between stamps, as a fraction of the brush size
    flow: 1,           // see-through-ness of each stamp (low = builds up)
    angle: 'fixed',    // 'fixed' | 'follow' (turns with the line) | 'random'
    angleDeg: 0,       // for 'fixed'
    angleJitter: 0,    // ± degrees
    sizeJitter: 0,     // 0..1
    scatter: 0,        // how far stamps wander from the line (fraction of size)
    count: 1,          // stamps per step
    sizeScale: 1,      // brush size compared to the thickness slider
    stampScale: 1,     // each stamp compared to the brush size (small for spray)
  };

  const BUILT_IN = [
    { id: 'pen', name: 'Pen', kind: 'path' },
    { id: 'pencil', name: 'Pencil', tip: 'pencil', spacing: 0.12, flow: 0.55, angle: 'random', sizeJitter: 0.1, sizeScale: 1.1 },
    { id: 'soft', name: 'Soft brush', tip: 'soft', spacing: 0.08, flow: 0.18, sizeScale: 2 },
    { id: 'calligraphy', name: 'Calligraphy', tip: 'flat', spacing: 0.03, flow: 1, angle: 'fixed', angleDeg: -35, sizeScale: 1.6 },
    { id: 'chalk', name: 'Chalk', tip: 'chalk', spacing: 0.15, flow: 0.75, angle: 'random', sizeJitter: 0.2, sizeScale: 1.6 },
    { id: 'spray', name: 'Spray', tip: 'dot', spacing: 0.3, flow: 0.9, count: 16, scatter: 1, stampScale: 0.09, sizeScale: 3 },
  ].map((b) => ({ ...DEFAULTS, ...b, builtIn: true }));

  // ---------- repeatable randomness (the same line always looks the same) ----------
  function rng(seed) {
    let a = seed >>> 0;
    return () => {
      a = (a + 0x6D2B79F5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  // ---------- built-in tips (white + transparency) ----------
  function makeTip(kind) {
    const c = document.createElement('canvas');
    const w = kind === 'flat' ? TIP : kind === 'dot' ? 16 : TIP;
    const h = kind === 'flat' ? Math.round(TIP * 0.22) : w;
    c.width = w;
    c.height = h;
    const ctx = c.getContext('2d');
    if (kind === 'soft') {
      const g = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2);
      g.addColorStop(0, 'rgba(255,255,255,1)');
      g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);
      return c;
    }
    if (kind === 'flat' || kind === 'dot') {
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.ellipse(w / 2, h / 2, w / 2 - 0.5, h / 2 - 0.5, 0, 0, Math.PI * 2);
      ctx.fill();
      return c;
    }
    // grainy tips, drawn pixel by pixel
    const img = ctx.createImageData(w, h);
    const rand = rng(kind === 'pencil' ? 7 : 13);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const dx = (x + 0.5 - w / 2) / (w / 2);
        const dy = (y + 0.5 - h / 2) / (h / 2);
        const d = Math.hypot(dx, dy);
        let a = 0;
        if (kind === 'pencil' && d < 1) {
          a = (rand() > 0.45 ? 0.5 + 0.5 * rand() : 0.1 * rand()) * (1 - d * d * 0.6);
        }
        if (kind === 'chalk') {
          const edge = 1 - d * d;
          a = rand() < 0.55 * edge + 0.2 * (d < 0.9 ? 1 : 0) ? 0.85 + 0.15 * rand() : 0;
          if (d > 1 + 0.15 * rand()) a = 0;
        }
        const i = (y * w + x) * 4;
        img.data[i] = img.data[i + 1] = img.data[i + 2] = 255;
        img.data[i + 3] = Math.round(Math.max(0, Math.min(1, a)) * 255);
      }
    }
    ctx.putImageData(img, 0, 0);
    return c;
  }

  const tips = new Map(); // brush id -> tip canvas
  ['pencil', 'soft', 'flat', 'chalk', 'dot'].forEach((k) => tips.set(`builtin:${k}`, makeTip(k)));

  // ---------- custom brushes ----------
  let custom = [];
  try { custom = JSON.parse(localStorage.getItem(KEY)) || []; } catch { custom = []; }
  const persist = () => {
    try { localStorage.setItem(KEY, JSON.stringify(custom)); } catch { /* storage full */ }
  };
  const changed = () => window.dispatchEvent(new Event('brushchange')); // canvases redraw

  // turn a stored data URL into a tip canvas (async: images load in the background)
  function loadTip(brush) {
    if (!brush.tip?.startsWith('data:image/') || tips.has(brush.id)) return;
    const img = new Image();
    img.onload = () => {
      const c = document.createElement('canvas');
      c.width = img.width;
      c.height = img.height;
      c.getContext('2d').drawImage(img, 0, 0);
      tips.set(brush.id, c);
      tinted.clear();
      changed();
    };
    img.src = brush.tip;
  }
  custom.forEach(loadTip);

  const get = (id) => BUILT_IN.find((b) => b.id === id) || custom.find((b) => b.id === id) || null;
  const tipOf = (brush) => tips.get(brush.builtIn ? `builtin:${brush.tip}` : brush.id) || null;
  const isStamp = (id) => { const b = get(id); return !!b && b.kind === 'stamp' && !!tipOf(b); };

  // ---------- tinting tips with the pen colour (cached) ----------
  const tinted = new Map();
  function tintedTip(brush, color) {
    const key = `${brush.id}|${color}`;
    let c = tinted.get(key);
    if (c) return c;
    const tip = tipOf(brush);
    c = document.createElement('canvas');
    c.width = tip.width;
    c.height = tip.height;
    const ctx = c.getContext('2d');
    ctx.drawImage(tip, 0, 0);
    ctx.globalCompositeOperation = 'source-in';
    ctx.fillStyle = color;
    ctx.fillRect(0, 0, c.width, c.height);
    if (tinted.size > 200) tinted.clear();
    tinted.set(key, c);
    return c;
  }

  // ---------- stamping along a line ----------
  // the same smooth curve the pen draws: quadratic pieces through the midpoints
  function segmentsOf(p, withTail) {
    const segs = [];
    let sx = p[0];
    let sy = p[1];
    for (let i = 2; i < p.length; i += 2) {
      const ex = (p[i - 2] + p[i]) / 2;
      const ey = (p[i - 1] + p[i + 1]) / 2;
      segs.push([sx, sy, p[i - 2], p[i - 1], ex, ey]);
      sx = ex;
      sy = ey;
    }
    if (withTail && p.length > 2) {
      const lx = p[p.length - 2];
      const ly = p[p.length - 1];
      segs.push([sx, sy, (sx + lx) / 2, (sy + ly) / 2, lx, ly]);
    }
    return segs;
  }

  // a fresh "walker" for one line (keeps stamping evenly spaced and random numbers in order)
  const begin = (stroke) => ({ carry: 0, rand: rng(stroke.r || 1), done: 0, started: false });

  function stamp(ctx, brush, tip, size, x, y, dir, st) {
    for (let k = 0; k < brush.count; k++) {
      const d = size * brush.stampScale * (1 - brush.sizeJitter * st.rand());
      let ox = 0;
      let oy = 0;
      if (brush.scatter) {
        const r = brush.scatter * (size / 2) * Math.sqrt(st.rand());
        const t = st.rand() * Math.PI * 2;
        ox = Math.cos(t) * r;
        oy = Math.sin(t) * r;
      }
      let a = brush.angle === 'follow' ? dir : brush.angle === 'random' ? st.rand() * Math.PI * 2 : (brush.angleDeg || 0) * Math.PI / 180;
      if (brush.angleJitter) a += (st.rand() * 2 - 1) * brush.angleJitter * Math.PI / 180;
      const w = d;
      const h = d * (tip.height / tip.width);
      ctx.save();
      ctx.translate(x + ox, y + oy);
      if (a) ctx.rotate(a);
      ctx.globalAlpha = brush.flow;
      ctx.drawImage(tip, -w / 2, -h / 2, w, h);
      ctx.restore();
    }
  }

  // stamp along curve pieces; returns nothing, updates the walker
  function walk(ctx, brush, tip, size, segs, st) {
    const spacing = Math.max(0.4, brush.spacing * size);
    segs.forEach(([x0, y0, cx, cy, x1, y1]) => {
      const steps = Math.max(2, Math.ceil(Math.hypot(cx - x0, cy - y0) + Math.hypot(x1 - cx, y1 - cy)) / 2);
      let px = x0;
      let py = y0;
      for (let i = 1; i <= steps; i++) {
        const t = i / steps;
        const qx = (1 - t) * (1 - t) * x0 + 2 * (1 - t) * t * cx + t * t * x1;
        const qy = (1 - t) * (1 - t) * y0 + 2 * (1 - t) * t * cy + t * t * y1;
        const len = Math.hypot(qx - px, qy - py);
        const dir = Math.atan2(qy - py, qx - px);
        let pos = st.carry;
        while (pos <= len) {
          const f = len ? pos / len : 0;
          stamp(ctx, brush, tip, size, px + (qx - px) * f, py + (qy - py) * f, dir, st);
          pos += spacing;
        }
        st.carry = pos - len;
        px = qx;
        py = qy;
      }
    });
  }

  // the size of the brush in drawing units
  const sizeOf = (brush, stroke) => stroke.s * brush.sizeScale;

  // a reusable canvas for drawing a see-through line in one go
  let layer = null;
  function layerLike(ctx) {
    const { width, height } = ctx.canvas;
    if (!layer || layer.width !== width || layer.height !== height) {
      layer = document.createElement('canvas');
      layer.width = width;
      layer.height = height;
    }
    const l = layer.getContext('2d');
    l.setTransform(1, 0, 0, 1, 0, 0);
    l.clearRect(0, 0, width, height);
    l.setTransform(ctx.getTransform());
    return l;
  }

  /** draw a whole stamped line (used for finished lines, layers, mirrors and downloads) */
  function drawStamped(ctx, stroke, color) {
    const brush = get(stroke.b);
    const tip = tintedTip(brush, color);
    const size = sizeOf(brush, stroke);
    const opacity = stroke.o ?? 1;
    // a see-through line is drawn on its own first, so its stamps don't pile up past the opacity
    const target = opacity < 1 ? layerLike(ctx) : ctx;
    target.globalCompositeOperation = 'source-over';
    const st = begin(stroke);
    stamp(target, brush, tip, size, stroke.p[0], stroke.p[1], 0, st); // first stamp at the start
    st.carry = Math.max(0.4, brush.spacing * size);
    walk(target, brush, tip, size, segmentsOf(stroke.p, true), st);
    if (target !== ctx) {
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.globalAlpha = opacity;
      ctx.globalCompositeOperation = 'source-over';
      ctx.drawImage(target.canvas, 0, 0);
      ctx.restore();
    }
  }

  /** while drawing: stamp only the new finished pieces of the line onto the live canvas */
  function drawLiveStep(ctx, stroke, st, color) {
    const brush = get(stroke.b);
    const tip = tintedTip(brush, color);
    const size = sizeOf(brush, stroke);
    if (!st.started) {
      st.started = true;
      stamp(ctx, brush, tip, size, stroke.p[0], stroke.p[1], 0, st);
      st.carry = Math.max(0.4, brush.spacing * size);
    }
    const segs = segmentsOf(stroke.p, false);
    walk(ctx, brush, tip, size, segs.slice(st.done), st);
    st.done = segs.length;
  }

  // ---------- importing / exporting ----------
  // image file -> white tip with transparency
  function imageToTip(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = reject;
      reader.onload = () => {
        const img = new Image();
        img.onerror = reject;
        img.onload = () => {
          const scale = Math.min(1, MAX_IMPORT / Math.max(img.width, img.height));
          const w = Math.max(1, Math.round(img.width * scale));
          const h = Math.max(1, Math.round(img.height * scale));
          const c = document.createElement('canvas');
          c.width = w;
          c.height = h;
          const ctx = c.getContext('2d');
          ctx.drawImage(img, 0, 0, w, h);
          const data = ctx.getImageData(0, 0, w, h);
          const d = data.data;
          let seeThrough = false;
          for (let i = 3; i < d.length; i += 4) if (d[i] < 250) { seeThrough = true; break; }
          for (let i = 0; i < d.length; i += 4) {
            // transparent images: use their transparency; solid images: dark parts paint
            const lum = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
            const a = seeThrough ? d[i + 3] : 255 - lum;
            d[i] = d[i + 1] = d[i + 2] = 255;
            d[i + 3] = a;
          }
          ctx.putImageData(data, 0, 0);
          resolve(c.toDataURL('image/png'));
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  function addCustom(def) {
    const brush = { ...DEFAULTS, ...def, id: `custom-${App.state.uid()}`, builtIn: false, hidden: false };
    custom.push(brush);
    persist();
    loadTip(brush);
    return brush;
  }

  // accepts images and .json brush files; returns the new brushes
  async function importFiles(files) {
    const added = [];
    for (const file of files) {
      try {
        if (file.type.startsWith('image/')) {
          const tip = await imageToTip(file);
          added.push(addCustom({ name: file.name.replace(/\.[^.]+$/, '').slice(0, 30) || 'Brush', tip, spacing: 0.25 }));
        } else if (/json/.test(file.type) || /\.json$/i.test(file.name)) {
          const data = JSON.parse(await file.text());
          const list = data?.format === 'boards-brush' ? data.brushes : [];
          list.forEach((b) => {
            if (typeof b?.tip !== 'string' || !b.tip.startsWith('data:image/')) return;
            const settings = {};
            Object.keys(DEFAULTS).forEach((k) => { if (k !== 'kind' && b[k] !== undefined) settings[k] = b[k]; });
            added.push(addCustom({ ...settings, name: String(b.name || 'Brush').slice(0, 30), tip: b.tip }));
          });
        }
      } catch (err) {
        console.warn('Could not import brush', file.name, err);
      }
    }
    if (added.length) changed();
    return added;
  }

  function exportBrush(id) {
    const b = get(id);
    if (!b || b.builtIn) return;
    const out = { format: 'boards-brush', version: 1, brushes: [{ name: b.name, tip: b.tip }] };
    Object.keys(DEFAULTS).forEach((k) => { if (k !== 'kind') out.brushes[0][k] = b[k]; });
    const blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${b.name.replace(/[^\w-]+/g, '-') || 'brush'}.brush.json`;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }

  function update(id, patch) {
    const b = custom.find((x) => x.id === id);
    if (!b) return;
    Object.assign(b, patch);
    persist();
    changed();
  }

  // removed brushes vanish from the list, but drawings already made with them keep their look
  function remove(id) {
    update(id, { hidden: true });
  }

  // small sample stroke for the brush picker
  function preview(brush, w, h, color) {
    const c = document.createElement('canvas');
    const dpr = window.devicePixelRatio || 1;
    c.width = Math.round(w * dpr);
    c.height = Math.round(h * dpr);
    const ctx = c.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const p = [];
    for (let i = 0; i <= 12; i++) {
      const t = i / 12;
      p.push(8 + t * (w - 16), h / 2 + Math.sin(t * Math.PI * 2) * (h / 2 - 9));
    }
    // imported tips are shown a bit bigger so you can see their shape
    const s = brush.builtIn ? (brush.id === 'spray' ? 4 : 5) : Math.min(14, h * 0.6) / brush.sizeScale;
    const stroke = { b: brush.id, c: 'ink', s, p, r: 42 };
    if (brush.kind === 'path' || !tipOf(brush)) {
      ctx.strokeStyle = color;
      ctx.lineWidth = 3;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(p[0], p[1]);
      for (let i = 2; i < p.length; i += 2) ctx.quadraticCurveTo(p[i - 2], p[i - 1], (p[i - 2] + p[i]) / 2, (p[i - 1] + p[i + 1]) / 2);
      ctx.stroke();
    } else {
      drawStamped(ctx, stroke, color);
    }
    return c;
  }

  return {
    get,
    list: () => [...BUILT_IN, ...custom.filter((b) => !b.hidden)],
    isStamp,
    begin,
    drawStamped,
    drawLiveStep,
    importFiles,
    exportBrush,
    update,
    remove,
    preview,
  };
})();
