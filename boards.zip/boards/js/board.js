// board.js — draws all cards onto the canvas and handles adding new ones
window.App = window.App || {};

App.board = (() => {
  let canvas;
  let viewport;

  function renderCard(card) {
    const type = App.cardTypes[card.type];
    if (!type) return null;
    const { el, body } = App.createCardShell(card);
    type.render(card, body);
    return el;
  }

  function emptyState() {
    const el = document.createElement('div');
    el.className = 'empty-state';
    el.innerHTML = '<strong>This board is empty</strong>Drag a note, to-do list or media card in from the left, or double-click anywhere to add a note.';
    return el;
  }

  // Only adds/removes cards that changed, so existing cards (and playing videos) are left alone
  // Only adds/removes cards that changed, so existing cards (and playing videos) are left alone.
  // Nested cards are drawn by their parent; a parent is redrawn when its children change.
  function render(data) {
    const topLevel = data.cards.filter((c) => !c.parent);
    const ids = new Set(topLevel.map((c) => c.id));
    const childKey = (id) => data.cards.filter((c) => c.parent === id).map((c) => c.id).join(',');
    const existing = new Map([...canvas.querySelectorAll(':scope > .card')].map((el) => [el.dataset.id, el]));

    canvas.querySelector('.empty-state')?.remove();
    existing.forEach((el, id) => { if (!ids.has(id)) el.remove(); });

    topLevel.forEach((card) => {
      const el = existing.get(card.id);
      const key = childKey(card.id);
      if (el && el.dataset.children === key) return;
      const fresh = renderCard(card);
      if (!fresh) return;
      fresh.dataset.children = key;
      if (el) el.replaceWith(fresh);
      else canvas.append(fresh);
    });

    if (!topLevel.length) canvas.append(emptyState());
  }

  // Board coordinates for a point on screen
  function toCanvasPoint(clientX, clientY) {
    const rect = canvas.getBoundingClientRect();
    return { x: clientX - rect.left, y: clientY - rect.top };
  }

  function visibleCenter() {
    return {
      x: viewport.scrollLeft + viewport.clientWidth / 2 - 130,
      y: viewport.scrollTop + viewport.clientHeight / 2 - 80,
    };
  }

  // extra = starting data, e.g. a mediaId for a file that was dropped in
  function addCard(type, point = visibleCenter(), extra = {}) {
    const def = App.cardTypes[type];
    if (!def) return null;
    const card = App.state.addCard({
      type,
      x: Math.max(0, Math.round(point.x)),
      y: Math.max(0, Math.round(point.y)),
      ...def.defaults(),
      ...extra,
    });
    const el = canvas.querySelector(`.card[data-id="${card.id}"]`);
    if (el) def.focus?.(el);
    return card;
  }

  function init() {
    canvas = document.getElementById('canvas');
    viewport = document.getElementById('viewport');

    render(App.state.get());
    App.state.subscribe(render);
    App.drag.attach(canvas);
    App.resize.attach(canvas);
    App.wires.init();

    canvas.addEventListener('dblclick', (e) => {
      if (e.target !== canvas) return;
      const p = toCanvasPoint(e.clientX, e.clientY);
      addCard('note', { x: p.x - 20, y: p.y - 14 });
    });
  }

  return { init, addCard, toCanvasPoint };
})();
