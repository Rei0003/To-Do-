// board.js — draws all cards onto the canvas and handles adding new ones
window.App = window.App || {};

App.board = (() => {
  let canvas;
  let viewport;

  function renderCard(card) {
    const type = App.cardTypes[card.type];
    if (!type) return null;
    const { el, body } = App.createCardShell(card);
    type.render(card, body);
    return el;
  }

  function emptyState() {
    const el = document.createElement('div');
    el.className = 'empty-state';
    el.innerHTML = '<strong>This board is empty</strong>Drag a note or to-do list in from the left, or double-click anywhere to add a note.';
    return el;
  }

  function render(data) {
    canvas.replaceChildren(...data.cards.map(renderCard).filter(Boolean));
    if (!data.cards.length) canvas.append(emptyState());
  }

  // Board coordinates for a point on screen
  function toCanvasPoint(clientX, clientY) {
    const rect = canvas.getBoundingClientRect();
    return { x: clientX - rect.left, y: clientY - rect.top };
  }

  function visibleCenter() {
    return {
      x: viewport.scrollLeft + viewport.clientWidth / 2 - 130,
      y: viewport.scrollTop + viewport.clientHeight / 2 - 80,
    };
  }

  function addCard(type, point = visibleCenter()) {
    const def = App.cardTypes[type];
    if (!def) return;
    const card = App.state.addCard({
      type,
      x: Math.max(0, Math.round(point.x)),
      y: Math.max(0, Math.round(point.y)),
      ...def.defaults(),
    });
    const el = canvas.querySelector(`.card[data-id="${card.id}"]`);
    if (el) def.focus?.(el);
  }

  function init() {
    canvas = document.getElementById('canvas');
    viewport = document.getElementById('viewport');

    render(App.state.get());
    App.state.subscribe(render);
    App.drag.attach(canvas);

    canvas.addEventListener('dblclick', (e) => {
      if (e.target !== canvas) return;
      const p = toCanvasPoint(e.clientX, e.clientY);
      addCard('note', { x: p.x - 20, y: p.y - 14 });
    });
  }

  return { init, addCard, toCanvasPoint };
})();
