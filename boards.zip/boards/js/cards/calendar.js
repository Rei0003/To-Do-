// calendar.js — a month calendar card with events.
//  • ‹ › to change month, "Today" to jump back
//  • click a day to see its events below; double-click a day to add one straight away
//  • events have a title, an optional time and a colour (presets, saved or custom colours)
//  • drag an event (by its grip, or its little bar in the grid) onto another day to move it
//  • make the card wider to see event titles inside the days
//  • drop images/videos (or a media card) on a day to attach them to that day
//    (dropped elsewhere on the calendar they go on the selected day)
// Data on the card: events [{ id, date: 'YYYY-MM-DD', time: 'HH:MM' | '', title, color }],
// month ('YYYY-MM' being viewed), selected ('YYYY-MM-DD').
window.App = window.App || {};

App.cardTypes.calendar = (() => {
  const DRAG_TYPE = 'application/x-calendar-event';
  // the browser's language for dates — falls back safely if it reports an unusual code
  const locale = (() => {
    const wanted = String(navigator.language || '').split('@')[0];
    try { new Intl.DateTimeFormat(wanted); return wanted || undefined; } catch { return undefined; }
  })();
  const fmtMonth = new Intl.DateTimeFormat(locale, { month: 'long', year: 'numeric' });
  const fmtDay = new Intl.DateTimeFormat(locale, { weekday: 'long', day: 'numeric', month: 'long' });
  const fmtWeekday = new Intl.DateTimeFormat(locale, { weekday: 'short' });
  const fmtLong = new Intl.DateTimeFormat(locale, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const fmtShort = new Intl.DateTimeFormat(locale, { day: 'numeric', month: 'short' });

  const ICONS = {
    prev: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M10 3.5L5.5 8l4.5 4.5"/></svg>',
    next: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3.5L10.5 8 6 12.5"/></svg>',
    clip: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M10.5 5.5L6 10a1.4 1.4 0 0 0 2 2l5-5a2.8 2.8 0 0 0-4-4L4 8a4.2 4.2 0 0 0 6 6l3.5-3.5"/></svg>',
    remove: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>',
    grip: '<svg viewBox="0 0 12 12" fill="currentColor"><circle cx="4" cy="3" r="1"/><circle cx="8" cy="3" r="1"/><circle cx="4" cy="6" r="1"/><circle cx="8" cy="6" r="1"/><circle cx="4" cy="9" r="1"/><circle cx="8" cy="9" r="1"/></svg>',
  };

  // ---------- dates (always local time, stored as 'YYYY-MM-DD') ----------
  const pad = (n) => String(n).padStart(2, '0');
  const keyOf = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const dateOf = (key) => { const [y, m, d] = key.split('-').map(Number); return new Date(y, m - 1, d); };
  const todayKey = () => keyOf(new Date());
  const monthKeyOf = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;

  // Monday-first weekday names in the browser's language (1 Jan 2024 was a Monday)
  const WEEKDAYS = Array.from({ length: 7 }, (_, i) => fmtWeekday.format(new Date(2024, 0, 1 + i)));

  // events of one day: all-day ones first, then by time
  const sortDay = (list) => list.slice().sort((a, b) => (a.time || '').localeCompare(b.time || ''));

  // ---------- small colour menu for an existing event ----------
  let colorMenu = null;
  function closeColorMenu() {
    colorMenu?.remove();
    colorMenu = null;
    document.removeEventListener('pointerdown', onOutsideMenu, true);
  }
  function onOutsideMenu(e) {
    if (colorMenu && !colorMenu.contains(e.target) && !e.target.closest('.color-pop')) closeColorMenu();
  }
  function openColorMenu(anchor, value, onPick) {
    closeColorMenu();
    App.tooltip?.hide();
    colorMenu = document.createElement('div');
    colorMenu.className = 'cal-color-menu';
    const row = App.palette.create({
      presets: App.COLORS.slice(1).map((c) => ({ value: c, label: App.colorName(c), css: `var(--c-${c})` })),
      value,
      visible: 6,
      size: 18,
      onPick: (c) => { onPick(c); closeColorMenu(); },
    });
    colorMenu.append(row.el);
    document.body.append(colorMenu);
    const r = anchor.getBoundingClientRect();
    const w = colorMenu.offsetWidth;
    colorMenu.style.left = `${Math.min(Math.max(8, r.left - 8), window.innerWidth - w - 8)}px`;
    colorMenu.style.top = `${Math.min(r.bottom + 6, window.innerHeight - colorMenu.offsetHeight - 8)}px`;
    document.addEventListener('pointerdown', onOutsideMenu, true);
  }

  // ---------- card ----------
  function render(card, body) {
    card.events = card.events || [];
    let view = card.month ? dateOf(`${card.month}-01`) : new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    let selected = card.selected || todayKey();
    let newColor = 'blue';

    const root = document.createElement('div');
    root.className = 'cal';
    root.innerHTML = `
      <div class="cal-head">
        <button class="cal-nav" data-cal="prev" aria-label="Previous month" data-tooltip="Previous month">${ICONS.prev}</button>
        <h3 class="cal-title" aria-live="polite"></h3>
        <button class="cal-nav" data-cal="next" aria-label="Next month" data-tooltip="Next month">${ICONS.next}</button>
        <button class="cal-today" data-cal="today">Today</button>
      </div>
      <div class="cal-weekdays" aria-hidden="true">${WEEKDAYS.map((d) => `<span>${d}</span>`).join('')}</div>
      <div class="cal-grid" role="grid"></div>
      <div class="cal-day">
        <p class="cal-day-title"></p>
        <ul class="cal-events"></ul>
        <div class="attachments cal-attachments"></div>
        <div class="cal-add">
          <input class="cal-add-time" type="time" aria-label="Time (optional)" data-tooltip="Time (optional)">
          <input class="cal-add-title" type="text" placeholder="Add an event, press Enter" aria-label="New event">
          <span class="cal-add-color"></span>
        </div>
      </div>`;
    body.append(root);

    const title = root.querySelector('.cal-title');
    const grid = root.querySelector('.cal-grid');
    const dayTitle = root.querySelector('.cal-day-title');
    const list = root.querySelector('.cal-events');
    const dayAttachments = root.querySelector('.cal-attachments');
    const addTime = root.querySelector('.cal-add-time');
    const addTitle = root.querySelector('.cal-add-title');

    // colour for new events
    const addPalette = App.palette.create({
      presets: App.COLORS.slice(1).map((c) => ({ value: c, label: App.colorName(c), css: `var(--c-${c})` })),
      value: newColor,
      visible: 5,
      size: 14,
      onPick: (c) => { newColor = c; },
    });
    root.querySelector('.cal-add-color').append(addPalette.el);

    const save = () => App.state.updateCard(card.id, { events: card.events, month: monthKeyOf(view), selected });
    const eventsOn = (key) => sortDay(card.events.filter((ev) => ev.date === key));

    // ----- month grid -----
    function drawGrid() {
      title.textContent = fmtMonth.format(view);
      const first = new Date(view.getFullYear(), view.getMonth(), 1);
      const lead = (first.getDay() + 6) % 7; // days shown from the previous month (Monday first)
      const today = todayKey();
      const byDay = new Map();
      card.events.forEach((ev) => byDay.set(ev.date, [...(byDay.get(ev.date) || []), ev]));

      const cells = [];
      for (let i = 0; i < 42; i++) {
        const d = new Date(view.getFullYear(), view.getMonth(), 1 - lead + i);
        const key = keyOf(d);
        const evs = sortDay(byDay.get(key) || []);
        const cell = document.createElement('button');
        cell.className = 'cal-cell';
        cell.dataset.date = key;
        cell.setAttribute('role', 'gridcell');
        cell.classList.toggle('is-other', d.getMonth() !== view.getMonth());
        cell.classList.toggle('is-today', key === today);
        cell.classList.toggle('is-weekend', i % 7 >= 5);
        cell.setAttribute('aria-selected', String(key === selected));
        cell.setAttribute('aria-label', `${fmtLong.format(d)}${evs.length ? `, ${evs.length} event${evs.length > 1 ? 's' : ''}` : ''}`);
        cell.dataset.attachItem = key; // media can be dropped on this day
        cell.dataset.attachLabel = fmtShort.format(d);

        const num = document.createElement('span');
        num.className = 'cal-num';
        num.textContent = d.getDate();
        const marks = document.createElement('span');
        marks.className = 'cal-marks';
        evs.slice(0, 3).forEach((ev) => {
          const m = document.createElement('span');
          m.className = 'cal-mark';
          m.draggable = true;
          m.dataset.event = ev.id;
          m.style.setProperty('--ev', App.colorCss(ev.color || 'blue'));
          m.textContent = `${ev.time ? `${ev.time} ` : ''}${ev.title}`;
          marks.append(m);
        });
        if (evs.length > 3) {
          const more = document.createElement('span');
          more.className = 'cal-more';
          more.textContent = `+${evs.length - 3}`;
          marks.append(more);
        }
        cell.append(num, marks);
        // paperclip when something is attached to the day
        const attached = App.state.childrenOf(card.id, key).length;
        if (attached) {
          const clip = document.createElement('span');
          clip.className = 'cal-clip';
          clip.innerHTML = ICONS.clip;
          clip.title = `${attached} attached`;
          cell.append(clip);
        }
        cells.push(cell);
      }
      grid.replaceChildren(...cells);
    }

    // ----- selected day: its events + add row -----
    function drawDay() {
      dayTitle.textContent = fmtDay.format(dateOf(selected)) + (selected === todayKey() ? ' · Today' : '');
      const evs = eventsOn(selected);
      list.replaceChildren(...evs.map((ev) => {
        const li = document.createElement('li');
        li.className = 'cal-event';
        li.dataset.event = ev.id;
        li.innerHTML = `
          <span class="cal-grip" draggable="true" data-tooltip="Drag to another day">${ICONS.grip}</span>
          <button class="cal-dot" aria-label="Event colour" data-tooltip="Colour"></button>
          <input class="cal-time" type="time" aria-label="Time">
          <input class="cal-ev-title" type="text" aria-label="Event title">
          <button class="card-btn cal-remove" aria-label="Delete event" data-tooltip="Delete">${ICONS.remove}</button>`;
        li.querySelector('.cal-dot').style.setProperty('--ev', App.colorCss(ev.color || 'blue'));
        li.querySelector('.cal-time').value = ev.time || '';
        li.querySelector('.cal-ev-title').value = ev.title;
        return li;
      }));
      if (!evs.length) {
        const empty = document.createElement('li');
        empty.className = 'cal-empty';
        empty.textContent = 'No events';
        list.append(empty);
      }
      // images/videos attached to this day
      dayAttachments.replaceChildren();
      App.nesting.renderAttachments(card, dayAttachments, selected);
    }

    const drawAll = () => { drawGrid(); drawDay(); };

    function select(key) {
      selected = key;
      const d = dateOf(key);
      if (d.getMonth() !== view.getMonth() || d.getFullYear() !== view.getFullYear()) {
        view = new Date(d.getFullYear(), d.getMonth(), 1);
        drawAll();
      } else {
        // same month: just move the highlight (rebuilding the grid would swallow double-clicks)
        grid.querySelectorAll('.cal-cell').forEach((c) => c.setAttribute('aria-selected', String(c.dataset.date === key)));
        drawDay();
      }
      save();
    }

    function addEvent() {
      const text = addTitle.value.trim();
      if (!text) return;
      card.events.push({ id: App.state.uid(), date: selected, time: addTime.value || '', title: text, color: newColor });
      addTitle.value = '';
      addTime.value = '';
      save();
      drawAll();
      addTitle.focus();
    }

    // ----- clicks -----
    root.addEventListener('click', (e) => {
      const nav = e.target.closest('[data-cal]')?.dataset.cal;
      if (nav === 'prev') { view = new Date(view.getFullYear(), view.getMonth() - 1, 1); drawGrid(); save(); return; }
      if (nav === 'next') { view = new Date(view.getFullYear(), view.getMonth() + 1, 1); drawGrid(); save(); return; }
      if (nav === 'today') { view = new Date(new Date().getFullYear(), new Date().getMonth(), 1); select(todayKey()); return; }

      const cell = e.target.closest('.cal-cell');
      if (cell) { select(cell.dataset.date); return; }

      const row = e.target.closest('.cal-event');
      if (!row) return;
      const ev = card.events.find((x) => x.id === row.dataset.event);
      if (e.target.closest('.cal-remove')) {
        card.events = card.events.filter((x) => x !== ev);
        App.tooltip?.hide();
        save();
        drawAll();
      } else if (e.target.closest('.cal-dot')) {
        openColorMenu(e.target.closest('.cal-dot'), ev.color || 'blue', (c) => { ev.color = c; save(); drawAll(); });
      }
    });

    // double-click a day: select it and start typing an event
    grid.addEventListener('dblclick', (e) => {
      const cell = e.target.closest('.cal-cell');
      if (!cell) return;
      e.stopPropagation(); // don't let the board make a note
      select(cell.dataset.date);
      addTitle.focus();
    });

    // ----- editing events in the list -----
    list.addEventListener('change', (e) => {
      const row = e.target.closest('.cal-event');
      const ev = row && card.events.find((x) => x.id === row.dataset.event);
      if (!ev) return;
      if (e.target.classList.contains('cal-time')) ev.time = e.target.value || '';
      if (e.target.classList.contains('cal-ev-title')) {
        const t = e.target.value.trim();
        if (t) ev.title = t;
        else e.target.value = ev.title; // don't allow empty titles
      }
      save();
      drawAll();
    });
    list.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && e.target.matches('.cal-ev-title, .cal-time')) e.target.blur();
    });

    addTitle.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); addEvent(); }
    });
    addTime.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); addTitle.focus(); }
    });

    // ----- drag an event to another day -----
    root.addEventListener('dragstart', (e) => {
      const source = e.target.closest('.cal-grip, .cal-mark');
      if (!source) return;
      const id = source.dataset.event || source.closest('.cal-event')?.dataset.event;
      e.dataTransfer.setData(DRAG_TYPE, id);
      e.dataTransfer.effectAllowed = 'move';
      e.stopPropagation();
    });
    grid.addEventListener('dragover', (e) => {
      const cell = e.target.closest('.cal-cell');
      if (!cell || !e.dataTransfer.types.includes(DRAG_TYPE)) return;
      e.preventDefault();
      e.stopPropagation();
      e.dataTransfer.dropEffect = 'move';
      grid.querySelectorAll('.is-drop').forEach((c) => c !== cell && c.classList.remove('is-drop'));
      cell.classList.add('is-drop');
    });
    grid.addEventListener('dragleave', (e) => {
      if (!grid.contains(e.relatedTarget)) grid.querySelectorAll('.is-drop').forEach((c) => c.classList.remove('is-drop'));
    });
    grid.addEventListener('drop', (e) => {
      const cell = e.target.closest('.cal-cell');
      const id = e.dataTransfer.getData(DRAG_TYPE);
      if (!cell || !id) return;
      e.preventDefault();
      e.stopPropagation();
      const ev = card.events.find((x) => x.id === id);
      if (ev) ev.date = cell.dataset.date;
      selected = cell.dataset.date;
      save();
      drawAll();
    });

    // move around days with the arrow keys
    grid.addEventListener('keydown', (e) => {
      const steps = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 };
      if (!(e.key in steps)) return;
      e.preventDefault();
      const d = dateOf(selected);
      select(keyOf(new Date(d.getFullYear(), d.getMonth(), d.getDate() + steps[e.key])));
      grid.querySelector(`[data-date="${selected}"]`)?.focus();
    });

    drawAll();
  }

  return {
    label: 'Calendar',
    accepts: ['media', 'file'], // attach images, videos, audio and files to a day
    // dropped somewhere other than a day: use the selected day
    defaultItem: (data) => data.selected || todayKey(),
    itemLabel: (key) => fmtShort.format(dateOf(key)),
    resizable: true, // width; wider calendars show event titles in the days
    minWidth: 280,
    maxWidth: 1100,
    defaults: () => ({ events: [], width: 340 }),
    render,
    focus(el) { el.querySelector('.cal-add-title')?.focus(); },
  };
})();
