// board-card.js — a card that is a board of its own. Click it to go inside.
// It shows the board's name (rename it right here), a tiny preview of its layout and how many
// cards it has. Duplicating copies the whole board inside it; deleting asks, then deletes it too.
// Data on the card: boardId (the board inside), title (last known name, for quick drawing).
window.App = window.App || {};

App.cardTypes.board = (() => {
  const PREVIEW_COLORS = {
    note: 'var(--c-yellow)', todo: 'var(--c-green)', media: 'var(--c-blue)', drawing: 'var(--c-purple)',
    calendar: 'var(--c-pink)', table: 'var(--muted)', chart: 'var(--c-blue)', file: 'var(--danger)', board: 'var(--ink)', shape: 'var(--c-purple)',
  };
  const creating = new Set(); // cards whose board is being made right now

  // summaries are fetched in one request for all board cards on the page
  let queue = new Map();
  let timer = 0;
  function summary(id) {
    return new Promise((resolve) => {
      if (!queue.has(id)) queue.set(id, []);
      queue.get(id).push(resolve);
      clearTimeout(timer);
      timer = setTimeout(async () => {
        const batch = queue;
        queue = new Map();
        let res = {};
        try { res = await App.boards.summaries([...batch.keys()]); } catch { /* offline: keep what we have */ }
        batch.forEach((fns, key) => fns.forEach((fn) => fn(res?.[key] ?? undefined)));
      }, 30);
    });
  }

  // a little picture of where the cards sit on the inner board
  function previewSvg(preview) {
    if (!preview?.length) return '<p class="bc-empty">Empty board</p>';
    const minX = Math.min(...preview.map((p) => p[0]));
    const minY = Math.min(...preview.map((p) => p[1]));
    const maxX = Math.max(...preview.map((p) => p[0] + p[2]));
    const maxY = Math.max(...preview.map((p) => p[1] + p[3]));
    const w = Math.max(400, maxX - minX + 80);
    const h = Math.max(240, maxY - minY + 80);
    const rects = preview.map(([x, y, cw, ch, type]) =>
      `<rect x="${x - minX + 40}" y="${y - minY + 40}" width="${cw}" height="${ch}" rx="14" fill="${PREVIEW_COLORS[type] || 'var(--muted)'}"/>`).join('');
    return `<svg class="bc-map" viewBox="0 0 ${w} ${h}" preserveAspectRatio="xMidYMid meet" aria-hidden="true">${rects}</svg>`;
  }

  function render(card, body) {
    const wrap = document.createElement('div');
    wrap.className = 'bc';
    wrap.innerHTML = `
      <button class="bc-open" aria-label="Open this board">
        <span class="bc-preview"><span class="bc-loading"></span></span>
        <span class="bc-go">Open board
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3.5L10.5 8 6 12.5"/></svg></span>
      </button>
      <input class="bc-title" maxlength="200" aria-label="Board name" placeholder="Untitled board">
      <p class="bc-meta"></p>`;
    body.append(wrap);
    const title = wrap.querySelector('.bc-title');
    const meta = wrap.querySelector('.bc-meta');
    const preview = wrap.querySelector('.bc-preview');
    title.value = card.title || '';

    const open = () => { if (card.boardId) location.hash = `#/board/${card.boardId}`; };
    wrap.querySelector('.bc-open').addEventListener('click', open);
    title.addEventListener('keydown', (e) => { if (e.key === 'Enter') title.blur(); });

    // renaming here renames the board inside
    let renameTimer = 0;
    title.addEventListener('input', () => {
      card.title = title.value;
      App.state.updateCard(card.id, { title: title.value });
      clearTimeout(renameTimer);
      renameTimer = setTimeout(() => {
        if (card.boardId) App.boards.rename(card.boardId, title.value.trim() || 'Untitled board').catch(() => {});
      }, 600);
    });

    function show(s) {
      if (s === null) { // the board inside is gone (or you can't open it)
        preview.innerHTML = '<p class="bc-empty">This board isn’t available</p>';
        meta.textContent = '';
        wrap.classList.add('is-missing');
        return;
      }
      if (!s) return;
      if (document.activeElement !== title && s.title && s.title !== title.value) {
        title.value = s.title;
        if (s.title !== card.title) { card.title = s.title; App.state.updateCard(card.id, { title: s.title }); }
      }
      preview.innerHTML = previewSvg(s.preview);
      meta.textContent = `${s.cards} card${s.cards === 1 ? '' : 's'}`;
    }

    // a new board card: make its board (inside the board you're on)
    if (!card.boardId) {
      if (creating.has(card.id)) return;
      creating.add(card.id);
      const parent = App.storage.boardId || null;
      App.boards.create(card.title || 'Untitled board', null, parent).then((b) => {
        card.boardId = b.id;
        App.state.updateCard(card.id, { boardId: b.id, title: b.title });
        show({ title: b.title, cards: 0, preview: [] });
        title.focus();
        title.select();
      }).catch((err) => {
        preview.innerHTML = `<p class="bc-empty">${err.message}</p>`;
      }).finally(() => creating.delete(card.id));
      return;
    }
    summary(card.boardId).then(show);
  }

  return {
    label: 'Board',
    resizable: true,
    minWidth: 180,
    maxWidth: 520,
    defaults: () => ({ boardId: null, title: 'Untitled board', width: 240 }),
    render,
    focus(el) { el.querySelector('.bc-title')?.focus(); },
    // deleting the card deletes the board inside it — so ask first
    confirmDelete: (card) => ({
      title: `Delete “${card.title || 'Untitled board'}”?`,
      message: 'The board inside and everything on it (including boards inside it) are deleted too.',
      confirmLabel: 'Delete board',
    }),
    onRemove(card) { if (card.boardId) App.boards.remove(card.boardId).catch(() => {}); },
    // duplicating the card copies the board inside it (with everything in it)
    async onDuplicate(card) {
      if (!card.boardId) return;
      try {
        const copy = await App.boards.duplicate(card.boardId, App.storage.boardId || null);
        card.boardId = copy.id;
      } catch { card.boardId = null; }
    },
  };
})();
