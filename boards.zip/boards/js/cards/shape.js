// shape.js — a card that is a shape: rectangle, rounded rectangle, ellipse, triangle, diamond,
// line or arrow (8 directions). Outline / filled / soft fill, any colour, any thickness, and text
// inside (great for flowcharts). Resize it from the corner; wire it to other cards like any card.
// Data: card.shape = { kind, fill (0 outline · 1 filled · 2 soft), color, stroke, dir }, card.html (text).
window.App = window.App || {};

App.cardTypes.shape = (() => {
  const KINDS = [
    { id: 'rect', label: 'Rectangle' }, { id: 'rounded', label: 'Rounded rectangle' }, { id: 'ellipse', label: 'Ellipse' },
    { id: 'triangle', label: 'Triangle' }, { id: 'diamond', label: 'Diamond' }, { id: 'line', label: 'Line' }, { id: 'arrow', label: 'Arrow' },
  ];
  const FILLS = [{ id: 0, label: 'Outline' }, { id: 1, label: 'Filled' }, { id: 2, label: 'Soft fill' }];
  const DIRS = [ // where a line / arrow points
    { id: 'nw', a: '↖' }, { id: 'n', a: '↑' }, { id: 'ne', a: '↗' }, { id: 'w', a: '←' },
    { id: 'e', a: '→' }, { id: 'sw', a: '↙' }, { id: 's', a: '↓' }, { id: 'se', a: '↘' },
  ];
  const COLORS = ['ink', 'red', 'orange', 'green', 'blue', 'purple', 'pink'];
  const COLOR_NAMES = { ink: 'Ink', red: 'Red', orange: 'Orange', green: 'Green', blue: 'Blue', purple: 'Purple', pink: 'Pink' };
  const colorCss = (c) => (String(c).startsWith('#') ? c : c === 'ink' ? 'var(--ink)' : `var(--tc-${c})`);
  const isLine = (k) => k === 'line' || k === 'arrow';

  const ICON = {
    rect: '<rect x="2.5" y="4" width="11" height="8" rx=".8"/>',
    rounded: '<rect x="2.5" y="4" width="11" height="8" rx="3"/>',
    ellipse: '<ellipse cx="8" cy="8" rx="5.8" ry="4.4"/>',
    triangle: '<path d="M8 3l5.5 9.5h-11z"/>',
    diamond: '<path d="M8 2l6 6-6 6-6-6z"/>',
    line: '<path d="M3 13L13 3"/>',
    arrow: '<path d="M3 13L12.5 3.5M7 3.5h5.5V9"/>',
  };
  const icon = (k) => `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">${ICON[k]}</svg>`;

  // ---------- drawing (SVG at the card's real size, so the line stays the chosen thickness) ----------
  function draw(svg, sh, w, h) {
    const s = sh.stroke;
    const p = s / 2 + 1;
    const [x0, y0, x1, y1] = [p, p, Math.max(p + 1, w - p), Math.max(p + 1, h - p)];
    const cx = w / 2;
    const cy = h / 2;
    const col = colorCss(sh.color);
    svg.setAttribute('viewBox', `0 0 ${w} ${h}`);
    const fill = sh.fill ? col : 'none';
    const fillOpacity = sh.fill === 2 ? 0.22 : 1;
    const common = `stroke="${col}" stroke-width="${s}" stroke-linejoin="round" stroke-linecap="round" fill="${fill}" fill-opacity="${fillOpacity}"`;
    let body = '';
    if (sh.kind === 'rect') body = `<rect x="${x0}" y="${y0}" width="${x1 - x0}" height="${y1 - y0}" ${common}/>`;
    if (sh.kind === 'rounded') body = `<rect x="${x0}" y="${y0}" width="${x1 - x0}" height="${y1 - y0}" rx="${Math.min(22, (y1 - y0) / 2, (x1 - x0) / 2)}" ${common}/>`;
    if (sh.kind === 'ellipse') body = `<ellipse cx="${cx}" cy="${cy}" rx="${(x1 - x0) / 2}" ry="${(y1 - y0) / 2}" ${common}/>`;
    if (sh.kind === 'triangle') body = `<polygon points="${cx},${y0} ${x1},${y1} ${x0},${y1}" ${common}/>`;
    if (sh.kind === 'diamond') body = `<polygon points="${cx},${y0} ${x1},${cy} ${cx},${y1} ${x0},${cy}" ${common}/>`;
    if (isLine(sh.kind)) {
      const ends = {
        e: [x0, cy, x1, cy], w: [x1, cy, x0, cy], s: [cx, y0, cx, y1], n: [cx, y1, cx, y0],
        se: [x0, y0, x1, y1], nw: [x1, y1, x0, y0], ne: [x0, y1, x1, y0], sw: [x1, y0, x0, y1],
      }[sh.dir || 'e'];
      let [ax, ay, bx, by] = ends;
      const ang = Math.atan2(by - ay, bx - ax);
      let head = '';
      if (sh.kind === 'arrow') {
        const len = Math.max(10, s * 3.2);
        const spread = 0.5;
        const tip = [bx, by];
        const l = [bx - Math.cos(ang - spread) * len, by - Math.sin(ang - spread) * len];
        const r = [bx - Math.cos(ang + spread) * len, by - Math.sin(ang + spread) * len];
        head = `<polygon points="${tip} ${l} ${r}" fill="${col}" stroke="${col}" stroke-width="${Math.max(1, s * 0.6)}" stroke-linejoin="round"/>`;
        bx -= Math.cos(ang) * len * 0.7; // the line stops where the head starts
        by -= Math.sin(ang) * len * 0.7;
      }
      body = `<line x1="${ax}" y1="${ay}" x2="${bx}" y2="${by}" stroke="${col}" stroke-width="${s}" stroke-linecap="round"/>${head}`;
    }
    svg.innerHTML = body;
  }

  // ---------- the style panel ----------
  let panel = null;
  let panelAnchor = null;
  function closePanel() {
    panel?.remove();
    panel = null;
    panelAnchor = null;
    document.removeEventListener('pointerdown', outside, true);
    document.removeEventListener('keydown', onKey, true);
  }
  function outside(e) { if (panel && !panel.contains(e.target) && !panelAnchor?.contains(e.target) && !e.target.closest('.color-pop')) closePanel(); }
  function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); closePanel(); } }

  function openStyle(anchor, card, apply) {
    if (panelAnchor === anchor) return closePanel();
    closePanel();
    App.tooltip?.hide();
    const sh = card.shape;
    panel = document.createElement('div');
    panel.className = 'draw-panel shape-panel';
    panel.innerHTML = `
      <p class="draw-panel-title">Shape</p>
      <div class="shape-grid sp-kinds">${KINDS.map((k) => `<button class="shape-btn" data-kind="${k.id}" aria-label="${k.label}" data-tooltip="${k.label}">${icon(k.id)}</button>`).join('')}</div>
      <div class="sp-dirs" ${isLine(sh.kind) ? '' : 'hidden'}>
        <span class="sp-label">Direction</span>
        <div class="sp-dir-grid">${DIRS.map((d, i) => `${i === 4 ? '<span></span>' : ''}<button class="sp-dir" data-dir="${d.id}" aria-label="Point ${d.id}">${d.a}</button>`).join('')}</div>
      </div>
      <div class="shape-fills sp-fills" role="radiogroup" aria-label="Fill" ${isLine(sh.kind) ? 'hidden' : ''}>
        ${FILLS.map((f) => `<button class="shape-fill" data-fill="${f.id}" role="radio">${f.label}</button>`).join('')}
      </div>
      <span class="sp-label">Colour</span>
      <div class="sp-colors"></div>
      <label class="draw-panel-row sp-thick"><span>Thickness</span>
        <input type="range" min="1" max="16" step="1" aria-label="Line thickness"><output></output></label>`;
    const row = App.palette.create({
      presets: COLORS.map((c) => ({ value: c, label: COLOR_NAMES[c], css: colorCss(c) })),
      value: sh.color,
      visible: 7,
      size: 20,
      onPick: (c) => { apply({ color: c }); },
    });
    panel.querySelector('.sp-colors').append(row.el);
    const thick = panel.querySelector('.sp-thick input');
    const mark = () => {
      const now = card.shape;
      panel.querySelectorAll('[data-kind]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.kind === now.kind)));
      panel.querySelectorAll('[data-fill]').forEach((b) => b.setAttribute('aria-checked', String(+b.dataset.fill === now.fill)));
      panel.querySelectorAll('[data-dir]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.dir === (now.dir || 'e'))));
      panel.querySelector('.sp-dirs').hidden = !isLine(now.kind);
      panel.querySelector('.sp-fills').hidden = isLine(now.kind);
      thick.value = now.stroke;
      panel.querySelector('.sp-thick output').textContent = `${now.stroke}px`;
    };
    panel.addEventListener('click', (e) => {
      const k = e.target.closest('[data-kind]')?.dataset.kind;
      const f = e.target.closest('[data-fill]')?.dataset.fill;
      const d = e.target.closest('[data-dir]')?.dataset.dir;
      if (k) apply({ kind: k });
      if (f !== undefined) apply({ fill: +f });
      if (d) apply({ dir: d });
      mark();
    });
    thick.addEventListener('input', () => { apply({ stroke: +thick.value }); mark(); });
    mark();
    document.body.append(panel);
    const r = anchor.getBoundingClientRect();
    const h = panel.offsetHeight;
    let top = r.bottom + 6;
    if (top + h > window.innerHeight - 8) top = r.top - h - 6;
    panel.style.top = `${Math.max(8, top)}px`;
    panel.style.left = `${Math.min(Math.max(8, r.right - panel.offsetWidth), window.innerWidth - panel.offsetWidth - 8)}px`;
    document.addEventListener('pointerdown', outside, true);
    document.addEventListener('keydown', onKey, true);
  }

  // ---------- the card ----------
  function render(card, body) {
    card.shape = { kind: 'rect', fill: 2, color: 'blue', stroke: 3, dir: 'e', ...(card.shape || {}) };
    const wrap = document.createElement('div');
    wrap.className = 'shp';
    wrap.innerHTML = `
      <svg class="shp-svg" preserveAspectRatio="none" aria-hidden="true"></svg>
      <button class="shp-style" aria-label="Shape style" aria-haspopup="dialog" data-tooltip="Shape, fill, colour, thickness">
        <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><rect x="2.5" y="2.5" width="5" height="5" rx="1"/><circle cx="11" cy="11" r="2.6"/><path d="M11 2.5l2.6 4.5H8.4z"/></svg>
      </button>`;
    const svg = wrap.querySelector('.shp-svg');
    const text = App.richText.create({
      className: 'shp-text',
      placeholder: '',
      html: card.html ?? App.richText.fromText(card.text),
      onChange: (html, t) => App.state.updateCard(card.id, { html, text: t }),
    });
    wrap.append(text);
    body.append(wrap);

    const redraw = () => {
      const w = wrap.clientWidth;
      const h = wrap.clientHeight;
      if (!w || !h) return;
      draw(svg, card.shape, w, h);
      wrap.dataset.kind = card.shape.kind;
      wrap.classList.toggle('is-filled', card.shape.fill === 1);
    };
    new ResizeObserver(redraw).observe(wrap);
    window.addEventListener('themechange', redraw);

    const apply = (patch) => {
      card.shape = { ...card.shape, ...patch };
      // lines and arrows are flat by default; switching to one makes a squat card less awkward
      App.state.updateCard(card.id, { shape: card.shape });
      redraw();
    };
    wrap.querySelector('.shp-style').addEventListener('click', (e) => openStyle(e.currentTarget, card, apply));
    // double-click the shape to type in it
    wrap.addEventListener('dblclick', (e) => {
      if (e.target.closest('.shp-text, .shp-style')) return;
      e.stopPropagation();
      text.focus();
    });
    requestAnimationFrame(redraw);
  }

  return {
    label: 'Shape',
    resizable: 'both',
    minWidth: 40,
    maxWidth: 1600,
    minHeight: 24,
    maxHeight: 1200,
    defaults: () => ({ width: 200, height: 130, shape: { kind: 'rect', fill: 2, color: 'blue', stroke: 3, dir: 'e' } }),
    render,
    focus(el) { el.querySelector('.shp-text')?.focus(); },
  };
})();
