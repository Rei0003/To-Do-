// chart.js — a chart (diagram) card: bar, line, pie and doughnut charts.
//  • data can be the chart's own (edit it in the "Data" panel) or come live from a Table card:
//    first column = labels, header row = series names, other columns = numbers
//  • click a series' colour dot to recolour it (presets, saved or custom colours)
//  • hover bars, points and slices to see their values
// Data: card.chart = { kind, title, source (table card id or null), labels: [], series: [{ name, color, values: [] }] }
window.App = window.App || {};

App.cardTypes.chart = (() => {
  const SVG_NS = 'http://www.w3.org/2000/svg';
  const KINDS = [
    { id: 'bar', label: 'Bar chart' },
    { id: 'line', label: 'Line chart' },
    { id: 'pie', label: 'Pie chart' },
    { id: 'doughnut', label: 'Doughnut chart' },
  ];
  // series colours, in the order new series get them
  const PALETTE = ['blue', 'green', 'orange', 'purple', 'pink', 'red', 'yellow'];
  const PALETTE_CSS = {
    blue: 'var(--c-blue)', green: 'var(--c-green)', orange: 'var(--tc-orange)', purple: 'var(--c-purple)',
    pink: 'var(--c-pink)', red: 'var(--tc-red)', yellow: 'var(--c-yellow)',
  };
  const colorCss = (c, i = 0) => (String(c || '').startsWith('#') ? c : PALETTE_CSS[c] || PALETTE_CSS[PALETTE[i % PALETTE.length]]);
  const colorName = (c) => (String(c).startsWith('#') ? `Custom ${c}` : c[0].toUpperCase() + c.slice(1));

  const I = (d) => `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
  const ICONS = {
    bar: I('<path d="M2.5 13.5h11"/><rect x="3.5" y="7" width="2.4" height="6.5" rx=".5"/><rect x="7.2" y="3.5" width="2.4" height="10" rx=".5"/><rect x="10.9" y="9" width="2.4" height="4.5" rx=".5"/>'),
    line: I('<path d="M2.5 13.5h11"/><path d="M3 10.5l3-3.5 3 2 4-5"/>'),
    pie: I('<circle cx="8" cy="8" r="5.5"/><path d="M8 2.5V8l4.5 3"/>'),
    doughnut: I('<circle cx="8" cy="8" r="5.5"/><circle cx="8" cy="8" r="2.4"/><path d="M8 2.5v3.1"/>'),
    data: I('<rect x="2" y="2.5" width="12" height="11" rx="1.5"/><path d="M2 6.5h12M6 2.5v11"/>'),
    link: I('<path d="M6.5 9.5l3-3M7 4.5l1-1a2.5 2.5 0 0 1 3.5 3.5l-1 1M9 11.5l-1 1A2.5 2.5 0 0 1 4.5 9l1-1"/>'),
    plus: I('<path d="M8 3.5v9M3.5 8h9" stroke-width="1.6"/>'),
    remove: I('<path d="M4.5 4.5l7 7M11.5 4.5l-7 7"/>'),
  };

  // "4 500", "4,500", "4.5", "4,5", "12%", "€30" -> numbers (null if it isn't one)
  function parseNumber(text) {
    let s = String(text ?? '').replace(/[\s\u00a0]/g, '').replace(/[^\d.,\-]/g, '');
    if (!s || s === '-') return null;
    if (s.includes('.') && s.includes(',')) s = s.replace(/,/g, '');
    else if (/^-?\d{1,3}(,\d{3})+$/.test(s)) s = s.replace(/,/g, '');
    else s = s.replace(',', '.');
    const n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  // the data to draw: { labels, series } — from the chart itself or from a table card
  function dataOf(chart) {
    if (!chart.source) return { labels: chart.labels, series: chart.series, from: null };
    const table = App.state.getCard(chart.source);
    if (!table?.table) return { labels: [], series: [], from: 'missing' };
    const t = table.table;
    const rows = t.cells.map((row) => row.map((c) => (c?.text || '').trim()));
    const header = t.header ? rows[0] : null;
    const body = (t.header ? rows.slice(1) : rows).filter((r) => r.some((v) => v)); // skip empty rows
    const labels = body.map((r, i) => r[0] || `${i + 1}`);
    const series = [];
    for (let c = 1; c < t.cols; c++) {
      const values = body.map((r) => parseNumber(r[c]));
      if (!values.some((v) => v !== null)) continue; // a column with no numbers
      const saved = chart.sourceColors?.[c];
      series.push({ name: header?.[c] || `Column ${c + 1}`, color: saved || PALETTE[(c - 1) % PALETTE.length], values, col: c });
    }
    return { labels, series, from: table };
  }

  // nice round axis numbers
  function niceTicks(min, max, count = 5) {
    if (min === max) { max = min + 1; min = Math.min(0, min); }
    const step0 = (max - min) / count;
    const mag = 10 ** Math.floor(Math.log10(step0));
    const step = [1, 2, 2.5, 5, 10].map((m) => m * mag).find((s) => s >= step0) || 10 * mag;
    const lo = Math.floor(min / step) * step;
    const hi = Math.ceil(max / step) * step;
    const ticks = [];
    for (let v = lo; v <= hi + step / 2; v += step) ticks.push(Math.round(v * 1e6) / 1e6);
    return ticks;
  }
  const fmt = (n) => (Math.abs(n) >= 1000 ? n.toLocaleString(undefined, { maximumFractionDigits: 1 }) : String(Math.round(n * 100) / 100));

  const el = (tag, attrs = {}, text) => {
    const e = document.createElementNS(SVG_NS, tag);
    Object.entries(attrs).forEach(([k, v]) => e.setAttribute(k, v));
    if (text !== undefined) e.textContent = text;
    return e;
  };

  // ---------- drawing ----------
  function drawAxes(svg, { labels, series }, w, h, kind) {
    const all = series.flatMap((s) => s.values).filter((v) => v !== null);
    const ticks = niceTicks(Math.min(0, ...all), Math.max(0, ...all));
    const lo = ticks[0];
    const hi = ticks[ticks.length - 1];
    const yLabelW = Math.max(...ticks.map((t) => fmt(t).length)) * 6.5 + 10;
    const pad = { l: yLabelW, r: 10, t: 10, b: 24 };
    const pw = Math.max(10, w - pad.l - pad.r);
    const ph = Math.max(10, h - pad.t - pad.b);
    const y = (v) => pad.t + ph - ((v - lo) / (hi - lo)) * ph;
    const band = pw / Math.max(1, labels.length);

    // grid + y numbers
    ticks.forEach((t) => {
      svg.append(el('line', { class: t === 0 ? 'ch-zero' : 'ch-grid', x1: pad.l, x2: pad.l + pw, y1: y(t), y2: y(t) }));
      svg.append(el('text', { class: 'ch-ytick', x: pad.l - 6, y: y(t) + 4, 'text-anchor': 'end' }, fmt(t)));
    });
    // x labels (skip some when crowded, shorten long ones)
    const every = Math.ceil(46 / band);
    const maxChars = Math.max(3, Math.floor((band * every) / 6.6));
    labels.forEach((label, i) => {
      if (i % every) return;
      const text = label.length > maxChars ? `${label.slice(0, maxChars - 1)}…` : label;
      const t = el('text', { class: 'ch-xtick', x: pad.l + band * (i + 0.5), y: pad.t + ph + 16, 'text-anchor': 'middle' }, text);
      t.dataset.tooltip = label;
      svg.append(t);
    });

    if (kind === 'bar') {
      const k = Math.max(1, series.length);
      const groupW = band * 0.72;
      const barW = groupW / k;
      series.forEach((s, si) => {
        s.values.forEach((v, i) => {
          if (v === null) return;
          const x = pad.l + band * i + (band - groupW) / 2 + barW * si;
          const top = Math.min(y(v), y(0));
          const r = el('rect', {
            class: 'ch-bar', x: x + 1, y: top, width: Math.max(1, barW - 2), height: Math.max(1, Math.abs(y(v) - y(0))), rx: 2,
          });
          r.style.fill = colorCss(s.color, si);
          r.dataset.tooltip = `${labels[i]}${series.length > 1 ? ` · ${s.name}` : ''}: ${fmt(v)}`;
          svg.append(r);
        });
      });
    } else { // line
      series.forEach((s, si) => {
        const pts = s.values.map((v, i) => (v === null ? null : [pad.l + band * (i + 0.5), y(v)]));
        let d = '';
        pts.forEach((p, i) => { if (p) d += `${d && pts[i - 1] ? 'L' : 'M'}${p[0]},${p[1]}`; });
        const path = el('path', { class: 'ch-line', d });
        path.style.stroke = colorCss(s.color, si);
        svg.append(path);
        pts.forEach((p, i) => {
          if (!p) return;
          const c = el('circle', { class: 'ch-point', cx: p[0], cy: p[1], r: 3.5 });
          c.style.fill = colorCss(s.color, si);
          c.dataset.tooltip = `${labels[i]}${series.length > 1 ? ` · ${s.name}` : ''}: ${fmt(s.values[i])}`;
          svg.append(c);
        });
      });
    }
  }

  function drawPie(svg, { labels, series }, w, h, hole) {
    const s = series[0];
    const items = labels.map((label, i) => ({ label, v: s.values[i] })).filter((x) => x.v > 0);
    const total = items.reduce((a, x) => a + x.v, 0);
    const cx = w / 2;
    const cy = h / 2;
    const r = Math.max(10, Math.min(w, h) / 2 - 8);
    let a0 = -Math.PI / 2;
    items.forEach((it, i) => {
      const a1 = a0 + (it.v / total) * Math.PI * 2;
      const large = a1 - a0 > Math.PI ? 1 : 0;
      const p = (a, rr) => `${cx + rr * Math.cos(a)},${cy + rr * Math.sin(a)}`;
      const ri = hole ? r * 0.58 : 0;
      const d = items.length === 1
        ? (hole ? `M${cx - r},${cy}a${r},${r} 0 1,0 ${r * 2},0a${r},${r} 0 1,0 ${-r * 2},0M${cx - ri},${cy}a${ri},${ri} 0 1,1 ${ri * 2},0a${ri},${ri} 0 1,1 ${-ri * 2},0`
          : `M${cx - r},${cy}a${r},${r} 0 1,0 ${r * 2},0a${r},${r} 0 1,0 ${-r * 2},0`)
        : hole
          ? `M${p(a0, r)}A${r},${r} 0 ${large} 1 ${p(a1, r)}L${p(a1, ri)}A${ri},${ri} 0 ${large} 0 ${p(a0, ri)}Z`
          : `M${cx},${cy}L${p(a0, r)}A${r},${r} 0 ${large} 1 ${p(a1, r)}Z`;
      const slice = el('path', { class: 'ch-slice', d, 'fill-rule': 'evenodd' });
      slice.style.fill = colorCss(PALETTE[i % PALETTE.length], i);
      slice.dataset.tooltip = `${it.label}: ${fmt(it.v)} (${Math.round((it.v / total) * 100)}%)`;
      svg.append(slice);
      a0 = a1;
    });
    if (hole) {
      svg.append(el('text', { class: 'ch-total', x: cx, y: cy + 2, 'text-anchor': 'middle' }, fmt(total)));
      svg.append(el('text', { class: 'ch-total-label', x: cx, y: cy + 18, 'text-anchor': 'middle' }, s.name || 'Total'));
    }
    return items;
  }

  // ---------- small popovers ----------
  let pop = null;
  let popAnchor = null;
  function closePop() {
    pop?.remove();
    pop = null;
    popAnchor = null;
    document.removeEventListener('pointerdown', onOutside, true);
    document.removeEventListener('keydown', onPopKey, true);
  }
  function onOutside(e) { if (pop && !pop.contains(e.target) && !popAnchor?.contains(e.target) && !e.target.closest('.color-pop')) closePop(); }
  function onPopKey(e) { if (e.key === 'Escape') { e.stopPropagation(); closePop(); } }
  function openPop(anchor, content) {
    if (popAnchor === anchor) return closePop();
    closePop();
    App.tooltip?.hide();
    pop = content;
    popAnchor = anchor;
    document.body.append(pop);
    const r = anchor.getBoundingClientRect();
    const w = pop.offsetWidth;
    const h = pop.offsetHeight;
    let top = r.bottom + 6;
    if (top + h > window.innerHeight - 8) top = r.top - h - 6;
    pop.style.top = `${Math.min(Math.max(8, top), window.innerHeight - h - 8)}px`;
    pop.style.left = `${Math.min(Math.max(8, r.left), window.innerWidth - w - 8)}px`;
    document.addEventListener('pointerdown', onOutside, true);
    document.addEventListener('keydown', onPopKey, true);
  }

  function colorMenu(anchor, value, onPick) {
    const box = document.createElement('div');
    box.className = 'ch-pop';
    const row = App.palette.create({
      presets: PALETTE.map((c) => ({ value: c, label: colorName(c), css: PALETTE_CSS[c] })),
      value,
      visible: 7,
      size: 18,
      onPick: (c) => { onPick(c); closePop(); },
    });
    box.append(row.el);
    openPop(anchor, box);
  }

  // "Table 2" etc., by order on the board
  const tableName = (id) => {
    const tables = App.state.get().cards.filter((c) => c.type === 'table');
    return `Table ${tables.findIndex((c) => c.id === id) + 1}`;
  };

  // ---------- card ----------
  function render(card, body) {
    const ch = card.chart || (card.chart = defaultsChart());
    let showData = false;

    const root = document.createElement('div');
    root.className = 'ch';
    root.innerHTML = `
      <div class="ch-tools">
        <div class="ch-kinds" role="radiogroup" aria-label="Chart type">
          ${KINDS.map((k) => `<button class="draw-btn" data-kind="${k.id}" role="radio" aria-label="${k.label}" data-tooltip="${k.label}">${ICONS[k.id]}</button>`).join('')}
        </div>
        <span class="tbl-sep"></span>
        <button class="ch-btn" data-ch="data" aria-expanded="false">${ICONS.data}<span>Data</span></button>
        <button class="ch-btn" data-ch="source" aria-haspopup="dialog">${ICONS.link}<span class="ch-source-label"></span></button>
      </div>
      <input class="ch-title" type="text" placeholder="Chart title" aria-label="Chart title">
      <div class="ch-legend"></div>
      <div class="ch-area"><svg class="ch-svg" role="img"></svg><p class="ch-empty" hidden></p></div>
      <div class="ch-data" hidden></div>`;
    body.append(root);

    const svg = root.querySelector('.ch-svg');
    const area = root.querySelector('.ch-area');
    const legend = root.querySelector('.ch-legend');
    const empty = root.querySelector('.ch-empty');
    const dataPanel = root.querySelector('.ch-data');
    const title = root.querySelector('.ch-title');
    title.value = ch.title || '';

    const save = () => App.state.updateCard(card.id, { chart: ch });

    // ----- draw the chart -----
    function draw() {
      const data = dataOf(ch);
      root.querySelectorAll('[data-kind]').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.kind === ch.kind)));
      root.querySelector('.ch-source-label').textContent = ch.source ? `From ${tableName(ch.source)}` : 'Own data';
      root.querySelector('[data-ch="source"]').dataset.tooltip = ch.source ? 'Data comes from a table on the board\n(click to change)' : 'Use data from a table on the board';
      const dataBtn = root.querySelector('[data-ch="data"]');
      dataBtn.hidden = !!ch.source;
      dataBtn.setAttribute('aria-pressed', String(showData && !ch.source));
      dataPanel.hidden = !showData || !!ch.source;

      const w = Math.max(60, area.clientWidth);
      const h = Math.max(60, area.clientHeight);
      svg.setAttribute('viewBox', `0 0 ${w} ${h}`);
      svg.setAttribute('width', w);
      svg.setAttribute('height', h);
      svg.replaceChildren();
      svg.setAttribute('aria-label', `${KINDS.find((k) => k.id === ch.kind)?.label}${ch.title ? `: ${ch.title}` : ''}`);

      const hasNumbers = data.series.some((s) => s.values.some((v) => v !== null && (ch.kind === 'bar' || ch.kind === 'line' || v > 0)));
      empty.hidden = hasNumbers;
      if (!hasNumbers) {
        empty.textContent = data.from === 'missing' ? 'The table this chart used was deleted. Pick another source.'
          : ch.source ? 'Add numbers to the table (labels in the first column) to see the chart.'
            : 'No numbers yet. Click “Data” to add some.';
        legend.replaceChildren();
        return;
      }

      let legendItems;
      if (ch.kind === 'pie' || ch.kind === 'doughnut') {
        const slices = drawPie(svg, data, w, h, ch.kind === 'doughnut');
        const total = slices.reduce((a, x) => a + x.v, 0);
        legendItems = slices.map((it, i) => ({ name: `${it.label} · ${Math.round((it.v / total) * 100)}%`, css: colorCss(PALETTE[i % PALETTE.length], i) }));
      } else {
        drawAxes(svg, data, w, h, ch.kind);
        legendItems = data.series.length > 1 || ch.source
          ? data.series.map((s, i) => ({ name: s.name, css: colorCss(s.color, i), series: s, index: i }))
          : [];
      }
      legend.replaceChildren(...legendItems.map((it) => {
        const item = document.createElement(it.series ? 'button' : 'span');
        item.className = 'ch-legend-item';
        item.innerHTML = '<span class="ch-swatch"></span><span></span>';
        item.firstChild.style.background = it.css;
        item.lastChild.textContent = it.name;
        if (it.series) {
          item.dataset.tooltip = 'Change colour';
          item.addEventListener('click', () => colorMenu(item, it.series.color, (c) => {
            if (ch.source) ch.sourceColors = { ...(ch.sourceColors || {}), [it.series.col]: c };
            else ch.series[it.index].color = c;
            save();
            draw();
            if (showData) drawData();
          }));
        }
        return item;
      }));
    }

    // ----- own data editor -----
    function drawData() {
      const s = ch.series;
      const rows = ch.labels.map((label, r) => `
        <tr>
          <td><input data-label="${r}" aria-label="Label"></td>
          ${s.map((_, c) => `<td><input data-cell="${r}:${c}" inputmode="decimal" aria-label="Value"></td>`).join('')}
          <td><button class="card-btn" data-del-row="${r}" aria-label="Remove row" data-tooltip="Remove row" ${ch.labels.length <= 1 ? 'disabled' : ''}>${ICONS.remove}</button></td>
        </tr>`).join('');
      dataPanel.innerHTML = `
        <div class="ch-data-scroll">
          <table class="ch-data-table">
            <thead><tr>
              <th>Label</th>
              ${s.map((ser, c) => `<th><div class="ch-series-head">
                <button class="ch-swatch-btn" data-color="${c}" aria-label="Series colour" data-tooltip="Colour"></button>
                <input data-series="${c}" aria-label="Series name">
                <button class="card-btn" data-del-series="${c}" aria-label="Remove series" data-tooltip="Remove series" ${s.length <= 1 ? 'disabled' : ''}>${ICONS.remove}</button>
              </div></th>`).join('')}
              <th><button class="ch-add" data-add="series" data-tooltip="Add a series (column)">${ICONS.plus}</button></th>
            </tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>
        <button class="ch-add ch-add-row" data-add="row">${ICONS.plus}<span>Add row</span></button>`;
      // values set as properties (safe for any text)
      ch.labels.forEach((label, r) => {
        dataPanel.querySelector(`[data-label="${r}"]`).value = label;
        s.forEach((ser, c) => {
          const v = ser.values[r];
          dataPanel.querySelector(`[data-cell="${r}:${c}"]`).value = v === null || v === undefined ? '' : v;
        });
      });
      s.forEach((ser, c) => {
        dataPanel.querySelector(`[data-series="${c}"]`).value = ser.name;
        dataPanel.querySelector(`[data-color="${c}"]`).style.background = colorCss(ser.color, c);
      });
    }

    dataPanel.addEventListener('input', (e) => {
      const t = e.target;
      if (t.dataset.label !== undefined) ch.labels[+t.dataset.label] = t.value;
      if (t.dataset.series !== undefined) ch.series[+t.dataset.series].name = t.value;
      if (t.dataset.cell) {
        const [r, c] = t.dataset.cell.split(':').map(Number);
        ch.series[c].values[r] = parseNumber(t.value);
      }
      save();
      draw();
    });
    dataPanel.addEventListener('click', (e) => {
      const b = e.target.closest('button');
      if (!b) return;
      if (b.dataset.add === 'row') {
        ch.labels.push(`Item ${ch.labels.length + 1}`);
        ch.series.forEach((s) => s.values.push(null));
      }
      if (b.dataset.add === 'series') {
        ch.series.push({ name: `Series ${ch.series.length + 1}`, color: PALETTE[ch.series.length % PALETTE.length], values: ch.labels.map(() => null) });
      }
      if (b.dataset.delRow !== undefined && ch.labels.length > 1) {
        const r = +b.dataset.delRow;
        ch.labels.splice(r, 1);
        ch.series.forEach((s) => s.values.splice(r, 1));
      }
      if (b.dataset.delSeries !== undefined && ch.series.length > 1) ch.series.splice(+b.dataset.delSeries, 1);
      if (b.dataset.color !== undefined) {
        const c = +b.dataset.color;
        colorMenu(b, ch.series[c].color, (col) => { ch.series[c].color = col; save(); draw(); drawData(); });
        return;
      }
      App.tooltip?.hide();
      save();
      drawData();
      draw();
      if (b.dataset.add === 'row') dataPanel.querySelector(`[data-label="${ch.labels.length - 1}"]`)?.select();
    });
    // Enter in a value moves to the same column on the next row
    dataPanel.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter' || !e.target.dataset.cell) return;
      const [r, c] = e.target.dataset.cell.split(':').map(Number);
      dataPanel.querySelector(`[data-cell="${r + 1}:${c}"]`)?.focus();
    });

    // ----- choosing where the data comes from -----
    function openSource(anchor) {
      const tables = App.state.get().cards.filter((c) => c.type === 'table');
      const box = document.createElement('div');
      box.className = 'ch-pop ch-source';
      box.innerHTML = `
        <p class="ch-pop-title">Chart data</p>
        <button class="ch-src-option" data-src="" aria-pressed="${!ch.source}"><strong>Own data</strong><span>Type the numbers into this chart</span></button>
        ${tables.length ? '' : '<p class="ch-pop-hint">Add a Table card to the board to chart its numbers.</p>'}`;
      tables.forEach((t) => {
        const b = document.createElement('button');
        b.className = 'ch-src-option';
        b.dataset.src = t.id;
        b.setAttribute('aria-pressed', String(ch.source === t.id));
        const head = (t.table?.cells?.[0] || []).map((c) => c?.text).filter(Boolean).slice(0, 3).join(', ');
        b.innerHTML = '<strong></strong><span></span>';
        b.firstChild.textContent = tableName(t.id);
        b.lastChild.textContent = head ? `${t.table.rows} × ${t.table.cols} · ${head}` : `${t.table?.rows || 0} × ${t.table?.cols || 0}`;
        b.addEventListener('mouseenter', () => document.querySelector(`.card[data-id="${t.id}"], .attachment[data-id="${t.id}"]`)?.classList.add('is-mirror-candidate'));
        b.addEventListener('mouseleave', () => document.querySelectorAll('.is-mirror-candidate').forEach((x) => x.classList.remove('is-mirror-candidate')));
        box.append(b);
      });
      box.addEventListener('click', (e) => {
        const opt = e.target.closest('[data-src]');
        if (!opt) return;
        document.querySelectorAll('.is-mirror-candidate').forEach((x) => x.classList.remove('is-mirror-candidate'));
        ch.source = opt.dataset.src || null;
        if (!ch.source) showData = true;
        closePop();
        save();
        if (showData) drawData();
        draw();
      });
      openPop(anchor, box);
    }

    // ----- toolbar -----
    root.querySelector('.ch-tools').addEventListener('click', (e) => {
      const kind = e.target.closest('[data-kind]')?.dataset.kind;
      if (kind) { ch.kind = kind; save(); draw(); return; }
      const a = e.target.closest('[data-ch]');
      if (a?.dataset.ch === 'data') {
        showData = !showData;
        if (showData) drawData();
        draw();
      }
      if (a?.dataset.ch === 'source') openSource(a);
    });
    title.addEventListener('input', () => { ch.title = title.value; save(); });

    // redraw when the card is resized, and follow the source table as it's edited
    let frame = 0;
    const drawSoon = () => { if (!frame) frame = requestAnimationFrame(() => { frame = 0; draw(); }); };
    new ResizeObserver(drawSoon).observe(area);
    const stop = App.state.onCardChange((id) => {
      if (!root.isConnected) { stop(); return; }
      if (ch.source && id === ch.source) drawSoon();
    });
    const stopBoard = App.state.subscribe(() => {
      if (!root.isConnected) { stopBoard(); return; }
      if (ch.source) drawSoon(); // source deleted, renamed order, etc.
    });

    draw();
  }

  function defaultsChart() {
    return {
      kind: 'bar',
      title: '',
      source: null,
      labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
      series: [{ name: 'Series 1', color: 'blue', values: [4, 7, 5, 9, 6] }],
    };
  }

  return {
    label: 'Chart',
    resizable: 'both',
    minWidth: 240,
    maxWidth: 1600,
    minHeight: 220,
    maxHeight: 1200,
    defaults: () => ({ width: 460, height: 420, chart: defaultsChart() }),
    render,
    focus(el) { el.querySelector('.ch-title')?.focus(); },
  };
})();
