// priority.js — priority levels for to-do tasks: the flag button and its picker menu
window.App = window.App || {};

App.priority = (() => {
  const LEVELS = [
    { id: 'none', label: 'No priority' },
    { id: 'low', label: 'Low' },
    { id: 'medium', label: 'Medium' },
    { id: 'high', label: 'High' },
    { id: 'urgent', label: 'Urgent' },
  ];

  const FLAG = `
    <svg viewBox="0 0 16 16" aria-hidden="true">
      <path d="M4 14V2.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
      <path class="flag-fill" d="M4 3h7.5L9.8 6l1.7 3H4z" fill="currentColor" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/>
    </svg>`;

  const labelOf = (id) => LEVELS.find((l) => l.id === id)?.label || 'No priority';

  let menu = null;
  let menuAnchor = null;

  function close() {
    menu?.remove();
    menu = null;
    menuAnchor = null;
    document.removeEventListener('pointerdown', onOutside, true);
    document.removeEventListener('keydown', onKey);
  }
  function onOutside(e) {
    if (menu && !menu.contains(e.target) && e.target.closest('.priority-btn') !== menuAnchor) close();
  }
  function onKey(e) {
    if (e.key !== 'Escape') return;
    const anchor = menuAnchor;
    close();
    anchor?.focus();
  }

  function open(anchor, current, onPick) {
    close();
    menu = document.createElement('div');
    menu.className = 'priority-menu';
    menu.setAttribute('role', 'menu');
    menuAnchor = anchor;

    LEVELS.forEach((level) => {
      const option = document.createElement('button');
      option.className = 'priority-option';
      option.dataset.level = level.id;
      option.setAttribute('role', 'menuitemradio');
      option.setAttribute('aria-checked', String(level.id === current));
      option.innerHTML = `${FLAG}<span>${level.label}</span>`;
      if (level.id !== 'none') option.dataset.tooltip = `${level.label} priority`;
      option.addEventListener('click', () => {
        onPick(level.id);
        close();
        anchor.focus();
      });
      menu.append(option);
    });

    document.body.append(menu);

    // place under the flag, or above it if there's no room below
    const r = anchor.getBoundingClientRect();
    const below = r.bottom + 4 + menu.offsetHeight < window.innerHeight;
    menu.style.top = `${below ? r.bottom + 4 : r.top - menu.offsetHeight - 4}px`;
    menu.style.left = `${Math.min(r.left, window.innerWidth - menu.offsetWidth - 8)}px`;
    menu.querySelector('[aria-checked="true"]')?.focus();

    document.addEventListener('pointerdown', onOutside, true);
    document.addEventListener('keydown', onKey);
    document.getElementById('viewport').addEventListener('scroll', close, { once: true });
  }

  // A flag button for one task. Calls onChange after the priority changes.
  function createButton(item, onChange) {
    const btn = document.createElement('button');
    btn.className = 'card-btn priority-btn';
    btn.innerHTML = FLAG;

    const sync = () => {
      const level = item.priority || 'none';
      btn.dataset.level = level;
      btn.dataset.tooltip = level === 'none' ? 'Set priority' : `${labelOf(level)} priority`;
      btn.setAttribute('aria-label', `Priority: ${labelOf(level)}`);
    };
    sync();

    btn.addEventListener('click', () => {
      if (menuAnchor === btn) return close();
      open(btn, item.priority || 'none', (level) => {
        item.priority = level;
        sync();
        onChange();
      });
    });

    return btn;
  }

  return { LEVELS, createButton, close };
})();
