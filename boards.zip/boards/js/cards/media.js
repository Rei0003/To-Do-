// media.js — an image or video card with an optional caption
window.App = window.App || {};

App.cardTypes.media = (() => {
  const UPLOAD_ICON = `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
      <rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="1.8"/><path d="M21 16l-5-5-8 9"/>
    </svg>`;

  function kindOf(file) {
    if (file.type.startsWith('image/')) return 'image';
    if (file.type.startsWith('video/')) return 'video';
    return null;
  }

  function renderPicker(card, body) {
    const zone = document.createElement('div');
    zone.className = 'media-drop';
    zone.innerHTML = `
      ${UPLOAD_ICON}
      <button class="media-pick" type="button">Choose image or video</button>
      <p class="media-hint">or drop a file here</p>
      <p class="media-error" hidden></p>
      <input type="file" accept="image/*,video/*" hidden>`;

    const input = zone.querySelector('input');
    const error = zone.querySelector('.media-error');
    const showError = (msg) => { error.textContent = msg; error.hidden = false; };

    async function attach(file) {
      if (!file) return;
      const kind = kindOf(file);
      if (!kind) return showError('Only images and videos can be added here.');
      zone.classList.add('is-loading');
      try {
        const mediaId = await App.mediaStore.put(file);
        App.state.updateCard(card.id, { mediaId, kind, name: file.name });
        render(card, body);
      } catch {
        zone.classList.remove('is-loading');
        showError('This file couldn’t be saved. It may be too large for browser storage.');
      }
    }

    zone.querySelector('.media-pick').addEventListener('click', () => input.click());
    input.addEventListener('change', () => attach(input.files[0]));

    // dropping a file straight onto this card fills it (instead of making a new card)
    zone.addEventListener('dragover', (e) => {
      if (!e.dataTransfer.types.includes('Files')) return;
      e.preventDefault();
      e.stopPropagation();
      zone.classList.add('is-over');
    });
    zone.addEventListener('dragleave', () => zone.classList.remove('is-over'));
    zone.addEventListener('drop', (e) => {
      if (!e.dataTransfer.files.length) return;
      e.preventDefault();
      e.stopPropagation();
      zone.classList.remove('is-over');
      attach(e.dataTransfer.files[0]);
    });

    body.append(zone);
  }

  function renderMedia(card, body) {
    const frame = document.createElement('div');
    frame.className = 'media-frame';

    let media;
    if (card.kind === 'video') {
      media = document.createElement('video');
      media.controls = true;
      media.preload = 'metadata';
      media.playsInline = true;
    } else {
      media = document.createElement('img');
      media.alt = card.caption || card.name || '';
      media.draggable = false;
    }
    frame.append(media);

    App.mediaStore.getUrl(card.mediaId)
      .then((url) => {
        if (url) media.src = url;
        else frame.innerHTML = '<p class="media-missing">This file is no longer available.</p>';
      })
      .catch(() => {
        frame.innerHTML = '<p class="media-missing">This file couldn’t be loaded.</p>';
      });

    const caption = document.createElement('input');
    caption.className = 'media-caption';
    caption.placeholder = 'Add a caption';
    caption.value = card.caption || '';
    caption.addEventListener('input', () => {
      App.state.updateCard(card.id, { caption: caption.value });
      if (card.kind === 'image') media.alt = caption.value || card.name;
    });

    body.append(frame, caption);
  }

  function render(card, body) {
    body.replaceChildren();
    if (card.mediaId) renderMedia(card, body);
    else renderPicker(card, body);
  }

  return {
    label: 'Media',
    defaults: () => ({ mediaId: null, kind: null, name: '', caption: '' }),
    kindOf,
    render,
    focus(el) { el.querySelector('.media-pick')?.focus(); },
    onRemove(card) { if (card.mediaId) App.mediaStore.remove(card.mediaId); },
  };
})();
