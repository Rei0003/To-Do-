// media.js — an image or video card with an optional caption.
// The media can be a file from your computer (kept in IndexedDB) or a link
// (image/video URL, YouTube or Vimeo).
window.App = window.App || {};

App.cardTypes.media = (() => {
  const UPLOAD_ICON = `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
      <rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="1.8"/><path d="M21 16l-5-5-8 9"/>
    </svg>`;
  const LINK_ICON = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 3h4v4M13 3L7.5 8.5M11 9.5V13H3V5h3.5"/></svg>';

  function kindOf(file) {
    if (file.type.startsWith('image/')) return 'image';
    if (file.type.startsWith('video/')) return 'video';
    if (file.type.startsWith('audio/')) return 'audio';
    // some systems don't say what a file is: go by its name
    if (/\.(mp3|wav|m4a|aac|flac|opus|oga|ogg|weba)$/i.test(file.name)) return 'audio';
    return null;
  }

  const hasMedia = (card) => !!(card.mediaId || card.url);

  // ---------- empty card: choose a file or paste a link ----------
  function renderPicker(card, body) {
    const zone = document.createElement('div');
    zone.className = 'media-drop';
    zone.innerHTML = `
      ${UPLOAD_ICON}
      <button class="media-pick" type="button">Choose image, video or audio</button>
      <p class="media-hint">or drop a file here</p>
      <div class="media-or"><span>or use a link</span></div>
      <div class="media-link-row">
        <input class="media-link-input" type="url" inputmode="url" spellcheck="false"
               placeholder="Paste an image, video or YouTube link" aria-label="Media link">
        <button class="media-link-add" type="button">Add</button>
      </div>
      <p class="media-error" hidden></p>
      <input class="media-file-input" type="file" accept="image/*,video/*,audio/*,.mp3,.wav,.m4a,.aac,.flac,.ogg,.opus" hidden>`;

    const fileInput = zone.querySelector('.media-file-input');
    const linkInput = zone.querySelector('.media-link-input');
    const error = zone.querySelector('.media-error');
    const showError = (msg) => { error.textContent = msg; error.hidden = false; };

    async function attachFile(file) {
      if (!file) return;
      const kind = kindOf(file);
      if (!kind) return showError('Only images, videos and audio can be added here.');
      zone.classList.add('is-loading');
      try {
        const mediaId = await App.mediaStore.put(file);
        App.state.updateCard(card.id, { mediaId, kind, name: file.name });
        render(card, body);
      } catch {
        zone.classList.remove('is-loading');
        showError('This file couldn’t be saved. It may be too large for browser storage.');
      }
    }

    function attachLink(text) {
      const link = App.mediaLinks.parse(text);
      if (!link) return showError('That isn’t a web link. Links start with https://');
      App.state.updateCard(card.id, { ...link, name: App.mediaLinks.domainOf(link.url) });
      render(card, body);
    }

    zone.querySelector('.media-pick').addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', () => attachFile(fileInput.files[0]));
    zone.querySelector('.media-link-add').addEventListener('click', () => attachLink(linkInput.value));
    linkInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); attachLink(linkInput.value); }
    });
    linkInput.addEventListener('input', () => { error.hidden = true; });

    // dropping a file or a link straight onto this card fills it (instead of making a new card)
    const usable = (e) => e.dataTransfer.types.includes('Files') || e.dataTransfer.types.includes('text/uri-list');
    zone.addEventListener('dragover', (e) => {
      if (!usable(e) || e.target === linkInput) return;
      e.preventDefault();
      e.stopPropagation();
      zone.classList.add('is-over');
    });
    zone.addEventListener('dragleave', () => zone.classList.remove('is-over'));
    zone.addEventListener('drop', (e) => {
      if (!usable(e) || e.target === linkInput) return;
      e.preventDefault();
      e.stopPropagation();
      zone.classList.remove('is-over');
      if (e.dataTransfer.files.length) attachFile(e.dataTransfer.files[0]);
      else attachLink(e.dataTransfer.getData('text/uri-list').split('\n')[0]);
    });

    body.append(zone);
  }

  // ---------- filled card ----------
  function linkFailed(frame, card) {
    frame.innerHTML = `
      <p class="media-missing">This link couldn’t be shown as an image, video or audio.
        <a href="" target="_blank" rel="noopener noreferrer" draggable="false">Open it</a></p>`;
    frame.querySelector('a').href = card.url;
  }

  function buildPlayer(card, frame) {
    // audio: our own player with a waveform (see audio-player.js)
    if (card.kind === 'audio') {
      frame.classList.add('media-frame--audio');
      const player = App.audioPlayer.create({
        name: card.name,
        key: card.mediaId || card.url,
        src: card.url ? card.url : App.mediaStore.getUrl(card.mediaId),
        getBuffer: card.url
          ? () => fetch(card.url).then((r) => (r.ok ? r.arrayBuffer() : null)) // works only if the site allows it
          : () => App.mediaStore.getBlob(card.mediaId).then((b) => b?.arrayBuffer()),
        onError: () => {
          if (card.url) linkFailed(frame, card);
          else frame.innerHTML = '<p class="media-missing">This audio file couldn’t be played.</p>';
        },
      });
      frame.append(player);
      return player;
    }
    // Spotify / SoundCloud: their own players
    if (card.kind === 'spotify' || card.kind === 'soundcloud') {
      frame.classList.add('media-frame--audio');
      const iframe = document.createElement('iframe');
      iframe.className = `media-embed media-embed--audio${card.tall ? ' is-tall' : ''}`;
      iframe.src = card.embed;
      iframe.title = card.caption || (card.kind === 'spotify' ? 'Spotify player' : 'SoundCloud player');
      iframe.loading = 'lazy';
      iframe.allow = 'autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture';
      frame.append(iframe);
      return iframe;
    }
    // YouTube / Vimeo
    if (card.kind === 'youtube' || card.kind === 'vimeo') {
      const iframe = document.createElement('iframe');
      iframe.className = 'media-embed';
      iframe.src = card.embed;
      iframe.title = card.caption || `${card.kind === 'youtube' ? 'YouTube' : 'Vimeo'} video`;
      iframe.loading = 'lazy';
      iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen';
      iframe.referrerPolicy = 'strict-origin-when-cross-origin';
      iframe.allowFullscreen = true;
      frame.append(iframe);
      return iframe;
    }

    let media;
    if (card.kind === 'video') {
      media = document.createElement('video');
      media.controls = true;
      media.preload = 'metadata';
      media.playsInline = true;
    } else {
      media = document.createElement('img');
      media.alt = card.caption || card.name || '';
      media.draggable = false;
    }
    frame.append(media);

    if (card.url) {
      // linked image/video
      media.addEventListener('error', () => linkFailed(frame, card), { once: true });
      media.src = card.url;
    } else {
      // file stored in the browser
      App.mediaStore.getUrl(card.mediaId)
        .then((url) => {
          if (url) media.src = url;
          else frame.innerHTML = '<p class="media-missing">This file is no longer available.</p>';
        })
        .catch(() => { frame.innerHTML = '<p class="media-missing">This file couldn’t be loaded.</p>'; });
    }
    return media;
  }

  function renderMedia(card, body) {
    const frame = document.createElement('div');
    frame.className = 'media-frame';
    const media = buildPlayer(card, frame);

    const caption = App.richText.create({
      className: 'media-caption',
      placeholder: 'Add a caption',
      multiline: false,
      html: card.captionHtml ?? App.richText.fromText(card.caption),
      onChange: (captionHtml, text) => {
        App.state.updateCard(card.id, { captionHtml, caption: text });
        if (media.tagName === 'IMG') media.alt = text || card.name;
      },
    });

    body.append(frame, caption);

    // where a linked item came from, e.g. "youtube.com ↗"
    if (card.url) {
      const source = document.createElement('a');
      source.className = 'media-source';
      source.href = card.url;
      source.target = '_blank';
      source.rel = 'noopener noreferrer';
      source.draggable = false;
      source.innerHTML = `<span></span>${LINK_ICON}`;
      source.firstChild.textContent = App.mediaLinks.domainOf(card.url);
      source.dataset.tooltip = 'Open the original link';
      body.append(source);
    }
  }

  function render(card, body) {
    body.replaceChildren();
    if (hasMedia(card)) renderMedia(card, body);
    else renderPicker(card, body);
    // attached notes show underneath
    const attachments = document.createElement('div');
    attachments.className = 'attachments';
    App.nesting.renderAttachments(card, attachments);
    body.append(attachments);
  }

  return {
    label: 'Media',
    accepts: ['note'], // a note under a picture or video, e.g. a description
    resizable: true,
    minWidth: 160,
    maxWidth: 1400,
    defaults: () => ({ mediaId: null, url: null, kind: null, name: '', caption: '' }),
    kindOf,
    render,
    focus(el) { el.querySelector('.media-pick')?.focus(); },
    onRemove(card) { if (card.mediaId) App.mediaStore.remove(card.mediaId); },
  };
})();
