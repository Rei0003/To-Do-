// due-date.js — "complete by" dates (and optional times) for to-do tasks.
// A clock button on each task opens a small picker; once set, the task shows a chip:
//   grey = later, orange = due today, red = overdue (finished tasks go quiet).
// Stored on the task as item.due: 'YYYY-MM-DD' or 'YYYY-MM-DDTHH:MM'.
window.App = window.App || {};

App.dueDate = (() => {
  // the browser's language for dates — falls back safely if it reports an unusual code
  const locale = (() => {
    const wanted = String(navigator.language || '').split('@')[0];
    try { new Intl.DateTimeFormat(wanted); return wanted || undefined; } catch { return undefined; }
  })();
  const fmtWeekday = new Intl.DateTimeFormat(locale, { weekday: 'short' });
  const fmtDay = new Intl.DateTimeFormat(locale, { day: 'numeric', month: 'short' });
  const fmtDayYear = new Intl.DateTimeFormat(locale, { day: 'numeric', month: 'short', year: 'numeric' });
  const fmtFull = new Intl.DateTimeFormat(locale, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const fmtTime = new Intl.DateTimeFormat(locale, { hour: '2-digit', minute: '2-digit' });

  const CLOCK = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8.5" r="5.5"/><path d="M8 5.5v3l2 1.5"/></svg>';

  // ---------- dates ----------
  const pad = (n) => String(n).padStart(2, '0');
  const dayKey = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parse = (due) => {
    if (!due) return null;
    const [date, time] = due.split('T');
    const [y, m, d] = date.split('-').map(Number);
    const [hh, mm] = (time || '23:59').split(':').map(Number);
    return { at: new Date(y, m - 1, d, hh, mm), day: new Date(y, m - 1, d), hasTime: !!time };
  };
  const daysBetween = (a, b) => Math.round((b - a) / 86400000);

  // "Today 14:00", "Tomorrow", "Fri", "3 Oct", "3 Oct 2027"
  function label(due) {
    const p = parse(due);
    if (!p) return '';
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const diff = daysBetween(today, p.day);
    let text;
    if (diff === 0) text = 'Today';
    else if (diff === 1) text = 'Tomorrow';
    else if (diff === -1) text = 'Yesterday';
    else if (diff > 1 && diff < 7) text = fmtWeekday.format(p.day);
    else text = (p.day.getFullYear() === today.getFullYear() ? fmtDay : fmtDayYear).format(p.day);
    return p.hasTime ? `${text} ${fmtTime.format(p.at)}` : text;
  }

  // 'overdue' | 'today' | 'later'
  function status(due) {
    const p = parse(due);
    if (!p) return null;
    const now = new Date();
    if (p.at < now) return 'overdue';
    return dayKey(p.day) === dayKey(now) ? 'today' : 'later';
  }

  function describe(due) {
    const p = parse(due);
    if (!p) return '';
    const when = `${fmtFull.format(p.day)}${p.hasTime ? ` at ${fmtTime.format(p.at)}` : ''}`;
    const s = status(due);
    if (s === 'overdue') {
      const mins = Math.round((Date.now() - p.at) / 60000);
      const late = mins < 60 ? `${mins} min` : mins < 1440 ? `${Math.round(mins / 60)} h` : `${Math.round(mins / 1440)} days`;
      return `Due ${when}\nOverdue by ${late}`;
    }
    return `Due ${when}${s === 'today' ? '\nDue today' : ''}`;
  }

  // ---------- picker ----------
  let pop = null;
  let anchor = null;

  function close() {
    if (!pop) return;
    pop.remove();
    pop = null;
    anchor = null;
    document.removeEventListener('pointerdown', onOutside, true);
    document.removeEventListener('keydown', onKey, true);
  }
  function onOutside(e) { if (!pop.contains(e.target) && !anchor?.contains(e.target)) close(); }
  function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } }

  function open(button, item, onChange) {
    if (pop && anchor === button) return close();
    close();
    App.tooltip?.hide();
    anchor = button;

    const current = parse(item.due);
    pop = document.createElement('div');
    pop.className = 'due-pop';
    pop.setAttribute('role', 'dialog');
    pop.setAttribute('aria-label', 'Due date');
    pop.innerHTML = `
      <p class="due-pop-title">Complete by</p>
      <div class="due-quick">
        <button data-quick="0">Today</button>
        <button data-quick="1">Tomorrow</button>
        <button data-quick="7">Next week</button>
      </div>
      <label class="due-field"><span>Date</span><input type="date" class="due-date"></label>
      <label class="due-field"><span>Time <em>(optional)</em></span><input type="time" class="due-time"></label>
      <div class="due-actions">
        <button class="due-clear" data-due="clear">Remove</button>
        <button class="confirm-pop-btn color-pop-use" data-due="done">Done</button>
      </div>`;
    const dateInput = pop.querySelector('.due-date');
    const timeInput = pop.querySelector('.due-time');
    if (current) {
      dateInput.value = dayKey(current.day);
      if (current.hasTime) timeInput.value = item.due.split('T')[1];
    }
    pop.querySelector('.due-clear').hidden = !item.due;

    // every change applies straight away
    function apply() {
      if (!dateInput.value) {
        // a time on its own means "today at that time"
        if (!timeInput.value) return;
        dateInput.value = dayKey(new Date());
      }
      item.due = timeInput.value ? `${dateInput.value}T${timeInput.value}` : dateInput.value;
      pop.querySelector('.due-clear').hidden = false;
      onChange();
    }
    dateInput.addEventListener('change', apply);
    timeInput.addEventListener('change', apply);

    pop.addEventListener('click', (e) => {
      const quick = e.target.closest('[data-quick]');
      if (quick) {
        const d = new Date();
        d.setDate(d.getDate() + Number(quick.dataset.quick));
        dateInput.value = dayKey(d);
        apply();
      }
      const action = e.target.closest('[data-due]')?.dataset.due;
      if (action === 'clear') { delete item.due; onChange(); close(); }
      if (action === 'done') close();
    });

    document.body.append(pop);
    const r = button.getBoundingClientRect();
    const w = pop.offsetWidth;
    const h = pop.offsetHeight;
    let top = r.bottom + 6;
    if (top + h > window.innerHeight - 8) top = r.top - h - 6;
    pop.style.top = `${Math.min(Math.max(8, top), window.innerHeight - h - 8)}px`;
    pop.style.left = `${Math.min(Math.max(8, r.left + r.width / 2 - w / 2), window.innerWidth - w - 8)}px`;
    document.addEventListener('pointerdown', onOutside, true);
    document.addEventListener('keydown', onKey, true);
  }

  // ---------- pieces for a task row ----------
  /**
   * Returns { button, chip, refresh } for one task.
   * button: the clock (shown on hover while no due date is set)
   * chip:   the "Due …" label under the task text (click to change)
   */
  function forTask(item, onChange) {
    const button = document.createElement('button');
    button.className = 'card-btn due-btn';
    button.setAttribute('aria-label', 'Set a due date');
    button.dataset.tooltip = 'Complete by…';
    button.innerHTML = CLOCK;

    const chip = document.createElement('button');
    chip.className = 'due-chip';
    chip.setAttribute('aria-label', 'Change due date');

    function refresh() {
      const has = !!item.due;
      chip.hidden = !has;
      button.classList.toggle('has-due', has);
      if (!has) return;
      chip.innerHTML = `${CLOCK}<span></span>`;
      chip.querySelector('span').textContent = label(item.due);
      chip.dataset.status = status(item.due);
      chip.dataset.tooltip = describe(item.due);
    }
    const changed = () => { refresh(); onChange(); };
    button.addEventListener('click', () => open(button, item, changed));
    chip.addEventListener('click', () => open(chip, item, changed));
    chip.dueRefresh = refresh; // so the clock can update it every minute
    refresh();
    return { button, chip, refresh };
  }

  // overdue / today colours change as time passes
  setInterval(() => {
    document.querySelectorAll('.due-chip').forEach((c) => c.dueRefresh?.());
  }, 60 * 1000);

  return { forTask, label, status };
})();
