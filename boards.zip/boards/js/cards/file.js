// file.js — the File card: keep any file (PDF, Word, Excel, text, zip…) on the board.
// Shows its type, name and size; click it (or Open) to read it inside the app, or Download it.
// The file itself is stored in the browser like images/videos (card.mediaId), so duplicating
// a card copies the file and deleting the card deletes it.
window.App = window.App || {};

// colours/labels for file types
App.fileIcons = (() => {
  const GROUPS = {
    pdf: ['pdf'],
    word: ['doc', 'docx', 'odt', 'rtf', 'pages'],
    sheet: ['xls', 'xlsx', 'ods', 'csv', 'tsv', 'numbers'],
    slides: ['ppt', 'pptx', 'odp', 'key'],
    image: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'bmp', 'heic', 'avif'],
    media: ['mp3', 'wav', 'm4a', 'flac', 'ogg', 'mp4', 'mov', 'webm', 'mkv', 'avi'],
    archive: ['zip', 'rar', '7z', 'tar', 'gz'],
    code: ['js', 'ts', 'py', 'php', 'html', 'css', 'json', 'java', 'c', 'cpp', 'cs', 'sql', 'xml', 'sh'],
    text: ['txt', 'md', 'markdown', 'log'],
  };
  const NAMES = {
    pdf: 'PDF document', word: 'Word document', sheet: 'Spreadsheet', slides: 'Presentation', image: 'Image',
    media: 'Audio / video', archive: 'Archive', code: 'Code', text: 'Text', other: 'File',
  };
  function groupOf(meta) {
    const e = (String(meta.name).match(/\.([a-z0-9]+)$/i)?.[1] || '').toLowerCase();
    return Object.keys(GROUPS).find((g) => GROUPS[g].includes(e)) || 'other';
  }
  return { groupOf, nameOf: (meta) => NAMES[groupOf(meta)] };
})();

App.cardTypes.file = (() => {
  const ICONS = {
    upload: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M12 17v-6M9.5 13.5L12 11l2.5 2.5"/></svg>',
    open: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M1.5 8S4 3.5 8 3.5 14.5 8 14.5 8 12 12.5 8 12.5 1.5 8 1.5 8z"/><circle cx="8" cy="8" r="2"/></svg>',
    download: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2.5v8M4.5 7L8 10.5 11.5 7M3 13.5h10"/></svg>',
  };

  const sizeText = (bytes) => {
    if (!Number.isFinite(bytes)) return '';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(bytes < 10240 ? 1 : 0)} KB`;
    if (bytes < 1024 ** 3) return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
    return `${(bytes / 1024 ** 3).toFixed(2)} GB`;
  };
  const ext = (name) => (String(name).match(/\.([a-z0-9]+)$/i)?.[1] || '').toLowerCase();

  // save a stored file to the computer
  async function download(card) {
    const blob = await App.mediaStore.getBlob(card.mediaId);
    if (!blob) return;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = card.name || 'file';
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }

  // ---------- empty card: choose / drop a file ----------
  function renderPicker(card, body) {
    const zone = document.createElement('div');
    zone.className = 'media-drop file-drop';
    zone.innerHTML = `
      ${ICONS.upload}
      <button class="media-pick" type="button">Choose a file</button>
      <p class="media-hint">or drop one here · PDF, Word, text, spreadsheets, anything</p>
      <p class="media-error" hidden></p>
      <input type="file" hidden>`;
    const input = zone.querySelector('input');
    const error = zone.querySelector('.media-error');

    async function attach(file) {
      if (!file) return;
      zone.classList.add('is-loading');
      try {
        const mediaId = await App.mediaStore.put(file);
        App.state.updateCard(card.id, { mediaId, name: file.name, size: file.size, fileType: file.type });
        render(card, body);
      } catch {
        zone.classList.remove('is-loading');
        error.textContent = 'This file couldn’t be saved. It may be too large for browser storage.';
        error.hidden = false;
      }
    }

    zone.querySelector('.media-pick').addEventListener('click', () => input.click());
    input.addEventListener('change', () => attach(input.files[0]));
    zone.addEventListener('dragover', (e) => {
      if (!e.dataTransfer.types.includes('Files')) return;
      e.preventDefault();
      e.stopPropagation();
      zone.classList.add('is-over');
    });
    zone.addEventListener('dragleave', () => zone.classList.remove('is-over'));
    zone.addEventListener('drop', (e) => {
      if (!e.dataTransfer.files.length) return;
      e.preventDefault();
      e.stopPropagation();
      zone.classList.remove('is-over');
      attach(e.dataTransfer.files[0]);
    });
    body.append(zone);
  }

  // ---------- a stored file ----------
  function renderFile(card, body) {
    const meta = { name: card.name, size: card.size, type: card.fileType };
    const group = App.fileIcons.groupOf(meta);
    const viewable = App.fileViewer.canView(meta);

    const wrap = document.createElement('div');
    wrap.className = 'file';
    wrap.innerHTML = `
      <button class="file-main" ${viewable ? '' : 'data-nopreview'}>
        <span class="file-icon"></span>
        <span class="file-info"><span class="file-name"></span><span class="file-meta"></span></span>
      </button>
      <div class="file-actions">
        ${viewable ? `<button class="file-btn" data-file="open">${ICONS.open}Open</button>` : ''}
        <button class="file-btn" data-file="download">${ICONS.download}Download</button>
      </div>`;
    const icon = wrap.querySelector('.file-icon');
    icon.textContent = (ext(card.name) || 'file').slice(0, 4).toUpperCase();
    icon.dataset.ext = group;
    wrap.querySelector('.file-name').textContent = card.name || 'File';
    wrap.querySelector('.file-meta').textContent = [sizeText(card.size), App.fileIcons.nameOf(meta)].filter(Boolean).join(' · ');
    const main = wrap.querySelector('.file-main');
    main.dataset.tooltip = viewable ? 'Click to read it here' : 'This type can’t be shown here — click to download';

    const open = () => App.fileViewer.open(meta, () => App.mediaStore.getBlob(card.mediaId), () => download(card));
    wrap.addEventListener('click', (e) => {
      const a = e.target.closest('[data-file]')?.dataset.file;
      if (a === 'open') open();
      if (a === 'download') download(card);
      if (e.target.closest('.file-main')) (viewable ? open : () => download(card))();
    });

    // description under the file
    const caption = App.richText.create({
      className: 'media-caption file-caption',
      placeholder: 'Add a description',
      multiline: false,
      html: card.captionHtml ?? App.richText.fromText(card.caption),
      onChange: (captionHtml, text) => App.state.updateCard(card.id, { captionHtml, caption: text }),
    });
    body.append(wrap, caption);
  }

  function render(card, body) {
    body.replaceChildren();
    if (card.mediaId) renderFile(card, body);
    else renderPicker(card, body);
  }

  return {
    label: 'File',
    resizable: true,
    minWidth: 220,
    maxWidth: 700,
    defaults: () => ({ mediaId: null, name: '', size: 0, fileType: '', width: 300 }),
    render,
    focus(el) { el.querySelector('.media-pick')?.focus(); },
    onRemove(card) { if (card.mediaId) App.mediaStore.remove(card.mediaId); },
    download,
  };
})();
