// drawing.js — the Canvas card: draw with the mouse, pen or finger.
// White in light mode, a chalkboard in dark mode (or any background colour you pick).
//
// Drawings are saved as strokes (lists of points), so they stay sharp at any size and
// their colours follow the theme.
// Scaling: strokes are stored in the canvas's "reference size" (card.ref). When the canvas is
// resized the whole drawing scales with it (keeping its shape, anchored top-left), unless
// scaling is switched off (card.fixedScale), in which case resizing just adds/removes space.
// Layers are optional (see drawing-layers.js): until switched on, everything is one drawing.
// Mirroring (see canvas-mirror.js): a canvas can show another canvas live (card.mirrorOf),
// optionally flipped (card.mirrorFlip = { h, v }). It keeps its own drawing for when you stop.
// Shapes: a stroke with `sh` (rect, ellipse, line, arrow, triangle, diamond), p = [x1, y1, x2, y2]
// and `f` (0 outline, 1 filled, 2 soft fill).
// Brushes (see brushes.js): a line drawn with a brush remembers it (stroke.b) plus a random seed
// (stroke.r), so it looks exactly the same every time it's drawn.
// A mirror can choose its own layers (card.mirrorLayers = { mode: 'same' | 'all' | 'custom', hidden: [ids] }),
// e.g. you work on one layer in the original while the mirror shows every layer together.
window.App = window.App || {};

// ---------- live link between canvases (for mirrors) ----------
App.canvasSync = (() => {
  const bus = new EventTarget();
  const live = new Map(); // canvas id -> () => the line being drawn right now
  let pending = new Set();
  let frame = 0;
  return {
    // "this canvas changed" (batched to once per frame)
    emit(id) {
      pending.add(id);
      if (frame) return;
      frame = requestAnimationFrame(() => {
        frame = 0;
        const ids = pending;
        pending = new Set();
        ids.forEach((i) => bus.dispatchEvent(new CustomEvent('change', { detail: i })));
      });
    },
    on: (fn) => bus.addEventListener('change', fn),
    off: (fn) => bus.removeEventListener('change', fn),
    setLive: (id, getter) => live.set(id, getter),
    getLive: (id) => live.get(id)?.() || null,
  };
})();

App.cardTypes.drawing = (() => {
  const COLORS = ['ink', 'red', 'orange', 'green', 'blue', 'purple', 'pink'];
  const COLOR_NAMES = { ink: 'Chalk / ink', red: 'Red', orange: 'Orange', green: 'Green', blue: 'Blue', purple: 'Purple', pink: 'Pink' };
  const SIZE = { min: 1, max: 40, start: 5 }; // pen thickness slider (screen px)
  const SHAPES = [
    { id: 'rect', label: 'Rectangle' }, { id: 'ellipse', label: 'Ellipse' }, { id: 'triangle', label: 'Triangle' },
    { id: 'diamond', label: 'Diamond' }, { id: 'line', label: 'Line' }, { id: 'arrow', label: 'Arrow' },
  ];
  const FILLS = [{ id: 0, label: 'Outline' }, { id: 1, label: 'Filled' }, { id: 2, label: 'Soft fill' }];
  const ERASER_SCALE = 3; // the eraser is wider than the pen
  const MIN_STEP = 1.5;   // ignore movements smaller than this (keeps saved data small)

  const ICONS = {
    pen: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10.5 2.5l3 3L6 13H3v-3z"/><path d="M9 4l3 3"/></svg>',
    eraser: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6 13.5h8M2.8 9.7l6.4-6.4a1.5 1.5 0 0 1 2.1 0l1.4 1.4a1.5 1.5 0 0 1 0 2.1L7.2 12.3a1.5 1.5 0 0 1-2.1 0L2.8 10a.2.2 0 0 1 0-.3z"/><path d="M5.5 7l3.5 3.5"/></svg>',
    hand: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5.5 8V3.5a1 1 0 0 1 2 0V7.5M7.5 7V2.5a1 1 0 0 1 2 0V7.5M9.5 7.5V3.5a1 1 0 0 1 2 0V9M5.5 8V6.5a1 1 0 0 0-2 0V9.5a5 5 0 0 0 5 5h.5a4 4 0 0 0 4-4V6a1 1 0 0 0-2 0"/></svg>',
    more: '<svg viewBox="0 0 16 16" fill="currentColor"><circle cx="3.5" cy="8" r="1.3"/><circle cx="8" cy="8" r="1.3"/><circle cx="12.5" cy="8" r="1.3"/></svg>',
    sh_rect: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2.5" y="3.5" width="11" height="9" rx="1"/></svg>',
    sh_ellipse: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><ellipse cx="8" cy="8" rx="5.8" ry="4.6"/></svg>',
    sh_triangle: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><path d="M8 2.8l5.8 10H2.2z"/></svg>',
    sh_diamond: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><path d="M8 2l6 6-6 6-6-6z"/></svg>',
    sh_line: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3 13L13 3"/></svg>',
    sh_arrow: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 13L12.5 3.5M7 3.5h5.5V9"/></svg>',
    brush: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M13.8 2.2a1.2 1.2 0 0 0-1.7 0L7 7.3 8.7 9l5.1-5.1a1.2 1.2 0 0 0 0-1.7z"/><path d="M6.6 8c-1.6 0-2.6 1.1-2.8 2.6-.1 1-.6 2-1.8 2.6 2.6.9 5.4.2 6.1-1.6.4-1-.1-2.4-1.5-3.6z"/></svg>',
    pick: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M10.2 2.6a1.9 1.9 0 0 1 2.7 2.7l-1.6 1.6.8.8-1.2 1.2-3.8-3.8 1.2-1.2.8.8z"/><path d="M7.9 5.9L3 10.8V13h2.2l4.9-4.9"/></svg>',
    undo: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3L2 6l3 3"/><path d="M2 6h7.5a4 4 0 0 1 0 8H7"/></svg>',
    bucket: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 8.5L8 3l5 5-5.5 5.5z"/><path d="M5 1.5L8 3"/><path d="M13.5 10.5s1.2 1.5 1.2 2.3a1.2 1.2 0 0 1-2.4 0c0-.8 1.2-2.3 1.2-2.3z" fill="currentColor"/></svg>',
    scale: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9.5 2.5h4v4M13.5 2.5L9 7M6.5 13.5h-4v-4M2.5 13.5L7 9"/></svg>',
    layers: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"><path d="M8 2l6 3.2-6 3.2-6-3.2z"/><path d="M2 8.2l6 3.2 6-3.2" stroke-linecap="round"/><path d="M2 11l6 3.2 6-3.2" stroke-linecap="round"/></svg>',
    mirror: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"><path d="M8 1.5v13" stroke-dasharray="1.6 1.6"/><path d="M6 4L1.5 12H6z"/><path d="M10 4l4.5 8H10z"/></svg>',
    flipH: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2v12"/><path d="M5.5 5L2.5 8l3 3M10.5 5l3 3-3 3"/></svg>',
    flipV: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2 8h12"/><path d="M5 5.5L8 2.5l3 3M5 10.5l3 3 3-3"/></svg>',
    unlink: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M6.5 9.5l-2 2a2.1 2.1 0 0 1-3-3l2-2M9.5 6.5l2-2a2.1 2.1 0 0 1 3 3l-2 2M2 2l12 12"/></svg>',
    download: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2.5v8M4.5 7L8 10.5 11.5 7M3 13.5h10"/></svg>',
    thickness: '<svg viewBox="0 0 16 16" fill="currentColor"><rect x="2" y="3" width="12" height="1" rx=".5"/><rect x="2" y="6.5" width="12" height="2" rx="1"/><rect x="2" y="11" width="12" height="3" rx="1.5"/></svg>',
    opacity: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M8 2s4.5 4.6 4.5 7.6A4.5 4.5 0 0 1 3.5 9.6C3.5 6.6 8 2 8 2z"/><path d="M8 14.1V2" /><path d="M8 5.5l2.6 2.6M8 9l3.8 3.8" stroke-width="1.1"/></svg>',
    clear: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5l.7 9h5.6l.7-9"/></svg>',
  };

  const redrawers = new Map(); // canvas element -> redraw function (for theme changes)

  // colour name -> actual colour, read from the canvas (its ink depends on theme + background)
  function colorValue(name, boardEl) {
    if (String(name).startsWith('#')) return name; // custom colour
    const prop = name === 'ink' ? '--board-ink' : `--tc-${name}`;
    return getComputedStyle(boardEl).getPropertyValue(prop).trim() || '#000';
  }

  // ---------- drawing strokes ----------
  function styleFor(ctx, stroke, boardEl) {
    ctx.globalCompositeOperation = stroke.e ? 'destination-out' : 'source-over';
    ctx.strokeStyle = ctx.fillStyle = stroke.e ? '#000' : colorValue(stroke.c, boardEl);
    ctx.globalAlpha = stroke.e ? 1 : (stroke.o ?? 1); // pen opacity
    ctx.lineWidth = stroke.s;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
  }

  function dot(ctx, x, y, size) {
    ctx.beginPath();
    ctx.arc(x, y, size / 2, 0, Math.PI * 2);
    ctx.fill();
  }

  // a shape stroke: rectangle, ellipse, triangle, diamond, line or arrow
  function drawShape(ctx, st, boardEl) {
    const [x1, y1, x2, y2] = st.p;
    styleFor(ctx, st, boardEl);
    const left = Math.min(x1, x2);
    const top = Math.min(y1, y2);
    const w = Math.abs(x2 - x1);
    const h = Math.abs(y2 - y1);
    const path = new Path2D();
    const open = st.sh === 'line' || st.sh === 'arrow';
    if (st.sh === 'rect') path.rect(left, top, w, h);
    if (st.sh === 'ellipse') path.ellipse(left + w / 2, top + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
    if (st.sh === 'triangle') { // point towards where you started dragging
      path.moveTo((x1 + x2) / 2, y1); path.lineTo(x2, y2); path.lineTo(x1, y2); path.closePath();
    }
    if (st.sh === 'diamond') {
      path.moveTo(left + w / 2, top); path.lineTo(left + w, top + h / 2); path.lineTo(left + w / 2, top + h); path.lineTo(left, top + h / 2); path.closePath();
    }
    let ex = x2;
    let ey = y2;
    const angle = Math.atan2(y2 - y1, x2 - x1);
    const head = st.s * 2.6 + 8;
    if (st.sh === 'arrow') { // stop the line where the arrow head starts
      const len = Math.hypot(x2 - x1, y2 - y1);
      const cut = Math.min(len, head * 0.7);
      ex = x2 - Math.cos(angle) * cut;
      ey = y2 - Math.sin(angle) * cut;
    }
    if (open) { path.moveTo(x1, y1); path.lineTo(ex, ey); }

    if (!open && st.f) { // filled / soft fill
      ctx.save();
      if (st.f === 2) ctx.globalAlpha *= 0.25;
      ctx.fill(path);
      ctx.restore();
    }
    ctx.stroke(path);
    if (st.sh === 'arrow') {
      const spread = 0.48;
      const head2 = new Path2D();
      head2.moveTo(x2, y2);
      head2.lineTo(x2 - Math.cos(angle - spread) * head, y2 - Math.sin(angle - spread) * head);
      head2.lineTo(x2 - Math.cos(angle + spread) * head, y2 - Math.sin(angle + spread) * head);
      head2.closePath();
      ctx.fill(head2);
      ctx.lineWidth = Math.max(1, st.s * 0.6);
      ctx.stroke(head2);
    }
  }

  // whole stroke, smoothed through the midpoints between samples
  function drawStroke(ctx, stroke, boardEl) {
    if (stroke.sh) return drawShape(ctx, stroke, boardEl);
    if (stroke.b && !stroke.e && App.brushes.isStamp(stroke.b)) {
      App.brushes.drawStamped(ctx, stroke, colorValue(stroke.c, boardEl));
      return;
    }
    const p = stroke.p;
    styleFor(ctx, stroke, boardEl);
    if (p.length <= 2) return dot(ctx, p[0], p[1], stroke.s);
    ctx.beginPath();
    ctx.moveTo(p[0], p[1]);
    for (let i = 2; i < p.length; i += 2) {
      ctx.quadraticCurveTo(p[i - 2], p[i - 1], (p[i - 2] + p[i]) / 2, (p[i - 1] + p[i + 1]) / 2);
    }
    ctx.lineTo(p[p.length - 2], p[p.length - 1]);
    ctx.stroke();
  }

  // ---------- painting a whole canvas document ----------
  let scratch = null; // reusable canvas for drawing one layer at a time
  function scratchFor(w, h) {
    if (!scratch || scratch.width !== w || scratch.height !== h) {
      scratch = document.createElement('canvas');
      scratch.width = w;
      scratch.height = h;
    }
    return scratch;
  }

  /**
   * Paint `doc` (a canvas card's data) into `target` (w × h pixels).
   * setT(ctx) sets up the coordinates; colorEl is where theme colours are read from;
   * extra = a line still being drawn (painted in its layer, or on top).
   * isVisible(layer) = which layers to show (default: the layer's own eye setting).
   */
  function paintDoc(doc, target, w, h, setT, colorEl, extra = null, isVisible = (l) => l.visible) {
    const strokes = doc.strokes || [];
    if (!doc.layersOn) {
      setT(target);
      strokes.forEach((s) => drawStroke(target, s, colorEl));
      if (extra) drawStroke(target, extra, colorEl);
      return;
    }
    // each layer is drawn on its own, so the eraser only erases within that layer
    const buf = scratchFor(w, h);
    const bctx = buf.getContext('2d');
    doc.layers.forEach((layer) => {
      if (!isVisible(layer)) return;
      bctx.setTransform(1, 0, 0, 1, 0, 0);
      bctx.globalCompositeOperation = 'source-over';
      bctx.clearRect(0, 0, w, h);
      setT(bctx);
      strokes.forEach((s) => {
        if (App.drawingLayers.layerIdOf(doc, s) === layer.id) drawStroke(bctx, s, colorEl);
      });
      if (extra && App.drawingLayers.layerIdOf(doc, extra) === layer.id) drawStroke(bctx, extra, colorEl);
      target.setTransform(1, 0, 0, 1, 0, 0);
      target.globalCompositeOperation = 'source-over';
      target.globalAlpha = layer.opacity ?? 1;
      target.drawImage(buf, 0, 0);
      target.globalAlpha = 1;
    });
  }

  // strokes you can actually see (hidden layers left out)
  function visibleStrokes(doc, isVisible = (l) => l.visible) {
    const strokes = doc.strokes || [];
    if (!doc.layersOn) return strokes;
    return strokes.filter((s) => {
      const layer = doc.layers.find((l) => l.id === App.drawingLayers.layerIdOf(doc, s));
      return layer && isVisible(layer);
    });
  }

  // "Canvas 2" etc., by order on the board
  function nameOf(id) {
    const canvases = App.state.get().cards.filter((c) => c.type === 'drawing');
    const i = canvases.findIndex((c) => c.id === id);
    return i < 0 ? 'Canvas' : `Canvas ${i + 1}`;
  }

  // small preview image of a canvas (for the mirror picker)
  function thumbnail(doc, w, h) {
    const c = document.createElement('canvas');
    const dpr = window.devicePixelRatio || 1;
    c.width = Math.round(w * dpr);
    c.height = Math.round(h * dpr);
    const colorEl = document.querySelector(`.card[data-id="${doc.id}"] .card-body`) || document.documentElement;
    const ref = doc.ref || { w: 400, h: 300 };
    const k = Math.min(w / ref.w, h / ref.h) * dpr;
    paintDoc(doc, c.getContext('2d'), c.width, c.height, (ctx) => ctx.setTransform(k, 0, 0, k, 0, 0), colorEl);
    c.style.background = getComputedStyle(colorEl).getPropertyValue('--board-bg');
    return c;
  }

  // parse '#hex' / 'rgb()' into {r,g,b}
  function rgbOf(color) {
    const c = String(color).trim();
    return App.colorPicker.hexToRgb(c) || App.colorPicker.hexToRgb(App.colorPicker.cssRgbToHex(c) || '') || { r: 255, g: 255, b: 255 };
  }

  // ---------- card ----------
  function render(card, body) {
    card.strokes = card.strokes || [];
    const tool = { mode: 'pen', color: 'ink', size: SIZE.start, opacity: 1, pickFor: 'pen', before: 'pen', brush: card.brush || 'pen',
      shape: card.shapeTool?.shape || 'rect', fill: card.shapeTool?.fill ?? 0 };

    // tool bar — one compact row ("draw-edit" parts are hidden while mirroring another canvas):
    //   tools · colour · pen (size/opacity/brush) · … zoom · undo · ⋯ (everything else)
    const bar = document.createElement('div');
    bar.className = 'draw-tools';
    bar.innerHTML = `
      <div class="draw-group draw-edit draw-modes" role="group" aria-label="Tools">
        <button class="draw-btn" data-draw-mode="pen" aria-label="Draw" data-tooltip="Draw  B">${ICONS.pen}</button>
        <button class="draw-btn" data-draw-mode="eraser" aria-label="Eraser" data-tooltip="Eraser  E">${ICONS.eraser}</button>
        <button class="draw-btn" data-draw-mode="shape" aria-label="Shapes" aria-haspopup="dialog" data-tooltip="Shapes  U&#10;(click again to pick a shape)"></button>
        <button class="draw-btn" data-draw-mode="hand" aria-label="Move around" data-tooltip="Move around  H&#10;(or hold Space)">${ICONS.hand}</button>
        <button class="draw-btn" data-draw-mode="pick" aria-label="Eyedropper" data-tooltip="Eyedropper  I&#10;(or Alt + click)">${ICONS.pick}</button>
      </div>
      <div class="draw-group draw-edit">
        <button class="draw-swatch-btn" data-draw-action="color" aria-label="Colour" aria-haspopup="dialog" data-tooltip="Colour"><span></span></button>
        <button class="draw-pen-btn" data-draw-action="pen" aria-label="Size, opacity and brush" aria-haspopup="dialog"><span class="draw-pen-dot"></span><span class="draw-pen-size"></span></button>
      </div>
      <div class="draw-group draw-mirror-bar">
        <span class="draw-mirror-label"></span>
        <button class="draw-btn" data-draw-action="flip-h" aria-label="Flip left-right" data-tooltip="Flip left ↔ right">${ICONS.flipH}</button>
        <button class="draw-btn" data-draw-action="flip-v" aria-label="Flip upside down" data-tooltip="Flip upside down">${ICONS.flipV}</button>
        <button class="draw-btn draw-mirror-layers" data-draw-action="mirror-layers" aria-label="Which layers to show" aria-haspopup="dialog">${ICONS.layers}</button>
      </div>
      <span class="draw-spacer"></span>
      <div class="draw-zoom-slot"></div>
      <div class="draw-group">
        <button class="draw-btn draw-edit" data-draw-action="undo" aria-label="Undo" data-tooltip="Undo  Ctrl+Z">${ICONS.undo}</button>
        <button class="draw-btn" data-draw-action="more" aria-label="More" aria-haspopup="menu" data-tooltip="More: layers, background,&#10;mirror, download, clear…">${ICONS.more}</button>
      </div>`;

    // drawing surface
    const surface = document.createElement('div');
    surface.className = 'draw-surface';
    surface.tabIndex = 0;
    surface.setAttribute('aria-label', 'Drawing area');
    const canvas = document.createElement('canvas');
    canvas.className = 'draw-canvas';
    // a second, see-through layer shows the line you're drawing right now
    // (redrawn as one shape, so see-through lines don't get darker where they overlap themselves)
    const liveCanvas = document.createElement('canvas');
    liveCanvas.className = 'draw-canvas draw-live';
    // eyedropper: little bubble showing the colour under the pointer
    const pickBubble = document.createElement('span');
    pickBubble.className = 'pick-bubble';
    pickBubble.hidden = true;
    // shown on a mirror whose original was deleted
    const notice = document.createElement('div');
    notice.className = 'draw-notice';
    notice.hidden = true;
    surface.append(canvas, liveCanvas, pickBubble, notice);
    const ctx = canvas.getContext('2d');
    const liveCtx = liveCanvas.getContext('2d');

    const main = document.createElement('div');
    main.className = 'draw-main';
    main.append(surface);
    body.append(bar, main);

    // ----- mirroring -----
    const mirroring = () => !!card.mirrorOf;
    const source = () => (card.mirrorOf ? App.state.getCard(card.mirrorOf) : null);
    // what this canvas shows: its own drawing, or the one it mirrors
    const doc = () => (mirroring() ? source() || { strokes: [] } : card);

    // which layers to show: a mirror can pick its own (see card.mirrorLayers)
    function layerRule() {
      if (!mirroring()) return (l) => l.visible;
      const ml = card.mirrorLayers || { mode: 'same' };
      if (ml.mode === 'all') return () => true;
      if (ml.mode === 'custom') {
        const hidden = new Set(ml.hidden || []);
        return (l) => !hidden.has(l.id);
      }
      return (l) => l.visible; // 'same': whatever the original shows
    }

    // ----- layers (optional, see drawing-layers.js) -----
    const layersUI = App.drawingLayers.attach({
      card,
      onChange: () => { redraw(); syncTools(); },
      onDisable: () => { redraw(); syncTools(); },
    });
    main.append(layersUI.panel);
    layersUI.panel.hidden = true;

    // ----- small panels that open from the toolbar (colour, pen, shapes, ⋯ menu) -----
    let panel = null;
    let panelAnchor = null;
    function closePanel() {
      panel?.remove();
      panel = null;
      panelAnchor?.setAttribute('aria-expanded', 'false');
      panelAnchor = null;
      document.removeEventListener('pointerdown', onOutsidePanel, true);
      document.removeEventListener('keydown', onPanelKey, true);
    }
    function onOutsidePanel(e) {
      if (panel && !panel.contains(e.target) && !panelAnchor?.contains(e.target) && !e.target.closest('.color-pop, .confirm-pop')) closePanel();
    }
    function onPanelKey(e) { if (e.key === 'Escape') { e.stopPropagation(); const a = panelAnchor; closePanel(); a?.focus(); } }
    function openPanel(anchor, el) {
      if (panelAnchor === anchor) { closePanel(); return; }
      closePanel();
      App.tooltip?.hide();
      panel = el;
      panelAnchor = anchor;
      anchor.setAttribute('aria-expanded', 'true');
      el.classList.add('draw-panel');
      document.body.append(el);
      const r = anchor.getBoundingClientRect();
      const w = el.offsetWidth;
      const h = el.offsetHeight;
      let top = r.bottom + 6;
      if (top + h > window.innerHeight - 8) top = r.top - h - 6;
      el.style.top = `${Math.min(Math.max(8, top), window.innerHeight - h - 8)}px`;
      el.style.left = `${Math.min(Math.max(8, r.left), window.innerWidth - w - 8)}px`;
      document.addEventListener('pointerdown', onOutsidePanel, true);
      document.addEventListener('keydown', onPanelKey, true);
    }

    // pen colours: presets + saved custom colours + "+" (see palette.js); lives in the colour panel
    const colorRow = App.palette.create({
      presets: COLORS.map((c) => ({
        value: c,
        label: COLOR_NAMES[c],
        css: c === 'ink' ? 'var(--board-ink)' : `var(--tc-${c})`,
      })),
      value: tool.color,
      visible: 8,
      size: 20,
      onPick: (c) => {
        tool.color = c;
        if (tool.mode !== 'shape') tool.mode = 'pen';
        syncTools();
        closePanel();
      },
    });

    function openColorPanel(anchor) {
      const el = document.createElement('div');
      el.innerHTML = `<p class="draw-panel-title">Colour</p>
        <button class="draw-panel-link" data-p="pick">${ICONS.pick}<span>Pick a colour from the drawing</span></button>`;
      el.insertBefore(colorRow.el, el.querySelector('[data-p]'));
      el.querySelector('[data-p="pick"]').addEventListener('click', () => { closePanel(); startPicking('pen'); });
      openPanel(anchor, el);
    }

    function openPenPanel(anchor) {
      const brush = App.brushes.get(tool.brush) || App.brushes.get('pen');
      const el = document.createElement('div');
      el.innerHTML = `
        <p class="draw-panel-title">Pen</p>
        <label class="draw-panel-row"><span>Thickness</span>
          <input type="range" min="${SIZE.min}" max="${SIZE.max}" step="1" data-p="size"><output data-o="size"></output></label>
        <label class="draw-panel-row"><span>Opacity</span>
          <input type="range" min="5" max="100" step="5" data-p="opacity" class="draw-opacity"><output data-o="opacity"></output></label>
        <div class="draw-panel-brush">
          <span class="draw-panel-brush-name"></span>
          <button class="file-btn" data-p="brushes">${ICONS.brush}Brushes…</button>
        </div>`;
      const size = el.querySelector('[data-p="size"]');
      const opacity = el.querySelector('[data-p="opacity"]');
      const show = () => {
        el.querySelector('[data-o="size"]').textContent = `${tool.size}px`;
        el.querySelector('[data-o="opacity"]').textContent = `${Math.round(tool.opacity * 100)}%`;
      };
      size.value = tool.size;
      opacity.value = Math.round(tool.opacity * 100);
      opacity.style.setProperty('--pen', colorValue(tool.color, body));
      const preview = App.brushes.preview(brush, 72, 26, colorValue(tool.color, body));
      el.querySelector('.draw-panel-brush-name').append(preview, document.createTextNode(brush.name));
      size.addEventListener('input', () => { tool.size = +size.value; show(); syncTools(); });
      opacity.addEventListener('input', () => { tool.opacity = +opacity.value / 100; show(); syncTools(); });
      el.querySelector('[data-p="brushes"]').addEventListener('click', () => {
        closePanel();
        App.brushPicker.open(anchor, {
          current: tool.brush,
          color: colorValue(tool.color, body),
          onPick: (id) => {
            tool.brush = id;
            if (tool.mode !== 'pen') tool.mode = 'pen';
            card.brush = id;
            App.state.updateCard(card.id, { brush: id });
            syncTools();
          },
        });
      });
      show();
      openPanel(anchor, el);
    }

    function openShapePanel(anchor) {
      const el = document.createElement('div');
      el.innerHTML = `
        <p class="draw-panel-title">Shapes</p>
        <div class="shape-grid">
          ${SHAPES.map((sh) => `<button class="shape-btn" data-sh="${sh.id}" aria-label="${sh.label}" data-tooltip="${sh.label}">${ICONS[`sh_${sh.id}`]}</button>`).join('')}
        </div>
        <div class="shape-fills" role="radiogroup" aria-label="Fill">
          ${FILLS.map((f) => `<button class="shape-fill" data-fill="${f.id}" role="radio">${f.label}</button>`).join('')}
        </div>
        <p class="draw-panel-hint">Hold Shift for squares, circles and straight lines.</p>`;
      const mark = () => {
        el.querySelectorAll('[data-sh]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.sh === tool.shape)));
        el.querySelectorAll('[data-fill]').forEach((b) => b.setAttribute('aria-checked', String(+b.dataset.fill === tool.fill)));
      };
      el.addEventListener('click', (e) => {
        const sh = e.target.closest('[data-sh]')?.dataset.sh;
        const f = e.target.closest('[data-fill]')?.dataset.fill;
        if (sh) tool.shape = sh;
        if (f !== undefined) tool.fill = +f;
        if (sh || f !== undefined) {
          tool.mode = 'shape';
          card.shapeTool = { shape: tool.shape, fill: tool.fill };
          App.state.updateCard(card.id, { shapeTool: card.shapeTool });
          mark();
          syncTools();
        }
        if (sh) closePanel();
      });
      mark();
      openPanel(anchor, el);
    }

    // ⋯ menu: everything that isn't needed all the time
    function openMoreMenu(anchor) {
      const mirror = mirroring();
      const empty = visibleStrokes(doc(), layerRule()).length === 0;
      const items = mirror ? [
        ['download', ICONS.download, 'Download as image…', empty],
        ['mirror', ICONS.mirror, 'Mirror a different canvas…'],
        ['unmirror', ICONS.unlink, 'Stop mirroring'],
      ] : [
        ['layers', ICONS.layers, !card.layersOn ? 'Use layers' : (card.layersPanel ? 'Hide layers panel' : 'Show layers panel')],
        ['background', ICONS.bucket, 'Background colour…'],
        ['scale', ICONS.scale, 'Scale drawing with canvas', false, !card.fixedScale],
        ['mirror', ICONS.mirror, 'Mirror another canvas…'],
        ['download', ICONS.download, 'Download as image…', empty],
        ['clear', ICONS.clear, 'Clear drawing…', card.strokes.length === 0, null, true],
      ];
      const el = document.createElement('div');
      el.className = 'draw-menu';
      el.setAttribute('role', 'menu');
      items.forEach(([act, icon, label, disabled, checked, danger]) => {
        const b = document.createElement('button');
        b.setAttribute('role', checked === undefined || checked === null ? 'menuitem' : 'menuitemcheckbox');
        b.dataset.act = act;
        b.disabled = !!disabled;
        if (danger) b.classList.add('is-danger');
        b.innerHTML = `${icon}<span></span>${checked === undefined || checked === null ? '' : `<span class="draw-menu-check">${checked ? '✓' : ''}</span>`}`;
        b.querySelector('span').textContent = label;
        if (checked !== undefined && checked !== null) b.setAttribute('aria-checked', String(checked));
        if (act === 'clear') el.append(document.createElement('hr'));
        el.append(b);
      });
      el.addEventListener('click', (e) => {
        const act = e.target.closest('[data-act]')?.dataset.act;
        if (!act) return;
        closePanel();
        runAction(act, anchor);
        syncTools();
      });
      openPanel(anchor, el);
      el.querySelector('button:not(:disabled)')?.focus();
    }

    // ----- tool state -----
    function syncTools() {
      const mirror = mirroring();
      body.closest('.attachment, .card')?.classList.toggle('is-mirror', mirror);
      bar.querySelectorAll('[data-draw-mode]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.drawMode === tool.mode)));
      colorRow.set(tool.color);
      const penColor = colorValue(tool.color, body);
      const swatch = bar.querySelector('.draw-swatch-btn');
      swatch.style.setProperty('--pen', penColor);
      swatch.dataset.tooltip = `Colour: ${COLOR_NAMES[tool.color] || tool.color}`;
      const brush = App.brushes.get(tool.brush) || App.brushes.get('pen');
      const penBtn = bar.querySelector('.draw-pen-btn');
      penBtn.querySelector('.draw-pen-dot').style.setProperty('--d', `${Math.max(3, Math.min(16, tool.size))}px`);
      penBtn.querySelector('.draw-pen-dot').style.setProperty('--pen', penColor);
      penBtn.querySelector('.draw-pen-dot').style.opacity = String(Math.max(0.25, tool.opacity));
      penBtn.querySelector('.draw-pen-size').textContent = tool.size;
      penBtn.dataset.tooltip = `${tool.size}px · ${Math.round(tool.opacity * 100)}% · ${brush.name}\n(size, opacity and brush)`;
      penBtn.classList.toggle('has-brush', tool.brush !== 'pen');
      bar.querySelector('[data-draw-mode="shape"]').innerHTML = ICONS[`sh_${tool.shape}`];
      surface.dataset.mode = mirror ? 'hand' : tool.mode;
      bar.querySelector('[data-draw-action="undo"]').disabled = card.strokes.length === 0;

      // layers panel follows the card's setting
      const panelOpen = !!(card.layersOn && card.layersPanel && !mirror);
      if (layersUI.panel.hidden === panelOpen) { // just opened/closed
        layersUI.panel.hidden = !panelOpen;
        if (panelOpen) layersUI.render();
      }

      // mirroring
      const flip = card.mirrorFlip || {};
      bar.querySelector('[data-draw-action="flip-h"]').setAttribute('aria-pressed', String(!!flip.h));
      bar.querySelector('[data-draw-action="flip-v"]').setAttribute('aria-pressed', String(!!flip.v));
      bar.querySelector('.draw-mirror-label').textContent = mirror ? `Mirroring ${nameOf(card.mirrorOf)}` : '';
      // layer choice (only when the original uses layers)
      const mlBtn = bar.querySelector('[data-draw-action="mirror-layers"]');
      const src = source();
      const srcHasLayers = !!(mirror && src?.layersOn);
      const mode = card.mirrorLayers?.mode || 'same';
      mlBtn.disabled = !srcHasLayers;
      mlBtn.setAttribute('aria-pressed', String(srcHasLayers && mode !== 'same'));
      mlBtn.dataset.tooltip = !srcHasLayers ? 'The original doesn’t use layers'
        : mode === 'all' ? 'Showing all layers\n(click to choose)'
          : mode === 'custom' ? 'Showing chosen layers\n(click to change)'
            : 'Showing the same layers as the original\n(click to choose)';
      const flipCss = mirror && (flip.h || flip.v) ? `scale(${flip.h ? -1 : 1}, ${flip.v ? -1 : 1})` : '';
      canvas.style.transform = liveCanvas.style.transform = flipCss;
      notice.hidden = !(mirror && !source());
      if (!notice.hidden) {
        notice.innerHTML = '<p>The canvas this was mirroring has been deleted.</p><button class="confirm-pop-btn" data-draw-action="unmirror">Show this canvas’s own drawing</button>';
      }
    }

    const save = () => { App.state.updateCard(card.id, { strokes: card.strokes }); syncTools(); };

    // ----- scaling: canvas pixels <-> stored (reference) units -----
    let scale = 1;

    function computeScale() {
      const w = surface.clientWidth;
      const h = surface.clientHeight;
      if (!w || !h) return;
      if (mirroring()) { // a mirror always fits the whole original
        const ref = source()?.ref || card.ref || { w, h };
        scale = Math.min(w / ref.w, h / ref.h);
        return;
      }
      if (!card.ref) { // first time: today's size becomes the reference
        card.ref = { w, h };
        App.state.updateCard(card.id, { ref: card.ref });
      }
      scale = card.fixedScale ? 1 : Math.min(w / card.ref.w, h / card.ref.h);
    }

    // canvas drawing is in reference units; this maps them onto the screen
    // (canvas scaling × zoom, then the zoom's pan offset)
    function applyTransform(target = ctx) {
      const dpr = window.devicePixelRatio || 1;
      const k = zoomer.k();
      target.setTransform(dpr * k, 0, 0, dpr * k, dpr * zoomer.view.x, dpr * zoomer.view.y);
    }

    // the line being drawn, on the live layer (no layers only)
    function drawLive() {
      liveCtx.setTransform(1, 0, 0, 1, 0, 0);
      liveCtx.clearRect(0, 0, liveCanvas.width, liveCanvas.height);
      if (!live) liveCanvas.style.opacity = '';
      if (!live || live.stroke.e || card.layersOn) return;
      applyTransform(liveCtx);
      drawStroke(liveCtx, live.stroke, body);
    }

    function redraw() {
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      if (mirroring()) {
        const src = source();
        if (src) paintDoc(src, ctx, canvas.width, canvas.height, (c) => applyTransform(c), body, App.canvasSync.getLive(src.id), layerRule());
        return;
      }
      paint(ctx, canvas.width, canvas.height, (c) => applyTransform(c), card.layersOn ? live?.stroke : null);
      App.canvasSync.emit(card.id); // tell any mirrors
    }

    function paint(target, w, h, setT, extra = null) {
      paintDoc(card, target, w, h, setT, body, extra);
    }

    // repaint on the next frame (while drawing with layers, or when a mirrored canvas changes)
    let liveFrame = 0;
    const redrawSoon = () => {
      if (!liveFrame) liveFrame = requestAnimationFrame(() => { liveFrame = 0; redraw(); });
    };

    // bake the current scale into the strokes and make today's size the new reference,
    // so switching scaling on/off (or clearing) never makes the drawing jump
    function rebase() {
      if (scale !== 1) {
        card.strokes.forEach((st) => {
          st.s = Math.round(st.s * scale * 100) / 100;
          st.p = st.p.map((v) => Math.round(v * scale * 10) / 10);
        });
      }
      card.ref = { w: surface.clientWidth, h: surface.clientHeight };
      scale = 1;
    }

    // ----- zoom + pan inside the canvas (see drawing-zoom.js) -----
    const zoomer = App.drawingZoom.attach({ card, surface, getScale: () => scale, redraw });
    bar.querySelector('.draw-zoom-slot').replaceWith(zoomer.controls);

    // ----- background colour -----
    // custom colour -> set it on this canvas, and pick an ink that stays readable on it
    // (a mirror shows the original's background)
    function applyBackground() {
      const bg = doc().bg;
      const props = ['--board-bg', '--board-ink', '--board-edge'];
      if (!bg) {
        props.forEach((p) => body.style.removeProperty(p));
        return;
      }
      body.style.setProperty('--board-bg', bg);
      body.style.setProperty('--board-ink', App.boardBackground.inkFor(bg));
      body.style.setProperty('--board-edge', `color-mix(in srgb, ${bg} 80%, #808080)`);
    }

    function setBackground(color, persist) {
      card.bg = color || null;
      applyBackground();
      redraw(); // "ink" lines may need to switch between dark ink and chalk
      if (persist) App.state.updateCard(card.id, { bg: card.bg });
    }

    function undo() {
      if (!card.strokes.length || mirroring()) return;
      card.strokes.pop();
      redraw();
      save();
    }

    // ----- eyedropper -----
    // colour of the drawing at a point, mixed with the background where it's see-through
    function colorAt(clientX, clientY) {
      const r = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      const x = Math.min(canvas.width - 1, Math.max(0, Math.round((clientX - r.left) * dpr)));
      const y = Math.min(canvas.height - 1, Math.max(0, Math.round((clientY - r.top) * dpr)));
      const [pr, pg, pb, pa] = ctx.getImageData(x, y, 1, 1).data;
      const bg = rgbOf(getComputedStyle(body).getPropertyValue('--board-bg'));
      const a = pa / 255;
      return App.colorPicker.rgbToHex({
        r: pr * a + bg.r * (1 - a), g: pg * a + bg.g * (1 - a), b: pb * a + bg.b * (1 - a),
      });
    }

    function startPicking(forWhat) {
      if (tool.mode !== 'pick') tool.before = tool.mode;
      tool.pickFor = forWhat;
      tool.mode = 'pick';
      syncTools();
      surface.focus({ preventScroll: true });
    }

    function pickAt(e) {
      const hex = colorAt(e.clientX, e.clientY);
      if (tool.pickFor === 'background') {
        setBackground(hex, true);
        App.savedColors.add(hex);
        tool.mode = tool.before === 'pick' ? 'pen' : tool.before;
      } else {
        App.savedColors.add(hex); // so it shows up in the colour row
        tool.color = hex;
        tool.mode = 'pen';
      }
      tool.pickFor = 'pen';
      pickBubble.hidden = true;
      syncTools();
    }

    surface.addEventListener('pointermove', (e) => {
      if (tool.mode !== 'pick' || mirroring()) { pickBubble.hidden = true; return; }
      const r = surface.getBoundingClientRect();
      pickBubble.hidden = false;
      pickBubble.style.left = `${e.clientX - r.left}px`;
      pickBubble.style.top = `${e.clientY - r.top}px`;
      pickBubble.style.background = colorAt(e.clientX, e.clientY);
      pickBubble.dataset.for = tool.pickFor;
    });
    surface.addEventListener('pointerleave', () => { pickBubble.hidden = true; });

    // ----- mirror on / off -----
    function setMirror(id) {
      if (id) {
        card.mirrorOf = id;
        card.mirrorFlip = card.mirrorFlip || { h: false, v: false };
      } else {
        delete card.mirrorOf;
      }
      App.state.updateCard(card.id, { mirrorOf: card.mirrorOf || null, mirrorFlip: card.mirrorFlip || null });
      live = null;
      drawLive();
      applyBackground();
      computeScale();
      redraw();
      syncTools();
    }

    // follow the mirrored canvas as it changes
    const onSourceChange = (e) => {
      if (!body.isConnected) { App.canvasSync.off(onSourceChange); return; } // this card was removed
      if (mirroring() && e.detail === card.mirrorOf) {
        applyBackground();
        computeScale();
        redrawSoon();
        syncTools();
      }
    };
    App.canvasSync.on(onSourceChange);
    // and notice if it gets deleted
    const unsubscribe = App.state.subscribe(() => {
      if (!body.isConnected) { unsubscribe(); return; }
      if (mirroring()) { syncTools(); redrawSoon(); }
    });

    // toolbar and ⋯ menu actions (btn = what popups should open next to)
    function runAction(act, btn) {
      if (act === 'layers') {
        if (!card.layersOn) App.drawingLayers.enable(card); // first time: switch layers on
        else card.layersPanel = !card.layersPanel;
        App.state.updateCard(card.id, {
          layersOn: card.layersOn, layers: card.layers, activeLayer: card.activeLayer,
          layersPanel: card.layersPanel, strokes: card.strokes,
        });
        redraw();
      }
      if (act === 'mirror') {
        App.canvasMirror.openPicker(btn, {
          selfId: card.id,
          currentId: card.mirrorOf || null,
          nameOf,
          thumbnail,
          onPick: (id) => setMirror(id),
        });
      }
      if (act === 'unmirror') setMirror(null);
      if (act === 'mirror-layers' && source()?.layersOn) {
        App.canvasMirror.openLayers(btn, {
          source: source(),
          value: card.mirrorLayers || { mode: 'same', hidden: [] },
          onChange: (value) => {
            card.mirrorLayers = value;
            App.state.updateCard(card.id, { mirrorLayers: value });
            redraw();
            syncTools();
          },
        });
      }
      if (act === 'flip-h' || act === 'flip-v') {
        const flip = { ...(card.mirrorFlip || {}) };
        const axis = act === 'flip-h' ? 'h' : 'v';
        flip[axis] = !flip[axis];
        card.mirrorFlip = flip;
        App.state.updateCard(card.id, { mirrorFlip: flip });
      }
      if (act === 'download') {
        App.drawingExport.openMenu(btn, () => {
          const shown = doc();
          return {
            strokes: visibleStrokes(shown, layerRule()), // only what's visible (hidden layers aren't exported)
            paint: (c, w, h, setT) => paintDoc(shown, c, w, h, setT, body, null, layerRule()),
            background: getComputedStyle(body).getPropertyValue('--board-bg').trim() || '#FFFFFF',
            flip: mirroring() ? card.mirrorFlip : null,
          };
        });
      }
      if (act === 'scale') {
        rebase();
        card.fixedScale = !card.fixedScale;
        computeScale();
        redraw();
        App.state.updateCard(card.id, { ref: card.ref, fixedScale: card.fixedScale });
        save();
      }
      if (act === 'background') {
        // what the theme's own canvas colour is, as a starting point for the custom maker
        const probe = card.bg;
        if (probe) body.style.removeProperty('--board-bg');
        const themeColor = getComputedStyle(body).getPropertyValue('--board-bg').trim();
        if (probe) body.style.setProperty('--board-bg', probe);
        App.boardBackground.open(btn, {
          current: card.bg,
          themeColor,
          onInput: (c) => setBackground(c, false),
          onChange: (c) => setBackground(c, true),
          onEyedropper: () => startPicking('background'),
        });
      }
      if (act === 'clear') {
        App.confirmPopover.open(btn, {
          title: 'Clear this drawing?',
          message: 'Everything on this canvas will be erased.',
          confirmLabel: 'Clear',
          onConfirm: () => {
            card.strokes = [];
            rebase(); // start fresh at the current size
            App.state.updateCard(card.id, { ref: card.ref });
            redraw();
            save();
          },
        });
      }
    }

    bar.addEventListener('click', (e) => {
      const btn = e.target.closest('button');
      if (!btn) return;
      const d = btn.dataset;
      if (d.drawMode === 'pick') startPicking('pen');
      else if (d.drawMode === 'shape') {
        // first click: shape tool; clicking it again: choose which shape
        if (tool.mode === 'shape') openShapePanel(btn);
        else tool.mode = 'shape';
      } else if (d.drawMode) tool.mode = d.drawMode;
      const act = d.drawAction;
      if (act === 'undo') undo();
      else if (act === 'color') openColorPanel(btn);
      else if (act === 'pen') openPenPanel(btn);
      else if (act === 'more') openMoreMenu(btn);
      else if (act) runAction(act, btn);
      syncTools();
    });
    notice.addEventListener('click', (e) => {
      if (e.target.closest('[data-draw-action="unmirror"]')) setMirror(null);
    });

    // ----- keep the canvas pixel-sharp at any card size -----
    new ResizeObserver(() => {
      const dpr = window.devicePixelRatio || 1;
      const w = Math.max(1, Math.round(surface.clientWidth * dpr));
      const h = Math.max(1, Math.round(surface.clientHeight * dpr));
      const oldScale = scale;
      computeScale();
      if (canvas.width === w && canvas.height === h && scale === oldScale) return;
      canvas.width = liveCanvas.width = w;
      canvas.height = liveCanvas.height = h;
      redraw();
    }).observe(surface);
    redrawers.set(canvas, redraw);

    // ----- drawing with the pointer -----
    let live = null; // { stroke, lastMid }
    App.canvasSync.setLive(card.id, () => live?.stroke || null); // mirrors show lines as they're drawn

    // pointer position in reference units (undoing canvas scaling, zoom and pan)
    const pointOf = (e) => {
      const r = canvas.getBoundingClientRect();
      const k = zoomer.k();
      return [
        Math.round(((e.clientX - r.left - zoomer.view.x) / k) * 10) / 10,
        Math.round(((e.clientY - r.top - zoomer.view.y) / k) * 10) / 10,
      ];
    };

    function addPoint([x, y]) {
      const { stroke } = live;
      const p = stroke.p;
      const lx = p[p.length - 2];
      const ly = p[p.length - 1];
      if (Math.hypot(x - lx, y - ly) < MIN_STEP / zoomer.k()) return;
      p.push(x, y);
      App.canvasSync.emit(card.id); // mirrors follow along
      if (card.layersOn) return redrawSoon(); // layers: repaint with the line in its own layer
      if (live.stamp) { // brush: stamp just the new piece onto the live layer
        applyTransform(liveCtx);
        App.brushes.drawLiveStep(liveCtx, stroke, live.stamp, colorValue(stroke.c, body));
        return;
      }
      if (!stroke.e) return drawLive(); // pen: redraw the whole line on the live layer
      // eraser: erase just the new piece, from the last midpoint, curving through the previous point
      const mid = [(lx + x) / 2, (ly + y) / 2];
      styleFor(ctx, stroke, body);
      ctx.beginPath();
      ctx.moveTo(live.lastMid[0], live.lastMid[1]);
      ctx.quadraticCurveTo(lx, ly, mid[0], mid[1]);
      ctx.stroke();
      live.lastMid = mid;
    }

    surface.addEventListener('pointerdown', (e) => {
      // middle-drag, Hand tool, Space+drag (or anything on a mirror): move around inside the canvas
      if (e.button === 1 || (e.button === 0 && (mirroring() || tool.mode === 'hand' || zoomer.spaceHeld()))) {
        zoomer.startPan(e);
        return;
      }
      if (e.button !== 0) return; // right-drag still moves the whole page
      // eyedropper (or Alt + click with the pen)
      if (tool.mode === 'pick' || e.altKey) {
        e.preventDefault();
        e.stopPropagation();
        if (tool.mode !== 'pick') tool.pickFor = 'pen';
        pickAt(e);
        return;
      }
      if (card.layersOn && !App.drawingLayers.active(card).visible) {
        // can't draw on a hidden layer: point at it in the panel
        e.preventDefault();
        card.layersPanel = true;
        syncTools();
        layersUI.flashActive();
        return;
      }
      e.preventDefault();
      e.stopPropagation();
      surface.focus({ preventScroll: true });
      surface.setPointerCapture(e.pointerId);

      // shapes: drag from one corner to the other
      if (tool.mode === 'shape') {
        const [x, y] = pointOf(e);
        const st = { c: tool.color, s: Math.round((tool.size / zoomer.k()) * 100) / 100, sh: tool.shape, f: tool.fill, p: [x, y, x, y] };
        if (tool.opacity < 1) st.o = tool.opacity;
        if (card.layersOn) st.l = App.drawingLayers.active(card).id;
        live = { stroke: st, shape: true, pointerId: e.pointerId };
        liveCanvas.style.opacity = '';
        return;
      }

      const erasing = tool.mode === 'eraser';
      // sizes are stored in reference units too, so the pen looks the same size on screen
      // at any canvas size or zoom (zoom in to draw finer details)
      const size = (erasing ? tool.size * ERASER_SCALE : tool.size) / zoomer.k();
      const stroke = { c: tool.color, s: Math.round(size * 100) / 100, p: pointOf(e) };
      if (erasing) stroke.e = 1;
      else if (tool.opacity < 1) stroke.o = tool.opacity;
      if (!erasing && tool.brush !== 'pen' && App.brushes.isStamp(tool.brush)) {
        stroke.b = tool.brush;
        stroke.r = Math.floor(Math.random() * 1e9); // its own random pattern, kept forever
      }
      if (card.layersOn) stroke.l = App.drawingLayers.active(card).id;
      live = { stroke, lastMid: stroke.p.slice(), pointerId: e.pointerId };
      if (card.layersOn) {
        redrawSoon();
      } else if (stroke.b) {
        // brush: stamp onto the live layer as you go; its opacity is shown by the whole layer
        live.stamp = App.brushes.begin(stroke);
        liveCtx.setTransform(1, 0, 0, 1, 0, 0);
        liveCtx.clearRect(0, 0, liveCanvas.width, liveCanvas.height);
        liveCanvas.style.opacity = String(stroke.o ?? 1);
        applyTransform(liveCtx);
        App.brushes.drawLiveStep(liveCtx, stroke, live.stamp, colorValue(stroke.c, body));
      } else if (erasing) {
        applyTransform();
        styleFor(ctx, stroke, body);
        dot(ctx, stroke.p[0], stroke.p[1], stroke.s);
      } else {
        drawLive();
      }
      App.canvasSync.emit(card.id);
    });

    // end corner of a shape; Shift makes squares/circles and snaps lines to 15° steps
    function shapeEnd(e) {
      const p = live.stroke.p;
      let [x, y] = pointOf(e);
      if (e.shiftKey) {
        const dx = x - p[0];
        const dy = y - p[1];
        if (live.stroke.sh === 'line' || live.stroke.sh === 'arrow') {
          const step = Math.PI / 12;
          const a = Math.round(Math.atan2(dy, dx) / step) * step;
          const len = Math.hypot(dx, dy);
          x = p[0] + Math.cos(a) * len;
          y = p[1] + Math.sin(a) * len;
        } else {
          const m = Math.max(Math.abs(dx), Math.abs(dy));
          x = p[0] + Math.sign(dx || 1) * m;
          y = p[1] + Math.sign(dy || 1) * m;
        }
      }
      p[2] = Math.round(x * 10) / 10;
      p[3] = Math.round(y * 10) / 10;
      App.canvasSync.emit(card.id);
      if (card.layersOn) redrawSoon();
      else drawLive();
    }

    surface.addEventListener('pointermove', (e) => {
      if (!live || e.pointerId !== live.pointerId) return;
      if (live.shape) { shapeEnd(e); return; }
      (e.getCoalescedEvents?.() || [e]).forEach((ev) => addPoint(pointOf(ev)));
    });

    const finish = (e) => {
      if (!live || e.pointerId !== live.pointerId) return;
      const { stroke } = live;
      const p = stroke.p;
      // a click without dragging doesn't make a shape
      if (live.shape && Math.hypot(p[2] - p[0], p[3] - p[1]) < 3 / zoomer.k()) {
        live = null;
        drawLive();
        redraw();
        return;
      }
      if (card.layersOn) {
        card.strokes.push(stroke);
        live = null;
        redraw();
        save();
        if (!layersUI.panel.hidden) layersUI.render(); // update the line counts
        return;
      }
      if (stroke.e) {
        if (p.length > 2) { // finish the tail of the eraser line
          styleFor(ctx, stroke, body);
          ctx.beginPath();
          ctx.moveTo(live.lastMid[0], live.lastMid[1]);
          ctx.lineTo(p[p.length - 2], p[p.length - 1]);
          ctx.stroke();
        }
      } else {
        // move the finished line from the live layer onto the drawing
        applyTransform();
        drawStroke(ctx, stroke, body);
      }
      card.strokes.push(stroke);
      live = null;
      drawLive(); // clears the live layer
      App.canvasSync.emit(card.id);
      save();
    };
    surface.addEventListener('pointerup', finish);
    surface.addEventListener('pointercancel', finish);

    surface.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        undo();
      }
      // tool shortcuts: B draw, E eraser, U shapes, H move, I eyedropper, [ ] size
      if (!e.ctrlKey && !e.metaKey && !e.altKey && !mirroring()) {
        const k = e.key.toLowerCase();
        const modes = { b: 'pen', p: 'pen', e: 'eraser', u: 'shape', h: 'hand' };
        if (modes[k]) { tool.mode = modes[k]; syncTools(); }
        if (k === 'i') startPicking('pen');
        if (e.key === '[' || e.key === ']') {
          tool.size = Math.max(SIZE.min, Math.min(SIZE.max, tool.size + (e.key === ']' ? 1 : -1) * (tool.size >= 10 ? 2 : 1)));
          syncTools();
        }
      }
      if (e.key === 'Escape' && tool.mode === 'pick') {
        tool.mode = tool.before === 'pick' ? 'pen' : tool.before;
        tool.pickFor = 'pen';
        pickBubble.hidden = true;
        syncTools();
      }
    });

    applyBackground();
    syncTools();
  }

  // redraw every canvas when the theme flips (ink/chalk colours change)
  // an imported brush was tweaked or finished loading: redraw lines that use it
  window.addEventListener('brushchange', () => {
    redrawers.forEach((redraw, canvas) => {
      if (canvas.isConnected) redraw();
      else redrawers.delete(canvas);
    });
  });

  window.addEventListener('themechange', () => {
    redrawers.forEach((redraw, canvas) => {
      if (canvas.isConnected) redraw();
      else redrawers.delete(canvas);
    });
  });

  return {
    label: 'Canvas',
    resizable: 'both',
    minWidth: 240,
    maxWidth: 2000,
    minHeight: 200,
    maxHeight: 1600,
    defaults: () => ({ strokes: [], width: 680, height: 460, bg: null }),
    render,
    thumbnail,
    nameOf,
  };
})();
