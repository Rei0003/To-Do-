// todo.js — a checklist card with a title, tasks, priorities and a progress bar
window.App = window.App || {};

App.cardTypes.todo = {
  label: 'To-do list',
  accepts: ['media'],  // drag image/video cards into a list
  resizable: true,
  minWidth: 220,
  maxWidth: 900,
  defaults: () => ({ title: '', titleHtml: '', items: [] }),

  render(card, body) {
    const save = () => App.state.updateCard(card.id, { items: card.items });

    const addInput = document.createElement('input');
    addInput.className = 'todo-add';
    addInput.placeholder = 'Add a task, press Enter';

    const title = App.richText.create({
      className: 'todo-title',
      placeholder: 'List title',
      multiline: false,
      html: card.titleHtml ?? App.richText.fromText(card.title),
      onChange: (titleHtml, text) => App.state.updateCard(card.id, { titleHtml, title: text }),
      onEnter: () => addInput.focus(),
    });

    const progress = document.createElement('div');
    progress.className = 'todo-progress';
    progress.innerHTML = '<span></span>';

    const list = document.createElement('ul');
    list.className = 'todo-list';

    function refreshProgress() {
      const total = card.items.length;
      const done = card.items.filter((i) => i.done).length;
      progress.hidden = total === 0;
      progress.firstChild.style.width = total ? `${(done / total) * 100}%` : '0';
    }

    function itemRow(item) {
      const li = document.createElement('li');
      li.className = 'todo-item';
      li.classList.toggle('is-done', item.done);

      const check = document.createElement('input');
      check.type = 'checkbox';
      check.checked = item.done;
      check.setAttribute('aria-label', 'Mark done');
      check.addEventListener('change', () => {
        item.done = check.checked;
        li.classList.toggle('is-done', item.done);
        save();
        refreshProgress();
      });

      const text = App.richText.create({
        className: 'todo-text',
        placeholder: 'Task',
        multiline: false,
        html: item.html ?? App.richText.fromText(item.text),
        onChange: (html, plain) => { item.html = html; item.text = plain; save(); },
        onEnter: () => addInput.focus(),
      });

      const flag = App.priority.createButton(item, save);

      const remove = document.createElement('button');
      remove.className = 'card-btn';
      remove.setAttribute('aria-label', 'Delete task');
      remove.dataset.tooltip = 'Delete task';
      remove.innerHTML = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>';
      remove.addEventListener('click', () => {
        card.items = card.items.filter((i) => i.id !== item.id);
        li.remove();
        save();
        refreshProgress();
      });

      li.append(check, text, flag, remove);
      return li;
    }

    addInput.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter') return;
      const value = addInput.value.trim();
      if (!value) return;
      const item = { id: App.state.uid(), text: value, html: App.richText.fromText(value), done: false };
      card.items.push(item);
      list.append(itemRow(item));
      addInput.value = '';
      save();
      refreshProgress();
    });

    const attachments = document.createElement('div');
    attachments.className = 'attachments';
    App.nesting.renderAttachments(card, attachments);

    card.items.forEach((item) => list.append(itemRow(item)));
    refreshProgress();
    body.append(title, progress, list, addInput, attachments);
  },

  focus(el) {
    el.querySelector('.todo-title')?.focus();
  },
};
