// todo.js — a checklist card with a title, tasks and a progress bar
window.App = window.App || {};

App.cardTypes.todo = {
  label: 'To-do list',
  defaults: () => ({ title: '', items: [] }),

  render(card, body) {
    const save = () => App.state.updateCard(card.id, { items: card.items });

    const title = document.createElement('input');
    title.className = 'todo-title';
    title.placeholder = 'List title';
    title.value = card.title;
    title.addEventListener('input', () => App.state.updateCard(card.id, { title: title.value }));

    const progress = document.createElement('div');
    progress.className = 'todo-progress';
    progress.innerHTML = '<span></span>';

    const list = document.createElement('ul');
    list.className = 'todo-list';

    const addInput = document.createElement('input');
    addInput.className = 'todo-add';
    addInput.placeholder = 'Add a task, press Enter';

    function refreshProgress() {
      const total = card.items.length;
      const done = card.items.filter((i) => i.done).length;
      progress.hidden = total === 0;
      progress.firstChild.style.width = total ? `${(done / total) * 100}%` : '0';
    }

    function itemRow(item) {
      const li = document.createElement('li');
      li.className = 'todo-item';
      li.classList.toggle('is-done', item.done);

      const check = document.createElement('input');
      check.type = 'checkbox';
      check.checked = item.done;
      check.setAttribute('aria-label', 'Mark done');
      check.addEventListener('change', () => {
        item.done = check.checked;
        li.classList.toggle('is-done', item.done);
        save();
        refreshProgress();
      });

      const text = document.createElement('span');
      text.className = 'todo-text';
      text.contentEditable = 'true';
      text.textContent = item.text;
      text.addEventListener('input', () => { item.text = text.innerText; save(); });
      text.addEventListener('paste', App.pastePlainText);
      text.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); addInput.focus(); }
      });

      const remove = document.createElement('button');
      remove.className = 'card-btn';
      remove.setAttribute('aria-label', 'Delete task');
      remove.innerHTML = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>';
      remove.addEventListener('click', () => {
        card.items = card.items.filter((i) => i.id !== item.id);
        li.remove();
        save();
        refreshProgress();
      });

      const flag = App.priority.createButton(item, save);

      li.append(check, text, flag, remove);
      return li;
    }

    addInput.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter') return;
      const value = addInput.value.trim();
      if (!value) return;
      const item = { id: App.state.uid(), text: value, done: false };
      card.items.push(item);
      list.append(itemRow(item));
      addInput.value = '';
      save();
      refreshProgress();
    });

    card.items.forEach((item) => list.append(itemRow(item)));
    refreshProgress();
    body.append(title, progress, list, addInput);
  },

  focus(el) {
    el.querySelector('.todo-title')?.focus();
  },
};
