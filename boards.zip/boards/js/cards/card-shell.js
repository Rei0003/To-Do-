// card-shell.js — the frame every card shares: drag bar, colour picker, delete.
// Each card type (note.js, todo.js…) only fills in the body.
window.App = window.App || {};

App.cardTypes = {};
App.COLORS = ['none', 'yellow', 'pink', 'blue', 'green', 'purple'];
App.colorName = (c) => (c === 'none' ? 'No colour' : c[0].toUpperCase() + c.slice(1));

App.createCardShell = (card) => {
  const el = document.createElement('article');
  el.className = `card card--${card.type}`;
  el.dataset.id = card.id;
  el.dataset.type = card.type;
  el.dataset.color = card.color || 'none';
  el.style.left = `${card.x}px`;
  el.style.top = `${card.y}px`;
  el.style.zIndex = card.z;
  if (card.width) el.style.width = `${card.width}px`;

  el.innerHTML = `
    <div class="card-bar" data-drag-handle>
      <span class="card-grip" aria-hidden="true"></span>
      <div class="card-actions">
        <button class="card-btn" data-action="color" aria-label="Change colour" data-tooltip="Colour">
          <span class="swatch-dot"></span>
        </button>
        <button class="card-btn" data-action="delete" aria-label="Delete card" data-tooltip="Delete card">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>
        </button>
      </div>
    </div>
    <div class="card-palette" hidden></div>
    <div class="card-body"></div>
  `;

  const palette = el.querySelector('.card-palette');
  App.COLORS.forEach((color) => {
    const swatch = document.createElement('button');
    swatch.className = 'palette-swatch';
    swatch.dataset.color = color;
    swatch.setAttribute('aria-label', App.colorName(color));
    swatch.dataset.tooltip = App.colorName(color);
    swatch.style.background = color === 'none' ? 'var(--surface)' : `var(--c-${color})`;
    palette.append(swatch);
  });

  const colorBtn = el.querySelector('[data-action="color"]');
  const markSelected = () => {
    palette.querySelectorAll('.palette-swatch').forEach((s) =>
      s.setAttribute('aria-pressed', String(s.dataset.color === el.dataset.color)));
    colorBtn.dataset.tooltip = `Colour: ${App.colorName(el.dataset.color)}`;
  };
  markSelected();

  el.addEventListener('click', (e) => {
    const action = e.target.closest('[data-action]')?.dataset.action;
    if (action === 'delete') {
      App.nesting.removeChildrenOf(card.id);
      App.cardTypes[card.type]?.onRemove?.(card);
      App.state.removeCard(card.id);
    }
    if (action === 'color') palette.hidden = !palette.hidden;

    const swatch = e.target.closest('.palette-swatch');
    if (swatch) {
      el.dataset.color = swatch.dataset.color;
      App.state.updateCard(card.id, { color: swatch.dataset.color });
      markSelected();
      palette.hidden = true;
    }
  });

  if (App.cardTypes[card.type]?.resizable) App.resize.addHandle(el);
  App.wires.addPorts(el);

  return { el, body: el.querySelector('.card-body') };
};

