// card-shell.js — the frame every card shares: drag bar, colour picker, delete.
// Each card type (note.js, todo.js…) only fills in the body.
window.App = window.App || {};

App.cardTypes = {};
App.COLORS = ['none', 'yellow', 'pink', 'blue', 'green', 'purple'];
App.colorName = (c) => {
  if (!c || c === 'none') return 'No colour';
  if (c.startsWith('#')) return `Custom ${c}`;
  return c[0].toUpperCase() + c.slice(1);
};
// CSS for a card/wire colour value: a preset name or a custom '#RRGGBB(AA)'
App.colorCss = (c) => (c?.startsWith('#') ? c : `var(--c-${c})`);

// preset swatches for card + wire colour rows
App.presetSwatches = (noneCss) => App.COLORS.map((c) => ({
  value: c,
  label: App.colorName(c),
  css: c === 'none' ? noneCss : `var(--c-${c})`,
}));

// show a card's accent colour (top edge + dot)
App.applyCardColor = (el, color) => {
  const custom = color?.startsWith('#');
  el.dataset.color = custom ? 'custom' : (color || 'none');
  if (custom) el.style.setProperty('--swatch', color);
  else el.style.removeProperty('--swatch');
};

App.createCardShell = (card) => {
  const el = document.createElement('article');
  el.className = `card card--${card.type}`;
  el.dataset.id = card.id;
  el.dataset.type = card.type;
  el.style.left = `${card.x}px`;
  el.style.top = `${card.y}px`;
  el.style.zIndex = card.z;
  if (card.width) el.style.width = `${card.width}px`;
  if (card.height && App.cardTypes[card.type]?.resizable === 'both') el.style.height = `${card.height}px`;

  el.innerHTML = `
    <div class="card-bar" data-drag-handle>
      <span class="card-grip" aria-hidden="true"></span>
      <div class="card-actions">
        <button class="card-btn" data-action="color" aria-label="Change colour" data-tooltip="Colour">
          <span class="swatch-dot"></span>
        </button>
        <button class="card-btn" data-action="duplicate" aria-label="Duplicate card" data-tooltip="Duplicate">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"><rect x="5" y="5" width="8.5" height="8.5" rx="1.5"/><path d="M11 5V3.5A1.5 1.5 0 0 0 9.5 2h-6A1.5 1.5 0 0 0 2 3.5v6A1.5 1.5 0 0 0 3.5 11H5"/></svg>
        </button>
        <button class="card-btn" data-action="delete" aria-label="Delete card" data-tooltip="Delete card">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>
        </button>
      </div>
    </div>
    <div class="card-palette" hidden></div>
    <div class="card-body"></div>
  `;

  const colorBtn = el.querySelector('[data-action="color"]');
  const showColor = (color) => {
    App.applyCardColor(el, color);
    colorBtn.dataset.tooltip = `Colour: ${App.colorName(color || 'none')}`;
  };
  showColor(card.color);

  // colour row: presets, saved custom colours and "+" (see palette.js)
  const palette = el.querySelector('.card-palette');
  const colorRow = App.palette.create({
    presets: App.presetSwatches('var(--surface)'),
    value: card.color || 'none',
    visible: 6,
    size: 18,
    onPick: (color) => {
      showColor(color);
      App.state.updateCard(card.id, { color });
      palette.hidden = true;
    },
  });
  palette.append(colorRow.el);

  el.addEventListener('click', (e) => {
    const action = e.target.closest('[data-action]')?.dataset.action;
    if (action === 'delete') {
      if (App.access && !App.access.canDelete(card.id)) return;
      const doDelete = () => {
        App.nesting.removeChildrenOf(card.id);
        App.cardTypes[card.type]?.onRemove?.(card);
        App.state.removeCard(card.id);
      };
      // some cards (e.g. a board card) ask first
      const ask = App.cardTypes[card.type]?.confirmDelete?.(card);
      if (ask) App.confirmPopover.open(e.target.closest('[data-action]'), { ...ask, onConfirm: doDelete });
      else doDelete();
    }
    if (action === 'color') palette.hidden = !palette.hidden;
    if (action === 'duplicate') App.duplicate.cards([card.id]).then((ids) => App.selection.set(ids));
  });

  if (App.cardTypes[card.type]?.resizable) App.resize.addHandle(el);
  App.wires.addPorts(el);

  return { el, body: el.querySelector('.card-body') };
};

