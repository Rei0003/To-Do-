// card-shell.js — the frame every card shares: drag bar, colour picker, delete.
// Each card type (note.js, todo.js…) only fills in the body.
window.App = window.App || {};

App.cardTypes = {};
App.COLORS = ['none', 'yellow', 'pink', 'blue', 'green', 'purple'];

App.createCardShell = (card) => {
  const el = document.createElement('article');
  el.className = `card card--${card.type}`;
  el.dataset.id = card.id;
  el.dataset.color = card.color || 'none';
  el.style.left = `${card.x}px`;
  el.style.top = `${card.y}px`;
  el.style.zIndex = card.z;

  el.innerHTML = `
    <div class="card-bar" data-drag-handle>
      <span class="card-grip" aria-hidden="true"></span>
      <div class="card-actions">
        <button class="card-btn" data-action="color" aria-label="Change colour" title="Colour">
          <span class="swatch-dot"></span>
        </button>
        <button class="card-btn" data-action="delete" aria-label="Delete card" title="Delete">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>
        </button>
      </div>
    </div>
    <div class="card-palette" hidden></div>
    <div class="card-body"></div>
  `;

  const palette = el.querySelector('.card-palette');
  App.COLORS.forEach((color) => {
    const swatch = document.createElement('button');
    swatch.className = 'palette-swatch';
    swatch.dataset.color = color;
    swatch.setAttribute('aria-label', color === 'none' ? 'No colour' : color);
    swatch.style.background = color === 'none' ? 'var(--surface)' : `var(--c-${color})`;
    palette.append(swatch);
  });

  const markSelected = () =>
    palette.querySelectorAll('.palette-swatch').forEach((s) =>
      s.setAttribute('aria-pressed', String(s.dataset.color === el.dataset.color)));
  markSelected();

  el.addEventListener('click', (e) => {
    const action = e.target.closest('[data-action]')?.dataset.action;
    if (action === 'delete') App.state.removeCard(card.id);
    if (action === 'color') palette.hidden = !palette.hidden;

    const swatch = e.target.closest('.palette-swatch');
    if (swatch) {
      el.dataset.color = swatch.dataset.color;
      App.state.updateCard(card.id, { color: swatch.dataset.color });
      markSelected();
      palette.hidden = true;
    }
  });

  return { el, body: el.querySelector('.card-body') };
};

// Shared helper: paste as plain text into contenteditable fields
App.pastePlainText = (e) => {
  e.preventDefault();
  const text = e.clipboardData.getData('text/plain');
  document.execCommand('insertText', false, text);
};
