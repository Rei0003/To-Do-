// note.js — a free-text note card
window.App = window.App || {};

App.cardTypes.note = {
  label: 'Note',
  defaults: () => ({ text: '' }),

  render(card, body) {
    const text = document.createElement('div');
    text.className = 'note-text';
    text.contentEditable = 'true';
    text.dataset.placeholder = 'Write something…';
    text.textContent = card.text;

    text.addEventListener('input', () => {
      // keep :empty placeholder working after the user deletes everything
      if (text.innerText.trim() === '') text.innerHTML = '';
      App.state.updateCard(card.id, { text: text.innerText });
    });
    text.addEventListener('paste', App.pastePlainText);

    body.append(text);
  },

  focus(el) {
    el.querySelector('.note-text')?.focus();
  },
};
