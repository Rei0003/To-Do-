// note.js — a free-text note card with formatting
window.App = window.App || {};

App.cardTypes.note = {
  label: 'Note',
  defaults: () => ({ text: '', html: '' }),

  render(card, body) {
    const editor = App.richText.create({
      className: 'note-text',
      placeholder: 'Write something…',
      html: card.html ?? App.richText.fromText(card.text),
      onChange: (html, text) => App.state.updateCard(card.id, { html, text }),
    });
    body.append(editor);
  },

  focus(el) {
    el.querySelector('.note-text')?.focus();
  },
};
