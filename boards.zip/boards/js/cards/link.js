// link.js — a card for a web link, with a preview: the page's picture, title, description,
// the site's icon and its address. Click it to open the link in a new tab.
// The preview is fetched by the server (api/link-preview.php) and kept on the card, so everyone
// who opens the board sees it straight away. Without the server you get a simpler preview.
// Data: card.url, card.preview = { title, description, image, icon, site, site_name, fetched_at }
window.App = window.App || {};

App.cardTypes.link = (() => {
  // "example.com/page" -> "https://example.com/page"; anything that isn't a web address -> null
  function normalize(text) {
    let t = String(text || '').trim();
    if (!t || /\s/.test(t)) return null;
    if (!/^[a-z][a-z0-9+.-]*:/i.test(t)) t = `https://${t}`;
    try {
      const u = new URL(t);
      if (!/^https?:$/.test(u.protocol) || !u.hostname.includes('.')) return null;
      return u.href;
    } catch { return null; }
  }
  const siteOf = (url) => { try { return new URL(url).hostname.replace(/^www\./, ''); } catch { return url; } };

  async function fetchPreview(url, refresh) {
    if (App.session.mode !== 'server') return { site: siteOf(url), offline: true };
    return App.api.request('GET', `link-preview.php?url=${encodeURIComponent(url)}${refresh ? '&refresh=1' : ''}`);
  }

  function render(card, body) {
    body.replaceChildren();
    if (!card.url) return renderEmpty(card, body);
    const p = card.preview || { site: siteOf(card.url) };
    const wrap = document.createElement('div');
    wrap.className = 'lk';
    wrap.innerHTML = `
      <a class="lk-open" target="_blank" rel="noopener noreferrer">
        <span class="lk-image" hidden><img alt="" referrerpolicy="no-referrer"></span>
        <span class="lk-body">
          <span class="lk-site"><img class="lk-icon" alt="" referrerpolicy="no-referrer"><span class="lk-site-name"></span></span>
          <span class="lk-title"></span>
          <span class="lk-desc"></span>
        </span>
      </a>
      <div class="lk-tools">
        <button class="card-btn" data-lk="edit" aria-label="Change the link" data-tooltip="Change the link">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10.5 2.5l3 3L6 13H3v-3z"/></svg></button>
        <button class="card-btn" data-lk="refresh" aria-label="Refresh the preview" data-tooltip="Refresh the preview">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M13 8a5 5 0 1 1-1.5-3.5M13 2.5v3h-3"/></svg></button>
      </div>`;
    const a = wrap.querySelector('.lk-open');
    a.href = card.url;
    a.dataset.tooltip = card.url;
    const site = p.site_name && p.site_name.toLowerCase() !== (p.site || '').toLowerCase() ? `${p.site_name} · ${p.site}` : (p.site || siteOf(card.url));
    wrap.querySelector('.lk-site-name').textContent = site;
    wrap.querySelector('.lk-title').textContent = p.title || card.url;
    const desc = wrap.querySelector('.lk-desc');
    desc.textContent = p.description || (p.offline ? 'Open the app through the server to see a full preview.' : '');
    desc.hidden = !desc.textContent;
    const icon = wrap.querySelector('.lk-icon');
    if (p.icon) { icon.src = p.icon; icon.onerror = () => icon.classList.add('is-broken'); } else icon.classList.add('is-broken');
    if (p.image) {
      const box = wrap.querySelector('.lk-image');
      const img = box.querySelector('img');
      img.onload = () => { box.hidden = false; wrap.classList.add('has-image'); };
      img.onerror = () => box.remove();
      img.src = p.image;
    }
    if (p.loading) wrap.classList.add('is-loading');
    body.append(wrap);

    // don't follow the link when the card was just dragged
    a.addEventListener('click', (e) => { if (wrap.closest('.card')?.classList.contains('is-dragging')) e.preventDefault(); });
    wrap.querySelector('.lk-tools').addEventListener('click', async (e) => {
      const act = e.target.closest('[data-lk]')?.dataset.lk;
      if (act === 'edit') renderEmpty(card, body, card.url);
      if (act === 'refresh') load(card, body, true);
    });
    // a link added without a preview yet (e.g. pasted onto the board): get one
    if (!card.preview) load(card, body);
  }

  async function load(card, body, refresh) {
    const url = card.url;
    card.preview = { ...(card.preview || { site: siteOf(url) }), loading: true };
    render(card, body);
    let preview;
    try { preview = await fetchPreview(url, refresh); } catch (err) {
      preview = { site: siteOf(url), error: err.message };
    }
    if (card.url !== url) return; // changed meanwhile
    delete preview.loading;
    card.preview = preview;
    App.state.updateCard(card.id, { preview });
    if (body.isConnected) render(card, body);
  }

  // asking for a link (new card, or "Change the link")
  function renderEmpty(card, body, value = '') {
    body.replaceChildren();
    const box = document.createElement('div');
    box.className = 'lk-empty';
    box.innerHTML = `
      <span class="lk-empty-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M10 14a4.5 4.5 0 0 0 6.4 0l3-3a4.5 4.5 0 0 0-6.4-6.4l-1 1"/><path d="M14 10a4.5 4.5 0 0 0-6.4 0l-3 3a4.5 4.5 0 0 0 6.4 6.4l1-1"/></svg></span>
      <form class="lk-form" novalidate>
        <input type="url" placeholder="Paste a link, e.g. bmw.com" aria-label="Web address" autocomplete="off">
        <button class="confirm-pop-btn btn-primary" type="submit">Add</button>
      </form>
      <p class="media-error" hidden></p>`;
    const input = box.querySelector('input');
    const err = box.querySelector('.media-error');
    input.value = value;
    box.querySelector('form').addEventListener('submit', (e) => {
      e.preventDefault();
      const url = normalize(input.value);
      if (!url) { err.textContent = 'That doesn’t look like a web address.'; err.hidden = false; return; }
      card.url = url;
      card.preview = null;
      App.state.updateCard(card.id, { url, preview: null });
      load(card, body);
    });
    input.addEventListener('keydown', (e) => { if (e.key === 'Escape' && card.url) { e.stopPropagation(); render(card, body); } });
    body.append(box);
    requestAnimationFrame(() => input.focus());
  }

  return {
    label: 'Link',
    resizable: true,
    minWidth: 200,
    maxWidth: 640,
    defaults: () => ({ url: '', preview: null, width: 300 }),
    render,
    focus(el) { el.querySelector('.lk-form input')?.focus(); },
    normalize,
  };
})();
