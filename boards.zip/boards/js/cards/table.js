// table.js — a table card.
//  • start with 3 × 3; the size button lets you pick rows × columns (hover the grid or type numbers)
//  • + buttons add a row (below) or a column (right); the toolbar inserts/deletes rows and columns
//    next to the cell you're in, toggles a header row and colours cells
//  • Tab / Shift+Tab move between cells (Tab in the last cell adds a row), Enter moves down
//  • cells use the normal text formatting bar (bold, colours, sizes…)
//  • pasting from Excel / Google Sheets fills several cells at once
// Data: card.table = { rows, cols, header, cells: [[{ html, text, bg }]] }
window.App = window.App || {};

App.cardTypes.table = (() => {
  const MAX_ROWS = 100;
  const MAX_COLS = 26;
  const GRID = { rows: 8, cols: 10 }; // the hover-to-pick grid in the size box

  const I = (d) => `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
  const ICONS = {
    size: I('<rect x="2" y="2.5" width="12" height="11" rx="1.5"/><path d="M2 6.5h12M2 10h12M6 2.5v11M10 2.5v11"/>'),
    header: I('<rect x="2" y="2.5" width="12" height="11" rx="1.5"/><path d="M2 6.5h12" stroke-width="2.2"/>'),
    rowAbove: I('<rect x="2" y="8" width="12" height="5.5" rx="1"/><path d="M8 1.5v4.5M5.8 3.8H10.2"/>'),
    rowBelow: I('<rect x="2" y="2.5" width="12" height="5.5" rx="1"/><path d="M8 10v4.5M5.8 12.2h4.4"/>'),
    colLeft: I('<rect x="8" y="2" width="5.5" height="12" rx="1"/><path d="M1.5 8H6M3.8 5.8v4.4"/>'),
    colRight: I('<rect x="2.5" y="2" width="5.5" height="12" rx="1"/><path d="M10 8h4.5M12.2 5.8v4.4"/>'),
    delRow: I('<rect x="2" y="5" width="12" height="6" rx="1"/><path d="M6 8h4"/>'),
    delCol: I('<rect x="5" y="2" width="6" height="12" rx="1"/><path d="M8 6v4"/>'),
    fill: I('<path d="M2.5 8.5L8 3l5 5-5.5 5.5z"/><path d="M5 1.5L8 3"/><path d="M13.5 10.5s1.2 1.5 1.2 2.3a1.2 1.2 0 0 1-2.4 0c0-.8 1.2-2.3 1.2-2.3z" fill="currentColor"/>'),
    plus: I('<path d="M8 3v10M3 8h10" stroke-width="1.6"/>'),
  };

  const blank = () => ({ html: '', text: '' });
  const isEmpty = (cell) => !cell?.text?.trim();

  // make sure the stored table has every row and cell it should
  function normalize(card) {
    const t = card.table || (card.table = { rows: 3, cols: 3, header: true, cells: [] });
    t.rows = Math.max(1, Math.min(MAX_ROWS, t.rows || 1));
    t.cols = Math.max(1, Math.min(MAX_COLS, t.cols || 1));
    t.cells = t.cells || [];
    for (let r = 0; r < t.rows; r++) {
      t.cells[r] = t.cells[r] || [];
      for (let c = 0; c < t.cols; c++) t.cells[r][c] = t.cells[r][c] || blank();
      t.cells[r].length = t.cols;
    }
    t.cells.length = t.rows;
    return t;
  }

  // ---------- small popovers (size picker, cell colour) ----------
  let pop = null;
  let popAnchor = null;
  function closePop() {
    pop?.remove();
    pop = null;
    popAnchor = null;
    document.removeEventListener('pointerdown', onOutside, true);
    document.removeEventListener('keydown', onPopKey, true);
  }
  function onOutside(e) {
    if (pop && !pop.contains(e.target) && !popAnchor?.contains(e.target) && !e.target.closest('.color-pop, .confirm-pop')) closePop();
  }
  function onPopKey(e) { if (e.key === 'Escape') { e.stopPropagation(); closePop(); } }
  function openPop(anchor, el) {
    if (popAnchor === anchor) { closePop(); return false; }
    closePop();
    App.tooltip?.hide();
    pop = el;
    popAnchor = anchor;
    document.body.append(pop);
    const r = anchor.getBoundingClientRect();
    const w = pop.offsetWidth;
    const h = pop.offsetHeight;
    let top = r.bottom + 6;
    if (top + h > window.innerHeight - 8) top = r.top - h - 6;
    pop.style.top = `${Math.min(Math.max(8, top), window.innerHeight - h - 8)}px`;
    pop.style.left = `${Math.min(Math.max(8, r.left), window.innerWidth - w - 8)}px`;
    document.addEventListener('pointerdown', onOutside, true);
    document.addEventListener('keydown', onPopKey, true);
    return true;
  }

  // ---------- card ----------
  function render(card, body) {
    const t = normalize(card);
    let active = { r: 0, c: 0 }; // the cell you're in (toolbar buttons act on it)

    const root = document.createElement('div');
    root.className = 'tbl';
    root.innerHTML = `
      <div class="tbl-tools">
        <button class="tbl-size" data-tbl="size" aria-haspopup="dialog" data-tooltip="Table size (rows × columns)">${ICONS.size}<span></span></button>
        <button class="draw-btn" data-tbl="header" aria-label="Header row" data-tooltip="Header row">${ICONS.header}</button>
        <span class="tbl-sep"></span>
        <button class="draw-btn" data-tbl="row-above" aria-label="Insert row above" data-tooltip="Insert row above">${ICONS.rowAbove}</button>
        <button class="draw-btn" data-tbl="row-below" aria-label="Insert row below" data-tooltip="Insert row below">${ICONS.rowBelow}</button>
        <button class="draw-btn" data-tbl="col-left" aria-label="Insert column left" data-tooltip="Insert column left">${ICONS.colLeft}</button>
        <button class="draw-btn" data-tbl="col-right" aria-label="Insert column right" data-tooltip="Insert column right">${ICONS.colRight}</button>
        <span class="tbl-sep"></span>
        <button class="draw-btn" data-tbl="del-row" aria-label="Delete row" data-tooltip="Delete this row">${ICONS.delRow}</button>
        <button class="draw-btn" data-tbl="del-col" aria-label="Delete column" data-tooltip="Delete this column">${ICONS.delCol}</button>
        <span class="tbl-sep"></span>
        <button class="draw-btn" data-tbl="fill" aria-label="Cell colour" aria-haspopup="dialog" data-tooltip="Cell colour">${ICONS.fill}</button>
      </div>
      <div class="tbl-area">
        <div class="tbl-scroll"><table class="tbl-table"><tbody></tbody></table></div>
        <button class="tbl-add tbl-add-col" data-tbl="add-col" aria-label="Add column" data-tooltip="Add a column">${ICONS.plus}</button>
      </div>
      <button class="tbl-add tbl-add-row" data-tbl="add-row" aria-label="Add row" data-tooltip="Add a row">${ICONS.plus}</button>`;
    body.append(root);

    const tbody = root.querySelector('tbody');
    const sizeLabel = root.querySelector('.tbl-size span');
    const save = () => App.state.updateCard(card.id, { table: t });

    // ----- drawing the table -----
    function draw() {
      sizeLabel.textContent = `${t.rows} × ${t.cols}`;
      root.querySelector('[data-tbl="header"]').setAttribute('aria-pressed', String(!!t.header));
      root.querySelector('[data-tbl="del-row"]').disabled = t.rows <= 1;
      root.querySelector('[data-tbl="del-col"]').disabled = t.cols <= 1;
      root.querySelector('[data-tbl="add-row"]').disabled = t.rows >= MAX_ROWS;
      root.querySelector('[data-tbl="add-col"]').disabled = t.cols >= MAX_COLS;

      tbody.replaceChildren(...t.cells.map((row, r) => {
        const tr = document.createElement('tr');
        tr.classList.toggle('is-header', !!t.header && r === 0);
        row.forEach((cell, c) => {
          const td = document.createElement('td');
          td.dataset.r = r;
          td.dataset.c = c;
          if (cell.bg) td.style.setProperty('--cell', App.colorCss(cell.bg));
          td.classList.toggle('has-bg', !!cell.bg);
          const editor = App.richText.create({
            className: 'tbl-text',
            placeholder: '',
            multiline: false,
            html: cell.html ?? App.richText.fromText(cell.text),
            onChange: (html, text) => { cell.html = html; cell.text = text; save(); },
            onEnter: () => go(r + 1, c, true), // Enter moves down
          });
          td.append(editor);
          tr.append(td);
        });
        return tr;
      }));
      markActive();
    }

    function markActive() {
      tbody.querySelectorAll('td.is-active').forEach((td) => td.classList.remove('is-active'));
      tbody.querySelector(`td[data-r="${active.r}"][data-c="${active.c}"]`)?.classList.add('is-active');
    }

    // put the caret at the end of a cell
    function focusCell(r, c) {
      const editor = tbody.querySelector(`td[data-r="${r}"][data-c="${c}"] .tbl-text`);
      if (!editor) return;
      editor.focus({ preventScroll: false });
      const range = document.createRange();
      range.selectNodeContents(editor);
      range.collapse(false);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
    }

    // move to a cell; past the last row, optionally add one
    function go(r, c, grow) {
      if (r >= t.rows) {
        if (!grow || t.rows >= MAX_ROWS) return;
        insertRow(t.rows);
      }
      if (r < 0 || c < 0 || c >= t.cols) return;
      active = { r, c };
      focusCell(r, c);
    }

    // ----- structure changes -----
    function insertRow(at) {
      if (t.rows >= MAX_ROWS) return;
      t.cells.splice(at, 0, Array.from({ length: t.cols }, blank));
      t.rows++;
      save();
      draw();
    }
    function insertCol(at) {
      if (t.cols >= MAX_COLS) return;
      t.cells.forEach((row) => row.splice(at, 0, blank()));
      t.cols++;
      save();
      draw();
    }
    function deleteRow(at, button) {
      if (t.rows <= 1) return;
      const doIt = () => {
        t.cells.splice(at, 1);
        t.rows--;
        active.r = Math.min(active.r, t.rows - 1);
        save();
        draw();
        focusCell(active.r, active.c);
      };
      if (t.cells[at].every(isEmpty)) return doIt();
      App.confirmPopover.open(button, { title: 'Delete this row?', message: 'Its contents will be removed.', confirmLabel: 'Delete row', onConfirm: doIt });
    }
    function deleteCol(at, button) {
      if (t.cols <= 1) return;
      const doIt = () => {
        t.cells.forEach((row) => row.splice(at, 1));
        t.cols--;
        active.c = Math.min(active.c, t.cols - 1);
        save();
        draw();
        focusCell(active.r, active.c);
      };
      if (t.cells.every((row) => isEmpty(row[at]))) return doIt();
      App.confirmPopover.open(button, { title: 'Delete this column?', message: 'Its contents will be removed.', confirmLabel: 'Delete column', onConfirm: doIt });
    }

    // set the size; asks first if that would throw away text
    function resize(rows, cols, button) {
      rows = Math.max(1, Math.min(MAX_ROWS, rows));
      cols = Math.max(1, Math.min(MAX_COLS, cols));
      const losing = t.cells.some((row, r) => row.some((cell, c) => (r >= rows || c >= cols) && !isEmpty(cell)));
      const doIt = () => {
        t.rows = rows;
        t.cols = cols;
        normalize(card);
        active = { r: Math.min(active.r, rows - 1), c: Math.min(active.c, cols - 1) };
        save();
        draw();
      };
      if (!losing) return doIt();
      App.confirmPopover.open(button, {
        title: `Make it ${rows} × ${cols}?`,
        message: 'Some cells with text will be removed.',
        confirmLabel: 'Resize',
        onConfirm: doIt,
      });
    }

    // ----- size picker -----
    function openSize(button) {
      const el = document.createElement('div');
      el.className = 'tbl-pop';
      el.setAttribute('role', 'dialog');
      el.setAttribute('aria-label', 'Table size');
      el.innerHTML = `
        <p class="tbl-pop-title">Table size <span class="tbl-pop-hint">${t.rows} × ${t.cols}</span></p>
        <div class="tbl-grid" style="--cols:${GRID.cols}"></div>
        <div class="tbl-pop-fields">
          <label>Rows <input type="number" min="1" max="${MAX_ROWS}" value="${t.rows}" data-f="rows"></label>
          <span>×</span>
          <label>Columns <input type="number" min="1" max="${MAX_COLS}" value="${t.cols}" data-f="cols"></label>
          <button class="confirm-pop-btn btn-primary" data-f="apply">Apply</button>
        </div>`;
      const grid = el.querySelector('.tbl-grid');
      const hint = el.querySelector('.tbl-pop-hint');
      for (let r = 1; r <= GRID.rows; r++) {
        for (let c = 1; c <= GRID.cols; c++) {
          const b = document.createElement('button');
          b.className = 'tbl-grid-cell';
          b.dataset.r = r;
          b.dataset.c = c;
          b.setAttribute('aria-label', `${r} rows × ${c} columns`);
          grid.append(b);
        }
      }
      const showPick = (rows, cols) => {
        hint.textContent = `${rows} × ${cols}`;
        grid.querySelectorAll('.tbl-grid-cell').forEach((b) =>
          b.classList.toggle('is-on', +b.dataset.r <= rows && +b.dataset.c <= cols));
      };
      showPick(t.rows, t.cols);
      grid.addEventListener('pointerover', (e) => {
        const b = e.target.closest('.tbl-grid-cell');
        if (b) showPick(+b.dataset.r, +b.dataset.c);
      });
      grid.addEventListener('pointerleave', () => showPick(t.rows, t.cols));
      grid.addEventListener('click', (e) => {
        const b = e.target.closest('.tbl-grid-cell');
        if (!b) return;
        closePop();
        resize(+b.dataset.r, +b.dataset.c, button);
      });
      const apply = () => {
        const rows = +el.querySelector('[data-f="rows"]').value || t.rows;
        const cols = +el.querySelector('[data-f="cols"]').value || t.cols;
        closePop();
        resize(rows, cols, button);
      };
      el.querySelector('[data-f="apply"]').addEventListener('click', apply);
      el.querySelectorAll('input').forEach((i) => i.addEventListener('keydown', (e) => { if (e.key === 'Enter') apply(); }));
      openPop(button, el);
    }

    // ----- cell colour -----
    function openFill(button) {
      const cell = t.cells[active.r]?.[active.c];
      if (!cell) return;
      const el = document.createElement('div');
      el.className = 'tbl-pop tbl-fill';
      el.innerHTML = '<p class="tbl-pop-title">Cell colour</p>';
      const row = App.palette.create({
        presets: App.presetSwatches('var(--surface)'),
        value: cell.bg || 'none',
        visible: 6,
        size: 18,
        onPick: (c) => {
          if (c === 'none') delete cell.bg;
          else cell.bg = c;
          save();
          draw();
          closePop();
        },
      });
      el.append(row.el);
      openPop(button, el);
    }

    // ----- events -----
    root.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-tbl]');
      if (!btn) return;
      const a = btn.dataset.tbl;
      if (a === 'size') openSize(btn);
      if (a === 'header') { t.header = !t.header; save(); draw(); }
      if (a === 'row-above') { insertRow(active.r); go(active.r, active.c); }
      if (a === 'row-below') { insertRow(active.r + 1); go(active.r + 1, active.c); }
      if (a === 'col-left') { insertCol(active.c); go(active.r, active.c); }
      if (a === 'col-right') { insertCol(active.c + 1); go(active.r, active.c + 1); }
      if (a === 'del-row') deleteRow(active.r, btn);
      if (a === 'del-col') deleteCol(active.c, btn);
      if (a === 'fill') openFill(btn);
      if (a === 'add-row') { insertRow(t.rows); go(t.rows - 1, 0); }
      if (a === 'add-col') { insertCol(t.cols); go(0, t.cols - 1); }
    });

    // remember which cell you're in
    tbody.addEventListener('focusin', (e) => {
      const td = e.target.closest('td');
      if (!td) return;
      active = { r: +td.dataset.r, c: +td.dataset.c };
      markActive();
    });

    // Tab / Shift+Tab between cells
    tbody.addEventListener('keydown', (e) => {
      if (e.key !== 'Tab') return;
      e.preventDefault();
      let { r, c } = active;
      if (e.shiftKey) {
        c--;
        if (c < 0) { c = t.cols - 1; r--; }
        if (r >= 0) go(r, c);
      } else {
        c++;
        if (c >= t.cols) { c = 0; r++; }
        go(r, c, true); // Tab in the last cell adds a row
      }
    });

    // pasting several cells (from a spreadsheet) fills the table from the current cell
    tbody.addEventListener('paste', (e) => {
      const text = e.clipboardData?.getData('text/plain') || '';
      if (!/[\t\n]/.test(text.trim())) return; // a single value: normal paste
      e.preventDefault();
      e.stopPropagation();
      const rows = text.replace(/\r/g, '').replace(/\n$/, '').split('\n').map((line) => line.split('\t'));
      const needRows = Math.min(MAX_ROWS, active.r + rows.length);
      const needCols = Math.min(MAX_COLS, active.c + Math.max(...rows.map((r) => r.length)));
      t.rows = Math.max(t.rows, needRows);
      t.cols = Math.max(t.cols, needCols);
      normalize(card);
      rows.forEach((vals, i) => vals.forEach((v, j) => {
        const cell = t.cells[active.r + i]?.[active.c + j];
        if (!cell) return;
        cell.text = v.trim();
        cell.html = App.richText.fromText(cell.text);
      }));
      save();
      draw();
      focusCell(active.r, active.c);
    }, true);

    draw();
  }

  return {
    label: 'Table',
    resizable: true, // width
    minWidth: 220,
    maxWidth: 1600,
    defaults: () => ({ width: 420, table: { rows: 3, cols: 3, header: true, cells: [] } }),
    render,
    focus(el) { el.querySelector('.tbl-text')?.focus(); },
  };
})();
