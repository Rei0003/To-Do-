// selection.js — select several cards at once, then move, duplicate or delete them together.
//  • Shift- or Ctrl/⌘-click a card to add it to (or remove it from) the selection
//  • Drag on an empty part of the board to draw a selection box (hold Shift to add)
//  • Drag any selected card's top bar to move them all
//  • Delete/Backspace, Ctrl/⌘+D (duplicate), Ctrl/⌘+A (select all), Esc (deselect)
// A small bar at the top shows how many are selected, with Duplicate / Delete buttons.
window.App = window.App || {};

App.selection = (() => {
  const selected = new Set();
  let canvas;
  let bar;
  let box = null; // the selection rectangle while dragging

  const cardEl = (id) => canvas.querySelector(`:scope > .card[data-id="${id}"]`);
  const isTyping = (t) => !!t.closest?.('input, textarea, [contenteditable="true"]');

  // ---------- state ----------
  function paint() {
    canvas.querySelectorAll(':scope > .card').forEach((el) => {
      el.classList.toggle('is-selected', selected.has(el.dataset.id));
    });
    const n = selected.size;
    bar.hidden = n === 0;
    bar.querySelector('.sel-count').textContent = `${n} selected`;
  }

  function set(ids) {
    selected.clear();
    ids.forEach((id) => selected.add(id));
    paint();
  }
  const clear = () => { if (selected.size) set([]); };
  function toggle(id) {
    if (selected.has(id)) selected.delete(id);
    else selected.add(id);
    paint();
  }

  // keep the selection tidy when cards disappear or get nested
  function prune() {
    let changed = false;
    selected.forEach((id) => {
      const c = App.state.getCard(id);
      if (!c || c.parent) { selected.delete(id); changed = true; }
    });
    if (changed || selected.size) paint();
  }

  // ---------- actions ----------
  async function duplicateSelected() {
    if (!selected.size) return;
    const ids = await App.duplicate.cards([...selected]);
    set(ids); // the new copies become the selection
  }

  function deleteSelected(anchor) {
    const ids = [...selected].filter((id) => !App.access || App.access.canDelete(id));
    if (!ids.length) return;
    const doDelete = () => {
      ids.forEach((id) => {
        const card = App.state.getCard(id);
        if (!card) return;
        App.nesting.removeChildrenOf(id);
        App.cardTypes[card.type]?.onRemove?.(card);
        App.state.removeCard(id);
      });
      clear();
    };
    if (ids.length === 1) return doDelete();
    App.confirmPopover.open(anchor || bar.querySelector('[data-sel="delete"]'), {
      title: `Delete ${ids.length} cards?`,
      message: 'Everything inside them is deleted too.',
      confirmLabel: 'Delete',
      onConfirm: doDelete,
    });
  }

  function selectAll() {
    set(App.state.get().cards.filter((c) => !c.parent).map((c) => c.id));
  }

  // ---------- selection box ----------
  function startBox(e) {
    const p = App.board.toCanvasPoint(e.clientX, e.clientY);
    box = { x: p.x, y: p.y, add: e.shiftKey || e.ctrlKey || e.metaKey, before: new Set(selected), el: null, id: e.pointerId };
    canvas.setPointerCapture(e.pointerId);
  }

  function moveBox(e) {
    const p = App.board.toCanvasPoint(e.clientX, e.clientY);
    const x = Math.min(p.x, box.x);
    const y = Math.min(p.y, box.y);
    const w = Math.abs(p.x - box.x);
    const h = Math.abs(p.y - box.y);
    if (!box.el) {
      if (w < 4 && h < 4) return; // just a click so far
      box.el = document.createElement('div');
      box.el.className = 'sel-box';
      canvas.append(box.el);
    }
    Object.assign(box.el.style, { left: `${x}px`, top: `${y}px`, width: `${w}px`, height: `${h}px` });

    // every card the box touches
    const hit = [...canvas.querySelectorAll(':scope > .card')].filter((el) =>
      el.offsetLeft < x + w && el.offsetLeft + el.offsetWidth > x
      && el.offsetTop < y + h && el.offsetTop + el.offsetHeight > y).map((el) => el.dataset.id);
    set(box.add ? [...new Set([...box.before, ...hit])] : hit);
  }

  function endBox() {
    if (!box) return;
    if (!box.el && !box.add) clear(); // plain click on empty board: deselect
    box.el?.remove();
    box = null;
  }

  // ---------- setup ----------
  function init() {
    canvas = document.getElementById('canvas');

    bar = document.createElement('div');
    bar.className = 'sel-bar';
    bar.hidden = true;
    bar.innerHTML = `
      <span class="sel-count"></span>
      <button class="sel-btn" data-sel="duplicate" data-tooltip="Duplicate  Ctrl+D">
        <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"><rect x="5" y="5" width="8.5" height="8.5" rx="1.5"/><path d="M11 5V3.5A1.5 1.5 0 0 0 9.5 2h-6A1.5 1.5 0 0 0 2 3.5v6A1.5 1.5 0 0 0 3.5 11H5"/></svg>
        Duplicate</button>
      <button class="sel-btn sel-btn--danger" data-sel="delete" data-tooltip="Delete  Del">
        <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5l.7 9h5.6l.7-9"/></svg>
        Delete</button>
      <button class="sel-btn sel-btn--icon" data-sel="clear" aria-label="Deselect" data-tooltip="Deselect  Esc">
        <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg></button>`;
    document.body.append(bar);
    bar.addEventListener('click', (e) => {
      const action = e.target.closest('[data-sel]')?.dataset.sel;
      if (action === 'duplicate') duplicateSelected();
      if (action === 'delete') deleteSelected(e.target.closest('[data-sel]'));
      if (action === 'clear') clear();
    });

    // runs before dragging (capture), so Shift/Ctrl-click selects instead of starting other things
    canvas.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      const el = e.target.closest('.card');

      if (e.target.closest('.wire')) { clear(); return; } // picking a wire instead

      // on empty board: selection box
      if (!el && e.target === canvas) {
        startBox(e);
        return;
      }
      if (!el || el.parentElement !== canvas) return;

      if (e.shiftKey || e.ctrlKey || e.metaKey) {
        // modifier-click on a card (but not while selecting text inside it)
        if (isTyping(e.target) || e.target.closest('.draw-surface, .card-port, .card-resize')) return;
        e.preventDefault();
        e.stopPropagation();
        toggle(el.dataset.id);
        return;
      }
      // a plain click on a card that isn't selected starts a fresh selection
      if (selected.size && !selected.has(el.dataset.id)) clear();
    }, true);

    canvas.addEventListener('pointermove', (e) => { if (box && e.pointerId === box.id) moveBox(e); });
    canvas.addEventListener('pointerup', (e) => { if (box && e.pointerId === box.id) endBox(); });
    canvas.addEventListener('pointercancel', endBox);

    document.addEventListener('keydown', (e) => {
      if (isTyping(e.target) || e.target.closest?.('.draw-surface')) return;
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === 'a') { e.preventDefault(); selectAll(); return; }
      if (!selected.size) return;
      if (e.key === 'Escape') clear();
      if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); deleteSelected(); }
      if (mod && e.key.toLowerCase() === 'd') { e.preventDefault(); duplicateSelected(); }
    });

    App.state.subscribe(prune);
  }

  return {
    init,
    has: (id) => selected.has(id),
    ids: () => [...selected],
    size: () => selected.size,
    set,
    clear,
  };
})();
