// docx-reader.js — turns a Word .docx file into simple HTML for reading inside the app.
// A .docx is a zip of XML files; this unzips it with the browser's built-in decompression
// (no extra libraries) and converts paragraphs, headings, bold/italic/underline, colours,
// lists, tables, links and pictures. Fancy layout (columns, text boxes…) is simplified.
window.App = window.App || {};

App.docxReader = (() => {
  // ---------- tiny zip reader ----------
  async function unzip(buffer) {
    const bytes = new Uint8Array(buffer);
    const view = new DataView(buffer);
    // find the "end of central directory" record (at the end of the file)
    let eocd = -1;
    for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 70000); i--) {
      if (view.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('Not a zip file');
    const count = view.getUint16(eocd + 10, true);
    let ptr = view.getUint32(eocd + 16, true);
    const entries = new Map();
    const dec = new TextDecoder();
    for (let n = 0; n < count; n++) {
      if (view.getUint32(ptr, true) !== 0x02014b50) break;
      const method = view.getUint16(ptr + 10, true);
      const size = view.getUint32(ptr + 20, true);
      const nameLen = view.getUint16(ptr + 28, true);
      const extraLen = view.getUint16(ptr + 30, true);
      const commentLen = view.getUint16(ptr + 32, true);
      const offset = view.getUint32(ptr + 42, true);
      const name = dec.decode(bytes.subarray(ptr + 46, ptr + 46 + nameLen));
      entries.set(name, { method, size, offset });
      ptr += 46 + nameLen + extraLen + commentLen;
    }
    // read one file out of the zip
    async function read(name) {
      const e = entries.get(name);
      if (!e) return null;
      const nameLen = view.getUint16(e.offset + 26, true);
      const extraLen = view.getUint16(e.offset + 28, true);
      const start = e.offset + 30 + nameLen + extraLen;
      const data = bytes.subarray(start, start + e.size);
      if (e.method === 0) return data;
      if (e.method !== 8) throw new Error('Unsupported zip compression');
      const stream = new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
      return new Uint8Array(await new Response(stream).arrayBuffer());
    }
    return { has: (n) => entries.has(n), read, names: () => [...entries.keys()] };
  }

  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const kids = (el, name) => [...(el?.children || [])].filter((c) => c.nodeName === name);
  const kid = (el, name) => kids(el, name)[0] || null;
  const attr = (el, name) => el?.getAttribute(name);

  async function readXml(zip, name) {
    const data = await zip.read(name);
    if (!data) return null;
    return new DOMParser().parseFromString(new TextDecoder().decode(data), 'application/xml');
  }

  /** .docx (ArrayBuffer) -> { html, urls } (urls = picture blob URLs, to release later) */
  async function toHtml(buffer) {
    const zip = await unzip(buffer);
    const doc = await readXml(zip, 'word/document.xml');
    if (!doc) throw new Error('This doesn’t look like a Word document');
    const urls = [];

    // links + pictures are listed in the "relationships" file
    const rels = new Map();
    const relDoc = await readXml(zip, 'word/_rels/document.xml.rels');
    relDoc?.querySelectorAll('Relationship').forEach((r) => rels.set(r.getAttribute('Id'), r.getAttribute('Target')));

    // which styles are headings ("heading 1" in any language's Word keeps that internal name),
    // and which are list styles ("List Bullet", or styles with numbering built in)
    const headingOf = new Map();
    const styleList = new Map(); // styleId -> { numId } or { tag }
    const stylesDoc = await readXml(zip, 'word/styles.xml');
    [...(stylesDoc?.getElementsByTagName('w:style') || [])].forEach((s) => {
      const id = attr(s, 'w:styleId');
      const name = (attr(kid(s, 'w:name'), 'w:val') || '').toLowerCase();
      const m = name.match(/^heading (\d)$/);
      if (m) headingOf.set(id, `h${Math.min(6, +m[1])}`);
      else if (name === 'title') headingOf.set(id, 'h1');
      else if (name === 'subtitle') headingOf.set(id, 'h3');
      else if (name === 'quote' || name === 'intense quote') headingOf.set(id, 'blockquote');
      const styleNum = attr(s.getElementsByTagName('w:numId')[0], 'w:val');
      if (styleNum && styleNum !== '0') styleList.set(id, { numId: styleNum });
      else if (/^list (bullet|number)/.test(name)) styleList.set(id, { tag: name.includes('number') ? 'ol' : 'ul' });
    });

    // numbered or bulleted lists
    const listKind = new Map(); // numId -> 'ol' | 'ul'
    const numDoc = await readXml(zip, 'word/numbering.xml');
    if (numDoc) {
      const abstract = new Map();
      [...numDoc.getElementsByTagName('w:abstractNum')].forEach((a) => {
        const lvl = a.getElementsByTagName('w:lvl')[0];
        const fmt = attr(lvl?.getElementsByTagName('w:numFmt')[0], 'w:val');
        abstract.set(attr(a, 'w:abstractNumId'), fmt && fmt !== 'bullet' ? 'ol' : 'ul');
      });
      [...numDoc.getElementsByTagName('w:num')].forEach((n) => {
        listKind.set(attr(n, 'w:numId'), abstract.get(attr(n.getElementsByTagName('w:abstractNumId')[0], 'w:val')) || 'ul');
      });
    }

    // pictures: word/media/… -> blob URLs
    const pictures = new Map();
    async function picture(rId) {
      if (pictures.has(rId)) return pictures.get(rId);
      const target = rels.get(rId);
      if (!target) return null;
      const path = target.startsWith('/') ? target.slice(1) : `word/${target}`;
      const data = await zip.read(path);
      if (!data) return null;
      const type = /\.png$/i.test(path) ? 'image/png' : /\.gif$/i.test(path) ? 'image/gif' : /\.svg$/i.test(path) ? 'image/svg+xml' : 'image/jpeg';
      const url = URL.createObjectURL(new Blob([data], { type }));
      urls.push(url);
      pictures.set(rId, url);
      return url;
    }

    // ----- runs of text with formatting -----
    async function runHtml(r) {
      const rPr = kid(r, 'w:rPr');
      let out = '';
      for (const c of r.children) {
        if (c.nodeName === 'w:t') out += esc(c.textContent);
        else if (c.nodeName === 'w:tab') out += '&emsp;';
        else if (c.nodeName === 'w:br') out += attr(c, 'w:type') === 'page' ? '<hr class="docx-page">' : '<br>';
        else if (c.nodeName === 'w:drawing' || c.nodeName === 'w:pict') {
          const blip = c.getElementsByTagName('a:blip')[0] || c.getElementsByTagName('v:imagedata')[0];
          const rId = attr(blip, 'r:embed') || attr(blip, 'r:id');
          const url = rId && await picture(rId);
          if (url) out += `<img src="${url}" alt="">`;
        }
      }
      if (!out || !rPr) return out;
      const on = (name) => { const e = kid(rPr, name); return e && attr(e, 'w:val') !== '0' && attr(e, 'w:val') !== 'false'; };
      if (on('w:b')) out = `<b>${out}</b>`;
      if (on('w:i')) out = `<i>${out}</i>`;
      if (kid(rPr, 'w:u') && attr(kid(rPr, 'w:u'), 'w:val') !== 'none') out = `<u>${out}</u>`;
      if (on('w:strike')) out = `<s>${out}</s>`;
      const va = attr(kid(rPr, 'w:vertAlign'), 'w:val');
      if (va === 'superscript') out = `<sup>${out}</sup>`;
      if (va === 'subscript') out = `<sub>${out}</sub>`;
      const color = attr(kid(rPr, 'w:color'), 'w:val');
      if (color && /^[0-9a-f]{6}$/i.test(color) && color.toLowerCase() !== '000000') out = `<span style="color:#${color}">${out}</span>`;
      const hl = attr(kid(rPr, 'w:highlight'), 'w:val');
      if (hl && hl !== 'none') out = `<mark>${out}</mark>`;
      return out;
    }

    async function paragraphInner(p) {
      let out = '';
      for (const c of p.children) {
        if (c.nodeName === 'w:r') out += await runHtml(c);
        else if (c.nodeName === 'w:hyperlink') {
          let inner = '';
          for (const r of kids(c, 'w:r')) inner += await runHtml(r);
          const href = rels.get(attr(c, 'r:id'));
          out += href && /^(https?:|mailto:)/i.test(href) ? `<a href="${esc(href)}" target="_blank" rel="noopener noreferrer">${inner}</a>` : inner;
        } else if (c.nodeName === 'w:ins' || c.nodeName === 'w:smartTag' || c.nodeName === 'w:sdt') {
          for (const r of c.getElementsByTagName('w:r')) out += await runHtml(r);
        }
      }
      return out;
    }

    // ----- block-level content -----
    async function blocks(parent) {
      let html = '';
      let list = null; // the list currently open: { tag, numId }
      const closeList = () => { if (list) { html += `</${list.tag}>`; list = null; } };

      for (const el of parent.children) {
        if (el.nodeName === 'w:p') {
          const pPr = kid(el, 'w:pPr');
          const styleId = attr(kid(pPr, 'w:pStyle'), 'w:val');
          let numPr = kid(pPr, 'w:numPr');
          let numId = attr(kid(numPr, 'w:numId'), 'w:val');
          let forcedTag = null;
          // numbering that comes from the paragraph's style (e.g. "List Bullet")
          if (!numPr && styleList.has(styleId)) {
            const sl = styleList.get(styleId);
            numPr = true;
            numId = sl.numId || `style:${styleId}`;
            forcedTag = sl.tag || null;
          }
          const align = attr(kid(pPr, 'w:jc'), 'w:val');
          const style = align === 'center' || align === 'right' ? ` style="text-align:${align}"` : '';
          const inner = await paragraphInner(el);

          if (numPr && numId && numId !== '0') {
            const tag = forcedTag || listKind.get(numId) || 'ul';
            if (!list || list.numId !== numId) { closeList(); html += `<${tag}>`; list = { tag, numId }; }
            html += `<li${style}>${inner || '&nbsp;'}</li>`;
            continue;
          }
          closeList();
          const tag = headingOf.get(styleId) || 'p';
          html += inner ? `<${tag}${style}>${inner}</${tag}>` : '<p class="docx-empty">&nbsp;</p>';
        } else if (el.nodeName === 'w:tbl') {
          closeList();
          html += '<div class="docx-table"><table>';
          for (const tr of kids(el, 'w:tr')) {
            html += '<tr>';
            for (const tc of kids(tr, 'w:tc')) {
              const tcPr = kid(tc, 'w:tcPr');
              const span = attr(kid(tcPr, 'w:gridSpan'), 'w:val');
              const vMerge = kid(tcPr, 'w:vMerge');
              if (vMerge && attr(vMerge, 'w:val') !== 'restart') { html += '<td class="docx-merged"></td>'; continue; }
              html += `<td${span ? ` colspan="${+span}"` : ''}>${await blocks(tc)}</td>`;
            }
            html += '</tr>';
          }
          html += '</table></div>';
        } else if (el.nodeName === 'w:sdt') {
          closeList();
          html += await blocks(kid(el, 'w:sdtContent') || el);
        }
      }
      closeList();
      return html;
    }

    const body = doc.getElementsByTagName('w:body')[0];
    return { html: await blocks(body), urls };
  }

  return { toHtml, unzip };
})();
