// nesting.js — putting cards inside other cards (e.g. an image inside a to-do list).
// A nested card stays in the board data with `parent: <id>`; its parent draws it as an attachment.
// Card types opt in with `accepts: ['media']`.
window.App = window.App || {};

App.nesting = (() => {
  const ICONS = {
    out: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3h4v4M13 3L7.5 8.5M11 9.5V13H3V5h3.5"/></svg>',
    remove: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>',
    grip: '<svg viewBox="0 0 12 12" fill="currentColor"><circle cx="4" cy="3" r="1"/><circle cx="8" cy="3" r="1"/><circle cx="4" cy="6" r="1"/><circle cx="8" cy="6" r="1"/><circle cx="4" cy="9" r="1"/><circle cx="8" cy="9" r="1"/></svg>',
  };

  const accepts = (cardEl, type) =>
    !!cardEl && (App.cardTypes[cardEl.dataset.type]?.accepts || []).includes(type);

  // card under the pointer that can take a card of `type` (ignores `exclude`)
  function findTarget(e, type, exclude) {
    const under = document.elementFromPoint(e.clientX, e.clientY);
    const card = under?.closest('.card');
    if (!card || card === exclude) return null;
    return accepts(card, type) ? card : null;
  }

  function highlight(cardEl) {
    document.querySelectorAll('.card.is-nest-target').forEach((el) => {
      if (el !== cardEl) el.classList.remove('is-nest-target');
    });
    cardEl?.classList.add('is-nest-target');
  }

  // where a popped-out card lands: just to the right of its old parent
  function besideParent(parentId) {
    const parentEl = document.querySelector(`.card[data-id="${parentId}"]`);
    if (!parentEl) return { x: 80, y: 80 };
    return { x: parentEl.offsetLeft + parentEl.offsetWidth + 48, y: parentEl.offsetTop };
  }

  function removeChild(child) {
    App.cardTypes[child.type]?.onRemove?.(child);
    App.state.removeCard(child.id);
  }

  // draw the children of `card` into `container` (called by the parent card type)
  function renderAttachments(card, container) {
    const children = App.state.childrenOf(card.id);
    container.hidden = children.length === 0;

    children.forEach((child) => {
      const wrap = document.createElement('div');
      wrap.className = 'attachment';
      wrap.dataset.id = child.id;
      wrap.innerHTML = `
        <div class="attachment-bar">
          <span class="attachment-grip" data-attach-handle data-tooltip="Drag out onto the board">${ICONS.grip}</span>
          <span class="attachment-actions">
            <button class="card-btn" data-attach-action="out" aria-label="Move to board" data-tooltip="Move to board">${ICONS.out}</button>
            <button class="card-btn" data-attach-action="remove" aria-label="Delete attachment" data-tooltip="Delete">${ICONS.remove}</button>
          </span>
        </div>
        <div class="attachment-body"></div>`;

      App.cardTypes[child.type]?.render(child, wrap.querySelector('.attachment-body'));

      wrap.querySelector('[data-attach-action="out"]').addEventListener('click', () => {
        const { x, y } = besideParent(card.id);
        App.state.unnestCard(child.id, x, y);
      });
      wrap.querySelector('[data-attach-action="remove"]').addEventListener('click', () => {
        App.tooltip?.hide();
        removeChild(child);
      });

      // drag the grip to pull the attachment back out onto the board
      const grip = wrap.querySelector('[data-attach-handle]');
      grip.addEventListener('pointerdown', (e) => {
        if (e.button !== 0) return;
        e.preventDefault();
        e.stopPropagation();
        const start = { x: e.clientX, y: e.clientY };

        const onMove = (ev) => {
          if (Math.hypot(ev.clientX - start.x, ev.clientY - start.y) < 6) return;
          cleanup();
          const p = App.board.toCanvasPoint(ev.clientX, ev.clientY);
          App.state.unnestCard(child.id, Math.max(0, p.x - 40), Math.max(0, p.y - 12));
          const el = document.querySelector(`.card[data-id="${child.id}"]`);
          if (el) App.drag.begin(el, ev);
        };
        const cleanup = () => {
          window.removeEventListener('pointermove', onMove);
          window.removeEventListener('pointerup', cleanup);
        };
        window.addEventListener('pointermove', onMove);
        window.addEventListener('pointerup', cleanup);
      });

      container.append(wrap);
    });
  }

  // when a parent card is deleted, clean up its children (e.g. stored media files)
  function removeChildrenOf(cardId) {
    App.state.childrenOf(cardId).forEach((child) => App.cardTypes[child.type]?.onRemove?.(child));
  }

  return { accepts, findTarget, highlight, renderAttachments, removeChildrenOf };
})();
