// storage.js — saves the open board as you work.
// In this browser it saves straight away; with an account it saves to the server a moment
// after you stop changing things (and right away when you leave the board or close the tab).
// If the same board was changed somewhere else meanwhile, it asks what to do.
window.App = window.App || {};

App.storage = (() => {
  const DELAY = 800;   // ms of quiet before saving to the server
  let target = null;   // { id, rev } of the open board
  let pending = null;  // data waiting to be saved
  let timer = 0;
  let saving = false;
  let paused = false;
  const listeners = new Set();
  let status = 'saved';

  function setStatus(s, detail) {
    status = s;
    listeners.forEach((fn) => fn(s, detail));
  }

  async function flush({ keepalive = false, force = false } = {}) {
    clearTimeout(timer);
    if (!target || !pending || saving) return;
    const data = pending;
    pending = null;
    saving = true;
    setStatus('saving');
    try {
      const res = await App.boards.save(target.id, data, target.rev, { force, keepalive });
      if (res && typeof res.rev === 'number') target.rev = res.rev;
      setStatus(pending ? 'saving' : 'saved');
    } catch (err) {
      if (err.data?.conflict) {
        pending = data; // keep these changes until the user decides
        setStatus('conflict', err.data.board);
      } else if (err.name === 'QuotaExceededError' || /quota/i.test(err.message)) {
        setStatus('error', 'This browser’s storage is full. Remove some boards, or log in to save boards on the server.');
      } else {
        pending = pending || data; // try again soon
        setStatus('error', err.offline ? 'Offline — your changes will be saved when you’re back online.' : err.message);
        timer = setTimeout(flush, 5000);
      }
    } finally {
      saving = false;
      if (pending && status !== 'conflict') timer = setTimeout(flush, DELAY);
    }
  }

  // close / hide the tab: try to save whatever is left
  window.addEventListener('pagehide', () => { if (pending) flush({ keepalive: true }); });
  document.addEventListener('visibilitychange', () => { if (document.hidden && pending) flush({ keepalive: true }); });
  window.addEventListener('beforeunload', (e) => {
    if (pending || saving) { flush({ keepalive: true }); e.preventDefault(); }
  });

  return {
    // App.state calls this after every change
    save(data) {
      if (!target || paused || App.access?.readOnly()) return;
      pending = data;
      if (App.session.mode === 'local') { flush(); return; } // instant in this browser
      setStatus('unsaved');
      clearTimeout(timer);
      timer = setTimeout(flush, DELAY);
    },
    load: () => null,
    // which board the changes belong to (null = none open)
    setTarget(id, rev) {
      target = id ? { id, rev } : null;
      pending = null;
      setStatus('saved');
    },
    // don't save while a board is being loaded into the page
    pause(on) { paused = on; },
    flush,
    keepMine: () => flush({ force: true }),
    hasUnsaved: () => !!pending || saving,
    onStatus: (fn) => listeners.add(fn),
    get status() { return status; },
    get rev() { return target?.rev; },
    get boardId() { return target?.id; },
  };
})();
