// storage.js — saving and loading the board (browser localStorage)
window.App = window.App || {};

App.storage = (() => {
  const KEY = 'boards.v1';

  return {
    load() {
      try {
        const raw = localStorage.getItem(KEY);
        return raw ? JSON.parse(raw) : null;
      } catch {
        return null;
      }
    },
    save(data) {
      try {
        localStorage.setItem(KEY, JSON.stringify(data));
      } catch (err) {
        console.warn('Board could not be saved', err);
      }
    },
  };
})();
