// confirm-popover.js — a small "are you sure?" box next to a button,
// used instead of the browser's confirm() dialog.
window.App = window.App || {};

App.confirmPopover = (() => {
  let pop = null;
  let anchor = null;

  function close({ restoreFocus = true } = {}) {
    if (!pop) return;
    pop.remove();
    pop = null;
    document.removeEventListener('pointerdown', onOutside, true);
    document.removeEventListener('keydown', onKey);
    if (restoreFocus) anchor?.focus();
    anchor?.setAttribute('aria-expanded', 'false');
    anchor = null;
  }

  function onOutside(e) {
    if (!pop.contains(e.target) && !anchor.contains(e.target)) close({ restoreFocus: false });
  }
  function onKey(e) {
    if (e.key === 'Escape') close();
  }

  // Put the box next to the button on whichever side has room (right, left, below, above),
  // and always keep it fully on screen — even if the button itself is partly off screen.
  function position() {
    const GAP = 10;
    const EDGE = 8;
    const r = anchor.getBoundingClientRect();
    const w = pop.offsetWidth;
    const h = pop.offsetHeight;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;

    const options = {
      right: { left: r.right + GAP, top: cy - h / 2, room: vw - r.right - GAP - EDGE - w },
      left: { left: r.left - GAP - w, top: cy - h / 2, room: r.left - GAP - EDGE - w },
      below: { left: cx - w / 2, top: r.bottom + GAP, room: vh - r.bottom - GAP - EDGE - h },
      above: { left: cx - w / 2, top: r.top - GAP - h, room: r.top - GAP - EDGE - h },
    };
    // first side that fits, otherwise the side with the most room
    const side = ['right', 'left', 'below', 'above'].find((s) => options[s].room >= 0)
      || Object.keys(options).reduce((a, b) => (options[b].room > options[a].room ? b : a));

    const clamp = (v, max) => Math.min(Math.max(EDGE, v), max - EDGE);
    const left = clamp(options[side].left, vw - w);
    const top = clamp(options[side].top, vh - h);
    pop.style.left = `${left}px`;
    pop.style.top = `${top}px`;
    pop.dataset.side = side;

    // the little pointer aims at the button, but only if the button is actually beside the box
    const arrowX = cx - left;
    const arrowY = cy - top;
    const aims = side === 'left' || side === 'right' ? arrowY > 12 && arrowY < h - 12 : arrowX > 12 && arrowX < w - 12;
    const besideIt = side === 'right' ? left >= r.right
      : side === 'left' ? left + w <= r.left
        : side === 'below' ? top >= r.bottom : top + h <= r.top;
    pop.classList.toggle('no-arrow', !(aims && besideIt));
    pop.style.setProperty('--arrow-x', `${arrowX}px`);
    pop.style.setProperty('--arrow-y', `${arrowY}px`);
  }

  /**
   * options: title, message, confirmLabel, onConfirm
   */
  function open(button, { title, message = '', confirmLabel = 'Confirm', onConfirm }) {
    // clicking the same button again closes it
    if (pop && anchor === button) return close();
    close({ restoreFocus: false });

    anchor = button;
    anchor.setAttribute('aria-expanded', 'true');
    App.tooltip?.hide();

    pop = document.createElement('div');
    pop.className = 'confirm-pop';
    pop.setAttribute('role', 'alertdialog');
    pop.setAttribute('aria-labelledby', 'confirm-pop-title');
    pop.innerHTML = `
      <p class="confirm-pop-title" id="confirm-pop-title"></p>
      <p class="confirm-pop-msg"></p>
      <div class="confirm-pop-actions">
        <button class="confirm-pop-btn" data-choice="cancel">Cancel</button>
        <button class="confirm-pop-btn confirm-pop-btn--danger" data-choice="confirm"></button>
      </div>`;
    pop.querySelector('.confirm-pop-title').textContent = title;
    pop.querySelector('.confirm-pop-msg').textContent = message;
    pop.querySelector('.confirm-pop-msg').hidden = !message;
    pop.querySelector('[data-choice="confirm"]').textContent = confirmLabel;

    pop.addEventListener('click', (e) => {
      const choice = e.target.closest('[data-choice]')?.dataset.choice;
      if (!choice) return;
      close();
      if (choice === 'confirm') onConfirm?.();
    });

    document.body.append(pop);
    position();
    pop.querySelector('[data-choice="cancel"]').focus(); // safe default

    document.addEventListener('pointerdown', onOutside, true);
    document.addEventListener('keydown', onKey);
  }

  window.addEventListener('resize', () => { if (pop) position(); });

  return { open, close };
})();
