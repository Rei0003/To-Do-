// confirm-popover.js — a small "are you sure?" box next to a button,
// used instead of the browser's confirm() dialog.
window.App = window.App || {};

App.confirmPopover = (() => {
  let pop = null;
  let anchor = null;

  function close({ restoreFocus = true } = {}) {
    if (!pop) return;
    pop.remove();
    pop = null;
    document.removeEventListener('pointerdown', onOutside, true);
    document.removeEventListener('keydown', onKey);
    if (restoreFocus) anchor?.focus();
    anchor?.setAttribute('aria-expanded', 'false');
    anchor = null;
  }

  function onOutside(e) {
    if (!pop.contains(e.target) && !anchor.contains(e.target)) close({ restoreFocus: false });
  }
  function onKey(e) {
    if (e.key === 'Escape') close();
  }

  function position() {
    const r = anchor.getBoundingClientRect();
    const h = pop.offsetHeight;
    // to the right of the button, kept on screen
    pop.style.left = `${r.right + 10}px`;
    pop.style.top = `${Math.min(Math.max(8, r.top + r.height / 2 - h / 2), window.innerHeight - h - 8)}px`;
    pop.style.setProperty('--arrow-y', `${r.top + r.height / 2 - parseFloat(pop.style.top)}px`);
  }

  /**
   * options: title, message, confirmLabel, onConfirm
   */
  function open(button, { title, message = '', confirmLabel = 'Confirm', onConfirm }) {
    // clicking the same button again closes it
    if (pop && anchor === button) return close();
    close({ restoreFocus: false });

    anchor = button;
    anchor.setAttribute('aria-expanded', 'true');
    App.tooltip?.hide();

    pop = document.createElement('div');
    pop.className = 'confirm-pop';
    pop.setAttribute('role', 'alertdialog');
    pop.setAttribute('aria-labelledby', 'confirm-pop-title');
    pop.innerHTML = `
      <p class="confirm-pop-title" id="confirm-pop-title"></p>
      <p class="confirm-pop-msg"></p>
      <div class="confirm-pop-actions">
        <button class="confirm-pop-btn" data-choice="cancel">Cancel</button>
        <button class="confirm-pop-btn confirm-pop-btn--danger" data-choice="confirm"></button>
      </div>`;
    pop.querySelector('.confirm-pop-title').textContent = title;
    pop.querySelector('.confirm-pop-msg').textContent = message;
    pop.querySelector('.confirm-pop-msg').hidden = !message;
    pop.querySelector('[data-choice="confirm"]').textContent = confirmLabel;

    pop.addEventListener('click', (e) => {
      const choice = e.target.closest('[data-choice]')?.dataset.choice;
      if (!choice) return;
      close();
      if (choice === 'confirm') onConfirm?.();
    });

    document.body.append(pop);
    position();
    pop.querySelector('[data-choice="cancel"]').focus(); // safe default

    document.addEventListener('pointerdown', onOutside, true);
    document.addEventListener('keydown', onKey);
  }

  window.addEventListener('resize', () => { if (pop) position(); });

  return { open, close };
})();
