// title.js — the editable board name in the top bar
window.App = window.App || {};

App.title = {
  init() {
    const input = document.getElementById('board-title');
    const sync = () => { document.title = `${input.value || 'Untitled'} – Boards`; };

    input.value = App.state.get().title;
    sync();

    input.addEventListener('input', () => {
      App.state.setTitle(input.value);
      sync();
    });
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') input.blur();
    });
  },
};
