// color-popover.js — "Custom colour" box: the colour maker plus a Save & use button.
// Saved colours appear in every colour list (see saved-colors.js, palette.js).
window.App = window.App || {};

App.colorPopover = (() => {
  let pop = null;
  let anchor = null;

  function close() {
    if (!pop) return;
    pop.remove();
    pop = null;
    document.removeEventListener('pointerdown', onOutside, true);
    document.removeEventListener('keydown', onKey, true);
    anchor = null;
  }
  function onOutside(e) {
    if (!pop.contains(e.target) && !anchor?.contains(e.target)) close();
  }
  function onKey(e) {
    if (e.key === 'Escape') { e.stopPropagation(); close(); }
  }

  function place(rect) {
    const w = pop.offsetWidth;
    const h = pop.offsetHeight;
    let top = rect.bottom + 8;
    if (top + h > window.innerHeight - 8) top = rect.top - h - 8;
    top = Math.min(Math.max(8, top), window.innerHeight - h - 8);
    const left = Math.min(Math.max(8, rect.left + rect.width / 2 - w / 2), window.innerWidth - w - 8);
    pop.style.top = `${top}px`;
    pop.style.left = `${left}px`;
  }

  /**
   * button  what it opens from
   * options value (starting colour), alpha (opacity slider), onPick(hex)
   */
  function open(button, { value = '#3B82F6', alpha = true, onPick }) {
    if (pop && anchor === button) return close();
    close();
    App.tooltip?.hide();
    anchor = button;
    const rect = button.getBoundingClientRect(); // remember it: the button may disappear (e.g. text bar)

    pop = document.createElement('div');
    pop.className = 'color-pop';
    pop.setAttribute('role', 'dialog');
    pop.setAttribute('aria-label', 'Custom colour');
    pop.innerHTML = `
      <p class="color-pop-title">Custom colour</p>
      <div class="color-pop-maker"></div>
      <div class="color-pop-actions">
        <button class="confirm-pop-btn" data-choice="cancel">Cancel</button>
        <button class="confirm-pop-btn color-pop-use" data-choice="use">Save &amp; use</button>
      </div>`;
    const picker = App.colorPicker.create({ value, alpha });
    pop.querySelector('.color-pop-maker').append(picker.el);

    pop.addEventListener('click', (e) => {
      const choice = e.target.closest('[data-choice]')?.dataset.choice;
      if (!choice) return;
      const color = picker.value();
      close();
      if (choice === 'use') {
        App.savedColors.add(color);
        onPick?.(color);
      }
    });
    // keep the text bar's selection alive while using the box
    pop.addEventListener('mousedown', (e) => {
      if (!e.target.closest('input, .cp-sv')) e.preventDefault();
    });

    document.body.append(pop);
    place(rect);
    document.addEventListener('pointerdown', onOutside, true);
    document.addEventListener('keydown', onKey, true);
  }

  return { open, close, isOpen: () => !!pop };
})();
