// team.js — how the people on your boards are doing: tasks completed, average turnaround
// (from being assigned — or created — until done), on-time rate, open and overdue tasks.
// Used by the Team widget on a board's dashboard and by the Team activity page (#/team).
window.App = window.App || {};

App.team = (() => {
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  // 3 d 4 h · 5 h 20 min · 12 min · under a minute
  function duration(sec) {
    if (sec === null || sec === undefined) return '—';
    if (sec < 60) return 'under a minute';
    const m = Math.round(sec / 60);
    if (m < 60) return `${m} min`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h} h${m % 60 ? ` ${m % 60} min` : ''}`;
    const d = Math.floor(h / 24);
    return `${d} d${h % 24 ? ` ${h % 24} h` : ''}`;
  }
  const when = (t) => new Date(t * 1000).toLocaleDateString(undefined, { day: 'numeric', month: 'short' });

  const fetchStats = (boardId) => App.api.request('GET', boardId ? `team.php?board=${boardId}` : 'team.php');

  function nameCell(p) {
    const cell = document.createElement('span');
    cell.className = 'team-name';
    App.people.remember(p.email, p.avatar || null);
    cell.append(App.people.avatar(p.email, 26));
    const text = document.createElement('span');
    text.innerHTML = '<strong></strong><small></small>';
    text.firstChild.textContent = p.you ? `${p.name || 'You'} (you)` : (p.name || p.email);
    if (p.member_role) text.firstChild.append(' ', App.roles.badge(p.member_role, true));
    text.lastChild.textContent = p.name ? p.email : 'Invited — hasn’t signed up yet';
    cell.append(text);
    return cell;
  }

  /**
   * The stats table. compact = the dashboard widget (fewer columns, no details).
   */
  function table(res, { compact = false } = {}) {
    const wrap = document.createElement('div');
    wrap.className = `team${compact ? ' is-compact' : ''}`;
    const people = res.people.filter((p) => p.done || p.open || p.invited || !compact);
    if (!people.some((p) => p.done || p.open)) {
      wrap.innerHTML = `<p class="dash-empty">No finished or assigned tasks yet. Assign tasks to people and their progress shows up here.</p>`;
    }
    const maxDone = Math.max(1, ...people.map((p) => p.done));
    const t = document.createElement('table');
    t.className = 'team-table';
    t.innerHTML = `<thead><tr>
        <th>Person</th><th>Done</th><th title="From being assigned (or created) until done">Avg. turnaround</th>
        ${compact ? '' : '<th>Median</th><th title="Of finished tasks that had a due date">On time</th>'}
        <th>Open</th>${compact ? '' : '<th></th>'}
      </tr></thead><tbody></tbody>`;
    const body = t.querySelector('tbody');
    people.forEach((p) => {
      const tr = document.createElement('tr');
      tr.className = 'team-row';
      const nameTd = document.createElement('td');
      nameTd.append(nameCell(p));
      tr.append(nameTd);
      const onTime = p.on_time ? Math.round((p.on_time.done / p.on_time.with_due) * 100) : null;
      tr.insertAdjacentHTML('beforeend', `
        <td class="team-done"><span class="team-num">${p.done}</span><span class="dash-bar"><span style="width:${(p.done / maxDone) * 100}%"></span></span></td>
        <td class="team-turn" title="${p.turnaround ? `Fastest ${duration(p.turnaround.fastest)} · slowest ${duration(p.turnaround.slowest)} · ${p.turnaround.count} task${p.turnaround.count === 1 ? '' : 's'}` : ''}">${duration(p.turnaround?.average)}</td>
        ${compact ? '' : `<td>${duration(p.turnaround?.median)}</td>
          <td>${onTime === null ? '—' : `<span class="team-ontime ${onTime >= 80 ? 'is-good' : onTime >= 50 ? 'is-ok' : 'is-bad'}">${onTime}%</span> <small>${p.on_time.done}/${p.on_time.with_due}</small>`}</td>`}
        <td>${p.open}${p.overdue ? ` <span class="team-overdue">${p.overdue} overdue</span>` : ''}</td>
        ${compact ? '' : `<td>${p.recent.length ? '<button class="team-more" aria-expanded="false">Details</button>' : ''}</td>`}`);
      body.append(tr);
      if (!compact && p.recent.length) {
        // latest finished tasks, shown when "Details" is clicked
        const detail = document.createElement('tr');
        detail.className = 'team-detail';
        detail.hidden = true;
        detail.innerHTML = `<td colspan="7">
          <p class="team-detail-title">Recently completed${p.turnaround ? ` · fastest ${duration(p.turnaround.fastest)}, slowest ${duration(p.turnaround.slowest)}` : ''}</p>
          <ul>${p.recent.map((r) => `<li>
            <a href="#/board/${esc(r.board_id)}">${esc(r.text || 'Untitled task')}</a>
            <span>${esc(r.list || 'To-do list')} · ${esc(r.board)}</span>
            <span class="team-detail-when">${when(r.done_at)}${r.turnaround !== null ? ` · took ${duration(r.turnaround)}` : ''}</span>
          </li>`).join('')}</ul></td>`;
        body.append(detail);
        tr.querySelector('.team-more').addEventListener('click', (e) => {
          detail.hidden = !detail.hidden;
          e.target.setAttribute('aria-expanded', String(!detail.hidden));
          e.target.textContent = detail.hidden ? 'Details' : 'Hide';
        });
      }
    });
    const scroll = document.createElement('div');
    scroll.className = 'team-scroll';
    scroll.append(t);
    wrap.append(scroll);
    if (res.untracked) {
      wrap.insertAdjacentHTML('beforeend', `<p class="team-note">${res.untracked} task${res.untracked === 1 ? ' was' : 's were'} finished before activity tracking started and ${res.untracked === 1 ? 'isn’t' : 'aren’t'} counted.</p>`);
    }
    return wrap;
  }

  // ---------- the Team activity page (#/team) ----------
  async function page(el) {
    const u = App.session.user;
    el.innerHTML = `
      <div class="home">
        <header class="home-head">
          <a class="topbar-back" href="#/boards" aria-label="All boards" data-tooltip="All boards">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M10 3.5L5.5 8l4.5 4.5"/></svg></a>
          <div class="home-brand"><span>Team activity</span></div>
          <span class="home-spacer"></span>
          ${u ? '<button class="file-btn" data-team="roles">Your roles…</button>' : ''}
          <button class="account-btn"></button>
        </header>
        <main class="home-body">
          <div class="home-title"><h1>Team activity</h1>
            <p>Tasks on every board you own (and boards inside them): who finished what, and how quickly.</p></div>
          <div class="team-page"><p class="home-loading">Loading…</p></div>
          <p class="team-explain"><strong>Turnaround</strong> is the time from when a task was assigned to someone
            (or created, if it wasn’t assigned to them) until it was ticked off. <strong>On time</strong> counts finished
            tasks that had a due date.</p>
        </main>
      </div>`;
    App.screens.accountButton(el.querySelector('.account-btn'));
    el.querySelector('[data-team="roles"]')?.addEventListener('click', () => App.roles.manage(() => page(el)));
    const box = el.querySelector('.team-page');
    if (!u) { box.innerHTML = '<p class="home-loading">Team activity needs an account.</p>'; return; }
    try {
      const res = await fetchStats(null);
      box.replaceChildren(summary(res), table(res));
      if (res.roles?.some((r) => r.role)) box.append(byRole(res));
    } catch (err) {
      box.innerHTML = `<p class="home-loading">${esc(err.message)}</p>`;
    }
  }

  // headline numbers for the whole team
  function summary(res) {
    const done = res.people.reduce((a, p) => a + p.done, 0);
    const open = res.people.reduce((a, p) => a + p.open, 0);
    const overdue = res.people.reduce((a, p) => a + p.overdue, 0);
    const all = res.people.flatMap((p) => (p.turnaround ? Array(p.turnaround.count).fill(p.turnaround.average) : []));
    const avg = all.length ? all.reduce((a, b) => a + b, 0) / all.length : null;
    const el = document.createElement('div');
    el.className = 'dash-widget-body dash-overview-tiles';
    el.innerHTML = [
      [done, done === 1 ? 'task completed' : 'tasks completed', `on ${res.boards} board${res.boards === 1 ? '' : 's'}`],
      [duration(avg), 'average turnaround', 'assigned → done'],
      [open, open === 1 ? 'open task' : 'open tasks', 'assigned to someone'],
      [overdue, 'overdue', overdue ? 'need attention' : 'nothing late', overdue ? 'bad' : 'good'],
    ].map(([n, label, sub, tone]) => `<div class="dash-tile ${tone ? `is-${tone}` : ''}"><span class="dash-tile-n">${n}</span>
      <span class="dash-tile-label">${label}</span><span class="dash-tile-sub">${sub}</span></div>`).join('');
    return el;
  }

  // totals per custom role
  function byRole(res) {
    const wrap = document.createElement('section');
    wrap.className = 'team team-by-role';
    wrap.innerHTML = `<h2 class="team-section-title">By role</h2>
      <div class="team-scroll"><table class="team-table">
        <thead><tr><th>Role</th><th>People</th><th>Done</th><th>Avg. turnaround</th><th>Open</th></tr></thead>
        <tbody>${res.roles.map((r) => `<tr class="team-row">
          <td>${r.role ? App.roles.badgeHtml(r.role) : '<span class="team-norole">No role</span>'}</td>
          <td>${r.people}</td>
          <td><span class="team-num">${r.done}</span></td>
          <td class="team-turn">${duration(r.average)}</td>
          <td>${r.open}${r.overdue ? ` <span class="team-overdue">${r.overdue} overdue</span>` : ''}</td>
        </tr>`).join('')}</tbody></table></div>`;
    return wrap;
  }

  return { fetchStats, table, page, duration };
})();
