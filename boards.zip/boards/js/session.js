// session.js — who's using the app: a logged-in account (boards on the server) or
// "this browser only" (boards in this browser, like before accounts existed).
window.App = window.App || {};

App.session = (() => {
  const MODE_KEY = 'boards.mode'; // remembers "use without an account"
  let user = null;
  let server = false;   // is the PHP server there?
  let mode = 'local';   // 'server' | 'local'
  let verifyEmail = true; // does registering need an emailed code?
  const listeners = new Set();

  function setMode(next) {
    mode = next;
    App.mediaStore.useServer(mode === 'server');
    listeners.forEach((fn) => fn({ mode, user }));
  }

  // on start-up: find out what's possible and who's logged in
  async function start() {
    server = await App.api.available();
    if (server) {
      try {
        const me = await App.api.request('GET', 'auth.php?action=me');
        user = me.user;
        if (typeof me.verify_email === 'boolean') verifyEmail = me.verify_email;
      } catch { user = null; }
    }
    setMode(user ? 'server' : 'local');
    return { server, user, choseLocal: localStorage.getItem(MODE_KEY) === 'local' };
  }

  async function register(name, email, password) {
    user = (await App.api.request('POST', 'auth.php?action=register', { name, email, password })).user;
    localStorage.removeItem(MODE_KEY);
    setMode('server');
    return user;
  }

  // registering with an emailed code: 1) send the code  2) check it (creates the account)
  const registerStart = (name, email, password) => App.api.request('POST', 'auth.php?action=register_start', { name, email, password });
  const resendCode = (email) => App.api.request('POST', 'auth.php?action=register_resend', { email });
  async function verifyCode(email, code) {
    user = (await App.api.request('POST', 'auth.php?action=register_verify', { email, code })).user;
    localStorage.removeItem(MODE_KEY);
    setMode('server');
    return user;
  }

  async function login(email, password) {
    user = (await App.api.request('POST', 'auth.php?action=login', { email, password })).user;
    localStorage.removeItem(MODE_KEY);
    setMode('server');
    return user;
  }

  async function logout() {
    try { await App.api.request('POST', 'auth.php?action=logout'); } catch { /* still log out here */ }
    user = null;
    setMode('local');
  }

  // your profile changed (name or picture)
  function updateUser(next) {
    user = next;
    listeners.forEach((fn) => fn({ mode, user }));
  }

  function useLocal() {
    localStorage.setItem(MODE_KEY, 'local');
    setMode('local');
  }

  return {
    start,
    register,
    registerStart,
    resendCode,
    verifyCode,
    get verifyEmail() { return verifyEmail; },
    login,
    logout,
    useLocal,
    updateUser,
    onChange: (fn) => listeners.add(fn),
    get user() { return user; },
    get mode() { return mode; },
    get server() { return server; },
  };
})();
