// saved-colors.js — custom colours the user has made, shared by every colour picker in the app
window.App = window.App || {};

App.savedColors = (() => {
  const KEY = 'boards.savedColors';
  const OLD_KEY = 'boards.recentBackgrounds'; // from the first version of the background picker
  const MAX = 48;
  const listeners = new Set();

  function read() {
    try {
      const saved = JSON.parse(localStorage.getItem(KEY));
      if (Array.isArray(saved)) return saved;
      return JSON.parse(localStorage.getItem(OLD_KEY)) || [];
    } catch {
      return [];
    }
  }
  let colors = read();

  function write() {
    try { localStorage.setItem(KEY, JSON.stringify(colors)); } catch { /* storage full */ }
    listeners.forEach((fn) => fn(colors));
  }

  const norm = (c) => String(c).toUpperCase();

  return {
    list: () => colors.slice(),
    has: (c) => colors.includes(norm(c)),
    // newest first; adding an existing colour moves it to the front
    add(c) {
      if (!c || !/^#[0-9A-F]{6}([0-9A-F]{2})?$/i.test(c)) return;
      colors = [norm(c), ...colors.filter((x) => x !== norm(c))].slice(0, MAX);
      write();
    },
    remove(c) {
      colors = colors.filter((x) => x !== norm(c));
      write();
    },
    subscribe(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },
  };
})();
