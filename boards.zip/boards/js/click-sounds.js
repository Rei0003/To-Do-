// click-sounds.js — an optional sound on every mouse click (off by default).
// Built in: "Soft tick" and "Pop" (made by the browser's audio engine, no files needed),
// or "Your own sound": an audio file you import. Your choice, the volume and your own sound are
// kept in this browser (it's a preference for this device).
window.App = window.App || {};

App.clickSounds = (() => {
  const KEY = 'boards.clickSound';
  const MAX_FILE = 1024 * 1024;   // own sounds: 1 MB at most
  const MAX_LENGTH = 1.2;         // seconds played from your own sound (so fast clicks don't pile up)

  const SOUNDS = [
    { id: 'none', label: 'None', hint: 'No sound (default)' },
    { id: 'tick', label: 'Soft tick', hint: 'A short, quiet click' },
    { id: 'pop', label: 'Pop', hint: 'A small bubbly pop' },
    { id: 'custom', label: 'Your own sound', hint: 'Import an audio file' },
  ];

  let settings = { sound: 'none', volume: 0.5, customName: null };
  try { settings = { ...settings, ...JSON.parse(localStorage.getItem(KEY)) }; } catch { /* defaults */ }
  const persist = () => localStorage.setItem(KEY, JSON.stringify(settings));

  // ---------- your own sound lives in IndexedDB (localStorage is too small) ----------
  function db() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open('boards-sounds', 1);
      req.onupgradeneeded = () => req.result.createObjectStore('sounds');
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async function idb(mode, fn) {
    const d = await db();
    return new Promise((resolve, reject) => {
      const tx = d.transaction('sounds', mode);
      const r = fn(tx.objectStore('sounds'));
      tx.oncomplete = () => resolve(r?.result);
      tx.onerror = () => reject(tx.error);
    });
  }

  // ---------- audio ----------
  let ctx = null;
  let customBuffer = null;
  const audio = () => {
    if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  };

  async function loadCustom() {
    customBuffer = null;
    if (!settings.customName) return;
    try {
      const blob = await idb('readonly', (s) => s.get('custom'));
      if (blob) customBuffer = await audio().decodeAudioData(await blob.arrayBuffer());
    } catch { customBuffer = null; }
  }

  // "Soft tick": a tiny burst of filtered noise
  function tick(c, at, vol) {
    const len = Math.floor(c.sampleRate * 0.03);
    const buf = c.createBuffer(1, len, c.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len) ** 4;
    const src = c.createBufferSource();
    src.buffer = buf;
    const hp = c.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.value = 1800;
    const g = c.createGain();
    g.gain.value = vol * 0.9;
    src.connect(hp).connect(g).connect(c.destination);
    src.start(at);
  }

  // "Pop": a short tone that drops in pitch
  function pop(c, at, vol) {
    const o = c.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(720, at);
    o.frequency.exponentialRampToValueAtTime(180, at + 0.07);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, at);
    g.gain.exponentialRampToValueAtTime(vol * 0.6, at + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, at + 0.09);
    o.connect(g).connect(c.destination);
    o.start(at);
    o.stop(at + 0.1);
  }

  function custom(c, at, vol) {
    if (!customBuffer) return;
    const src = c.createBufferSource();
    src.buffer = customBuffer;
    const g = c.createGain();
    g.gain.value = vol;
    src.connect(g).connect(c.destination);
    src.start(at, 0, Math.min(MAX_LENGTH, customBuffer.duration));
  }

  /** play a sound now (id defaults to the chosen one) */
  function play(id = settings.sound, volume = settings.volume) {
    if (id === 'none' || volume <= 0) return;
    const c = audio();
    const at = c.currentTime + 0.001;
    if (id === 'tick') tick(c, at, volume);
    if (id === 'pop') pop(c, at, volume);
    if (id === 'custom') custom(c, at, volume);
  }

  // every click (left button / tap), a few at most per frame
  let last = 0;
  document.addEventListener('pointerdown', (e) => {
    if (settings.sound === 'none' || e.button !== 0) return;
    const now = performance.now();
    if (now - last < 35) return;
    last = now;
    play();
  }, true);

  // ---------- changing the settings ----------
  async function importFile(file) {
    if (!file) return null;
    if (!file.type.startsWith('audio/') && !/\.(mp3|wav|ogg|m4a|aac|flac|opus|webm)$/i.test(file.name)) {
      throw new Error('Please choose an audio file (MP3, WAV, OGG, M4A…).');
    }
    if (file.size > MAX_FILE) throw new Error('That sound is too big — 1 MB at most (short sounds work best).');
    // check it actually plays before keeping it
    let buffer;
    try { buffer = await audio().decodeAudioData(await file.arrayBuffer()); } catch {
      throw new Error('That file couldn’t be played as a sound.');
    }
    await idb('readwrite', (s) => s.put(file, 'custom'));
    customBuffer = buffer;
    settings.customName = file.name;
    settings.sound = 'custom';
    persist();
    return { name: file.name, duration: buffer.duration };
  }

  async function removeCustom() {
    await idb('readwrite', (s) => s.delete('custom')).catch(() => {});
    customBuffer = null;
    settings.customName = null;
    if (settings.sound === 'custom') settings.sound = 'none';
    persist();
  }

  loadCustom();

  return {
    SOUNDS,
    play,
    importFile,
    removeCustom,
    get settings() { return { ...settings }; },
    set(patch) { settings = { ...settings, ...patch }; persist(); },
    hasCustom: () => !!customBuffer,
  };
})();
