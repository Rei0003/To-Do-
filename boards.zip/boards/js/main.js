// main.js — starts everything up
App.theme.init();
App.title.init();
App.board.init();
App.toolbar.init();
App.mediaImport.init();
