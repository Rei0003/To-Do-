// main.js — starts everything up
App.title.init();
App.board.init();
App.toolbar.init();
