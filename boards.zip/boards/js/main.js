// main.js — starts everything up
App.tooltip.init();
App.formatToolbar.init();
App.theme.init();
App.title.init();
App.board.init();
App.toolbar.init();
App.mediaImport.init();
App.pan.init();
App.selection.init();
App.comments.init();
App.dashboard.init();
App.router.start(); // log in / your boards / open a board
