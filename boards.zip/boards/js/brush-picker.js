// brush-picker.js — the canvas "Brushes" box: pick a brush, import new ones,
// and fine-tune (or export/remove) imported brushes.
window.App = window.App || {};

App.brushPicker = (() => {
  let pop = null;
  let anchor = null;

  function close() {
    if (!pop) return;
    pop.remove();
    pop = null;
    anchor?.setAttribute('aria-expanded', 'false');
    anchor = null;
    document.removeEventListener('pointerdown', onOutside, true);
    document.removeEventListener('keydown', onKey, true);
  }
  function onOutside(e) {
    if (pop && !pop.contains(e.target) && !anchor?.contains(e.target) && !e.target.closest('.confirm-pop')) close();
  }
  function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); const a = anchor; close(); a?.focus(); } }

  // slider definitions for imported brushes: [setting, label, min, max, step, shown as %?]
  const SLIDERS = [
    ['spacing', 'Spacing', 0.02, 2, 0.01, true],
    ['flow', 'Flow', 0.05, 1, 0.05, true],
    ['scatter', 'Scatter', 0, 2, 0.05, true],
    ['sizeJitter', 'Size jitter', 0, 1, 0.05, true],
    ['angleJitter', 'Angle jitter', 0, 180, 5, false],
    ['count', 'Stamps per step', 1, 20, 1, false],
    ['sizeScale', 'Size', 0.25, 4, 0.05, true],
  ];

  /**
   * button   what it opens from
   * current  selected brush id
   * color    CSS colour for the previews
   * onPick(id)
   */
  function open(button, { current, color, onPick }) {
    if (pop && anchor === button) return close();
    close();
    App.tooltip?.hide();
    anchor = button;
    anchor.setAttribute('aria-expanded', 'true');
    let selected = current || 'pen';

    pop = document.createElement('div');
    pop.className = 'brush-pop';
    pop.setAttribute('role', 'dialog');
    pop.setAttribute('aria-label', 'Brushes');
    pop.innerHTML = `
      <div class="brush-head">
        <p class="brush-title">Brushes</p>
        <label class="brush-import" data-tooltip="PNG / JPG images become brush tips,&#10;or load a .brush.json file">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 10.5v-8M4.5 6L8 2.5 11.5 6M3 13.5h10"/></svg>
          Import…
          <input type="file" accept="image/*,.json,application/json" multiple hidden>
        </label>
      </div>
      <div class="brush-grid" role="listbox"></div>
      <div class="brush-settings" hidden></div>
      <p class="brush-hint">Imported images become brush tips: transparent parts (or light parts of a picture without transparency) don’t paint. Drop images here too.</p>`;
    const grid = pop.querySelector('.brush-grid');
    const settings = pop.querySelector('.brush-settings');

    function drawGrid() {
      grid.replaceChildren(...App.brushes.list().map((b) => {
        const tile = document.createElement('button');
        tile.className = 'brush-tile';
        tile.dataset.brush = b.id;
        tile.setAttribute('role', 'option');
        tile.setAttribute('aria-selected', String(b.id === selected));
        tile.append(App.brushes.preview(b, 92, 34, color));
        const name = document.createElement('span');
        name.textContent = b.name;
        tile.append(name);
        return tile;
      }));
    }

    function drawSettings() {
      const b = App.brushes.get(selected);
      settings.hidden = !b || b.builtIn;
      if (settings.hidden) return;
      settings.innerHTML = `
        <div class="brush-set-head">
          <input class="brush-name" maxlength="30" aria-label="Brush name">
          <button class="card-btn" data-act="export" aria-label="Export brush" data-tooltip="Export as .json">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2.5v8M4.5 7L8 10.5 11.5 7M3 13.5h10"/></svg></button>
          <button class="card-btn" data-act="remove" aria-label="Remove brush" data-tooltip="Remove brush">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5l.7 9h5.6l.7-9"/></svg></button>
        </div>
        <label class="brush-row"><span>Angle</span>
          <select data-set="angle">
            <option value="fixed">Fixed</option><option value="follow">Follow the line</option><option value="random">Random</option>
          </select>
          <input type="range" min="-180" max="180" step="5" data-set="angleDeg" aria-label="Fixed angle">
        </label>
        ${SLIDERS.map(([k, label, min, max, step]) => `
          <label class="brush-row"><span>${label}</span>
            <input type="range" min="${min}" max="${max}" step="${step}" data-set="${k}">
            <output data-out="${k}"></output></label>`).join('')}`;
      settings.querySelector('.brush-name').value = b.name;
      settings.querySelector('[data-set="angle"]').value = b.angle;
      const deg = settings.querySelector('[data-set="angleDeg"]');
      deg.value = b.angleDeg || 0;
      deg.hidden = b.angle !== 'fixed';
      SLIDERS.forEach(([k, , , , , pct]) => {
        settings.querySelector(`[data-set="${k}"]`).value = b[k];
        settings.querySelector(`[data-out="${k}"]`).textContent = pct ? `${Math.round(b[k] * 100)}%` : (k === 'angleJitter' ? `±${b[k]}°` : b[k]);
      });
    }

    // live tweaks to an imported brush
    settings.addEventListener('input', (e) => {
      const t = e.target;
      const b = App.brushes.get(selected);
      if (!b || b.builtIn) return;
      if (t.classList.contains('brush-name')) { App.brushes.update(b.id, { name: t.value || 'Brush' }); return; }
      const k = t.dataset.set;
      if (!k) return;
      const value = k === 'angle' ? t.value : Number(t.value);
      App.brushes.update(b.id, { [k]: value });
      drawSettings();
      // refresh this brush's preview
      const tile = grid.querySelector(`[data-brush="${b.id}"]`);
      tile?.querySelector('canvas')?.replaceWith(App.brushes.preview(App.brushes.get(b.id), 92, 34, color));
    });
    settings.addEventListener('change', (e) => { if (e.target.classList.contains('brush-name')) drawGrid(); });
    settings.addEventListener('click', (e) => {
      const act = e.target.closest('[data-act]')?.dataset.act;
      if (act === 'export') App.brushes.exportBrush(selected);
      if (act === 'remove') {
        App.confirmPopover.open(e.target.closest('[data-act]'), {
          title: 'Remove this brush?',
          message: 'Drawings already made with it keep their look.',
          confirmLabel: 'Remove',
          onConfirm: () => {
            App.brushes.remove(selected);
            selected = 'pen';
            onPick(selected);
            drawGrid();
            drawSettings();
          },
        });
      }
    });

    grid.addEventListener('click', (e) => {
      const tile = e.target.closest('[data-brush]');
      if (!tile) return;
      selected = tile.dataset.brush;
      onPick(selected);
      grid.querySelectorAll('.brush-tile').forEach((t) => t.setAttribute('aria-selected', String(t.dataset.brush === selected)));
      drawSettings();
    });

    // importing: file picker or dropping files onto the box
    async function importAndSelect(files) {
      const added = await App.brushes.importFiles([...files]);
      if (!added.length) return;
      selected = added[added.length - 1].id;
      onPick(selected);
      drawGrid();
      drawSettings();
    }
    pop.querySelector('.brush-import input').addEventListener('change', (e) => importAndSelect(e.target.files));
    pop.addEventListener('dragover', (e) => { if (e.dataTransfer.types.includes('Files')) { e.preventDefault(); e.stopPropagation(); pop.classList.add('is-over'); } });
    pop.addEventListener('dragleave', (e) => { if (!pop.contains(e.relatedTarget)) pop.classList.remove('is-over'); });
    pop.addEventListener('drop', (e) => {
      if (!e.dataTransfer.files.length) return;
      e.preventDefault();
      e.stopPropagation();
      pop.classList.remove('is-over');
      importAndSelect(e.dataTransfer.files);
    });

    // imported brush images load in the background: refresh the previews when they're ready
    const onBrushChange = () => {
      if (!pop) { window.removeEventListener('brushchange', onBrushChange); return; }
      grid.querySelectorAll('.brush-tile').forEach((tile) => {
        const b = App.brushes.get(tile.dataset.brush);
        if (b) tile.querySelector('canvas')?.replaceWith(App.brushes.preview(b, 92, 34, color));
      });
    };
    window.addEventListener('brushchange', onBrushChange);

    drawGrid();
    drawSettings();
    document.body.append(pop);
    const r = button.getBoundingClientRect();
    const w = pop.offsetWidth;
    const h = pop.offsetHeight;
    let top = r.bottom + 6;
    if (top + h > window.innerHeight - 8) top = r.top - h - 6;
    pop.style.top = `${Math.min(Math.max(8, top), window.innerHeight - h - 8)}px`;
    pop.style.left = `${Math.min(Math.max(8, r.left - 10), window.innerWidth - w - 8)}px`;
    document.addEventListener('pointerdown', onOutside, true);
    document.addEventListener('keydown', onKey, true);
  }

  return { open, close };
})();
