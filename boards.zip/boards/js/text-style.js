// text-style.js — shared machinery for styled text spans (used by text colour and font size).
// Saved form: <span style="color: var(--tc-red); font-size: var(--fs-large)">
// Each feature registers itself with App.textStyle.register({...}).
window.App = window.App || {};

App.textStyle = (() => {
  const props = {};   // key -> definition
  let pending = {};   // value being applied right now, e.g. { size: 'large' }

  /**
   * def: {
   *   key        'color' | 'size'
   *   cssProp    CSS property written to the span
   *   varPrefix  CSS variable prefix, e.g. '--tc-'
   *   values     allowed names (first one = default / no style)
   *   command    browser editing command used to apply it
   *   marker     temporary value passed to that command
   *   isMarker(el, style)  true if the browser just wrote the marker here
   * }
   */
  function register(def) {
    props[def.key] = def;
  }

  // { color: 'red', size: 'large' } for a span/font element (only known values)
  function parse(el) {
    const style = el.getAttribute('style') || '';
    const out = {};
    Object.values(props).forEach((def) => {
      const m = style.match(new RegExp(`(?:^|;)\\s*${def.cssProp}:\\s*var\\(${def.varPrefix}([a-z]+)\\)`));
      let value = m && def.values.includes(m[1]) ? m[1] : null;
      if (!value && def.isMarker(el, style)) value = pending[def.key] ?? null;
      if (value && value !== def.values[0]) out[def.key] = value;
    });
    return out;
  }

  // clean span for a set of values, or null if there's nothing to style
  function makeSpan(values) {
    const parts = Object.entries(values)
      .filter(([key]) => props[key])
      .map(([key, v]) => `${props[key].cssProp}: var(${props[key].varPrefix}${v})`);
    if (!parts.length) return null;
    const span = document.createElement('span');
    span.setAttribute('style', parts.join('; '));
    return span;
  }

  // swap whatever the browser produced for clean spans (or unwrap them)
  function normalize(root) {
    root.querySelectorAll('span, font').forEach((el) => {
      const clean = makeSpan(parse(el));
      if (!clean) return el.replaceWith(...el.childNodes);
      if (el.tagName === 'SPAN') return el.setAttribute('style', clean.getAttribute('style'));
      clean.append(...el.childNodes);
      el.replaceWith(clean);
    });
  }

  // remember the selection as character positions, so it survives DOM clean-up
  function saveSelection(root) {
    const range = window.getSelection().getRangeAt(0);
    const before = document.createRange();
    before.selectNodeContents(root);
    before.setEnd(range.startContainer, range.startOffset);
    const start = before.toString().length;
    return { start, end: start + range.toString().length };
  }

  function restoreSelection(root, { start, end }) {
    const range = document.createRange();
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let pos = 0;
    let node;
    let startSet = false;
    while ((node = walker.nextNode())) {
      const next = pos + node.length;
      if (!startSet && start <= next) { range.setStart(node, start - pos); startSet = true; }
      if (startSet && end <= next) { range.setEnd(node, end - pos); break; }
      pos = next;
    }
    if (!startSet) return;
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  }

  function apply(editor, key, value) {
    const def = props[key];
    pending = { [key]: value };
    document.execCommand('styleWithCSS', false, true);
    document.execCommand(def.command, false, def.marker);
    document.execCommand('styleWithCSS', false, false);
    const saved = saveSelection(editor);
    normalize(editor);
    restoreSelection(editor, saved);
    pending = {};
    editor.dispatchEvent(new Event('input', { bubbles: true })); // save
  }

  // value at the start of the selection, e.g. 'red' (or the default value)
  function current(editor, key) {
    const node = window.getSelection().anchorNode;
    let el = node?.nodeType === 1 ? node : node?.parentElement;
    while (el && el !== editor) {
      if (el.tagName === 'SPAN') {
        const value = parse(el)[key];
        if (value) return value;
      }
      el = el.parentElement;
    }
    return props[key].values[0];
  }

  return { register, parse, makeSpan, normalize, apply, current };
})();
