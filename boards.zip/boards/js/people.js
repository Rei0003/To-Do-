// people.js — the people on the open board (owner + everyone it's shared with), for assigning tasks.
// Tasks store the assignee's email; this turns emails into names, initials and colours.
window.App = window.App || {};

App.people = (() => {
  const COLORS = ['#2F6FD6', '#2C8A4C', '#8C6BD6', '#CC3C76', '#D4650F', '#0F8B8D', '#7A5C3E', '#B4387A'];
  let list = []; // [{ email, name, pending, role }]
  const pics = new Map(); // email -> profile picture address (from anywhere we've seen that person)
  let loadedFor = null;

  const norm = (e) => String(e || '').toLowerCase();
  const me = () => norm(App.session.user?.email);
  const colorOf = (email) => COLORS[[...norm(email)].reduce((a, c) => a + c.charCodeAt(0), 0) % COLORS.length];
  const find = (email) => list.find((p) => p.email === norm(email)) || null;
  const nameOf = (email) => {
    if (!email) return '';
    if (norm(email) === me()) return 'You';
    const p = find(email);
    return p?.name || norm(email);
  };
  const initial = (email) => (find(email)?.name || norm(email) || '?').trim()[0].toUpperCase();
  // remember someone's picture (null = they have none)
  function remember(email, avatar) {
    if (!email) return;
    if (avatar) pics.set(norm(email), avatar);
    else if (avatar === null) pics.delete(norm(email));
  }

  async function load(boardId) {
    if (App.session.mode !== 'server' || !boardId) { list = []; loadedFor = null; refreshAll(); return; }
    try {
      const res = await App.boards.members.list(boardId);
      list = [
        { email: norm(res.owner.email), name: res.owner.name, role: 'owner' },
        ...res.members.map((m) => ({ email: norm(m.email), name: m.name, pending: !m.name, role: m.role, memberRole: m.member_role })),
      ];
      // people invited to a board this one sits in can be assigned too
      (res.inherited || []).forEach((m) => {
        if (!list.some((p) => p.email === norm(m.email))) {
          list.push({ email: norm(m.email), name: m.name, pending: !m.name, role: m.role, memberRole: m.member_role, inherited: m.from });
        }
      });
      (res.inherited || []).forEach((m) => { if (m.name) remember(m.email, m.avatar || null); });
      remember(res.owner.email, res.owner.avatar || null);
      res.members.forEach((m) => { if (m.name) remember(m.email, m.avatar || null); });
      loadedFor = boardId;
    } catch {
      list = [];
    }
    refreshAll();
  }

  // a small round avatar: their profile picture, or their initial on a colour
  function avatar(email, size = 20) {
    const el = document.createElement('span');
    el.className = 'person-avatar';
    el.style.setProperty('--pc', colorOf(email));
    el.style.setProperty('--ps', `${size}px`);
    el.textContent = initial(email);
    const pic = pics.get(norm(email)) || (norm(email) === me() ? App.session.user?.avatar : null);
    if (pic) {
      const img = document.createElement('img');
      img.alt = '';
      img.src = pic;
      img.onerror = () => img.remove(); // fall back to the initial
      el.classList.add('has-pic');
      el.append(img);
    }
    return el;
  }

  // fill an assignee chip for a task (also used to update them once names are known)
  function paintChip(chip, email) {
    chip.dataset.assignee = norm(email);
    chip.hidden = !email;
    if (!email) return;
    chip.replaceChildren(avatar(email, 16), document.createTextNode(nameOf(email)));
    chip.classList.toggle('is-me', norm(email) === me());
    const p = find(email);
    const role = p?.memberRole ? ` · ${p.memberRole.name}` : '';
    chip.dataset.tooltip = norm(email) === me()
      ? `Assigned to you${role}`
      : `Assigned to ${p?.name || norm(email)}${role}${p ? '' : '\n(no longer has access to this board)'}`;
  }
  function refreshAll() {
    document.querySelectorAll('.assignee-chip[data-assignee]').forEach((c) => {
      if (c.dataset.assignee) paintChip(c, c.dataset.assignee);
    });
  }

  // ---------- choosing someone ----------
  let menu = null;
  let anchorEl = null;
  function close() {
    menu?.remove();
    menu = null;
    anchorEl = null;
    document.removeEventListener('pointerdown', outside, true);
    document.removeEventListener('keydown', onKey, true);
  }
  function outside(e) { if (menu && !menu.contains(e.target) && !anchorEl?.contains(e.target)) close(); }
  function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } }

  function openPicker(anchor, current, onPick) {
    if (menu && anchorEl === anchor) return close();
    close();
    App.tooltip?.hide();
    anchorEl = anchor;
    menu = document.createElement('div');
    menu.className = 'draw-menu draw-panel people-menu';
    menu.setAttribute('role', 'menu');
    const title = document.createElement('p');
    title.className = 'draw-panel-title';
    title.textContent = 'Assign to';
    menu.append(title);
    if (!list.length) {
      const p = document.createElement('p');
      p.className = 'draw-panel-hint';
      p.textContent = 'Share this board to assign tasks to other people.';
      menu.append(p);
    }
    // you first, then the others
    const people = [...list].sort((a, b) => (b.email === me()) - (a.email === me()));
    people.forEach((p) => {
      const b = document.createElement('button');
      b.setAttribute('role', 'menuitemradio');
      b.setAttribute('aria-checked', String(p.email === norm(current)));
      b.append(avatar(p.email, 22));
      const label = document.createElement('span');
      label.className = 'people-label';
      label.innerHTML = '<strong></strong><small></small>';
      label.firstChild.textContent = p.email === me() ? `${p.name || 'You'} (you)` : (p.name || p.email);
      label.lastChild.textContent = p.pending ? 'Invited — not signed up yet' : p.role === 'view' ? 'Can view · can still tick off their tasks' : p.email;
      if (p.memberRole) label.firstChild.append(' ', App.roles.badge(p.memberRole, true));
      b.append(label);
      if (p.email === norm(current)) b.append(Object.assign(document.createElement('span'), { className: 'draw-menu-check', textContent: '✓' }));
      b.addEventListener('click', () => { close(); onPick(p.email); });
      menu.append(b);
    });
    if (current) {
      menu.append(document.createElement('hr'));
      const un = document.createElement('button');
      un.textContent = 'Unassign';
      un.addEventListener('click', () => { close(); onPick(null); });
      menu.append(un);
    }
    document.body.append(menu);
    const r = anchor.getBoundingClientRect();
    const h = menu.offsetHeight;
    let top = r.bottom + 4;
    if (top + h > window.innerHeight - 8) top = r.top - h - 4;
    menu.style.top = `${Math.max(8, top)}px`;
    menu.style.left = `${Math.min(r.left, window.innerWidth - menu.offsetWidth - 8)}px`;
    document.addEventListener('pointerdown', outside, true);
    document.addEventListener('keydown', onKey, true);
    menu.querySelector('button')?.focus();
  }

  return {
    load,
    remember,
    refresh: refreshAll,
    find,
    nameOf,
    roleOf: (email) => find(email)?.memberRole || null,
    avatar,
    paintChip,
    openPicker,
    isMe: (email) => !!email && norm(email) === me(),
    get available() { return App.session.mode === 'server'; },
    get loadedFor() { return loadedFor; },
  };
})();
