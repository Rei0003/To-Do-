// comments.js — the Comments panel on the right side of a board.
// Everyone with access can comment (viewers too). Comments can be about the whole board or about
// one card (click the card first); clicking that label later jumps to the card.
// Reply, resolve (hide finished conversations), edit or delete your own; the owner can delete any.
// With an account comments live on the server (api/comments.php); otherwise in this browser.
window.App = window.App || {};

App.comments = (() => {
  // ---------- where comments are kept ----------
  const localKey = (id) => `boards.comments.${id}`;
  const readLocal = (id) => { try { return JSON.parse(localStorage.getItem(localKey(id))) || []; } catch { return []; } };
  const writeLocal = (id, list) => localStorage.setItem(localKey(id), JSON.stringify(list));
  const now = () => Math.floor(Date.now() / 1000);

  const local = {
    // (on your own browser every comment is yours, so nothing is ever "new")
    list: async (b) => ({ comments: readLocal(b), seen_at: Number(localStorage.getItem(`boards.commentsSeen.${b}`)) || 0 }),
    seen: async (b) => { localStorage.setItem(`boards.commentsSeen.${b}`, String(now())); },
    async add(b, { text, card, parent }) {
      const list = readLocal(b);
      const p = parent && list.find((c) => c.id === parent);
      const c = {
        id: App.state.uid(), parent: parent || null, card: p ? p.card : (card || null), text,
        resolved: false, created_at: now(), updated_at: now(), author: { name: 'You' }, mine: true,
      };
      writeLocal(b, [...list, c]);
      return c;
    },
    async update(b, id, patch) {
      writeLocal(b, readLocal(b).map((c) => (c.id === id ? { ...c, ...patch, updated_at: patch.text ? now() : c.updated_at } : c)));
    },
    async remove(b, id) { writeLocal(b, readLocal(b).filter((c) => c.id !== id && c.parent !== id)); },
  };
  const api = (...a) => App.api.request(...a);
  const server = {
    list: async (b) => api('GET', `comments.php?board=${b}`), // { comments, seen_at }
    seen: async (b) => api('POST', `comments.php?board=${b}&action=seen`),
    add: async (b, body) => (await api('POST', `comments.php?board=${b}`, body)).comment,
    update: async (b, id, patch) => api('PATCH', `comments.php?id=${id}`, patch),
    remove: async (b, id) => api('DELETE', `comments.php?id=${id}`),
  };
  const repo = () => (App.session.mode === 'server' ? server : local);

  // ---------- helpers ----------
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  function ago(t) {
    const d = Math.max(0, now() - t);
    if (d < 60) return 'just now';
    if (d < 3600) return `${Math.floor(d / 60)} min ago`;
    if (d < 86400) return `${Math.floor(d / 3600)} h ago`;
    if (d < 172800) return 'yesterday';
    return new Date(t * 1000).toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
  }
  // text with clickable links (built from text nodes, so nothing in a comment can run as code)
  function textNodes(text) {
    const frag = document.createDocumentFragment();
    String(text).split(/(https?:\/\/[^\s<]+)/g).forEach((part, i) => {
      if (i % 2) {
        const a = document.createElement('a');
        a.href = part;
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        a.textContent = part;
        frag.append(a);
      } else frag.append(document.createTextNode(part));
    });
    return frag;
  }
  // a short name for a card: "Note: Drag cards by…"
  const TYPE = { note: 'Note', todo: 'To-do', media: 'Media', drawing: 'Canvas', calendar: 'Calendar', table: 'Table', chart: 'Chart', file: 'File', board: 'Board', shape: 'Shape', link: 'Link' };
  function cardLabel(id) {
    const c = App.state.getCard(id);
    if (!c) return 'a card that was deleted';
    const words = (c.text || c.title || c.caption || c.name || c.chart?.title || '').trim().replace(/\s+/g, ' ');
    const short = words.length > 34 ? `${words.slice(0, 33)}…` : words;
    return `${TYPE[c.type] || 'Card'}${short ? `: ${short}` : ''}`;
  }
  // scroll to a card and make it flash
  function jumpTo(id) {
    const top = App.state.topOf(id);
    const el = top && document.querySelector(`#canvas > .card[data-id="${top.id}"]`);
    if (!el) return;
    const vp = document.getElementById('viewport');
    vp.scrollTo({
      left: el.offsetLeft - (vp.clientWidth - 340) / 2 + el.offsetWidth / 2,
      top: el.offsetTop - vp.clientHeight / 2 + Math.min(el.offsetHeight, vp.clientHeight - 80) / 2,
      behavior: 'smooth',
    });
    el.classList.remove('is-flash');
    void el.offsetWidth;
    el.classList.add('is-flash');
  }
  const ICON = {
    bubble: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><path d="M2.5 3.5h11v7.5H8L5 13.5V11H2.5z"/></svg>',
    check: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 8.5l3 3 6-7"/></svg>',
    more: '<svg viewBox="0 0 16 16" fill="currentColor"><circle cx="3.5" cy="8" r="1.3"/><circle cx="8" cy="8" r="1.3"/><circle cx="12.5" cy="8" r="1.3"/></svg>',
    close: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>',
    target: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M9 3h4v4M13 3L8 8M7 4H3.5v8.5H12V9"/></svg>',
  };

  // ---------- state ----------
  let boardId = null;
  let comments = [];
  let showResolved = false;
  let aboutCard = null;   // the card a new comment will be about
  let lastCard = null;    // the card you clicked last
  let poll = 0;
  let panel;
  let button;

  const isOpen = () => panel && !panel.hidden;
  let seenAt = 0;        // when you last opened the comments (from the server)
  let newSince = null;   // comments newer than this get a "New" marker while the panel is open
  const isNew = (c, since) => !c.mine && c.created_at > since;
  const unreadCount = () => comments.filter((c) => isNew(c, seenAt)).length;
  // you've looked: the counter goes away
  async function markSeen() {
    if (!boardId) return;
    try { await repo().seen(boardId); } catch { /* try again next time */ }
    seenAt = now();
    setCount(0);
  }

  function setCount(n) {
    const badge = button.querySelector('.cm-count');
    badge.textContent = n > 99 ? '99+' : String(n);
    badge.hidden = !n;
    button.dataset.tooltip = n ? `${n} new comment${n === 1 ? '' : 's'} or repl${n === 1 ? 'y' : 'ies'}` : 'Comments';
  }

  async function reload({ keepScroll } = {}) {
    if (!boardId) return;
    try {
      const res = await repo().list(boardId);
      comments = res.comments || [];
      if (typeof res.seen_at === 'number') seenAt = res.seen_at;
    } catch { return; }
    comments.forEach((c) => { if (c.author?.email) App.people.remember(c.author.email, c.author.avatar || null); });
    if (isOpen()) {
      // you're looking at them: anything new counts as read straight away
      if (unreadCount()) markSeen();
      render(keepScroll);
    } else setCount(unreadCount());
  }

  // ---------- drawing the panel ----------
  function render(keepScroll) {
    const list = panel.querySelector('.cm-list');
    const scroll = list.scrollTop;
    const atBottom = list.scrollHeight - list.scrollTop - list.clientHeight < 40;
    const tops = comments.filter((c) => !c.parent && (showResolved || !c.resolved));
    const resolvedCount = comments.filter((c) => !c.parent && c.resolved).length;
    panel.querySelector('.cm-resolved-toggle').hidden = !resolvedCount;
    panel.querySelector('.cm-resolved-toggle span').textContent = showResolved ? 'Hide resolved' : `Show resolved (${resolvedCount})`;

    if (!tops.length) {
      list.innerHTML = `<div class="cm-empty">${ICON.bubble}<p><strong>No comments yet</strong></p>
        <p>Ask a question or leave feedback. Click a card first to comment on that card.</p></div>`;
    } else {
      list.replaceChildren(...tops.map(thread));
    }
    if (keepScroll && !atBottom) list.scrollTop = scroll;
    else list.scrollTop = list.scrollHeight;
  }

  function canResolve(c) { return c.mine || App.access.canEditAll(); }
  function canDelete(c) { return c.mine || App.access.canManage(); }

  function commentEl(c) {
    const el = document.createElement('div');
    el.className = `cm-item${newSince !== null && isNew(c, newSince) ? ' is-new' : ''}`;
    el.dataset.id = c.id;
    const who = c.author?.email && App.session.user && c.author.email.toLowerCase() === App.session.user.email.toLowerCase() ? 'You' : (c.author?.name || 'You');
    el.innerHTML = `
      <div class="cm-head">
        <span class="cm-who"></span>
        ${newSince !== null && isNew(c, newSince) ? '<span class="cm-new">New</span>' : ''}
        <span class="cm-time" title="${esc(new Date(c.created_at * 1000).toLocaleString())}">${ago(c.created_at)}${c.updated_at > c.created_at + 5 ? ' · edited' : ''}</span>
        <span class="cm-actions">
          ${!c.parent && canResolve(c) ? `<button class="cm-btn" data-cm="resolve" aria-label="${c.resolved ? 'Reopen' : 'Resolve'}" data-tooltip="${c.resolved ? 'Reopen' : 'Resolve (hide this conversation)'}">${ICON.check}</button>` : ''}
          ${c.mine || canDelete(c) ? `<button class="cm-btn" data-cm="menu" aria-label="More" data-tooltip="Edit or delete">${ICON.more}</button>` : ''}
        </span>
      </div>
      <div class="cm-text"></div>`;
    const avatar = c.author?.email ? App.people.avatar(c.author.email, 22) : Object.assign(document.createElement('span'), { className: 'person-avatar', textContent: 'Y' });
    el.querySelector('.cm-who').append(avatar, document.createTextNode(who));
    const role = c.author?.email && App.people.roleOf(c.author.email);
    if (role) el.querySelector('.cm-who').append(App.roles.badge(role, true));
    el.querySelector('.cm-text').append(textNodes(c.text));
    return el;
  }

  function thread(c) {
    const t = document.createElement('article');
    const fresh = newSince !== null && (isNew(c, newSince) || comments.some((x) => x.parent === c.id && isNew(x, newSince)));
    t.className = `cm-thread${c.resolved ? ' is-resolved' : ''}${fresh ? ' has-new' : ''}`;
    t.dataset.id = c.id;
    if (c.card) {
      const chip = document.createElement('button');
      chip.className = 'cm-card';
      chip.dataset.cm = 'jump';
      chip.dataset.card = c.card;
      chip.innerHTML = `${ICON.target}<span></span>`;
      chip.lastChild.textContent = cardLabel(c.card);
      chip.dataset.tooltip = 'Show this card on the board';
      t.append(chip);
    }
    if (c.resolved) {
      const r = document.createElement('p');
      r.className = 'cm-resolved-label';
      r.textContent = 'Resolved';
      t.append(r);
    }
    t.append(commentEl(c));
    comments.filter((x) => x.parent === c.id).forEach((reply) => {
      const r = commentEl(reply);
      r.classList.add('cm-reply');
      t.append(r);
    });
    if (!c.resolved) {
      const rb = document.createElement('button');
      rb.className = 'cm-reply-btn';
      rb.dataset.cm = 'reply';
      rb.textContent = 'Reply';
      t.append(rb);
    }
    return t;
  }

  // a small text box (replying or editing)
  function inlineEditor(after, initial, onSave, label) {
    const box = document.createElement('div');
    box.className = 'cm-inline';
    box.innerHTML = `<textarea rows="2" aria-label="${label}"></textarea>
      <div class="cm-inline-row"><button class="file-btn" data-x="cancel">Cancel</button>
      <button class="confirm-pop-btn btn-primary" data-x="save">${label === 'Reply' ? 'Reply' : 'Save'}</button></div>`;
    const ta = box.querySelector('textarea');
    ta.value = initial || '';
    after.after(box);
    ta.focus();
    ta.setSelectionRange(ta.value.length, ta.value.length);
    autosize(ta);
    const done = async (ok) => {
      if (ok) {
        const text = ta.value.trim();
        if (!text) return;
        box.querySelector('[data-x="save"]').disabled = true;
        try { await onSave(text); } catch (err) { box.querySelector('[data-x="save"]').disabled = false; alertIn(box, err.message); return; }
      }
      box.remove();
    };
    box.addEventListener('click', (e) => { const x = e.target.closest('[data-x]')?.dataset.x; if (x) done(x === 'save'); });
    ta.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); done(true); }
      if (e.key === 'Escape') { e.stopPropagation(); done(false); }
    });
    return box;
  }
  function alertIn(el, msg) {
    let p = el.querySelector('.cm-error');
    if (!p) { p = document.createElement('p'); p.className = 'cm-error'; el.append(p); }
    p.textContent = msg;
  }
  function autosize(ta) {
    const fit = () => { ta.style.height = 'auto'; ta.style.height = `${Math.min(160, ta.scrollHeight + 2)}px`; };
    ta.addEventListener('input', fit);
    fit();
  }

  // ---------- the composer at the bottom ----------
  function showAbout() {
    const row = panel.querySelector('.cm-about');
    const valid = aboutCard && App.state.getCard(aboutCard);
    row.hidden = !valid;
    if (valid) row.querySelector('.cm-about-name').textContent = cardLabel(aboutCard);
    panel.querySelector('.cm-hint').hidden = !!valid;
  }

  async function send() {
    const ta = panel.querySelector('.cm-compose textarea');
    const text = ta.value.trim();
    if (!text || !boardId) return;
    const btn = panel.querySelector('[data-cm="send"]');
    btn.disabled = true;
    try {
      const c = await repo().add(boardId, { text, card: aboutCard && App.state.getCard(aboutCard) ? aboutCard : null });
      comments.push(c);
      ta.value = '';
      ta.style.height = '';
      // (the card stays chosen for follow-up comments; × or another card changes it)
      
      render();
    } catch (err) {
      alertIn(panel.querySelector('.cm-compose'), err.message);
    } finally { btn.disabled = false; }
  }

  // ---------- open / close ----------
  function open() {
    if (!boardId) return;
    panel.hidden = false;
    button.setAttribute('aria-pressed', 'true');
    document.body.classList.add('has-comments');
    // a single selected card (or the one you clicked last) is what you'll comment on
    const sel = App.selection?.ids() || [];
    aboutCard = sel.length === 1 ? sel[0] : lastCard;
    showAbout();
    newSince = null;
    render();
    // once we know when you last looked (from the server), mark what's newer, then count it as read
    let opening = true;
    const before = { boardId };
    (async () => {
      try {
        const res = await repo().list(boardId);
        if (before.boardId !== boardId || panel.hidden) return;
        comments = res.comments || [];
        comments.forEach((c) => { if (c.author?.email) App.people.remember(c.author.email, c.author.avatar || null); });
        newSince = typeof res.seen_at === 'number' ? res.seen_at : seenAt;
        render();
        markSeen();
      } finally { opening = false; }
    })();
    clearInterval(poll);
    poll = setInterval(() => {
      if (document.hidden || panel.querySelector('.cm-inline textarea')) return;
      reload({ keepScroll: true });
    }, 5000);
    const ta = panel.querySelector('.cm-compose textarea');
    ta.dispatchEvent(new Event('input')); // size the box now that it's visible
    ta.focus({ preventScroll: true });
  }
  function close() {
    if (!panel || panel.hidden) return;
    panel.hidden = true;
    newSince = null;
    button.setAttribute('aria-pressed', 'false');
    document.body.classList.remove('has-comments');
    clearInterval(poll);
  }

  // ---------- setup ----------
  function init() {
    button = document.getElementById('comments-btn');
    panel = document.createElement('aside');
    panel.className = 'comments-panel';
    panel.hidden = true;
    panel.setAttribute('aria-label', 'Comments');
    panel.innerHTML = `
      <header class="cm-header">
        <h2>Comments</h2>
        <button class="cm-resolved-toggle file-btn" hidden><span></span></button>
        <button class="fv-close" data-cm="close" aria-label="Close comments">${ICON.close}</button>
      </header>
      <div class="cm-list" role="log" aria-live="polite"></div>
      <div class="cm-compose">
        <div class="cm-about" hidden>
          <span>About</span>
          <button class="cm-card" data-cm="jump-about">${ICON.target}<span class="cm-about-name"></span></button>
          <button class="cm-btn" data-cm="no-about" aria-label="Comment on the whole board instead" data-tooltip="Comment on the whole board instead">${ICON.close}</button>
        </div>
        <textarea rows="2" placeholder="Write a comment…" aria-label="Write a comment"></textarea>
        <div class="cm-compose-row">
          <span class="cm-hint">Tip: click a card first to comment on it · Ctrl+Enter sends</span>
          <button class="confirm-pop-btn btn-primary" data-cm="send">Comment</button>
        </div>
      </div>`;
    document.body.append(panel);
    autosize(panel.querySelector('.cm-compose textarea'));

    button.addEventListener('click', () => (isOpen() ? close() : open()));
    panel.querySelector('.cm-resolved-toggle').addEventListener('click', () => { showResolved = !showResolved; render(true); });
    panel.querySelector('.cm-compose textarea').addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); send(); }
      if (e.key === 'Escape') close();
    });

    panel.addEventListener('click', async (e) => {
      const btn = e.target.closest('[data-cm]');
      if (!btn) return;
      const a = btn.dataset.cm;
      const threadEl = btn.closest('.cm-thread');
      const itemEl = btn.closest('.cm-item');
      const c = itemEl && comments.find((x) => x.id === itemEl.dataset.id);
      if (a === 'close') close();
      if (a === 'send') send();
      if (a === 'jump') jumpTo(btn.dataset.card);
      if (a === 'jump-about') jumpTo(aboutCard);
      if (a === 'no-about') { aboutCard = null; showAbout(); }
      if (a === 'reply') {
        if (threadEl.querySelector('.cm-inline')) return;
        inlineEditor(btn, '', async (text) => {
          comments.push(await repo().add(boardId, { text, parent: threadEl.dataset.id }));
          render(true);
        }, 'Reply');
        btn.hidden = true;
      }
      if (a === 'resolve' && c) {
        await repo().update(boardId, c.id, { resolved: !c.resolved });
        c.resolved = !c.resolved;
        
        render(true);
      }
      if (a === 'menu' && c) {
        const items = [];
        if (c.mine) items.push(['edit', 'Edit']);
        if (canDelete(c)) items.push(['delete', c.parent ? 'Delete reply' : 'Delete comment']);
        const m = document.createElement('div');
        m.className = 'draw-menu draw-panel cm-menu';
        m.innerHTML = items.map(([k, label]) => `<button data-k="${k}" class="${k === 'delete' ? 'is-danger' : ''}">${label}</button>`).join('');
        document.body.append(m);
        const r = btn.getBoundingClientRect();
        m.style.top = `${r.bottom + 4}px`;
        m.style.left = `${Math.min(r.right - m.offsetWidth, window.innerWidth - m.offsetWidth - 8)}px`;
        const shut = (ev) => { if (!m.contains(ev.target)) { m.remove(); document.removeEventListener('pointerdown', shut, true); } };
        document.addEventListener('pointerdown', shut, true);
        m.addEventListener('click', async (ev) => {
          const k = ev.target.closest('[data-k]')?.dataset.k;
          if (!k) return;
          m.remove();
          document.removeEventListener('pointerdown', shut, true);
          if (k === 'edit') {
            const textEl = itemEl.querySelector('.cm-text');
            textEl.hidden = true;
            const box = inlineEditor(textEl, c.text, async (text) => {
              await repo().update(boardId, c.id, { text });
              c.text = text;
              c.updated_at = now();
              render(true);
            }, 'Edit comment');
            box.querySelector('[data-x="cancel"]').addEventListener('click', () => { textEl.hidden = false; });
          }
          if (k === 'delete') {
            App.confirmPopover.open(btn, {
              title: c.parent ? 'Delete this reply?' : 'Delete this comment?',
              message: c.parent ? '' : 'Its replies are deleted too.',
              confirmLabel: 'Delete',
              onConfirm: async () => {
                await repo().remove(boardId, c.id);
                comments = comments.filter((x) => x.id !== c.id && x.parent !== c.id);
                
                render(true);
              },
            });
          }
        });
      }
    });

    // remember the card you clicked last (the comment will be about it)
    document.getElementById('canvas').addEventListener('pointerdown', (e) => {
      const card = e.target.closest('#canvas > .card');
      if (!card) return;
      lastCard = card.dataset.id;
      if (isOpen() && !panel.querySelector('.cm-compose textarea').value.trim()) {
        aboutCard = lastCard;
        showAbout();
      }
    }, true);
  }

  return {
    init,
    open,
    close,
    jumpTo,
    // the router tells us which board is open (and how many open comments it has)
    setBoard(id, count) {
      if (boardId !== id) { comments = []; lastCard = null; aboutCard = null; showResolved = false; seenAt = 0; newSince = null; }
      boardId = id;
      if (!id) { close(); return; }
      if (typeof count === 'number') setCount(count);
      else reload();
    },
    setCount: (n) => { if (!isOpen()) setCount(n); },
    // every comment on the open board (for the dashboard)
    all: async () => (boardId ? repo().list(boardId).then((r) => r.comments || []).catch(() => []) : []),
    // open the panel scrolled to one conversation
    show(id) {
      open();
      setTimeout(() => {
        const t = panel.querySelector(`.cm-thread[data-id="${id}"]`);
        t?.scrollIntoView({ block: 'center' });
        t?.classList.add('is-flash-thread');
        setTimeout(() => t?.classList.remove('is-flash-thread'), 1400);
      }, 120);
    },
  };
})();
