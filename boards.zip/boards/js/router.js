// router.js — which screen is showing, from the address bar:
//   #/login            log in / create account
//   #/boards           your boards
//   #/board/<id>       one board
window.App = window.App || {};

App.router = (() => {
  let info = { server: false, user: null, choseLocal: false };
  let openId = null;
  let openInfo = null;   // the open board's summary (access, members…)
  let poll = 0;          // checks shared boards for other people's changes

  const authEl = () => document.getElementById('screen-auth');
  const homeEl = () => document.getElementById('screen-home');

  function show(screen) {
    document.body.dataset.screen = screen;
    authEl().hidden = screen !== 'auth';
    homeEl().hidden = screen !== 'home';
    // the board behind other screens can't be reached with Tab
    document.querySelectorAll('.topbar, .toolbar, .viewport').forEach((el) => { el.inert = screen !== 'board'; });
    App.screens.closeMenu();
    App.selection?.clear();
    App.tooltip?.hide();
  }

  async function leaveBoard() {
    clearInterval(poll);
    App.share?.close();
    App.comments?.setBoard(null);
    App.dashboard?.setBoard(null);
    if (!openId) return;
    await App.storage.flush();
    App.storage.setTarget(null);
    openId = null;
  }

  async function openBoard(id) {
    if (openId === id) { show('board'); return; }
    await leaveBoard();
    document.body.dataset.loading = 'true';
    App.storage.pause(true);
    try {
      const { board, data, rev } = await App.boards.get(id);
      openInfo = board;
      App.access.set(board.access || null); // before drawing, so read-only cards are locked
      App.selection?.clear();
      App.board.clear(); // a fresh page for the new board
      App.state.load(data);
      App.title.refresh();
      const vp = document.getElementById('viewport');
      vp.scrollLeft = 0;
      vp.scrollTop = 0;
      App.storage.setTarget(id, rev);
      openId = id;
      localStorage.setItem(`boards.last.${App.session.user?.id || 'local'}`, id);
      show('board');
      showPath(board.path || []);
      showSharing();
      startPolling();
      App.people.load(id); // names for assigned tasks
      App.comments.setBoard(id, board.comments); // the Comments panel (and its count)
      App.dashboard.setBoard(id); // Canvas or Dashboard, as last used on this board
    } catch (err) {
      if (err.status === 401) { location.hash = '#/login'; return; }
      location.hash = '#/boards';
    } finally {
      App.storage.pause(false);
      delete document.body.dataset.loading;
    }
  }

  async function route() {
    const hash = location.hash || '#/boards';
    const m = hash.match(/^#\/board\/([\w-]+)/);
    const needsLogin = info.server && App.session.mode === 'local' && !App.session.user
      && localStorage.getItem('boards.mode') !== 'local';

    if (hash.startsWith('#/login')) {
      await leaveBoard();
      App.screens.auth(authEl(), { server: App.session.server, tab: hash.includes('register') ? 'register' : 'login' });
      show('auth');
      return;
    }
    if (needsLogin) { location.hash = '#/login'; return; }
    if (hash.startsWith('#/team')) {
      await leaveBoard();
      show('home');
      App.team.page(homeEl());
      return;
    }
    if (m) { await openBoard(m[1]); return; }
    await leaveBoard();
    show('home');
    App.screens.home(homeEl());
  }

  // breadcrumbs: Car projects › E34 build › (this board); ← goes up one level
  function showPath(path) {
    const nav = document.getElementById('breadcrumbs');
    const back = document.querySelector('.topbar-back');
    nav.hidden = !path.length;
    nav.replaceChildren(...path.flatMap((p) => {
      const a = document.createElement('a');
      a.href = `#/board/${p.id}`;
      a.textContent = p.title || 'Untitled board';
      const sep = document.createElement('span');
      sep.className = 'crumb-sep';
      sep.textContent = '›';
      return [a, sep];
    }));
    const parent = path[path.length - 1];
    back.href = parent ? `#/board/${parent.id}` : '#/boards';
    back.dataset.tooltip = parent ? `Back to ${parent.title || 'Untitled board'}` : 'All boards';
    back.setAttribute('aria-label', back.dataset.tooltip);
  }

  // ---------- sharing on the board page ----------
  const ROLE_TEXT = { view: 'View only', edit: 'Shared with you', cards: 'You can edit some cards' };
  function showSharing() {
    const shareBtn = document.getElementById('share-btn');
    const badge = document.getElementById('access-badge');
    const a = openInfo?.access;
    const server = App.session.mode === 'server';
    shareBtn.hidden = !server;
    shareBtn.querySelector('span').textContent = a?.role === 'owner'
      ? (openInfo.members ? `Shared · ${openInfo.members + 1}` : 'Share') : 'People';
    shareBtn.dataset.tooltip = a?.role === 'owner' ? 'Invite people and choose what they can do' : 'Who has access';
    badge.hidden = !a || a.role === 'owner';
    if (!badge.hidden) {
      badge.textContent = ROLE_TEXT[a.role];
      badge.dataset.role = a.role;
      badge.dataset.tooltip = `${a.owner.name}’s board${a.role === 'cards' ? '\nHighlighted cards are yours to edit' : ''}`;
    }
    document.getElementById('board-title').readOnly = !App.access.canEditAll();
  }

  // shared boards: every few seconds, pick up other people's changes
  // (not while you have unsaved changes or are typing)
  function startPolling() {
    clearInterval(poll);
    const shared = openInfo?.access && (openInfo.access.role !== 'owner' || openInfo.members > 0);
    if (!shared || App.session.mode !== 'server') return;
    poll = setInterval(async () => {
      if (!openId || document.hidden || App.storage.hasUnsaved() || App.cardPicker?.active) return;
      const a = document.activeElement;
      if (a && a.closest('#canvas') && a.matches('input, textarea, select, [contenteditable="true"]')) return;
      try {
        const { rev, comments } = await App.api.request('GET', `boards.php?id=${openId}&rev_only=1`);
        App.comments.setCount(comments);
        if (rev > (App.storage.rev ?? 0)) refreshOpenBoard();
      } catch (err) {
        if (err.status === 404) { clearInterval(poll); location.hash = '#/boards'; } // access removed
      }
    }, 5000);
  }

  // reload the open board in place (keeps where you're looking)
  async function refreshOpenBoard() {
    const id = openId;
    const vp = document.getElementById('viewport');
    const { scrollLeft, scrollTop } = vp;
    const { board, data, rev } = await App.boards.get(id);
    if (openId !== id || App.storage.hasUnsaved()) return;
    openInfo = board;
    App.storage.pause(true);
    App.access.set(board.access || null);
    App.board.clear();
    App.state.load(data);
    App.title.refresh();
    showPath(board.path || []);
    App.storage.setTarget(id, rev);
    App.storage.pause(false);
    vp.scrollLeft = scrollLeft;
    vp.scrollTop = scrollTop;
    showSharing();
  }

  // the board page's top bar: back, save status, account, "changed elsewhere" bar
  function wireTopbar() {
    const status = document.getElementById('save-status');
    const conflict = document.getElementById('conflict-bar');
    App.storage.onStatus((s, detail) => {
      const local = App.session.mode === 'local';
      status.dataset.state = s;
      status.textContent = {
        saved: local ? 'Saved in this browser' : 'Saved',
        saving: 'Saving…',
        unsaved: 'Saving…',
        error: 'Not saved',
        conflict: 'Not saved',
      }[s];
      status.dataset.tooltip = s === 'error' ? (detail || 'Couldn’t save') : '';
      conflict.hidden = s !== 'conflict';
    });
    conflict.addEventListener('click', async (e) => {
      const a = e.target.closest('[data-conflict]')?.dataset.conflict;
      if (a === 'mine') App.storage.keepMine();
      if (a === 'theirs') {
        const id = openId;
        App.storage.setTarget(null); // drop the unsaved changes
        openId = null;
        conflict.hidden = true;
        await openBoard(id);
      }
    });
    App.session.onChange(() => {
      document.querySelectorAll('.account-btn').forEach((b) => App.screens.accountButton(b));
      App.people.refresh(); // assignee chips etc.
    });
    document.getElementById('share-btn').addEventListener('click', () => { if (openId) App.share.open(openId); });
  }

  async function start() {
    show('loading');
    wireTopbar();
    info = await App.session.start();
    App.screens.accountButton(document.getElementById('account-btn'));
    window.addEventListener('hashchange', route);
    if (!location.hash) {
      const last = localStorage.getItem(`boards.last.${info.user?.id || 'local'}`);
      if (info.server && !info.user && !info.choseLocal) location.hash = '#/login';
      else location.hash = last ? `#/board/${last}` : '#/boards';
      return; // hashchange runs route()
    }
    route();
  }

  // after inviting/removing people: the board now counts as shared (or not)
  async function sharingChanged() {
    if (!openId) return;
    try { openInfo = (await App.boards.get(openId)).board; } catch { return; }
    showSharing();
    startPolling();
    App.people.load(openId);
  }

  return { start, sharingChanged };
})();
