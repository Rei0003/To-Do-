// state.js — the single source of truth for board data.
// Structural changes (add/remove card) notify listeners so the board re-renders.
// Small edits (typing, moving, ticking) just save, so focus isn't lost.
window.App = window.App || {};

App.state = (() => {
  const listeners = new Set();
  const uid = () => Math.random().toString(36).slice(2, 10);

  function starterBoard() {
    return {
      title: 'My first board',
      cards: [
        {
          id: uid(), type: 'note', x: 96, y: 72, z: 1, color: 'yellow',
          text: 'Drag cards by their top edge.\nDouble-click empty space to add a note.',
        },
        {
          id: uid(), type: 'todo', x: 392, y: 72, z: 2, color: 'none',
          title: 'This week',
          items: [
            { id: uid(), text: 'Sketch the board layout', done: true },
            { id: uid(), text: 'Add a column card type', done: false, priority: 'high' },
          ],
        },
      ],
    };
  }

  let data = App.storage.load() || starterBoard();
  data.connections = data.connections || []; // wires between cards

  const save = () => App.storage.save(data);
  const notify = () => listeners.forEach((fn) => fn(data));
  const getCard = (id) => data.cards.find((c) => c.id === id);
  const topZ = () => data.cards.reduce((max, c) => Math.max(max, c.z || 0), 0);

  return {
    uid,
    get: () => data,
    getCard,

    subscribe(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },

    setTitle(title) {
      data.title = title;
      save();
    },

    addCard(card) {
      const full = { id: uid(), z: topZ() + 1, color: 'none', ...card };
      data.cards.push(full);
      save();
      notify();
      return full;
    },

    // Silent update: saves without re-rendering
    updateCard(id, patch) {
      const card = getCard(id);
      if (!card) return;
      Object.assign(card, patch);
      save();
    },

    // removes the card and anything nested inside it
    removeCard(id) {
      const gone = new Set([id, ...data.cards.filter((c) => c.parent === id).map((c) => c.id)]);
      data.cards = data.cards.filter((c) => !gone.has(c.id));
      data.connections = data.connections.filter((w) => !gone.has(w.from.card) && !gone.has(w.to.card));
      save();
      notify();
    },

    // ---- cards inside cards ----
    childrenOf: (parentId) => data.cards.filter((c) => c.parent === parentId),

    nestCard(id, parentId) {
      const card = getCard(id);
      if (!card || id === parentId || !getCard(parentId)) return;
      card.parent = parentId;
      // a wire between the card and its new parent would go nowhere
      data.connections = data.connections.filter((w) =>
        !((w.from.card === id && w.to.card === parentId) || (w.from.card === parentId && w.to.card === id)));
      save();
      notify();
    },

    unnestCard(id, x, y) {
      const card = getCard(id);
      if (!card) return;
      delete card.parent;
      Object.assign(card, { x: Math.round(x), y: Math.round(y), z: topZ() + 1 });
      save();
      notify();
    },

    // ---- wires between cards ----
    addConnection(from, to) {
      const exists = data.connections.some((w) =>
        (w.from.card === from.card && w.to.card === to.card)
        || (w.from.card === to.card && w.to.card === from.card));
      if (exists || from.card === to.card) return null;
      const conn = { id: uid(), from, to, color: 'none' };
      data.connections.push(conn);
      save();
      notify();
      return conn;
    },

    updateConnection(id, patch) {
      const conn = data.connections.find((w) => w.id === id);
      if (!conn) return;
      Object.assign(conn, patch);
      save();
      notify();
    },

    removeConnection(id) {
      data.connections = data.connections.filter((w) => w.id !== id);
      save();
      notify();
    },

    bringToFront(id) {
      const card = getCard(id);
      if (!card) return 0;
      const top = topZ();
      if (card.z !== top) card.z = top + 1;
      save();
      return card.z;
    },

    clear() {
      data.cards = [];
      data.connections = [];
      save();
      notify();
    },
  };
})();
