// state.js — the single source of truth for board data.
// Structural changes (add/remove card) notify listeners so the board re-renders.
// Small edits (typing, moving, ticking) just save, so focus isn't lost.
window.App = window.App || {};

App.state = (() => {
  const listeners = new Set();
  const cardListeners = new Set();
  const uid = () => Math.random().toString(36).slice(2, 10);

  function starterBoard() {
    return {
      title: 'My first board',
      cards: [
        {
          id: uid(), type: 'note', x: 96, y: 72, z: 1, color: 'yellow',
          text: 'Drag cards by their top edge.\nDouble-click empty space to add a note.',
        },
        {
          id: uid(), type: 'todo', x: 392, y: 72, z: 2, color: 'none',
          title: 'This week',
          items: [
            { id: uid(), text: 'Sketch the board layout', done: true },
            { id: uid(), text: 'Add a column card type', done: false, priority: 'high' },
          ],
        },
      ],
    };
  }

  let data = App.storage.load() || starterBoard();
  data.connections = data.connections || []; // wires between cards
  // older wires had their start fixed to one side; starts now follow the cards around
  data.connections.forEach((w) => {
    if (!w.v) { w.from.side = 'auto'; w.v = 2; }
  });

  const save = () => App.storage.save(data);
  const notify = () => listeners.forEach((fn) => fn(data));
  const getCard = (id) => data.cards.find((c) => c.id === id);
  const topZ = () => data.cards.reduce((max, c) => Math.max(max, c.z || 0), 0);

  return {
    uid,
    get: () => data,
    getCard,

    subscribe(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },

    setTitle(title) {
      data.title = title;
      save();
    },

    addCard(card) {
      const full = { id: uid(), z: topZ() + 1, color: 'none', ...card };
      data.cards.push(full);
      save();
      notify();
      return full;
    },

    // Silent update: saves without re-rendering
    updateCard(id, patch) {
      const card = getCard(id);
      if (!card) return;
      Object.assign(card, patch);
      save();
      cardListeners.forEach((fn) => fn(id)); // e.g. a chart following a table
    },

    // be told whenever one card's data changes (even small edits that don't redraw the board)
    onCardChange(fn) {
      cardListeners.add(fn);
      return () => cardListeners.delete(fn);
    },

    // removes the card and anything nested inside it (at any depth)
    removeCard(id) {
      const gone = new Set([id]);
      let grew = true;
      while (grew) { // collect children, grandchildren, …
        grew = false;
        data.cards.forEach((c) => {
          if (c.parent && gone.has(c.parent) && !gone.has(c.id)) { gone.add(c.id); grew = true; }
        });
      }
      data.cards = data.cards.filter((c) => !gone.has(c.id));
      data.connections = data.connections.filter((w) => !gone.has(w.from.card) && !gone.has(w.to.card));
      save();
      notify();
    },

    // ---- cards inside cards ----
    // children of a card: itemId = null -> attached to the card itself, an id -> attached to that task
    childrenOf: (parentId, itemId = null) =>
      data.cards.filter((c) => c.parent === parentId && (c.parentItem || null) === itemId),
    allChildrenOf: (parentId) => data.cards.filter((c) => c.parent === parentId),
    // children, grandchildren, … of a card
    descendantsOf(parentId) {
      const out = [];
      const walk = (pid) => data.cards.forEach((c) => {
        if (c.parent === pid) { out.push(c); walk(c.id); }
      });
      walk(parentId);
      return out;
    },
    // the card on the board that (eventually) contains this one
    topOf(id) {
      let c = getCard(id);
      while (c?.parent) c = getCard(c.parent);
      return c;
    },

    // itemId (optional) attaches it to one task in a to-do list
    nestCard(id, parentId, itemId = null) {
      const card = getCard(id);
      if (!card || id === parentId || !getCard(parentId)) return;
      // never put a card inside one of its own attachments
      for (let p = getCard(parentId); p; p = p.parent ? getCard(p.parent) : null) {
        if (p.id === id) return;
      }
      card.parent = parentId;
      if (itemId) card.parentItem = itemId;
      else delete card.parentItem;
      // a wire between the card and its new parent would go nowhere
      data.connections = data.connections.filter((w) =>
        !((w.from.card === id && w.to.card === parentId) || (w.from.card === parentId && w.to.card === id)));
      save();
      notify();
    },

    unnestCard(id, x, y) {
      const card = getCard(id);
      if (!card) return;
      delete card.parent;
      delete card.parentItem;
      Object.assign(card, { x: Math.round(x), y: Math.round(y), z: topZ() + 1 });
      save();
      notify();
    },

    // ---- wires between cards ----
    // an end is { card, side, item? } — item is set when the wire goes to a single task
    addConnection(from, to) {
      const key = (end) => `${end.card}/${end.item || ''}`;
      const [a, b] = [key(from), key(to)];
      if (a === b) return null;
      const exists = data.connections.some((w) => {
        const [x, y] = [key(w.from), key(w.to)];
        return (x === a && y === b) || (x === b && y === a);
      });
      if (exists) return null;
      const conn = { id: uid(), from, to, color: 'none', v: 2 };
      data.connections.push(conn);
      save();
      notify();
      return conn;
    },

    updateConnection(id, patch) {
      const conn = data.connections.find((w) => w.id === id);
      if (!conn) return;
      Object.assign(conn, patch);
      save();
      notify();
    },

    // a task was deleted: its attachments move up to the list itself
    releaseTaskChildren(cardId, itemId) {
      const kids = data.cards.filter((c) => c.parent === cardId && c.parentItem === itemId);
      if (!kids.length) return;
      kids.forEach((c) => delete c.parentItem);
      save();
      notify();
    },

    // wires attached to one task (when that task is deleted)
    removeTaskConnections(cardId, itemId) {
      const hit = (end) => end.card === cardId && end.item === itemId;
      const before = data.connections.length;
      data.connections = data.connections.filter((w) => !hit(w.from) && !hit(w.to));
      if (data.connections.length === before) return;
      save();
      notify();
    },

    removeConnection(id) {
      data.connections = data.connections.filter((w) => w.id !== id);
      save();
      notify();
    },

    bringToFront(id) {
      const card = getCard(id);
      if (!card) return 0;
      const top = topZ();
      if (card.z !== top) card.z = top + 1;
      save();
      return card.z;
    },

    clear() {
      data.cards = [];
      data.connections = [];
      save();
      notify();
    },
  };
})();
