// state.js — the single source of truth for board data.
// Structural changes (add/remove card) notify listeners so the board re-renders.
// Small edits (typing, moving, ticking) just save, so focus isn't lost.
window.App = window.App || {};

App.state = (() => {
  const listeners = new Set();
  const uid = () => Math.random().toString(36).slice(2, 10);

  function starterBoard() {
    return {
      title: 'My first board',
      cards: [
        {
          id: uid(), type: 'note', x: 96, y: 72, z: 1, color: 'yellow',
          text: 'Drag cards by their top edge.\nDouble-click empty space to add a note.',
        },
        {
          id: uid(), type: 'todo', x: 392, y: 72, z: 2, color: 'none',
          title: 'This week',
          items: [
            { id: uid(), text: 'Sketch the board layout', done: true },
            { id: uid(), text: 'Add a column card type', done: false, priority: 'high' },
          ],
        },
      ],
    };
  }

  let data = App.storage.load() || starterBoard();

  const save = () => App.storage.save(data);
  const notify = () => listeners.forEach((fn) => fn(data));
  const getCard = (id) => data.cards.find((c) => c.id === id);
  const topZ = () => data.cards.reduce((max, c) => Math.max(max, c.z || 0), 0);

  return {
    uid,
    get: () => data,
    getCard,

    subscribe(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },

    setTitle(title) {
      data.title = title;
      save();
    },

    addCard(card) {
      const full = { id: uid(), z: topZ() + 1, color: 'none', ...card };
      data.cards.push(full);
      save();
      notify();
      return full;
    },

    // Silent update: saves without re-rendering
    updateCard(id, patch) {
      const card = getCard(id);
      if (!card) return;
      Object.assign(card, patch);
      save();
    },

    removeCard(id) {
      data.cards = data.cards.filter((c) => c.id !== id);
      save();
      notify();
    },

    bringToFront(id) {
      const card = getCard(id);
      if (!card) return 0;
      const top = topZ();
      if (card.z !== top) card.z = top + 1;
      save();
      return card.z;
    },

    clear() {
      data.cards = [];
      save();
      notify();
    },
  };
})();
