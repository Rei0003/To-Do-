// palette.js — a row of colour swatches used by every colour choice in the app:
// preset colours, then your saved custom colours, then a "+" to make a new one.
// When there are more colours than fit, arrows appear at both ends,
// and the mouse wheel scrolls the row too. Right-click a saved colour to remove it.
window.App = window.App || {};

App.palette = (() => {
  const palettes = new Set(); // to refresh when saved colours change

  App.savedColors.subscribe(() => {
    palettes.forEach((p) => {
      if (p.mounted && !p.el.isConnected) palettes.delete(p); // its card was removed
      else p.refresh();
    });
  });

  const isCustom = (v) => typeof v === 'string' && v.startsWith('#');

  /**
   * options:
   *  presets   [{ value, label, css }] — css is the swatch's colour (any CSS colour / var())
   *  value     selected value
   *  onPick    (value) => {}   — preset value or '#RRGGBB(AA)'
   *  visible   how many swatches fit before arrows appear (default 7)
   *  size      swatch size in px (default 18)
   *  alpha     allow see-through custom colours (default true)
   *  variant   'dark' for dark bars (text formatting bar)
   *  beforeCustom  () => {} — called just before the custom colour box opens
   *  customStart   () => starting colour for the custom box
   */
  function create(options) {
    const { presets, onPick, visible = 7, size = 18, alpha = true, variant, beforeCustom, customStart } = options;
    let value = options.value ?? presets[0]?.value;

    const el = document.createElement('div');
    el.className = `pal${variant ? ` pal--${variant}` : ''}`;
    el.style.setProperty('--pal-size', `${size}px`);
    el.style.setProperty('--pal-visible', visible);
    el.innerHTML = `
      <button class="pal-arrow" data-dir="-1" aria-label="Previous colours" tabindex="-1">
        <svg viewBox="0 0 10 10"><path d="M6.5 2L3.5 5l3 3" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
      <div class="pal-track" role="listbox" aria-label="Colours"></div>
      <button class="pal-arrow" data-dir="1" aria-label="More colours" tabindex="-1">
        <svg viewBox="0 0 10 10"><path d="M3.5 2l3 3-3 3" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
      <button class="pal-add" aria-label="Custom colour" data-tooltip="Custom colour…">
        <svg viewBox="0 0 10 10"><path d="M5 1.5v7M1.5 5h7" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg></button>`;
    const track = el.querySelector('.pal-track');
    const [prev, next] = el.querySelectorAll('.pal-arrow');
    const addBtn = el.querySelector('.pal-add');

    function swatch(v, label, css, saved) {
      const b = document.createElement('button');
      b.className = `pal-swatch${saved ? ' pal-swatch--saved' : ''}`;
      b.dataset.value = v;
      b.style.setProperty('--c', css);
      b.setAttribute('role', 'option');
      b.setAttribute('aria-label', label);
      b.dataset.tooltip = saved ? `${label}\nRight-click to remove` : label;
      return b;
    }

    function arrows() {
      const over = track.scrollWidth > track.clientWidth + 1;
      el.classList.toggle('is-overflowing', over);
      prev.disabled = track.scrollLeft <= 1;
      next.disabled = track.scrollLeft + track.clientWidth >= track.scrollWidth - 1;
    }

    function mark() {
      track.querySelectorAll('.pal-swatch').forEach((b) => {
        const on = b.dataset.value === String(value);
        b.setAttribute('aria-selected', String(on));
      });
    }

    function refresh() {
      const saved = App.savedColors.list().filter((c) => alpha || c.length === 7);
      track.replaceChildren(
        ...presets.map((p) => swatch(p.value, p.label, p.css, false)),
        ...saved.map((c) => swatch(c, c, c, true)),
      );
      mark();
      requestAnimationFrame(arrows);
    }

    // show the selected swatch if it's scrolled out of view
    function reveal() {
      const sel = track.querySelector('[aria-selected="true"]');
      if (!sel) return;
      const l = sel.offsetLeft - track.offsetLeft;
      if (l < track.scrollLeft) track.scrollLeft = l - 4;
      else if (l + sel.offsetWidth > track.scrollLeft + track.clientWidth) track.scrollLeft = l + sel.offsetWidth - track.clientWidth + 4;
    }

    function pick(v) {
      value = v;
      mark();
      onPick?.(v);
    }

    el.addEventListener('click', (e) => {
      const sw = e.target.closest('.pal-swatch');
      if (sw) return pick(sw.dataset.value);
      const arrow = e.target.closest('.pal-arrow');
      if (arrow) {
        track.scrollBy({ left: +arrow.dataset.dir * (size + 6) * Math.max(1, visible - 2), behavior: 'smooth' });
        return;
      }
      if (e.target.closest('.pal-add')) {
        beforeCustom?.();
        App.colorPopover.open(addBtn, {
          value: customStart?.() || (isCustom(value) ? value : '#3B82F6'),
          alpha,
          onPick: (c) => { pick(c); requestAnimationFrame(reveal); },
        });
      }
    });

    // right-click a saved colour to remove it
    track.addEventListener('contextmenu', (e) => {
      const sw = e.target.closest('.pal-swatch--saved');
      if (!sw) return;
      e.preventDefault();
      e.stopPropagation();
      App.confirmPopover.open(sw, {
        title: 'Remove this saved colour?',
        message: 'Things already using it keep their colour.',
        confirmLabel: 'Remove',
        onConfirm: () => App.savedColors.remove(sw.dataset.value),
      });
    });
    // don't let the board start panning from a right-click here
    track.addEventListener('pointerdown', (e) => { if (e.button === 2) e.stopPropagation(); });

    // mouse wheel scrolls the row sideways
    el.addEventListener('wheel', (e) => {
      if (!el.classList.contains('is-overflowing')) return;
      e.preventDefault();
      e.stopPropagation();
      track.scrollLeft += (Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY) * (e.deltaMode === 1 ? 20 : 1);
    }, { passive: false });

    track.addEventListener('scroll', arrows);
    const instance = { el, mounted: false, refresh };
    new ResizeObserver(() => {
      if (el.isConnected) instance.mounted = true;
      arrows();
    }).observe(track);
    palettes.add(instance);

    refresh();

    return {
      el,
      set(v) { value = v; mark(); requestAnimationFrame(reveal); },
      refresh,
    };
  }

  return { create, isCustom };
})();
