// media-store.js — where uploaded files (images, video, audio, documents…) live.
// Cards only store a mediaId pointing here.
//  • without an account: in this browser (IndexedDB — localStorage is too small for files)
//  • with an account: on the server (api/files.php), so they follow you to any computer.
//    There, files used by several boards (e.g. duplicated ones) are shared, and the server
//    deletes files once no board uses them — so copy() and remove() don't need to do anything.
window.App = window.App || {};

App.mediaStore = (() => {
  const DB_NAME = 'boards-media';
  const STORE = 'files';
  const urls = new Map(); // mediaId -> object URL, so files load once per session
  let dbPromise;

  function open() {
    dbPromise ||= new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => req.result.createObjectStore(STORE);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }

  async function run(mode, action) {
    const db = await open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, mode);
      const req = action(tx.objectStore(STORE));
      tx.oncomplete = () => resolve(req?.result);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  }

  const local = {
    async put(file) {
      const id = App.state.uid();
      await run('readwrite', (store) => store.put(file, id));
      return id;
    },

    // the stored file itself (e.g. to draw an audio waveform)
    async getBlob(id) {
      return run('readonly', (store) => store.get(id));
    },

    async getUrl(id) {
      if (urls.has(id)) return urls.get(id);
      const blob = await run('readonly', (store) => store.get(id));
      if (!blob) return null;
      const url = URL.createObjectURL(blob);
      urls.set(id, url);
      return url;
    },

    // a separate copy of a stored file (used when duplicating a card)
    async copy(id) {
      const blob = await run('readonly', (store) => store.get(id));
      if (!blob) return null;
      const newId = App.state.uid();
      await run('readwrite', (store) => store.put(blob, newId));
      return newId;
    },

    async remove(id) {
      if (urls.has(id)) URL.revokeObjectURL(urls.get(id));
      urls.delete(id);
      await run('readwrite', (store) => store.delete(id));
    },

    async clear() {
      urls.forEach((url) => URL.revokeObjectURL(url));
      urls.clear();
      await run('readwrite', (store) => store.clear());
    },
  };

  // ---------- on the server (logged in) ----------
  const server = {
    async put(file) {
      const form = new FormData();
      form.append('file', file);
      form.append('type', file.type || '');
      const res = await App.api.request('POST', 'files.php', undefined, { form });
      return res.id;
    },
    getBlob: (id) => fetch(`api/files.php?id=${encodeURIComponent(id)}`, { credentials: 'same-origin' })
      .then((r) => (r.ok ? r.blob() : null)),
    getUrl: async (id) => `api/files.php?id=${encodeURIComponent(id)}`,
    copy: async (id) => id,       // shared; the server keeps it while any board uses it
    remove: async () => {},       // the server tidies up unused files itself
    clear: async () => {},
  };

  let current = local;
  return {
    put: (file) => current.put(file),
    getBlob: (id) => current.getBlob(id),
    getUrl: (id) => current.getUrl(id),
    copy: (id) => current.copy(id),
    remove: (id) => current.remove(id),
    clear: () => current.clear(),
    useServer(on) { current = on ? server : local; },
    local, // used when copying this browser's boards into an account
  };
})();
