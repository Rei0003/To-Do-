// media-store.js — keeps image/video files in IndexedDB.
// localStorage is too small for media, so cards only store a mediaId pointing here.
window.App = window.App || {};

App.mediaStore = (() => {
  const DB_NAME = 'boards-media';
  const STORE = 'files';
  const urls = new Map(); // mediaId -> object URL, so files load once per session
  let dbPromise;

  function open() {
    dbPromise ||= new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => req.result.createObjectStore(STORE);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }

  async function run(mode, action) {
    const db = await open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, mode);
      const req = action(tx.objectStore(STORE));
      tx.oncomplete = () => resolve(req?.result);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  }

  return {
    async put(file) {
      const id = App.state.uid();
      await run('readwrite', (store) => store.put(file, id));
      return id;
    },

    async getUrl(id) {
      if (urls.has(id)) return urls.get(id);
      const blob = await run('readonly', (store) => store.get(id));
      if (!blob) return null;
      const url = URL.createObjectURL(blob);
      urls.set(id, url);
      return url;
    },

    async remove(id) {
      if (urls.has(id)) URL.revokeObjectURL(urls.get(id));
      urls.delete(id);
      await run('readwrite', (store) => store.delete(id));
    },

    async clear() {
      urls.forEach((url) => URL.revokeObjectURL(url));
      urls.clear();
      await run('readwrite', (store) => store.clear());
    },
  };
})();
