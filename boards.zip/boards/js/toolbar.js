// toolbar.js — click or drag tools from the sidebar to create cards
window.App = window.App || {};

App.toolbar = {
  init() {
    const bar = document.getElementById('toolbar');
    const canvas = document.getElementById('canvas');
    const DRAG_TYPE = 'application/x-card-type';

    bar.addEventListener('click', (e) => {
      const tool = e.target.closest('[data-type]');
      if (tool) App.board.addCard(tool.dataset.type);
    });

    bar.addEventListener('dragstart', (e) => {
      const tool = e.target.closest('[data-type]');
      if (!tool) return;
      e.dataTransfer.setData(DRAG_TYPE, tool.dataset.type);
      e.dataTransfer.effectAllowed = 'copy';
    });

    canvas.addEventListener('dragover', (e) => {
      if (!e.dataTransfer.types.includes(DRAG_TYPE)) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
    });

    canvas.addEventListener('drop', (e) => {
      const type = e.dataTransfer.getData(DRAG_TYPE);
      if (!type) return;
      e.preventDefault();
      const p = App.board.toCanvasPoint(e.clientX, e.clientY);
      const target = App.nesting.dropTargetOf(e.target, type);
      const extra = target
        ? { parent: target.card.dataset.id, ...(target.item && { parentItem: target.item }) }
        : {};
      App.board.addCard(type, { x: p.x - 24, y: p.y - 14 }, extra);
    });

    const clearBtn = document.getElementById('clear-board');
    clearBtn.addEventListener('click', () => {
      const count = App.state.get().cards.length;
      if (!count) return; // nothing to clear

      App.confirmPopover.open(clearBtn, {
        title: `Remove all ${count} card${count === 1 ? '' : 's'}?`,
        message: 'This can’t be undone.',
        confirmLabel: 'Clear board',
        onConfirm: () => {
          // only this board's stored files (other boards keep theirs)
          App.state.get().cards.forEach((c) => { if (c.mediaId) App.mediaStore.remove(c.mediaId); });
          App.state.clear();
        },
      });
    });
  },
};
