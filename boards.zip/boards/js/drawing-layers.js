// drawing-layers.js — optional layers for drawing canvases (off until you switch them on).
//
// Data on the card when layers are on:
//   card.layersOn    true
//   card.layers      [{ id, name, visible, opacity }]   index 0 = bottom layer
//   card.activeLayer id of the layer you draw on
//   card.layersPanel whether the layers panel is open
//   stroke.l         which layer a stroke belongs to
// Each layer is drawn separately, so the eraser only erases on its own layer.
window.App = window.App || {};

App.drawingLayers = (() => {
  const ICONS = {
    eye: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M1.5 8S4 3.5 8 3.5 14.5 8 14.5 8 12 12.5 8 12.5 1.5 8 1.5 8z"/><circle cx="8" cy="8" r="2"/></svg>',
    eyeOff: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M2 2l12 12M6.6 4a6.4 6.4 0 0 1 1.4-.5C12 3.5 14.5 8 14.5 8a12 12 0 0 1-1.9 2.4M10 11.9a5 5 0 0 1-2 .6C4 12.5 1.5 8 1.5 8a12 12 0 0 1 2.4-2.9"/></svg>',
    plus: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M8 3v10M3 8h10"/></svg>',
    up: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9.5L8 5.5l4 4"/></svg>',
    down: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6.5l4 4 4-4"/></svg>',
    copy: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"><rect x="5" y="5" width="8.5" height="8.5" rx="1.5"/><path d="M11 5V3.5A1.5 1.5 0 0 0 9.5 2h-6A1.5 1.5 0 0 0 2 3.5v6A1.5 1.5 0 0 0 3.5 11H5"/></svg>',
    trash: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5l.7 9h5.6l.7-9"/></svg>',
  };

  const uid = () => App.state.uid();

  // ---------- data helpers ----------
  // strokes with no (or an unknown) layer belong to the bottom layer
  const layerIdOf = (card, stroke) =>
    (card.layers.some((l) => l.id === stroke.l) ? stroke.l : card.layers[0].id);
  const active = (card) => card.layers.find((l) => l.id === card.activeLayer) || card.layers[card.layers.length - 1];
  const strokesIn = (card, layerId) => card.strokes.filter((s) => layerIdOf(card, s) === layerId);

  // switch layers on: everything already drawn goes on "Layer 1"
  function enable(card) {
    const id = uid();
    card.layers = [{ id, name: 'Layer 1', visible: true, opacity: 1 }];
    card.strokes.forEach((s) => { s.l = id; });
    card.activeLayer = id;
    card.layersOn = true;
    card.layersPanel = true;
  }

  // switch layers off: merge the visible layers into one drawing (bottom to top)
  function disable(card) {
    const merged = [];
    card.layers.forEach((layer) => {
      if (!layer.visible) return; // hidden layers are dropped
      strokesIn(card, layer.id).forEach((s) => {
        if (!s.e && layer.opacity < 1) s.o = Math.round((s.o ?? 1) * layer.opacity * 100) / 100;
        delete s.l;
        merged.push(s);
      });
    });
    card.strokes = merged;
    card.layersOn = false;
    delete card.layers;
    delete card.activeLayer;
    delete card.layersPanel;
  }

  // does merging change how things look? (erasers on upper layers would reach lower ones)
  function mergeWarning(card) {
    const notes = [];
    if (card.layers.some((l) => !l.visible && strokesIn(card, l.id).length)) notes.push('Hidden layers will be deleted.');
    if (card.layers.slice(1).some((l) => strokesIn(card, l.id).some((s) => s.e))) {
      notes.push('Eraser marks on upper layers may also erase things below them.');
    }
    return notes.join(' ');
  }

  /**
   * Layers panel for one canvas.
   * onChange(save) — something changed: redraw, and save if `save` is true
   * onDisable()     — layers were switched off
   */
  function attach({ card, onChange, onDisable }) {
    const panel = document.createElement('aside');
    panel.className = 'layers-panel';
    panel.setAttribute('aria-label', 'Layers');
    panel.innerHTML = `
      <div class="layers-head">
        <span>Layers</span>
        <div class="layers-head-actions">
          <button class="draw-btn" data-layer-action="add" aria-label="New layer" data-tooltip="New layer">${ICONS.plus}</button>
          <button class="draw-btn" data-layer-action="duplicate" aria-label="Duplicate layer" data-tooltip="Duplicate layer">${ICONS.copy}</button>
        </div>
      </div>
      <ol class="layers-list" role="listbox" aria-label="Layers, top first"></ol>
      <div class="layers-foot">
        <label class="layers-opacity" data-tooltip="Layer opacity">
          <span>Opacity</span>
          <input type="range" min="0" max="100" step="5" aria-label="Layer opacity">
          <span class="layers-opacity-val"></span>
        </label>
        <div class="layers-foot-actions">
          <button class="draw-btn" data-layer-action="up" aria-label="Move layer up" data-tooltip="Move up">${ICONS.up}</button>
          <button class="draw-btn" data-layer-action="down" aria-label="Move layer down" data-tooltip="Move down">${ICONS.down}</button>
          <button class="draw-btn" data-layer-action="delete" aria-label="Delete layer" data-tooltip="Delete layer">${ICONS.trash}</button>
        </div>
        <button class="layers-off" data-layer-action="off">Turn off layers</button>
      </div>`;

    const list = panel.querySelector('.layers-list');
    const opacity = panel.querySelector('.layers-opacity input');
    const opacityVal = panel.querySelector('.layers-opacity-val');

    const persist = () => App.state.updateCard(card.id, {
      layers: card.layers, activeLayer: card.activeLayer, layersOn: card.layersOn, strokes: card.strokes,
    });

    // footer (opacity + buttons) for the current layer
    function renderFoot() {
      const current = active(card);
      opacity.value = Math.round((current.opacity ?? 1) * 100);
      opacityVal.textContent = `${opacity.value}%`;
      const i = card.layers.indexOf(current);
      panel.querySelector('[data-layer-action="up"]').disabled = i === card.layers.length - 1;
      panel.querySelector('[data-layer-action="down"]').disabled = i === 0;
      panel.querySelector('[data-layer-action="delete"]').disabled = card.layers.length === 1;
    }

    // pick a layer without rebuilding the list (so double-click to rename still works)
    function select(id) {
      card.activeLayer = id;
      list.querySelectorAll('.layer-row').forEach((r) => r.setAttribute('aria-selected', String(r.dataset.layer === id)));
      renderFoot();
      persist();
    }

    function render() {
      if (!card.layersOn) return;
      const current = active(card);
      list.replaceChildren(...[...card.layers].reverse().map((layer) => {
        const li = document.createElement('li');
        li.className = 'layer-row';
        li.dataset.layer = layer.id;
        li.setAttribute('role', 'option');
        li.setAttribute('aria-selected', String(layer.id === current.id));
        li.classList.toggle('is-hidden', !layer.visible);
        const count = strokesIn(card, layer.id).length;
        li.innerHTML = `
          <button class="layer-eye" data-layer-action="visible" aria-label="${layer.visible ? 'Hide' : 'Show'} layer"
            data-tooltip="${layer.visible ? 'Hide' : 'Show'} layer">${layer.visible ? ICONS.eye : ICONS.eyeOff}</button>
          <span class="layer-name" data-tooltip="Double-click to rename"></span>
          <span class="layer-count">${count}</span>`;
        li.querySelector('.layer-name').textContent = layer.name;
        return li;
      }));
      renderFoot();
    }

    // ---------- actions ----------
    function addLayer(copyFrom) {
      const current = active(card);
      const id = uid();
      const n = card.layers.length + 1;
      const layer = { id, name: copyFrom ? `${copyFrom.name} copy` : `Layer ${n}`, visible: true, opacity: copyFrom?.opacity ?? 1 };
      card.layers.splice(card.layers.indexOf(current) + 1, 0, layer); // just above the current one
      if (copyFrom) {
        strokesIn(card, copyFrom.id).forEach((s) => card.strokes.push({ ...s, p: s.p.slice(), l: id }));
      }
      card.activeLayer = id;
      persist();
      render();
      onChange(false);
    }

    function deleteLayer(button) {
      const current = active(card);
      const doDelete = () => {
        const i = card.layers.indexOf(current);
        card.strokes = card.strokes.filter((s) => layerIdOf(card, s) !== current.id);
        card.layers.splice(i, 1);
        card.activeLayer = card.layers[Math.max(0, i - 1)].id;
        persist();
        render();
        onChange(false);
      };
      if (!strokesIn(card, current.id).length) return doDelete();
      App.confirmPopover.open(button, {
        title: `Delete “${current.name}”?`,
        message: 'Everything drawn on this layer will be removed.',
        confirmLabel: 'Delete layer',
        onConfirm: doDelete,
      });
    }

    function move(dir) {
      const current = active(card);
      const i = card.layers.indexOf(current);
      const j = i + dir;
      if (j < 0 || j >= card.layers.length) return;
      [card.layers[i], card.layers[j]] = [card.layers[j], card.layers[i]];
      persist();
      render();
      onChange(false);
    }

    function turnOff(button) {
      const doIt = () => { disable(card); App.state.updateCard(card.id, { strokes: card.strokes, layersOn: false, layers: null, activeLayer: null }); onDisable(); };
      if (card.layers.length === 1 && card.layers[0].visible && (card.layers[0].opacity ?? 1) === 1) return doIt();
      App.confirmPopover.open(button, {
        title: 'Merge layers and turn them off?',
        message: mergeWarning(card) || 'All layers will be combined into one drawing.',
        confirmLabel: 'Merge',
        onConfirm: doIt,
      });
    }

    function rename(row) {
      const layer = card.layers.find((l) => l.id === row.dataset.layer);
      const name = row.querySelector('.layer-name');
      const input = document.createElement('input');
      input.className = 'layer-rename';
      input.value = layer.name;
      input.maxLength = 40;
      name.replaceWith(input);
      input.focus();
      input.select();
      let done = false;
      const commit = (keep) => {
        if (done) return;
        done = true;
        if (keep && input.value.trim()) layer.name = input.value.trim();
        persist();
        render();
      };
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') commit(true);
        if (e.key === 'Escape') commit(false);
        e.stopPropagation();
      });
      input.addEventListener('blur', () => commit(true));
    }

    panel.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-layer-action]');
      const row = e.target.closest('.layer-row');
      const action = btn?.dataset.layerAction;

      if (action === 'visible' && row) {
        const layer = card.layers.find((l) => l.id === row.dataset.layer);
        layer.visible = !layer.visible;
        persist();
        render();
        onChange(false);
        return;
      }
      if (row && !btn && !e.target.closest('input')) {
        if (card.activeLayer !== row.dataset.layer) select(row.dataset.layer);
        return;
      }
      if (action === 'add') addLayer(null);
      if (action === 'duplicate') addLayer(active(card));
      if (action === 'delete') deleteLayer(btn);
      if (action === 'up') move(1);
      if (action === 'down') move(-1);
      if (action === 'off') turnOff(btn);
    });

    list.addEventListener('dblclick', (e) => {
      const row = e.target.closest('.layer-row');
      if (row && !e.target.closest('button') && !row.querySelector('.layer-rename')) rename(row);
    });

    opacity.addEventListener('input', () => {
      active(card).opacity = +opacity.value / 100;
      opacityVal.textContent = `${opacity.value}%`;
      onChange(false);
    });
    opacity.addEventListener('change', persist);

    // a little nudge when you try to draw on a hidden layer
    function flashActive() {
      const row = list.querySelector('[aria-selected="true"]');
      row?.classList.remove('is-flash');
      void row?.offsetWidth; // restart the animation
      row?.classList.add('is-flash');
    }

    return { panel, render, flashActive };
  }

  return { attach, enable, layerIdOf, active, strokesIn };
})();
