// profile.js — your profile: change your name and profile picture.
// Choosing a picture opens a cropper: drag it into place, zoom with the slider or mouse wheel,
// and it's saved as a 256×256 picture shown in a circle everywhere you appear.
window.App = window.App || {};

App.profile = (() => {
  const OUT = 256;  // saved picture size (px)
  const VIEW = 240; // cropper size on screen (px)
  let modal = null;

  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  function close() {
    modal?.remove();
    modal = null;
    document.removeEventListener('keydown', onKey, true);
  }
  function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } }

  function open() {
    const u = App.session.user;
    if (!u) return;
    close();
    App.tooltip?.hide();
    modal = document.createElement('div');
    modal.className = 'fv profile';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-label', 'Your profile');
    modal.innerHTML = `
      <div class="profile-window">
        <header class="share-head">
          <h2>Your profile</h2>
          <button class="fv-close" data-p="close" aria-label="Close">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg></button>
        </header>
        <div class="profile-main">
          <div class="profile-pic-view">
            <div class="profile-big"></div>
            <div class="profile-pic-actions">
              <label class="file-btn profile-upload">Upload picture<input type="file" accept="image/png,image/jpeg,image/webp" hidden></label>
              <button class="file-btn profile-remove" data-p="remove" ${u.avatar ? '' : 'hidden'}>Remove</button>
            </div>
          </div>
          <div class="profile-crop" hidden>
            <div class="crop-stage" tabindex="0" aria-label="Drag to move the picture; use the slider or mouse wheel to zoom">
              <canvas width="${VIEW}" height="${VIEW}"></canvas>
            </div>
            <label class="crop-zoom"><span>Zoom</span><input type="range" min="1" max="4" step="0.01" value="1"></label>
            <div class="crop-actions">
              <button class="file-btn" data-p="crop-cancel">Cancel</button>
              <button class="confirm-pop-btn btn-primary" data-p="crop-save">Save picture</button>
            </div>
          </div>
          <form class="profile-form" novalidate>
            <label class="auth-field"><span>Name</span><input name="name" maxlength="60" value="${esc(u.name)}"></label>
            <p class="profile-email">${esc(u.email)}</p>
            <button class="confirm-pop-btn btn-primary" type="submit">Save name</button>
          </form>
          <p class="share-msg" role="status" hidden></p>
        </div>
      </div>`;
    modal.addEventListener('click', (e) => { if (e.target === modal) close(); });
    document.addEventListener('keydown', onKey, true);
    document.body.append(modal);

    const msg = modal.querySelector('.share-msg');
    const say = (text, error) => { msg.textContent = text; msg.hidden = !text; msg.classList.toggle('is-error', !!error); };
    const showBig = () => {
      const user = App.session.user;
      modal.querySelector('.profile-big').replaceChildren(App.people.avatar(user.email, 120));
      modal.querySelector('.profile-remove').hidden = !user.avatar;
    };
    showBig();

    // after any change: everyone's view of you updates
    const updated = (user) => {
      App.people.remember(user.email, user.avatar || null);
      App.session.updateUser(user);
      showBig();
    };

    modal.querySelector('[data-p="close"]').addEventListener('click', close);
    modal.querySelector('.profile-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = e.target.name.value.trim();
      if (!name) return say('Please enter your name.', true);
      try {
        updated((await App.api.request('PATCH', 'profile.php', { name })).user);
        say('Name saved.');
      } catch (err) { say(err.message, true); }
    });
    modal.querySelector('[data-p="remove"]').addEventListener('click', async () => {
      try {
        updated((await App.api.request('DELETE', 'profile.php')).user);
        say('Picture removed.');
      } catch (err) { say(err.message, true); }
    });

    // ----- choosing + cropping a picture -----
    const view = modal.querySelector('.profile-pic-view');
    const crop = modal.querySelector('.profile-crop');
    const form = modal.querySelector('.profile-form');
    const canvas = crop.querySelector('canvas');
    const ctx = canvas.getContext('2d');
    const zoom = crop.querySelector('input[type="range"]');
    let img = null;
    let scale = 1;      // on-screen pixels per image pixel at zoom 1 (the picture just covers the circle)
    let offset = { x: 0, y: 0 }; // picture centre relative to the circle centre (screen px)

    const zoomed = () => scale * Number(zoom.value);
    // keep the circle covered by the picture
    function clamp() {
      const s = zoomed();
      const maxX = Math.max(0, (img.width * s - VIEW) / 2);
      const maxY = Math.max(0, (img.height * s - VIEW) / 2);
      offset.x = Math.max(-maxX, Math.min(maxX, offset.x));
      offset.y = Math.max(-maxY, Math.min(maxY, offset.y));
    }
    function paint(target, size) {
      const c = target.getContext('2d');
      const k = size / VIEW;
      const s = zoomed() * k;
      c.fillStyle = '#fff';
      c.fillRect(0, 0, size, size);
      c.imageSmoothingQuality = 'high';
      c.drawImage(img, size / 2 + offset.x * k - (img.width * s) / 2, size / 2 + offset.y * k - (img.height * s) / 2, img.width * s, img.height * s);
    }
    function draw() {
      clamp();
      paint(canvas, VIEW);
    }

    modal.querySelector('.profile-upload input').addEventListener('change', (e) => {
      const file = e.target.files[0];
      e.target.value = '';
      if (!file) return;
      if (!/^image\/(png|jpe?g|webp)$/.test(file.type)) return say('Please choose a PNG, JPG or WebP picture.', true);
      const reader = new FileReader();
      reader.onload = () => {
        const im = new Image();
        im.onload = () => {
          img = im;
          scale = VIEW / Math.min(im.width, im.height);
          zoom.value = 1;
          offset = { x: 0, y: 0 };
          view.hidden = true;
          form.hidden = true;
          crop.hidden = false;
          say('');
          draw();
          crop.querySelector('.crop-stage').focus();
        };
        im.onerror = () => say('That picture couldn’t be opened.', true);
        im.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
    zoom.addEventListener('input', draw);
    const stage = crop.querySelector('.crop-stage');
    stage.addEventListener('wheel', (e) => {
      e.preventDefault();
      zoom.value = Math.max(1, Math.min(4, Number(zoom.value) * (e.deltaY < 0 ? 1.08 : 1 / 1.08)));
      draw();
    }, { passive: false });
    stage.addEventListener('pointerdown', (e) => {
      stage.setPointerCapture(e.pointerId);
      const start = { x: e.clientX, y: e.clientY, ox: offset.x, oy: offset.y };
      const move = (ev) => { offset.x = start.ox + ev.clientX - start.x; offset.y = start.oy + ev.clientY - start.y; draw(); };
      const up = () => { stage.removeEventListener('pointermove', move); stage.removeEventListener('pointerup', up); };
      stage.addEventListener('pointermove', move);
      stage.addEventListener('pointerup', up);
    });
    // arrow keys move it, +/- zoom (for keyboards)
    stage.addEventListener('keydown', (e) => {
      const step = e.shiftKey ? 20 : 5;
      if (e.key === 'ArrowLeft') offset.x -= step;
      else if (e.key === 'ArrowRight') offset.x += step;
      else if (e.key === 'ArrowUp') offset.y -= step;
      else if (e.key === 'ArrowDown') offset.y += step;
      else if (e.key === '+' || e.key === '=') zoom.value = Math.min(4, Number(zoom.value) + 0.1);
      else if (e.key === '-') zoom.value = Math.max(1, Number(zoom.value) - 0.1);
      else return;
      e.preventDefault();
      draw();
    });
    const backToView = () => { crop.hidden = true; view.hidden = false; form.hidden = false; };
    modal.querySelector('[data-p="crop-cancel"]').addEventListener('click', backToView);
    modal.querySelector('[data-p="crop-save"]').addEventListener('click', async (e) => {
      const out = document.createElement('canvas');
      out.width = OUT;
      out.height = OUT;
      paint(out, OUT);
      const blob = await new Promise((res) => out.toBlob(res, 'image/jpeg', 0.9));
      const fd = new FormData();
      fd.append('avatar', new File([blob], 'avatar.jpg', { type: 'image/jpeg' }));
      e.target.disabled = true;
      try {
        updated((await App.api.request('POST', 'profile.php', undefined, { form: fd })).user);
        backToView();
        say('Picture saved.');
      } catch (err) { say(err.message, true); } finally { e.target.disabled = false; }
    });
  }

  return { open, close };
})();
