// wires.js — connect cards with wires, like nodes in a visual scripting editor.
// Hover a card, drag from one of the dots on its sides and drop on another card.
// Click a wire to recolour or delete it.
window.App = window.App || {};

App.wires = (() => {
  const SIDES = ['top', 'right', 'bottom', 'left'];
  const NORMAL = { top: [0, -1], right: [1, 0], bottom: [0, 1], left: [-1, 0] };
  const SVG_NS = 'http://www.w3.org/2000/svg';

  let canvas;
  let layer;      // wires behind the cards
  let draftLayer; // wire being drawn, above the cards
  let toolbar;    // colour/delete bar for the selected wire
  let selectedId = null;
  let draft = null;
  let frame = 0;
  const observed = new WeakSet();
  let resizeObserver;

  // ---------- geometry ----------
  // a nested card has no element on the board, so its wires attach to its parent
  function cardEl(id) {
    const card = App.state.getCard(id);
    const shownId = card?.parent || id;
    return canvas.querySelector(`:scope > .card[data-id="${shownId}"]`);
  }

  function portPoint(el, side) {
    const x = el.offsetLeft;
    const y = el.offsetTop;
    const w = el.offsetWidth;
    const h = el.offsetHeight;
    return {
      top: { x: x + w / 2, y },
      right: { x: x + w, y: y + h / 2 },
      bottom: { x: x + w / 2, y: y + h },
      left: { x, y: y + h / 2 },
    }[side];
  }

  // side of `el` closest to a point (used when a wire is dropped on a card, not a dot)
  function nearestSide(el, point) {
    return SIDES.reduce((best, side) => {
      const p = portPoint(el, side);
      const d = Math.hypot(p.x - point.x, p.y - point.y);
      return d < best.d ? { side, d } : best;
    }, { side: 'left', d: Infinity }).side;
  }

  // smooth S-curve leaving each card straight out of its side
  function curve(a, aSide, b, bSide) {
    const k = Math.min(160, Math.max(40, Math.hypot(b.x - a.x, b.y - a.y) * 0.45));
    const c1 = { x: a.x + NORMAL[aSide][0] * k, y: a.y + NORMAL[aSide][1] * k };
    const c2 = bSide ? { x: b.x + NORMAL[bSide][0] * k, y: b.y + NORMAL[bSide][1] * k } : b;
    return {
      d: `M${a.x},${a.y} C${c1.x},${c1.y} ${c2.x},${c2.y} ${b.x},${b.y}`,
      mid: { x: (a.x + 3 * c1.x + 3 * c2.x + b.x) / 8, y: (a.y + 3 * c1.y + 3 * c2.y + b.y) / 8 },
    };
  }

  // resolve a stored connection to points (target side can be 'auto')
  function endpoints(conn) {
    const fromEl = cardEl(conn.from.card);
    const toEl = cardEl(conn.to.card);
    if (!fromEl || !toEl) return null;
    const a = portPoint(fromEl, conn.from.side);
    const toSide = conn.to.side === 'auto' ? nearestSide(toEl, a) : conn.to.side;
    return { a, aSide: conn.from.side, b: portPoint(toEl, toSide), bSide: toSide };
  }

  // ---------- drawing ----------
  const svgEl = (tag, attrs) => {
    const el = document.createElementNS(SVG_NS, tag);
    Object.entries(attrs).forEach(([k, v]) => el.setAttribute(k, v));
    return el;
  };

  function render() {
    frame = 0;
    const { connections } = App.state.get();
    layer.replaceChildren();
    let selectedMid = null;

    connections.forEach((conn) => {
      const ends = endpoints(conn);
      if (!ends) return;
      const { d, mid } = curve(ends.a, ends.aSide, ends.b, ends.bSide);

      const g = svgEl('g', { class: 'wire', 'data-id': conn.id });
      if (conn.color && conn.color !== 'none') g.style.setProperty('--wire-color', `var(--c-${conn.color})`);
      if (conn.id === selectedId) { g.classList.add('is-selected'); selectedMid = mid; }

      g.append(
        svgEl('path', { class: 'wire-hit', d }),
        svgEl('path', { class: 'wire-path', d }),
        svgEl('circle', { class: 'wire-end', cx: ends.a.x, cy: ends.a.y, r: 4 }),
        svgEl('circle', { class: 'wire-end', cx: ends.b.x, cy: ends.b.y, r: 4 }),
      );
      layer.append(g);
    });

    if (selectedMid) showToolbar(selectedMid);
    else hideToolbar();

    // keep an eye on card sizes (typing, images loading, resizing)
    canvas.querySelectorAll('.card').forEach((el) => {
      if (!observed.has(el)) { observed.add(el); resizeObserver.observe(el); }
    });
  }

  // redraw on the next frame (cheap to call often, e.g. while dragging)
  function schedule() {
    if (!frame) frame = requestAnimationFrame(render);
  }

  // ---------- selected-wire toolbar ----------
  function buildToolbar() {
    toolbar = document.createElement('div');
    toolbar.className = 'wire-toolbar';
    toolbar.hidden = true;
    App.COLORS.forEach((color) => {
      const b = document.createElement('button');
      b.className = 'wire-swatch';
      b.dataset.wireColor = color;
      b.dataset.tooltip = color === 'none' ? 'Default' : App.colorName(color);
      b.setAttribute('aria-label', `Wire colour: ${b.dataset.tooltip}`);
      b.style.setProperty('--swatch', color === 'none' ? 'var(--muted)' : `var(--c-${color})`);
      toolbar.append(b);
    });
    const del = document.createElement('button');
    del.className = 'card-btn wire-delete';
    del.dataset.tooltip = 'Delete wire  (Del)';
    del.setAttribute('aria-label', 'Delete wire');
    del.innerHTML = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>';
    toolbar.append(del);

    toolbar.addEventListener('click', (e) => {
      if (!selectedId) return;
      const swatch = e.target.closest('[data-wire-color]');
      if (swatch) App.state.updateConnection(selectedId, { color: swatch.dataset.wireColor });
      if (e.target.closest('.wire-delete')) removeSelected();
    });
    canvas.append(toolbar);
  }

  function showToolbar(mid) {
    const conn = App.state.get().connections.find((c) => c.id === selectedId);
    toolbar.querySelectorAll('[data-wire-color]').forEach((b) =>
      b.setAttribute('aria-pressed', String(b.dataset.wireColor === (conn?.color || 'none'))));
    toolbar.style.left = `${mid.x}px`;
    toolbar.style.top = `${mid.y}px`;
    toolbar.hidden = false;
  }
  const hideToolbar = () => { toolbar.hidden = true; };

  function select(id) {
    selectedId = id;
    schedule();
  }

  function removeSelected() {
    const id = selectedId;
    selectedId = null;
    App.tooltip?.hide();
    App.state.removeConnection(id);
  }

  // ---------- drawing a new wire ----------
  function clearTargets() {
    canvas.querySelectorAll('.is-drop-target').forEach((el) => el.classList.remove('is-drop-target'));
    canvas.querySelectorAll('.card-port.is-target').forEach((el) => el.classList.remove('is-target'));
  }

  // which card/side is under the pointer?
  function findTarget(e) {
    const under = document.elementFromPoint(e.clientX, e.clientY);
    const card = under?.closest('.card');
    if (!card || card.dataset.id === draft.fromId) return null;
    const port = under.closest('.card-port');
    return { card, side: port ? port.dataset.side : 'auto', port };
  }

  function startDraft(e, port) {
    const card = port.closest('.card');
    draft = { fromId: card.dataset.id, side: port.dataset.side, pointerId: e.pointerId };
    port.setPointerCapture(e.pointerId);
    document.body.classList.add('is-wiring');
    select(null);
  }

  function moveDraft(e) {
    const fromEl = cardEl(draft.fromId);
    const a = portPoint(fromEl, draft.side);
    const target = findTarget(e);

    clearTargets();
    let b = App.board.toCanvasPoint(e.clientX, e.clientY);
    let bSide = null;
    if (target) {
      target.card.classList.add('is-drop-target');
      target.port?.classList.add('is-target');
      bSide = target.side === 'auto' ? nearestSide(target.card, a) : target.side;
      b = portPoint(target.card, bSide);
    }

    const { d } = curve(a, draft.side, b, bSide);
    draftLayer.replaceChildren(
      svgEl('path', { class: 'wire-path wire-draft', d }),
      svgEl('circle', { class: 'wire-end', cx: a.x, cy: a.y, r: 4 }),
    );
  }

  function endDraft(e, cancelled = false) {
    const target = !cancelled && e ? findTarget(e) : null;
    if (target) {
      App.state.addConnection(
        { card: draft.fromId, side: draft.side },
        { card: target.card.dataset.id, side: target.side },
      );
    }
    draft = null;
    clearTargets();
    draftLayer.replaceChildren();
    document.body.classList.remove('is-wiring');
  }

  // ---------- setup ----------
  function init() {
    canvas = document.getElementById('canvas');
    layer = svgEl('svg', { class: 'wires', 'aria-hidden': 'true' });
    draftLayer = svgEl('svg', { class: 'wires-draft', 'aria-hidden': 'true' });
    canvas.prepend(layer);
    canvas.append(draftLayer);
    buildToolbar();

    resizeObserver = new ResizeObserver(schedule);
    App.state.subscribe(schedule);

    canvas.addEventListener('pointerdown', (e) => {
      const port = e.target.closest('.card-port');
      if (port && e.button === 0) {
        e.preventDefault();
        e.stopPropagation();
        return startDraft(e, port);
      }
      const wire = e.target.closest('.wire');
      if (wire && e.button === 0) return select(wire.dataset.id);
      if (selectedId && !e.target.closest('.wire-toolbar')) select(null);
    }, true);

    canvas.addEventListener('pointermove', (e) => { if (draft && e.pointerId === draft.pointerId) moveDraft(e); });
    canvas.addEventListener('pointerup', (e) => { if (draft && e.pointerId === draft.pointerId) endDraft(e); });
    canvas.addEventListener('pointercancel', () => { if (draft) endDraft(null, true); });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && draft) return endDraft(null, true);
      if (e.key === 'Escape' && selectedId) return select(null);
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedId
          && !e.target.closest?.('input, textarea, [contenteditable="true"]')) {
        e.preventDefault();
        removeSelected();
      }
    });

    window.addEventListener('load', schedule); // fonts/images can change card sizes
    schedule();
  }

  // the four connection dots on a card (called from card-shell.js)
  function addPorts(el) {
    SIDES.forEach((side) => {
      const port = document.createElement('span');
      port.className = 'card-port';
      port.dataset.side = side;
      port.setAttribute('aria-hidden', 'true');
      el.append(port);
    });
  }

  return { init, schedule, addPorts };
})();
