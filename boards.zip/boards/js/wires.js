// wires.js — connect cards with wires, like nodes in a visual scripting editor.
// Hover a card, drag from one of the dots on its sides and drop on another card.
// The start of a wire always uses whichever side faces the other card. The end does too,
// unless you dropped it on a specific dot — then it stays on that dot.
// To-do tasks have their own dots too, so a wire can point at one specific task.
// Click a wire to recolour or delete it.
window.App = window.App || {};

App.wires = (() => {
  const SIDES = ['top', 'right', 'bottom', 'left'];
  const NORMAL = { top: [0, -1], right: [1, 0], bottom: [0, 1], left: [-1, 0] };
  const SVG_NS = 'http://www.w3.org/2000/svg';

  let canvas;
  let layer;      // wires behind the cards
  let draftLayer; // wire being drawn, above the cards
  let toolbar;    // colour/delete bar for the selected wire
  let wirePalette;
  let selectedId = null;
  let draft = null;
  let frame = 0;
  const observed = new WeakSet();
  let resizeObserver;

  // ---------- geometry ----------
  const cardEl = (id) => canvas.querySelector(`:scope > .card[data-id="${id}"]`);

  // A nested card isn't on the board itself, so its wires go to where it's shown:
  // the task it's attached to, or else the card it's inside.
  function visibleEnd(end) {
    let card = App.state.getCard(end.card);
    if (!card?.parent) return end;
    // climb to the attachment that sits directly in a card on the board
    while (App.state.getCard(card.parent)?.parent) card = App.state.getCard(card.parent);
    return card.parentItem
      ? { card: card.parent, item: card.parentItem, side: 'auto' }
      : { card: card.parent, side: end.side };
  }

  function portPoint(el, side) {
    const x = el.offsetLeft;
    const y = el.offsetTop;
    const w = el.offsetWidth;
    const h = el.offsetHeight;
    return {
      top: { x: x + w / 2, y },
      right: { x: x + w, y: y + h / 2 },
      bottom: { x: x + w / 2, y: y + h },
      left: { x, y: y + h / 2 },
    }[side];
  }

  // side of `el` closest to a point (used when a wire is dropped on a card, not a dot)
  function nearestSide(el, point) {
    return SIDES.reduce((best, side) => {
      const p = portPoint(el, side);
      const d = Math.hypot(p.x - point.x, p.y - point.y);
      return d < best.d ? { side, d } : best;
    }, { side: 'left', d: Infinity }).side;
  }

  // smooth S-curve leaving each card straight out of its side
  function curve(a, aSide, b, bSide) {
    const k = Math.min(160, Math.max(40, Math.hypot(b.x - a.x, b.y - a.y) * 0.45));
    const c1 = { x: a.x + NORMAL[aSide][0] * k, y: a.y + NORMAL[aSide][1] * k };
    const c2 = bSide ? { x: b.x + NORMAL[bSide][0] * k, y: b.y + NORMAL[bSide][1] * k } : b;
    return {
      d: `M${a.x},${a.y} C${c1.x},${c1.y} ${c2.x},${c2.y} ${b.x},${b.y}`,
      mid: { x: (a.x + 3 * c1.x + 3 * c2.x + b.x) / 8, y: (a.y + 3 * c1.y + 3 * c2.y + b.y) / 8 },
    };
  }

  // ---- task (row) ends ----
  const taskRow = (el, itemId) => el.querySelector(`.todo-item[data-item-id="${itemId}"]`);

  // left/right edge of the card, level with the task's checkbox (its first line)
  function taskPoint(el, row, side) {
    const canvasRect = canvas.getBoundingClientRect();
    const box = row.querySelector('input[type="checkbox"]') || row;
    const r = box.getBoundingClientRect();
    return {
      x: side === 'left' ? el.offsetLeft : el.offsetLeft + el.offsetWidth,
      y: r.top + r.height / 2 - canvasRect.top,
    };
  }

  // left or right, whichever faces the other end
  const sideFacing = (el, point) => (point.x < el.offsetLeft + el.offsetWidth / 2 ? 'left' : 'right');

  const isPinned = (end) => SIDES.includes(end.side);

  // one end of a wire -> { point, side }. `other` = point it should face when its side is 'auto'
  function resolveEnd(end, other) {
    const el = cardEl(end.card);
    if (!el) return null;
    if (end.item) {
      const row = taskRow(el, end.item);
      if (row) {
        const side = end.side === 'left' || end.side === 'right' ? end.side : sideFacing(el, other);
        return { point: taskPoint(el, row, side), side };
      }
    }
    const side = isPinned(end) ? end.side : nearestSide(el, other);
    return { point: portPoint(el, side), side };
  }

  // rough position of an end, used to decide which way the other end should face
  function anchorOf(end) {
    const el = cardEl(end.card);
    if (!el) return null;
    if (isPinned(end)) return resolveEnd(end).point;
    const row = end.item && taskRow(el, end.item);
    return {
      x: el.offsetLeft + el.offsetWidth / 2,
      y: row ? taskPoint(el, row, 'left').y : el.offsetTop + el.offsetHeight / 2,
    };
  }

  // a stored connection -> the two points and sides to draw between
  function endpoints(conn) {
    const fromEnd = visibleEnd(conn.from);
    const toEnd = visibleEnd(conn.to);
    const toAnchor = anchorOf(toEnd);
    if (!toAnchor) return null;
    const from = resolveEnd(fromEnd, toAnchor); // start faces the other card
    const to = from && resolveEnd(toEnd, from.point);
    if (!from || !to) return null;
    return { a: from.point, aSide: from.side, b: to.point, bSide: to.side };
  }

  // ---------- drawing ----------
  const svgEl = (tag, attrs) => {
    const el = document.createElementNS(SVG_NS, tag);
    Object.entries(attrs).forEach(([k, v]) => el.setAttribute(k, v));
    return el;
  };

  function render() {
    frame = 0;
    const { connections } = App.state.get();
    layer.replaceChildren();
    let selectedMid = null;

    connections.forEach((conn) => {
      const ends = endpoints(conn);
      if (!ends) return;
      const { d, mid } = curve(ends.a, ends.aSide, ends.b, ends.bSide);

      const g = svgEl('g', { class: 'wire', 'data-id': conn.id });
      if (conn.color && conn.color !== 'none') g.style.setProperty('--wire-color', App.colorCss(conn.color));
      if (conn.id === selectedId) { g.classList.add('is-selected'); selectedMid = mid; }

      g.append(
        svgEl('path', { class: 'wire-hit', d }),
        svgEl('path', { class: 'wire-path', d }),
        svgEl('circle', { class: 'wire-end', cx: ends.a.x, cy: ends.a.y, r: 4 }),
        svgEl('circle', { class: 'wire-end', cx: ends.b.x, cy: ends.b.y, r: 4 }),
      );
      layer.append(g);
    });

    if (selectedMid) showToolbar(selectedMid);
    else hideToolbar();

    // keep an eye on card sizes (typing, images loading, resizing)
    canvas.querySelectorAll('.card').forEach((el) => {
      if (!observed.has(el)) { observed.add(el); resizeObserver.observe(el); }
    });
  }

  // redraw on the next frame (cheap to call often, e.g. while dragging)
  function schedule() {
    if (!frame) frame = requestAnimationFrame(render);
  }

  // ---------- selected-wire toolbar ----------
  function buildToolbar() {
    toolbar = document.createElement('div');
    toolbar.className = 'wire-toolbar';
    toolbar.hidden = true;
    // colour row: presets, saved custom colours and "+" (see palette.js)
    const presets = App.presetSwatches('var(--muted)');
    presets[0].label = 'Default';
    wirePalette = App.palette.create({
      presets,
      visible: 6,
      size: 16,
      onPick: (color) => { if (selectedId) App.state.updateConnection(selectedId, { color }); },
    });
    toolbar.append(wirePalette.el);
    const del = document.createElement('button');
    del.className = 'card-btn wire-delete';
    del.dataset.tooltip = 'Delete wire  (Del)';
    del.setAttribute('aria-label', 'Delete wire');
    del.innerHTML = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>';
    toolbar.append(del);

    toolbar.addEventListener('click', (e) => {
      if (!selectedId) return;
      if (e.target.closest('.wire-delete')) removeSelected();
    });
    canvas.append(toolbar);
  }

  function showToolbar(mid) {
    const conn = App.state.get().connections.find((c) => c.id === selectedId);
    wirePalette.set(conn?.color || 'none');
    toolbar.style.left = `${mid.x}px`;
    toolbar.style.top = `${mid.y}px`;
    toolbar.hidden = false;
  }
  const hideToolbar = () => { toolbar.hidden = true; };

  function select(id) {
    selectedId = id;
    schedule();
  }

  function removeSelected() {
    const id = selectedId;
    selectedId = null;
    App.tooltip?.hide();
    App.state.removeConnection(id);
  }

  // ---------- drawing a new wire ----------
  function clearTargets() {
    canvas.querySelectorAll('.is-drop-target').forEach((el) => el.classList.remove('is-drop-target'));
    canvas.querySelectorAll('.card-port.is-target').forEach((el) => el.classList.remove('is-target'));
    canvas.querySelectorAll('.todo-item.is-wire-target').forEach((el) => el.classList.remove('is-wire-target'));
  }

  // what's under the pointer: a card, a task row, or one of their dots?
  // Returns { card, side, item, port, row } or null.
  function findTarget(e) {
    const under = document.elementFromPoint(e.clientX, e.clientY);
    const card = under?.closest('#canvas > .card');
    if (!card) return null;

    const port = under.closest('.card-port');
    let row = port?.closest('.todo-item') || under.closest('.todo-item');
    if (row && row.closest('.attachment, .card') !== card) row = null; // a task inside an attachment
    const item = port ? port.dataset.item : row?.dataset.itemId;

    // the same card only works when going from one task to a different task
    if (card.dataset.id === draft.fromId && (!item || !draft.item || item === draft.item)) return null;

    return { card, side: port ? port.dataset.side : 'auto', item: item || undefined, port, row };
  }

  function startDraft(e, port) {
    const card = port.closest('.card');
    draft = {
      fromId: card.dataset.id,
      side: port.dataset.side,
      item: port.dataset.item, // set when starting from a task's dot
      pointerId: e.pointerId,
    };
    port.setPointerCapture(e.pointerId);
    document.body.classList.add('is-wiring');
    select(null);
  }

  function moveDraft(e) {
    const fromEnd = { card: draft.fromId, side: 'auto', item: draft.item };
    const target = findTarget(e);
    const cursor = App.board.toCanvasPoint(e.clientX, e.clientY);

    clearTargets();
    let from;
    let b = cursor;
    let bSide = null;
    if (target) {
      target.card.classList.add('is-drop-target');
      target.port?.classList.add('is-target');
      target.row?.classList.add('is-wire-target');
      const toEnd = { card: target.card.dataset.id, side: target.side, item: target.item };
      from = resolveEnd(fromEnd, anchorOf(toEnd));
      const to = resolveEnd(toEnd, from.point);
      b = to.point;
      bSide = to.side;
    } else {
      from = resolveEnd(fromEnd, cursor); // start swings round to face the cursor
    }
    if (!from) return;
    const a = from.point;
    const aSide = from.side;

    const { d } = curve(a, aSide, b, bSide);
    draftLayer.replaceChildren(
      svgEl('path', { class: 'wire-path wire-draft', d }),
      svgEl('circle', { class: 'wire-end', cx: a.x, cy: a.y, r: 4 }),
    );
  }

  const endOf = (card, side, item) => (item ? { card, side, item } : { card, side });

  function endDraft(e, cancelled = false) {
    const target = !cancelled && e ? findTarget(e) : null;
    if (target) {
      App.state.addConnection(
        endOf(draft.fromId, 'auto', draft.item), // the start always faces the other end
        endOf(target.card.dataset.id, target.side, target.item),
      );
    }
    draft = null;
    clearTargets();
    draftLayer.replaceChildren();
    document.body.classList.remove('is-wiring');
  }

  // ---------- setup ----------
  function init() {
    canvas = document.getElementById('canvas');
    layer = svgEl('svg', { class: 'wires', 'aria-hidden': 'true' });
    draftLayer = svgEl('svg', { class: 'wires-draft', 'aria-hidden': 'true' });
    canvas.prepend(layer);
    canvas.append(draftLayer);
    buildToolbar();

    resizeObserver = new ResizeObserver(schedule);
    App.state.subscribe(schedule);

    canvas.addEventListener('pointerdown', (e) => {
      const port = e.target.closest('.card-port');
      if (port && e.button === 0) {
        e.preventDefault();
        e.stopPropagation();
        return startDraft(e, port);
      }
      const wire = e.target.closest('.wire');
      if (wire && e.button === 0) return select(wire.dataset.id);
      if (selectedId && !e.target.closest('.wire-toolbar')) select(null);
    }, true);

    canvas.addEventListener('pointermove', (e) => { if (draft && e.pointerId === draft.pointerId) moveDraft(e); });
    canvas.addEventListener('pointerup', (e) => { if (draft && e.pointerId === draft.pointerId) endDraft(e); });
    canvas.addEventListener('pointercancel', () => { if (draft) endDraft(null, true); });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && draft) return endDraft(null, true);
      if (e.key === 'Escape' && selectedId) return select(null);
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedId
          && !e.target.closest?.('input, textarea, [contenteditable="true"]')) {
        e.preventDefault();
        removeSelected();
      }
    });

    window.addEventListener('load', schedule); // fonts/images can change card sizes
    schedule();
  }

  // the four connection dots on a card (called from card-shell.js)
  function addPorts(el) {
    SIDES.forEach((side) => {
      const port = document.createElement('span');
      port.className = 'card-port';
      port.dataset.side = side;
      port.setAttribute('aria-hidden', 'true');
      el.append(port);
    });
  }

  // left/right dots on a single to-do task (called from todo.js)
  function addTaskPorts(row, itemId) {
    ['left', 'right'].forEach((side) => {
      const port = document.createElement('span');
      port.className = 'card-port item-port';
      port.dataset.side = side;
      port.dataset.item = itemId;
      port.setAttribute('aria-hidden', 'true');
      row.append(port);
    });
  }

  return { init, schedule, addPorts, addTaskPorts };
})();
