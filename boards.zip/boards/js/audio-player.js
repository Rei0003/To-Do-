// audio-player.js — the player for audio in media cards:
// play/pause, a waveform you can click or drag to jump around, and the time.
// The waveform is worked out from the sound itself when the browser can read the file
// (stored files always; links only if the website allows it — otherwise a plain bar is shown).
window.App = window.App || {};

App.audioPlayer = (() => {
  const BAR = 3;     // waveform bar width + gap (px)
  const peaksCache = new Map(); // key -> array of 0..1 loudness values

  const ICONS = {
    play: '<svg viewBox="0 0 16 16" fill="currentColor"><path d="M5 3.2v9.6a.6.6 0 0 0 .9.5l7.6-4.8a.6.6 0 0 0 0-1L5.9 2.7a.6.6 0 0 0-.9.5z"/></svg>',
    pause: '<svg viewBox="0 0 16 16" fill="currentColor"><rect x="4" y="3" width="3" height="10" rx=".8"/><rect x="9" y="3" width="3" height="10" rx=".8"/></svg>',
  };

  const time = (s) => {
    if (!Number.isFinite(s)) return '0:00';
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return m >= 60 ? `${Math.floor(m / 60)}:${String(m % 60).padStart(2, '0')}:${String(sec).padStart(2, '0')}` : `${m}:${String(sec).padStart(2, '0')}`;
  };

  // loudness of ~600 slices of the sound (later shrunk to fit the width)
  async function computePeaks(arrayBuffer) {
    const Ctx = window.OfflineAudioContext || window.webkitOfflineAudioContext;
    const ctx = new Ctx(1, 2, 44100);
    const audio = await ctx.decodeAudioData(arrayBuffer);
    const data = audio.getChannelData(0);
    const n = 600;
    const size = Math.max(1, Math.floor(data.length / n));
    const peaks = [];
    for (let i = 0; i < n; i++) {
      let max = 0;
      for (let j = i * size, end = Math.min(data.length, j + size); j < end; j += 4) {
        const v = Math.abs(data[j]);
        if (v > max) max = v;
      }
      peaks.push(max);
    }
    const top = Math.max(...peaks) || 1;
    return peaks.map((p) => p / top);
  }

  // only one sound plays at a time
  document.addEventListener('play', (e) => {
    if (!(e.target instanceof HTMLAudioElement)) return;
    document.querySelectorAll('.ap audio').forEach((a) => { if (a !== e.target) a.pause(); });
  }, true);

  /**
   * src           Promise of a URL to play
   * name          title shown above the waveform
   * key           id for caching the waveform (file id or link)
   * getBuffer()   Promise of the raw file (ArrayBuffer) for the waveform, or null
   * onError()     the sound couldn't be loaded
   */
  function create({ src, name, key, getBuffer, onError }) {
    const el = document.createElement('div');
    el.className = 'ap';
    el.innerHTML = `
      <button class="ap-play" aria-label="Play">${ICONS.play}</button>
      <div class="ap-main">
        <div class="ap-name"></div>
        <div class="ap-wave" role="slider" tabindex="0" aria-label="Position (arrow keys skip 5 seconds)"
             aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><canvas></canvas></div>
        <div class="ap-time"><span class="ap-cur">0:00</span><span class="ap-dur">0:00</span></div>
      </div>
      <audio preload="metadata"></audio>`;
    const audio = el.querySelector('audio');
    const playBtn = el.querySelector('.ap-play');
    const wave = el.querySelector('.ap-wave');
    const canvas = wave.querySelector('canvas');
    const cur = el.querySelector('.ap-cur');
    const dur = el.querySelector('.ap-dur');
    el.querySelector('.ap-name').textContent = name || 'Audio';

    let peaks = peaksCache.get(key) || null;
    let frame = 0;

    // ----- drawing the waveform -----
    function draw() {
      const w = wave.clientWidth;
      const h = wave.clientHeight;
      if (!w || !h) return;
      const dpr = window.devicePixelRatio || 1;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      const ctx = canvas.getContext('2d');
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const styles = getComputedStyle(el);
      const played = styles.getPropertyValue('--ap-played').trim() || '#2F6FD6';
      const rest = styles.getPropertyValue('--ap-rest').trim() || '#bbb';
      const progress = audio.duration ? audio.currentTime / audio.duration : 0;
      const bars = Math.max(1, Math.floor(w / BAR));
      for (let i = 0; i < bars; i++) {
        let v = 0.35; // no waveform available: an even bar
        if (peaks) {
          const from = Math.floor((i / bars) * peaks.length);
          const to = Math.max(from + 1, Math.floor(((i + 1) / bars) * peaks.length));
          v = Math.max(0.06, ...peaks.slice(from, to));
        }
        const bh = Math.max(2, v * (h - 2));
        ctx.fillStyle = (i + 0.5) / bars <= progress ? played : rest;
        ctx.fillRect(i * BAR, (h - bh) / 2, BAR - 1, bh);
      }
      wave.setAttribute('aria-valuenow', String(Math.round(progress * 100)));
    }
    const drawSoon = () => { if (!frame) frame = requestAnimationFrame(() => { frame = 0; draw(); }); };

    function tick() {
      cur.textContent = time(audio.currentTime);
      draw();
      if (!audio.paused) frame = requestAnimationFrame(tick);
      else frame = 0;
    }

    // ----- playing -----
    playBtn.addEventListener('click', () => {
      if (audio.paused) audio.play().catch(() => onError?.());
      else audio.pause();
    });
    audio.addEventListener('play', () => {
      playBtn.innerHTML = ICONS.pause;
      playBtn.setAttribute('aria-label', 'Pause');
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(tick);
    });
    audio.addEventListener('pause', () => {
      playBtn.innerHTML = ICONS.play;
      playBtn.setAttribute('aria-label', 'Play');
      drawSoon();
    });
    audio.addEventListener('ended', () => { audio.currentTime = 0; drawSoon(); cur.textContent = '0:00'; });
    audio.addEventListener('loadedmetadata', () => { dur.textContent = time(audio.duration); drawSoon(); });
    audio.addEventListener('error', () => onError?.(), { once: true });

    // ----- jumping around: click / drag the waveform, or arrow keys -----
    function seekTo(clientX) {
      if (!audio.duration) return;
      const r = wave.getBoundingClientRect();
      const f = Math.min(1, Math.max(0, (clientX - r.left) / r.width));
      audio.currentTime = f * audio.duration;
      cur.textContent = time(audio.currentTime);
      draw();
    }
    wave.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      e.preventDefault();
      e.stopPropagation();
      wave.setPointerCapture(e.pointerId);
      seekTo(e.clientX);
      const move = (ev) => seekTo(ev.clientX);
      const up = () => { wave.removeEventListener('pointermove', move); wave.removeEventListener('pointerup', up); };
      wave.addEventListener('pointermove', move);
      wave.addEventListener('pointerup', up);
    });
    wave.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
        e.preventDefault();
        audio.currentTime = Math.max(0, Math.min(audio.duration || 0, audio.currentTime + (e.key === 'ArrowRight' ? 5 : -5)));
        cur.textContent = time(audio.currentTime);
        draw();
      }
      if (e.key === ' ') { e.preventDefault(); playBtn.click(); }
    });

    new ResizeObserver(drawSoon).observe(wave);
    window.addEventListener('themechange', drawSoon);

    // ----- load the sound (and its waveform) -----
    Promise.resolve(src).then((url) => {
      if (!url) { onError?.(); return; }
      audio.src = url;
    }).catch(() => onError?.());

    if (!peaks && getBuffer) {
      Promise.resolve(getBuffer())
        .then((buf) => (buf ? computePeaks(buf) : null))
        .then((p) => { if (p) { peaks = p; peaksCache.set(key, p); drawSoon(); } })
        .catch(() => { /* no waveform (e.g. a link the website won't share): plain bar */ });
    }

    return el;
  }

  return { create };
})();
