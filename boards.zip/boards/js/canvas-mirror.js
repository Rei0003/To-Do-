// canvas-mirror.js — the "Mirror another canvas" picker.
// Lists the other canvases with a small preview; hovering one highlights it on the board.
window.App = window.App || {};

App.canvasMirror = (() => {
  let pop = null;
  let anchor = null;

  const unhighlight = () =>
    document.querySelectorAll('.card.is-mirror-candidate').forEach((el) => el.classList.remove('is-mirror-candidate'));

  function close() {
    if (!pop) return;
    pop.remove();
    pop = null;
    unhighlight();
    anchor?.setAttribute('aria-expanded', 'false');
    anchor = null;
    document.removeEventListener('pointerdown', onOutside, true);
    document.removeEventListener('keydown', onKey);
  }
  function onOutside(e) { if (!pop.contains(e.target) && !anchor.contains(e.target)) close(); }
  function onKey(e) { if (e.key === 'Escape') { const a = anchor; close(); a?.focus(); } }

  /**
   * selfId     the canvas asking
   * currentId  what it mirrors now (or null)
   * nameOf(id), thumbnail(card, w, h) — from drawing.js
   * onPick(id)
   */
  function openPicker(button, { selfId, currentId, nameOf, thumbnail, onPick }) {
    if (pop && anchor === button) return close();
    close();
    App.tooltip?.hide();
    anchor = button;
    anchor.setAttribute('aria-expanded', 'true');

    // other canvases that aren't mirrors themselves
    const options = App.state.get().cards.filter((c) => c.type === 'drawing' && c.id !== selfId && !c.mirrorOf);

    pop = document.createElement('div');
    pop.className = 'mirror-pop';
    pop.setAttribute('role', 'dialog');
    pop.setAttribute('aria-label', 'Mirror another canvas');
    pop.innerHTML = `
      <p class="mirror-pop-title">Mirror a canvas</p>
      <p class="mirror-pop-hint">This canvas will show the one you pick, live, as it's drawn on.
        Its own drawing is kept for when you stop.</p>
      <div class="mirror-list"></div>`;
    const list = pop.querySelector('.mirror-list');

    if (!options.length) {
      list.innerHTML = '<p class="mirror-empty">Add another canvas to the board first, then you can mirror it here.</p>';
    }
    options.forEach((c) => {
      const b = document.createElement('button');
      b.className = 'mirror-option';
      b.dataset.id = c.id;
      b.setAttribute('aria-pressed', String(c.id === currentId));
      const thumb = thumbnail(c, 84, 56);
      thumb.className = 'mirror-thumb';
      const label = document.createElement('span');
      label.textContent = nameOf(c.id);
      b.append(thumb, label);
      b.addEventListener('mouseenter', () => {
        unhighlight();
        document.querySelector(`.card[data-id="${c.id}"]`)?.classList.add('is-mirror-candidate');
      });
      b.addEventListener('mouseleave', unhighlight);
      b.addEventListener('click', () => { close(); onPick(c.id); });
      list.append(b);
    });

    document.body.append(pop);
    const r = button.getBoundingClientRect();
    const w = pop.offsetWidth;
    const h = pop.offsetHeight;
    let top = r.bottom + 6;
    if (top + h > window.innerHeight - 8) top = r.top - h - 6;
    pop.style.top = `${Math.min(Math.max(8, top), window.innerHeight - h - 8)}px`;
    pop.style.left = `${Math.min(Math.max(8, r.left + r.width / 2 - w / 2), window.innerWidth - w - 8)}px`;

    document.addEventListener('pointerdown', onOutside, true);
    document.addEventListener('keydown', onKey);
  }

  // ---------- which of the original's layers a mirror shows ----------
  /**
   * source    the original canvas (with layers)
   * value     { mode: 'same' | 'all' | 'custom', hidden: [layer ids] }
   * onChange(value) — called on every change (the mirror updates straight away)
   */
  function openLayers(button, { source, value, onChange }) {
    if (pop && anchor === button) return close();
    close();
    App.tooltip?.hide();
    anchor = button;
    anchor.setAttribute('aria-expanded', 'true');
    let state = { mode: value.mode || 'same', hidden: [...(value.hidden || [])] };

    pop = document.createElement('div');
    pop.className = 'mirror-pop mirror-layers-pop';
    pop.setAttribute('role', 'dialog');
    pop.setAttribute('aria-label', 'Layers to show in this mirror');
    pop.innerHTML = `
      <p class="mirror-pop-title">Layers in this mirror</p>
      <p class="mirror-pop-hint">Choose what this mirror shows, separately from what's visible in the original.</p>
      <div class="ml-modes" role="radiogroup">
        <label class="ml-mode"><input type="radio" name="ml-mode" value="same"> Same as the original</label>
        <label class="ml-mode"><input type="radio" name="ml-mode" value="all"> All layers together</label>
        <label class="ml-mode"><input type="radio" name="ml-mode" value="custom"> Only the ones I tick</label>
      </div>
      <ol class="ml-list"></ol>`;
    const list = pop.querySelector('.ml-list');

    // tick boxes, top layer first; they show what's on screen right now for any mode
    function shownIn(layer) {
      if (state.mode === 'all') return true;
      if (state.mode === 'custom') return !state.hidden.includes(layer.id);
      return layer.visible;
    }

    function paintList() {
      pop.querySelectorAll('input[name="ml-mode"]').forEach((r) => { r.checked = r.value === state.mode; });
      list.replaceChildren(...[...source.layers].reverse().map((layer) => {
        const li = document.createElement('li');
        li.innerHTML = `<label class="ml-layer"><input type="checkbox"><span></span>
          ${layer.visible ? '' : '<em>hidden in original</em>'}</label>`;
        li.querySelector('span').textContent = layer.name;
        const box = li.querySelector('input');
        box.checked = shownIn(layer);
        box.dataset.layer = layer.id;
        return li;
      }));
    }

    pop.addEventListener('change', (e) => {
      if (e.target.name === 'ml-mode') {
        // switching to "custom" starts from whatever is showing now
        if (e.target.value === 'custom' && state.mode !== 'custom') {
          state.hidden = source.layers.filter((l) => !shownIn(l)).map((l) => l.id);
        }
        state = { ...state, mode: e.target.value };
      } else if (e.target.dataset.layer) {
        // ticking a box means you're choosing layers yourself
        if (state.mode !== 'custom') state.hidden = source.layers.filter((l) => !shownIn(l)).map((l) => l.id);
        const id = e.target.dataset.layer;
        state.hidden = e.target.checked ? state.hidden.filter((h) => h !== id) : [...state.hidden, id];
        state = { ...state, mode: 'custom' };
      }
      paintList();
      onChange({ mode: state.mode, hidden: state.hidden });
    });

    paintList();
    document.body.append(pop);
    const r = button.getBoundingClientRect();
    const w = pop.offsetWidth;
    const h = pop.offsetHeight;
    let top = r.bottom + 6;
    if (top + h > window.innerHeight - 8) top = r.top - h - 6;
    pop.style.top = `${Math.min(Math.max(8, top), window.innerHeight - h - 8)}px`;
    pop.style.left = `${Math.min(Math.max(8, r.left + r.width / 2 - w / 2), window.innerWidth - w - 8)}px`;

    document.addEventListener('pointerdown', onOutside, true);
    document.addEventListener('keydown', onKey);
  }

  return { openPicker, openLayers, close };
})();
