// resize.js — drag the corner handle to resize cards.
// Card types opt in with `resizable: true` (width only, e.g. images keep their shape)
// or `resizable: 'both'` (width and height, e.g. drawing canvases).
window.App = window.App || {};

App.resize = (() => {
  const STEP = 20; // arrow-key step in px

  const typeOf = (el) => App.cardTypes[el.dataset.type];
  const bothWays = (el) => typeOf(el)?.resizable === 'both';

  const limits = (el) => {
    const t = typeOf(el);
    return {
      minW: t?.minWidth || 160, maxW: t?.maxWidth || 1200,
      minH: t?.minHeight || 120, maxH: t?.maxHeight || 1400,
    };
  };
  const clamp = (v, min, max) => Math.round(Math.min(max, Math.max(min, v)));

  // null = back to the default size
  function setSize(el, width, height) {
    el.style.width = width ? `${width}px` : '';
    const patch = { width: width || null };
    if (bothWays(el)) {
      el.style.height = height ? `${height}px` : '';
      patch.height = height || null;
    }
    App.state.updateCard(el.dataset.id, patch);
  }

  // adds the handle to a card element (called from card-shell.js)
  function addHandle(el) {
    const handle = document.createElement('button');
    handle.className = 'card-resize';
    handle.setAttribute('aria-label', 'Resize card (arrow keys)');
    handle.dataset.tooltip = 'Drag to resize\nDouble-click to reset';
    handle.innerHTML = '<svg viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M11 5L5 11M11 8.5L8.5 11"/></svg>';
    el.append(handle);
  }

  function attach(canvas) {
    let active = null;

    canvas.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      const handle = e.target.closest('.card-resize');
      if (!handle) return;
      const el = handle.closest('.card');
      active = {
        el,
        both: bothWays(el),
        startX: e.clientX,
        startY: e.clientY,
        startW: el.offsetWidth,
        startH: el.offsetHeight,
        limits: limits(el),
      };
      el.classList.add('is-resizing');
      handle.setPointerCapture(e.pointerId);
      e.preventDefault();
    });

    canvas.addEventListener('pointermove', (e) => {
      if (!active) return;
      const { el, limits: l } = active;
      el.style.width = `${clamp(active.startW + e.clientX - active.startX, l.minW, l.maxW)}px`;
      if (active.both) el.style.height = `${clamp(active.startH + e.clientY - active.startY, l.minH, l.maxH)}px`;
    });

    const end = () => {
      if (!active) return;
      const { el } = active;
      el.classList.remove('is-resizing');
      setSize(el, el.offsetWidth, el.offsetHeight);
      active = null;
    };
    canvas.addEventListener('pointerup', end);
    canvas.addEventListener('pointercancel', end);

    // double-click the handle to go back to the default size
    canvas.addEventListener('dblclick', (e) => {
      const handle = e.target.closest('.card-resize');
      if (handle) setSize(handle.closest('.card'), null, null);
    });

    // keyboard: focus the handle and use ← → (and ↑ ↓ for height) to resize
    canvas.addEventListener('keydown', (e) => {
      const handle = e.target.closest?.('.card-resize');
      if (!handle) return;
      const el = handle.closest('.card');
      const l = limits(el);
      let w = el.offsetWidth;
      let h = el.offsetHeight;
      if (e.key === 'ArrowRight') w += STEP;
      else if (e.key === 'ArrowLeft') w -= STEP;
      else if (e.key === 'ArrowDown' && bothWays(el)) h += STEP;
      else if (e.key === 'ArrowUp' && bothWays(el)) h -= STEP;
      else return;
      e.preventDefault();
      setSize(el, clamp(w, l.minW, l.maxW), clamp(h, l.minH, l.maxH));
    });
  }

  return { attach, addHandle };
})();
