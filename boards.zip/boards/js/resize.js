// resize.js — drag the corner handle to resize cards whose type has `resizable: true`.
// Images and videos keep their shape, so only the width is stored.
window.App = window.App || {};

App.resize = (() => {
  const STEP = 20; // arrow-key step in px

  const limits = (el) => {
    const type = App.cardTypes[el.dataset.type];
    return { min: type?.minWidth || 160, max: type?.maxWidth || 1200 };
  };
  const clamp = (w, { min, max }) => Math.round(Math.min(max, Math.max(min, w)));

  function setWidth(el, width) {
    el.style.width = width ? `${width}px` : '';
    App.state.updateCard(el.dataset.id, { width: width || null });
  }

  // adds the handle to a card element (called from card-shell.js)
  function addHandle(el) {
    const handle = document.createElement('button');
    handle.className = 'card-resize';
    handle.setAttribute('aria-label', 'Resize card (arrow keys)');
    handle.dataset.tooltip = 'Drag to resize\nDouble-click to reset';
    handle.innerHTML = '<svg viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M11 5L5 11M11 8.5L8.5 11"/></svg>';
    el.append(handle);
  }

  function attach(canvas) {
    let active = null;

    canvas.addEventListener('pointerdown', (e) => {
      const handle = e.target.closest('.card-resize');
      if (!handle) return;
      const el = handle.closest('.card');
      active = { el, startX: e.clientX, startWidth: el.offsetWidth, limits: limits(el) };
      el.classList.add('is-resizing');
      handle.setPointerCapture(e.pointerId);
      e.preventDefault();
    });

    canvas.addEventListener('pointermove', (e) => {
      if (!active) return;
      const width = clamp(active.startWidth + e.clientX - active.startX, active.limits);
      active.el.style.width = `${width}px`;
    });

    const end = () => {
      if (!active) return;
      active.el.classList.remove('is-resizing');
      setWidth(active.el, active.el.offsetWidth);
      active = null;
    };
    canvas.addEventListener('pointerup', end);
    canvas.addEventListener('pointercancel', end);

    // double-click the handle to go back to the default size
    canvas.addEventListener('dblclick', (e) => {
      const handle = e.target.closest('.card-resize');
      if (handle) setWidth(handle.closest('.card'), null);
    });

    // keyboard: focus the handle and use ← → to resize
    canvas.addEventListener('keydown', (e) => {
      const handle = e.target.closest?.('.card-resize');
      if (!handle || !['ArrowLeft', 'ArrowRight'].includes(e.key)) return;
      e.preventDefault();
      const el = handle.closest('.card');
      const delta = e.key === 'ArrowRight' ? STEP : -STEP;
      setWidth(el, clamp(el.offsetWidth + delta, limits(el)));
    });
  }

  return { attach, addHandle };
})();
