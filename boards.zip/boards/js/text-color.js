// text-color.js — text colours. Saved as CSS variables so they adapt to dark mode
// (colour values live in rich-text.css and theme.css).
window.App = window.App || {};

App.textColor = (() => {
  const COLORS = ['default', 'grey', 'red', 'orange', 'green', 'blue', 'purple', 'pink'];
  const NAMES = {
    default: 'Default', grey: 'Grey', red: 'Red', orange: 'Orange',
    green: 'Green', blue: 'Blue', purple: 'Purple', pink: 'Pink',
  };

  App.textStyle.register({
    key: 'color',
    cssProp: 'color',
    varPrefix: '--tc-',
    values: COLORS,
    command: 'foreColor',
    marker: '#010203',
    isMarker: (el, style) =>
      /(?:^|;)\s*color:\s*rgb\(\s*1,\s*2,\s*3\s*\)/.test(style) || /^#010203$/i.test(el.getAttribute('color') || ''),
  });

  return {
    COLORS,
    NAMES,
    apply: (editor, name) => App.textStyle.apply(editor, 'color', name),
    current: (editor) => App.textStyle.current(editor, 'color'),
  };
})();
