// color-picker.js — a small custom colour maker:
// saturation/brightness square + hue slider + optional opacity slider + hex box.
// Colours come out as '#RRGGBB', or '#RRGGBBAA' when they're see-through.
window.App = window.App || {};

App.colorPicker = (() => {
  // ---------- colour maths ----------
  // '#RGB', '#RRGGBB' or '#RRGGBBAA' -> { r, g, b, a } (a = 0..1)
  function hexToRgb(hex) {
    let h = String(hex).trim().replace(/^#/, '');
    if (h.length === 3) h = h.split('').map((c) => c + c).join('');
    if (!/^[0-9a-f]{6}([0-9a-f]{2})?$/i.test(h)) return null;
    const n = parseInt(h.slice(0, 6), 16);
    const a = h.length === 8 ? parseInt(h.slice(6), 16) / 255 : 1;
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255, a };
  }
  function rgbToHex({ r, g, b, a = 1 }) {
    const two = (v) => Math.round(v).toString(16).padStart(2, '0');
    return `#${two(r)}${two(g)}${two(b)}${a < 1 ? two(a * 255) : ''}`.toUpperCase();
  }
  // 'rgb(…)' / 'rgba(…)' (as browsers write them) -> hex
  function cssRgbToHex(text) {
    const m = String(text).match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s/]+([\d.]+%?))?\s*\)/i);
    if (!m) return null;
    let a = m[4] === undefined ? 1 : parseFloat(m[4]);
    if (String(m[4]).endsWith('%')) a /= 100;
    return rgbToHex({ r: +m[1], g: +m[2], b: +m[3], a });
  }

  function rgbToHsv({ r, g, b }) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b);
    const d = max - Math.min(r, g, b);
    let h = 0;
    if (d) {
      if (max === r) h = ((g - b) / d) % 6;
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h = (h * 60 + 360) % 360;
    }
    return { h, s: max ? d / max : 0, v: max };
  }

  function hsvToRgb(h, s, v) {
    const f = (n) => {
      const k = (n + h / 60) % 6;
      return (v - v * s * Math.max(0, Math.min(k, 4 - k, 1))) * 255;
    };
    return { r: f(5), g: f(3), b: f(1) };
  }

  // ---------- picker ----------
  /**
   * options: value, alpha (show the opacity slider), onInput(hex) while dragging, onChange(hex) when settled
   * returns { el, set(hex), value() }
   */
  function create({ value = '#FFFFFF', alpha = false, onInput, onChange }) {
    const start = hexToRgb(value) || { r: 255, g: 255, b: 255, a: 1 };
    let { h, s, v } = rgbToHsv(start);
    let a = alpha ? start.a : 1;

    const el = document.createElement('div');
    el.className = 'cp';
    el.innerHTML = `
      <div class="cp-sv" tabindex="0" role="slider" aria-label="Saturation and brightness (arrow keys)">
        <span class="cp-sv-thumb"></span>
      </div>
      <input class="cp-hue" type="range" min="0" max="359" step="1" aria-label="Hue">
      ${alpha ? '<input class="cp-alpha" type="range" min="0" max="100" step="1" aria-label="Opacity">' : ''}
      <div class="cp-row">
        <span class="cp-preview"><span></span></span>
        <input class="cp-hex" type="text" maxlength="9" spellcheck="false" aria-label="Hex colour code">
        ${'EyeDropper' in window ? `<button class="cp-eyedrop" type="button" aria-label="Pick a colour from the screen" data-tooltip="Pick a colour from anywhere on screen">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M10.2 2.6a1.9 1.9 0 0 1 2.7 2.7l-1.6 1.6.8.8-1.2 1.2-3.8-3.8 1.2-1.2.8.8z"/><path d="M7.9 5.9L3 10.8V13h2.2l4.9-4.9"/></svg></button>` : ''}
        ${alpha ? '<span class="cp-alpha-val"></span>' : ''}
      </div>`;

    const sv = el.querySelector('.cp-sv');
    const thumb = el.querySelector('.cp-sv-thumb');
    const hue = el.querySelector('.cp-hue');
    const alphaInput = el.querySelector('.cp-alpha');
    const alphaVal = el.querySelector('.cp-alpha-val');
    const hex = el.querySelector('.cp-hex');
    const preview = el.querySelector('.cp-preview span');
    const current = () => rgbToHex({ ...hsvToRgb(h, s, v), a });
    const solid = () => rgbToHex(hsvToRgb(h, s, v));

    function paint() {
      const c = current();
      sv.style.setProperty('--hue', h);
      thumb.style.left = `${s * 100}%`;
      thumb.style.top = `${(1 - v) * 100}%`;
      hue.value = Math.round(h);
      if (alphaInput) {
        alphaInput.value = Math.round(a * 100);
        alphaInput.style.setProperty('--solid', solid());
        alphaVal.textContent = `${Math.round(a * 100)}%`;
      }
      if (document.activeElement !== hex) hex.value = c;
      preview.style.background = c;
      sv.setAttribute('aria-valuetext', c);
    }

    // square: drag to pick saturation (left→right) and brightness (bottom→top)
    function pickAt(e) {
      const r = sv.getBoundingClientRect();
      s = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
      v = Math.min(1, Math.max(0, 1 - (e.clientY - r.top) / r.height));
      paint();
      onInput?.(current());
    }
    sv.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      e.preventDefault();
      sv.focus();
      sv.setPointerCapture(e.pointerId);
      pickAt(e);
      const move = (ev) => pickAt(ev);
      const up = () => {
        sv.removeEventListener('pointermove', move);
        sv.removeEventListener('pointerup', up);
        onChange?.(current());
      };
      sv.addEventListener('pointermove', move);
      sv.addEventListener('pointerup', up);
    });
    sv.addEventListener('keydown', (e) => {
      const step = e.shiftKey ? 0.1 : 0.02;
      if (e.key === 'ArrowLeft') s -= step;
      else if (e.key === 'ArrowRight') s += step;
      else if (e.key === 'ArrowUp') v += step;
      else if (e.key === 'ArrowDown') v -= step;
      else return;
      e.preventDefault();
      s = Math.min(1, Math.max(0, s));
      v = Math.min(1, Math.max(0, v));
      paint();
      onInput?.(current());
      onChange?.(current());
    });

    hue.addEventListener('input', () => { h = +hue.value; paint(); onInput?.(current()); });
    hue.addEventListener('change', () => onChange?.(current()));
    alphaInput?.addEventListener('input', () => { a = +alphaInput.value / 100; paint(); onInput?.(current()); });
    alphaInput?.addEventListener('change', () => onChange?.(current()));

    // typing a hex code
    function commitHex() {
      const rgb = hexToRgb(hex.value);
      if (!rgb) { hex.value = current(); return; }
      ({ h, s, v } = rgbToHsv(rgb));
      a = alpha ? rgb.a : 1;
      paint();
      onInput?.(current());
      onChange?.(current());
    }
    hex.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); commitHex(); }
    });
    hex.addEventListener('blur', commitHex);

    // pick from anywhere on screen (browsers with the EyeDropper feature: Chrome, Edge)
    el.querySelector('.cp-eyedrop')?.addEventListener('click', async () => {
      try {
        const { sRGBHex } = await new window.EyeDropper().open();
        const rgb = hexToRgb(sRGBHex) || hexToRgb(cssRgbToHex(sRGBHex) || '');
        if (!rgb) return;
        ({ h, s, v } = rgbToHsv(rgb));
        paint();
        onInput?.(current());
        onChange?.(current());
      } catch { /* cancelled */ }
    });

    paint();

    return {
      el,
      value: current,
      set(newHex) {
        const rgb = hexToRgb(newHex);
        if (!rgb) return;
        ({ h, s, v } = rgbToHsv(rgb));
        a = alpha ? rgb.a : 1;
        paint();
      },
    };
  }

  return { create, hexToRgb, rgbToHex, cssRgbToHex };
})();
