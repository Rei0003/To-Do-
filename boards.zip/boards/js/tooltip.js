// tooltip.js — quick, styled tooltips for anything with a data-tooltip attribute.
// Add data-tooltip-side="right" to show it to the right instead of above.
window.App = window.App || {};

App.tooltip = (() => {
  let tip;
  let target = null;
  let timer = null;
  let lastHidden = 0;

  function place(el) {
    const r = el.getBoundingClientRect();
    const w = tip.offsetWidth;
    const h = tip.offsetHeight;
    let top;
    let left;
    if (el.dataset.tooltipSide === 'right') {
      left = r.right + 8;
      top = r.top + r.height / 2 - h / 2;
    } else {
      top = r.top - h - 6;
      if (top < 4) top = r.bottom + 6;
      left = r.left + r.width / 2 - w / 2;
    }
    tip.style.left = `${Math.min(Math.max(4, left), window.innerWidth - w - 4)}px`;
    tip.style.top = `${top}px`;
  }

  function show(el) {
    target = el;
    tip.textContent = el.dataset.tooltip;
    tip.hidden = false;
    place(el);
    tip.classList.add('is-visible');
  }

  function hide() {
    clearTimeout(timer);
    if (target) lastHidden = Date.now();
    target = null;
    tip.classList.remove('is-visible');
    tip.hidden = true;
  }

  function init() {
    tip = document.createElement('div');
    tip.className = 'tooltip';
    tip.setAttribute('role', 'tooltip');
    tip.hidden = true;
    document.body.append(tip);

    document.addEventListener('pointerover', (e) => {
      if (e.pointerType === 'touch') return;
      const el = e.target.closest?.('[data-tooltip]');
      if (el === target) return;
      clearTimeout(timer);
      if (!el) return hide();
      // moving from one tooltip to the next shows it straight away
      const quick = target || Date.now() - lastHidden < 400;
      if (target) hide();
      if (quick) show(el);
      else timer = setTimeout(() => show(el), 350);
    });

    document.addEventListener('pointerout', (e) => {
      const next = e.relatedTarget?.closest?.('[data-tooltip]');
      if (!next) hide();
    });

    let lastTouch = 0;
    document.addEventListener('pointerdown', (e) => { if (e.pointerType === 'touch') lastTouch = Date.now(); }, true);
    document.addEventListener('focusin', (e) => {
      if (Date.now() - lastTouch < 800) return; // tapped, not keyboard
      const el = e.target.closest?.('[data-tooltip]');
      if (el && el.matches(':focus-visible')) show(el);
    });
    document.addEventListener('focusout', hide);
    document.addEventListener('pointerdown', hide, true);
    document.addEventListener('scroll', hide, true);
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') hide(); });
  }

  return { init, hide };
})();
