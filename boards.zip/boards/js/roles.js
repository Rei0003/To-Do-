// roles.js — custom roles (your own labels like "Junior dev", "Designer", "Client").
// You create them once and give them to people you invite (Share window). A role has a name,
// a colour and optionally a suggested access level that's picked when you choose it while inviting.
window.App = window.App || {};

App.roles = (() => {
  const COLORS = ['blue', 'green', 'purple', 'pink', 'orange', 'red', 'yellow', 'teal', 'gray'];
  const ACCESS = { '': 'No suggestion', edit: 'Can edit', view: 'Can view' };
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const api = (...a) => App.api.request(...a);

  let mine = [];

  async function load() {
    if (App.session.mode !== 'server') { mine = []; return mine; }
    try { mine = (await api('GET', 'roles.php')).roles; } catch { mine = []; }
    return mine;
  }

  // a coloured pill with the role's name
  function badge(role, small) {
    const el = document.createElement('span');
    el.className = `role-badge${small ? ' is-small' : ''}`;
    el.dataset.color = role?.color || 'gray';
    el.textContent = role?.name || '';
    el.hidden = !role;
    return el;
  }
  const badgeHtml = (role, small) => (role ? `<span class="role-badge${small ? ' is-small' : ''}" data-color="${esc(role.color)}">${esc(role.name)}</span>` : '');

  // ---------- managing your roles (a small window) ----------
  let modal = null;
  function close() {
    modal?.remove();
    modal = null;
    document.removeEventListener('keydown', onKey, true);
  }
  function onKey(e) { if (e.key === 'Escape') { e.stopImmediatePropagation(); close(); } }

  // onChange(roles) is called after every change (so the Share window can update)
  async function manage(onChange) {
    close();
    App.tooltip?.hide();
    modal = document.createElement('div');
    modal.className = 'fv roles-modal';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-label', 'Your roles');
    modal.innerHTML = '<div class="roles-window"><p class="share-loading">Loading…</p></div>';
    modal.addEventListener('click', (e) => { if (e.target === modal) close(); });
    document.addEventListener('keydown', onKey, true);
    document.body.append(modal);
    await load();
    draw();

    function draw(message, error) {
      const win = modal.querySelector('.roles-window');
      win.innerHTML = `
        <header class="share-head">
          <h2>Your roles</h2>
          <button class="fv-close" data-r="close" aria-label="Close">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg></button>
        </header>
        <p class="roles-intro">Roles describe who people are on your team (like <em>Junior dev</em> or <em>Client</em>).
          Give them to people in the Share window. They’re yours, so you can use them on all your boards.</p>
        <ul class="roles-list">
          ${mine.length ? '' : '<li class="roles-none">No roles yet — create your first one below.</li>'}
          ${mine.map((r) => `<li class="roles-item" data-id="${esc(r.id)}">
            ${badgeHtml(r)}
            <span class="roles-access">${r.access ? `Suggests: ${ACCESS[r.access]}` : ''}</span>
            <button class="card-btn" data-r="edit" aria-label="Edit ${esc(r.name)}" data-tooltip="Edit">
              <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10.5 2.5l3 3L6 13H3v-3z"/></svg></button>
            <button class="card-btn" data-r="delete" aria-label="Delete ${esc(r.name)}" data-tooltip="Delete">
              <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5l.7 9h5.6l.7-9"/></svg></button>
          </li>`).join('')}
        </ul>
        <form class="roles-form" novalidate>
          <p class="roles-form-title">New role</p>
          ${formFields()}
          <button class="confirm-pop-btn btn-primary" type="submit">Create role</button>
        </form>
        <p class="share-msg" role="status" hidden></p>`;
      const msg = win.querySelector('.share-msg');
      if (message) { msg.textContent = message; msg.hidden = false; msg.classList.toggle('is-error', !!error); }
      win.querySelector('[data-r="close"]').addEventListener('click', close);
      wireForm(win.querySelector('.roles-form'), async (values) => {
        const res = await api('POST', 'roles.php', values);
        mine = res.roles;
        onChange?.(mine);
        draw(`Created “${values.name}”.`);
      });
      win.querySelector('.roles-list').addEventListener('click', async (e) => {
        const li = e.target.closest('[data-id]');
        const act = e.target.closest('[data-r]')?.dataset.r;
        if (!li || !act) return;
        const role = mine.find((r) => r.id === li.dataset.id);
        if (act === 'delete') {
          App.confirmPopover.open(e.target.closest('[data-r]'), {
            title: `Delete “${role.name}”?`,
            message: 'People who have this role keep their access — they just won’t have a role.',
            confirmLabel: 'Delete role',
            onConfirm: async () => {
              mine = (await api('DELETE', `roles.php?id=${role.id}`)).roles;
              onChange?.(mine);
              draw(`Deleted “${role.name}”.`);
            },
          });
        }
        if (act === 'edit') {
          const form = document.createElement('form');
          form.className = 'roles-form roles-edit';
          form.innerHTML = `${formFields(role)}<div class="roles-edit-actions"><button type="button" class="file-btn" data-x="cancel">Cancel</button>
            <button class="confirm-pop-btn btn-primary" type="submit">Save</button></div>`;
          li.replaceWith(form);
          form.querySelector('[data-x="cancel"]').addEventListener('click', () => draw());
          wireForm(form, async (values) => {
            mine = (await api('PATCH', `roles.php?id=${role.id}`, values)).roles;
            onChange?.(mine);
            draw('Saved.');
          });
          form.querySelector('input[name="name"]').focus();
        }
      });
    }
  }

  // name + colour + suggested access
  function formFields(role) {
    return `
      <div class="roles-fields">
        <input name="name" maxlength="40" placeholder="e.g. Junior dev" aria-label="Role name" value="${esc(role?.name || '')}">
        <select name="access" aria-label="Suggested access">
          ${Object.entries(ACCESS).map(([k, v]) => `<option value="${k}" ${(role?.access || '') === k ? 'selected' : ''}>${k ? `Suggest: ${v}` : v}</option>`).join('')}
        </select>
      </div>
      <div class="roles-colors" role="radiogroup" aria-label="Colour">
        ${COLORS.map((c) => `<label class="roles-color" data-color="${c}"><input type="radio" name="color" value="${c}" ${(role?.color || 'blue') === c ? 'checked' : ''} aria-label="${c}"><span></span></label>`).join('')}
      </div>`;
  }
  function wireForm(form, save) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = form.name.value.trim();
      const msg = modal.querySelector('.share-msg');
      if (!name) { msg.textContent = 'Give the role a name.'; msg.hidden = false; msg.classList.add('is-error'); return; }
      try {
        await save({ name, color: form.querySelector('input[name="color"]:checked')?.value || 'blue', access: form.access.value || null });
      } catch (err) { msg.textContent = err.message; msg.hidden = false; msg.classList.add('is-error'); }
    });
  }

  return { load, badge, badgeHtml, manage, close, get mine() { return mine; }, ACCESS };
})();
