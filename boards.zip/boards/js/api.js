// api.js — talking to the PHP server (the api/ folder).
window.App = window.App || {};

App.api = (() => {
  const BASE = 'api/';

  /**
   * method, path (e.g. 'boards.php?id=…'), body (sent as JSON), { form } (FormData for uploads)
   * Resolves with the JSON reply; throws an Error with .status (and .data) when it fails.
   */
  async function request(method, path, body, { form, keepalive } = {}) {
    const options = {
      method,
      credentials: 'same-origin',
      headers: { 'X-Requested-With': 'boards' }, // the server only accepts changes with this
      keepalive: !!keepalive,
    };
    if (form) options.body = form;
    else if (body !== undefined) {
      options.headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(body);
    }
    let res;
    try {
      res = await fetch(BASE + path, options);
    } catch {
      const err = new Error('Can’t reach the server. Check your connection.');
      err.offline = true;
      throw err;
    }
    const text = await res.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch { data = null; }
    if (!res.ok) {
      const err = new Error(data?.error || `Something went wrong on the server (${res.status}).`);
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  // is there a PHP server here? (not when the page is opened straight from a file)
  async function available() {
    if (location.protocol === 'file:') return false;
    try {
      const me = await request('GET', 'auth.php?action=me');
      return !!me && 'user' in me;
    } catch {
      return false;
    }
  }

  return { request, available };
})();
