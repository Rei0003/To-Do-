// board-background.js — the "Background colour" popover for drawing canvases:
// preset colours, a custom colour maker and your saved custom colours.
window.App = window.App || {};

App.boardBackground = (() => {
  const PRESETS = [
    { color: null, name: 'Theme default' },
    { color: '#FFFFFF', name: 'White' },
    { color: '#F6F1E3', name: 'Paper' },
    { color: '#FFF4C2', name: 'Sticky note' },
    { color: '#DCE8D3', name: 'Sage' },
    { color: '#DCE7F6', name: 'Sky' },
    { color: '#F6DDE3', name: 'Blush' },
    { color: '#E5DFF5', name: 'Lavender' },
    { color: '#1F2A25', name: 'Chalkboard' },
    { color: '#1B1D21', name: 'Blackboard' },
    { color: '#1F3D66', name: 'Blueprint' },
    { color: '#4A3428', name: 'Walnut' },
  ];

  // ---------- readable ink on any background ----------
  function luminance(hex) {
    const rgb = App.colorPicker.hexToRgb(hex);
    if (!rgb) return 1;
    const lin = (c) => { c /= 255; return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; };
    return 0.2126 * lin(rgb.r) + 0.7152 * lin(rgb.g) + 0.0722 * lin(rgb.b);
  }
  const contrast = (a, b) => (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
  const DARK_INK = '#1E2227';
  const LIGHT_INK = '#EEF0E8';

  // dark ink on light backgrounds, chalk on dark ones
  function inkFor(bg) {
    const l = luminance(bg);
    return contrast(l, luminance(DARK_INK)) >= contrast(l, luminance(LIGHT_INK)) ? DARK_INK : LIGHT_INK;
  }

  // ---------- saved custom colours (shared with every colour picker) ----------
  // backgrounds can't be see-through, so only solid saved colours are shown here
  const recent = () => App.savedColors.list().filter((c) => c.length === 7);
  function remember(color) {
    if (!color || PRESETS.some((p) => p.color === color)) return;
    App.savedColors.add(color);
  }

  // ---------- popover ----------
  let pop = null;
  let anchor = null;

  function close() {
    if (!pop) return;
    pop.remove();
    pop = null;
    document.removeEventListener('pointerdown', onOutside, true);
    document.removeEventListener('keydown', onKey);
    anchor?.setAttribute('aria-expanded', 'false');
    anchor = null;
  }
  function onOutside(e) {
    if (!pop.contains(e.target) && !anchor.contains(e.target)) close();
  }
  function onKey(e) {
    if (e.key !== 'Escape') return;
    const a = anchor;
    close();
    a?.focus();
  }

  function swatchButton(color, name, selected) {
    const b = document.createElement('button');
    b.className = 'bg-swatch';
    b.dataset.bg = color || '';
    b.dataset.tooltip = name;
    b.setAttribute('aria-label', name);
    b.setAttribute('aria-pressed', String(selected));
    if (color) b.style.setProperty('--swatch', color);
    else b.classList.add('bg-swatch--theme');
    return b;
  }

  /**
   * button: what the popover opens from
   * current: the canvas's colour now ('#RRGGBB' or null for theme default)
   * themeColor: what "theme default" looks like right now (starting point for the custom maker)
   * onInput(color) live preview, onChange(color) final choice (color null = theme default)
   * onEyedropper()  optional: start picking the background colour from the canvas
   */
  function open(button, { current, themeColor, onInput, onChange, onEyedropper }) {
    if (pop && anchor === button) return close();
    close();
    App.tooltip?.hide();
    anchor = button;
    anchor.setAttribute('aria-expanded', 'true');

    pop = document.createElement('div');
    pop.className = 'bg-pop';
    pop.setAttribute('role', 'dialog');
    pop.setAttribute('aria-label', 'Canvas background colour');
    pop.innerHTML = `
      <div class="bg-pop-head">
        <p class="bg-pop-title">Background</p>
        <button class="bg-eyedrop" hidden data-tooltip="Pick the background colour\nfrom the drawing">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M10.2 2.6a1.9 1.9 0 0 1 2.7 2.7l-1.6 1.6.8.8-1.2 1.2-3.8-3.8 1.2-1.2.8.8z"/><path d="M7.9 5.9L3 10.8V13h2.2l4.9-4.9"/></svg>
          Pick from canvas</button>
      </div>
      <div class="bg-grid bg-presets"></div>
      <p class="bg-pop-label">Custom colour</p>
      <div class="bg-custom"></div>
      <div class="bg-recent-wrap">
        <p class="bg-pop-label">Saved colours</p>
        <div class="bg-grid bg-recent"></div>
      </div>`;

    const eyedrop = pop.querySelector('.bg-eyedrop');
    if (onEyedropper) {
      eyedrop.hidden = false;
      eyedrop.addEventListener('click', () => { close(); onEyedropper(); });
    }

    const presets = pop.querySelector('.bg-presets');
    PRESETS.forEach((p) => presets.append(swatchButton(p.color, p.name, p.color === current)));

    const recentWrap = pop.querySelector('.bg-recent-wrap');
    const recentGrid = pop.querySelector('.bg-recent');
    function fillRecent(selected) {
      const list = recent();
      recentWrap.hidden = list.length === 0;
      recentGrid.replaceChildren(...list.map((c) => swatchButton(c, c, c === selected)));
    }
    fillRecent(current);

    const markSelected = (color) =>
      pop.querySelectorAll('.bg-swatch').forEach((b) =>
        b.setAttribute('aria-pressed', String((b.dataset.bg || null) === color)));

    const picker = App.colorPicker.create({
      value: current || themeColor,
      onInput: (c) => { markSelected(c); onInput(c); },
      onChange: (c) => { remember(c); fillRecent(c); markSelected(c); onChange(c); },
    });
    pop.querySelector('.bg-custom').append(picker.el);

    pop.addEventListener('click', (e) => {
      const sw = e.target.closest('.bg-swatch');
      if (!sw) return;
      const color = sw.dataset.bg || null;
      picker.set(color || themeColor);
      markSelected(color);
      onChange(color);
    });

    document.body.append(pop);

    // below the button, kept on screen
    const r = anchor.getBoundingClientRect();
    const w = pop.offsetWidth;
    const h = pop.offsetHeight;
    let top = r.bottom + 6;
    if (top + h > window.innerHeight - 8) top = Math.max(8, r.top - h - 6);
    pop.style.top = `${top}px`;
    pop.style.left = `${Math.min(Math.max(8, r.left + r.width / 2 - w / 2), window.innerWidth - w - 8)}px`;

    document.addEventListener('pointerdown', onOutside, true);
    document.addEventListener('keydown', onKey);
    document.getElementById('viewport').addEventListener('scroll', close, { once: true });
  }

  return { open, close, inkFor };
})();
