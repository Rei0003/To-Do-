// drawing-export.js — download a drawing canvas as a PNG or JPG image.
// The whole drawing is exported (even parts scrolled out of view), at 2× for sharpness.
window.App = window.App || {};

App.drawingExport = (() => {
  const PAD = 24;        // space around the drawing, in drawing units
  const SCALE = 2;       // export resolution
  const MAX_SIDE = 8000; // browsers struggle with bigger canvases

  // area covered by all strokes
  function bounds(strokes) {
    let x1 = Infinity; let y1 = Infinity; let x2 = -Infinity; let y2 = -Infinity;
    strokes.forEach((s) => {
      const r = s.s / 2;
      for (let i = 0; i < s.p.length; i += 2) {
        x1 = Math.min(x1, s.p[i] - r); x2 = Math.max(x2, s.p[i] + r);
        y1 = Math.min(y1, s.p[i + 1] - r); y2 = Math.max(y2, s.p[i + 1] + r);
      }
    });
    return { x: x1 - PAD, y: y1 - PAD, w: x2 - x1 + PAD * 2, h: y2 - y1 + PAD * 2 };
  }

  function stamp() {
    const d = new Date();
    const two = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())}-${two(d.getHours())}${two(d.getMinutes())}`;
  }

  /**
   * format: 'png' | 'png-clear' (transparent) | 'jpg'
   * strokes (visible ones, for the size), paint(ctx, w, h, setTransform), background (CSS colour)
   */
  function download(format, { strokes, paint, background, flip }) {
    if (!strokes.length) return;
    const b = bounds(strokes);
    const scale = Math.min(SCALE, MAX_SIDE / b.w, MAX_SIDE / b.h);
    const w = Math.max(1, Math.round(b.w * scale));
    const h = Math.max(1, Math.round(b.h * scale));

    // strokes on their own layer, so the eraser doesn't cut holes in the background
    const layer = document.createElement('canvas');
    layer.width = w;
    layer.height = h;
    const lctx = layer.getContext('2d');
    // a flipped mirror exports flipped too
    const sx = flip?.h ? -scale : scale;
    const sy = flip?.v ? -scale : scale;
    const ox = flip?.h ? (b.x + b.w) * scale : -b.x * scale;
    const oy = flip?.v ? (b.y + b.h) * scale : -b.y * scale;
    paint(lctx, w, h, (c) => c.setTransform(sx, 0, 0, sy, ox, oy));

    const out = document.createElement('canvas');
    out.width = w;
    out.height = h;
    const octx = out.getContext('2d');
    if (format !== 'png-clear') {
      octx.fillStyle = format === 'jpg' ? '#FFFFFF' : background; // JPG can't be see-through
      octx.fillRect(0, 0, w, h);
      if (format === 'jpg') { octx.fillStyle = background; octx.fillRect(0, 0, w, h); }
    }
    octx.drawImage(layer, 0, 0);

    const type = format === 'jpg' ? 'image/jpeg' : 'image/png';
    out.toBlob((blob) => {
      if (!blob) return;
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `drawing-${stamp()}.${format === 'jpg' ? 'jpg' : 'png'}`;
      document.body.append(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    }, type, 0.92);
  }

  // ---------- small menu: which format? ----------
  let menu = null;
  let anchor = null;

  function close() {
    if (!menu) return;
    menu.remove();
    menu = null;
    anchor?.setAttribute('aria-expanded', 'false');
    anchor = null;
    document.removeEventListener('pointerdown', onOutside, true);
    document.removeEventListener('keydown', onKey);
  }
  function onOutside(e) { if (!menu.contains(e.target) && !anchor.contains(e.target)) close(); }
  function onKey(e) { if (e.key === 'Escape') { const a = anchor; close(); a?.focus(); } }

  function openMenu(button, options) {
    if (menu && anchor === button) return close();
    close();
    App.tooltip?.hide();
    anchor = button;
    anchor.setAttribute('aria-expanded', 'true');

    menu = document.createElement('div');
    menu.className = 'export-menu';
    menu.setAttribute('role', 'menu');
    menu.innerHTML = `
      <p class="export-title">Download drawing</p>
      <button role="menuitem" data-format="png">PNG <span>with background</span></button>
      <button role="menuitem" data-format="png-clear">PNG <span>transparent background</span></button>
      <button role="menuitem" data-format="jpg">JPG <span>smaller file</span></button>`;
    menu.addEventListener('click', (e) => {
      const f = e.target.closest('[data-format]')?.dataset.format;
      if (!f) return;
      close();
      download(f, options());
    });
    document.body.append(menu);

    const r = button.getBoundingClientRect();
    const w = menu.offsetWidth;
    const h = menu.offsetHeight;
    let top = r.bottom + 6;
    if (top + h > window.innerHeight - 8) top = r.top - h - 6;
    menu.style.top = `${Math.min(Math.max(8, top), window.innerHeight - h - 8)}px`;
    menu.style.left = `${Math.min(Math.max(8, r.right - w), window.innerWidth - w - 8)}px`;
    menu.querySelector('button').focus();

    document.addEventListener('pointerdown', onOutside, true);
    document.addEventListener('keydown', onKey);
  }

  return { openMenu, download };
})();
