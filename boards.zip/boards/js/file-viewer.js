// file-viewer.js — reads files inside the app, in a window over the board.
// PDF: the browser's own PDF viewer. Word (.docx): docx-reader.js. Text, Markdown, CSV, JSON and
// code: shown as text (CSV as a table). Images, audio and video: shown/played.
// Anything else: a message with a Download button.
window.App = window.App || {};

App.fileViewer = (() => {
  const TEXT_LIMIT = 2 * 1024 * 1024; // show at most 2 MB of a text file
  let overlay = null;
  let cleanup = [];
  let lastFocus = null;

  const ext = (name) => (String(name).match(/\.([a-z0-9]+)$/i)?.[1] || '').toLowerCase();
  const TEXT_EXT = new Set(['txt', 'md', 'markdown', 'csv', 'tsv', 'json', 'log', 'xml', 'html', 'htm', 'css', 'js', 'ts', 'py', 'php', 'java', 'c', 'cpp', 'h', 'cs', 'sql', 'yml', 'yaml', 'ini', 'cfg', 'sh', 'bat', 'rtf']);

  // what kind of reader a file needs
  function viewerFor(meta) {
    const e = ext(meta.name);
    const t = meta.type || '';
    if (t === 'application/pdf' || e === 'pdf') return 'pdf';
    if (e === 'docx') return 'docx';
    if (t.startsWith('image/')) return 'image';
    if (t.startsWith('video/')) return 'video';
    if (t.startsWith('audio/')) return 'audio';
    if (e === 'csv' || e === 'tsv') return 'csv';
    if (t.startsWith('text/') || TEXT_EXT.has(e) || t === 'application/json') return 'text';
    return null;
  }
  const canView = (meta) => !!viewerFor(meta);

  // very small CSV reader (handles quotes)
  function parseCsv(text, sep) {
    const rows = [];
    let row = [];
    let cell = '';
    let quoted = false;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (quoted) {
        if (ch === '"' && text[i + 1] === '"') { cell += '"'; i++; } else if (ch === '"') quoted = false; else cell += ch;
      } else if (ch === '"') quoted = true;
      else if (ch === sep) { row.push(cell); cell = ''; } else if (ch === '\n') { row.push(cell); rows.push(row); row = []; cell = ''; } else if (ch !== '\r') cell += ch;
    }
    if (cell || row.length) { row.push(cell); rows.push(row); }
    return rows;
  }

  function close() {
    if (!overlay) return;
    overlay.remove();
    overlay = null;
    cleanup.forEach((fn) => fn());
    cleanup = [];
    document.removeEventListener('keydown', onKey, true);
    lastFocus?.focus?.();
  }
  function onKey(e) {
    if (e.key === 'Escape') { e.stopPropagation(); close(); }
  }

  /**
   * meta: { name, size, type }; getBlob(): Promise<Blob>; onDownload()
   */
  async function open(meta, getBlob, onDownload) {
    close();
    App.tooltip?.hide();
    lastFocus = document.activeElement;

    overlay = document.createElement('div');
    overlay.className = 'fv';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-label', meta.name);
    overlay.innerHTML = `
      <div class="fv-window">
        <header class="fv-head">
          <span class="file-icon fv-icon"></span>
          <p class="fv-name"></p>
          <button class="file-btn" data-fv="download">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2.5v8M4.5 7L8 10.5 11.5 7M3 13.5h10"/></svg>
            Download</button>
          <button class="fv-close" data-fv="close" aria-label="Close" data-tooltip="Close  Esc">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg></button>
        </header>
        <div class="fv-body"><p class="fv-message">Opening…</p></div>
      </div>`;
    overlay.querySelector('.fv-name').textContent = meta.name;
    const icon = overlay.querySelector('.fv-icon');
    icon.textContent = (ext(meta.name) || 'file').slice(0, 4).toUpperCase();
    icon.dataset.ext = App.fileIcons?.groupOf(meta) || 'other';
    const body = overlay.querySelector('.fv-body');

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) close(); // click outside the window
      const a = e.target.closest('[data-fv]')?.dataset.fv;
      if (a === 'close') close();
      if (a === 'download') onDownload();
    });
    document.addEventListener('keydown', onKey, true);
    document.body.append(overlay);
    overlay.querySelector('[data-fv="close"]').focus();

    const kind = viewerFor(meta);
    try {
      const blob = await getBlob();
      if (!blob) throw new Error('missing');
      if (!overlay) return; // closed while loading
      const show = (el) => body.replaceChildren(el);

      if (kind === 'pdf') {
        const url = URL.createObjectURL(blob.type === 'application/pdf' ? blob : new Blob([blob], { type: 'application/pdf' }));
        cleanup.push(() => URL.revokeObjectURL(url));
        const frame = document.createElement('iframe');
        frame.className = 'fv-pdf';
        frame.src = url;
        frame.title = meta.name;
        show(frame);
      } else if (kind === 'docx') {
        const { html, urls } = await App.docxReader.toHtml(await blob.arrayBuffer());
        cleanup.push(() => urls.forEach((u) => URL.revokeObjectURL(u)));
        const page = document.createElement('article');
        page.className = 'fv-page docx';
        page.innerHTML = html || '<p class="fv-message">This document is empty.</p>';
        show(page);
      } else if (kind === 'image' || kind === 'video' || kind === 'audio') {
        const url = URL.createObjectURL(blob);
        cleanup.push(() => URL.revokeObjectURL(url));
        const el = document.createElement(kind === 'image' ? 'img' : kind);
        el.className = 'fv-media';
        el.src = url;
        if (kind !== 'image') el.controls = true;
        show(el);
      } else if (kind === 'csv') {
        const text = await blob.slice(0, TEXT_LIMIT).text();
        const rows = parseCsv(text, ext(meta.name) === 'tsv' || (text.split('\t').length > text.split(',').length) ? '\t' : ',');
        const wrap = document.createElement('div');
        wrap.className = 'fv-page fv-csv';
        const table = document.createElement('table');
        rows.slice(0, 5000).forEach((r, i) => {
          const tr = document.createElement('tr');
          r.forEach((v) => {
            const td = document.createElement(i === 0 ? 'th' : 'td');
            td.textContent = v;
            tr.append(td);
          });
          table.append(tr);
        });
        wrap.append(table);
        show(wrap);
      } else if (kind === 'text') {
        let text = await blob.slice(0, TEXT_LIMIT).text();
        if (ext(meta.name) === 'json') {
          try { text = JSON.stringify(JSON.parse(text), null, 2); } catch { /* show as is */ }
        }
        const pre = document.createElement('pre');
        pre.className = 'fv-page fv-text';
        pre.textContent = text + (blob.size > TEXT_LIMIT ? '\n\n… (only the first 2 MB are shown — download the file to see all of it)' : '');
        show(pre);
      } else {
        body.innerHTML = `<div class="fv-message">
          <p><strong>This kind of file can’t be shown here.</strong></p>
          <p>Download it to open it with the right program.</p>
          <button class="confirm-pop-btn btn-primary" data-fv="download">Download</button></div>`;
      }
    } catch (err) {
      if (!overlay) return;
      body.innerHTML = `<div class="fv-message">
        <p><strong>This file couldn’t be opened here.</strong></p>
        <p>It may be damaged or in a format the reader doesn’t understand. You can still download it.</p>
        <button class="confirm-pop-btn btn-primary" data-fv="download">Download</button></div>`;
    }
  }

  return { open, close, canView, viewerFor, ext };
})();
