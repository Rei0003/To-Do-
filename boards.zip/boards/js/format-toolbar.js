// format-toolbar.js — the floating bar that appears when you select text in a card
window.App = window.App || {};

App.formatToolbar = (() => {
  const isMac = /Mac|iPhone|iPad/.test(navigator.platform);
  const mod = isMac ? '⌘' : 'Ctrl+';

  const BUTTONS = [
    { cmd: 'bold', label: 'Bold', keys: `${mod}B`, icon: '<b>B</b>' },
    { cmd: 'italic', label: 'Italic', keys: `${mod}I`, icon: '<i style="font-family:Georgia,serif">I</i>' },
    { cmd: 'underline', label: 'Underline', keys: `${mod}U`, icon: '<u>U</u>' },
    { cmd: 'strikeThrough', label: 'Strikethrough', keys: `${mod}Shift+X`, icon: '<s>S</s>' },
    { sep: true },
    { cmd: 'size', panel: true, label: 'Text size', icon: '<span class="format-size-a"><span>A</span><span>A</span></span>' },
    { cmd: 'color', panel: true, label: 'Text colour', icon: '<span class="format-color-a">A</span>' },
    { sep: true, blocksOnly: true },
    { cmd: 'heading', label: 'Heading', blocksOnly: true, icon: '<b>H</b>' },
    {
      cmd: 'insertUnorderedList', label: 'Bullet list', blocksOnly: true,
      icon: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M6 4h8M6 8h8M6 12h8"/><circle cx="2.5" cy="4" r=".9" fill="currentColor"/><circle cx="2.5" cy="8" r=".9" fill="currentColor"/><circle cx="2.5" cy="12" r=".9" fill="currentColor"/></svg>',
    },
    { sep: true },
    {
      cmd: 'removeFormat', label: 'Clear formatting',
      icon: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3 3h8M7 3L5 13M10 9l4 4M14 9l-4 4"/></svg>',
    },
  ];

  let bar;
  const panels = {};  // 'size' | 'color' -> panel element
  let editor = null;  // the text field the selection is in
  let colorPalette;

  const isHeading = () => /h3/i.test(document.queryCommandValue('formatBlock'));

  function activeEditor() {
    const sel = window.getSelection();
    if (!sel.rangeCount || sel.isCollapsed) return null;
    const node = sel.anchorNode;
    const el = (node.nodeType === 1 ? node : node.parentElement)?.closest('[data-rich]');
    return el && el.contains(sel.focusNode) ? el : null;
  }

  // ---- panels (size list, colour swatches) ----
  function togglePanel(name) {
    Object.entries(panels).forEach(([key, panel]) => {
      panel.hidden = key === name ? !panel.hidden : true;
      bar.querySelector(`[data-cmd="${key}"]`).setAttribute('aria-expanded', String(!panel.hidden));
    });
  }
  const closePanels = () => togglePanel(null);

  function buildSizePanel() {
    const panel = document.createElement('div');
    panel.className = 'format-panel format-sizes';
    panel.hidden = true;
    [...App.fontSize.SIZES].reverse().forEach((size) => {
      const option = document.createElement('button');
      option.className = 'format-size-option';
      option.dataset.textSize = size;
      option.textContent = App.fontSize.NAMES[size];
      panel.append(option);
    });
    panel.addEventListener('click', (e) => {
      const option = e.target.closest('[data-text-size]');
      if (!option || !editor) return;
      App.fontSize.apply(editor, option.dataset.textSize);
      closePanels();
      update();
    });
    return panel;
  }

  // the custom colour box takes focus away from the text, so remember the selection first
  let savedSelection = null;

  function buildColorPanel() {
    const panel = document.createElement('div');
    panel.className = 'format-panel format-colors';
    panel.hidden = true;
    colorPalette = App.palette.create({
      presets: App.textColor.COLORS.map((name) => ({
        value: name,
        label: App.textColor.NAMES[name],
        css: name === 'default' ? 'var(--surface)' : `var(--tc-${name})`,
      })),
      visible: 8,
      size: 20,
      variant: 'dark',
      beforeCustom: () => {
        const sel = window.getSelection();
        if (editor && sel.rangeCount) savedSelection = { editor, range: sel.getRangeAt(0).cloneRange() };
      },
      customStart: () => {
        const c = editor && App.textColor.current(editor);
        return c && c.startsWith('#') ? c : null;
      },
      onPick: (color) => {
        let target = editor;
        if (!target && savedSelection) { // coming back from the custom colour box
          target = savedSelection.editor;
          target.focus({ preventScroll: true });
          const sel = window.getSelection();
          sel.removeAllRanges();
          sel.addRange(savedSelection.range);
        }
        savedSelection = null;
        if (!target) return;
        App.textColor.apply(target, color);
        closePanels();
        update();
      },
    });
    panel.append(colorPalette.el);
    return panel;
  }

  // ---- commands ----
  function run(cmd) {
    if (panels[cmd]) return togglePanel(cmd);
    if (cmd === 'heading') {
      document.execCommand('formatBlock', false, isHeading() ? '<div>' : '<h3>');
    } else if (cmd === 'removeFormat') {
      document.execCommand('removeFormat');
      if (isHeading()) document.execCommand('formatBlock', false, '<div>');
    } else {
      document.execCommand(cmd);
    }
    update();
  }

  function position() {
    const rect = window.getSelection().getRangeAt(0).getBoundingClientRect();
    const w = bar.offsetWidth;
    const h = bar.offsetHeight;
    let top = rect.top - h - 8;
    if (top < 8) top = rect.bottom + 8;
    const left = Math.min(Math.max(8, rect.left + rect.width / 2 - w / 2), window.innerWidth - w - 8);
    bar.style.top = `${top}px`;
    bar.style.left = `${left}px`;
  }

  function update() {
    const found = activeEditor();
    if (found !== editor) closePanels(); // moved to another field
    editor = found;
    if (!editor) { bar.hidden = true; return; }
    if (!App.colorPopover.isOpen()) savedSelection = null; // a fresh selection replaces the remembered one

    const allowBlocks = editor.dataset.rich === 'blocks';
    bar.querySelectorAll('[data-blocks-only]').forEach((b) => { b.hidden = !allowBlocks; });

    bar.querySelectorAll('[data-cmd]').forEach((btn) => {
      const cmd = btn.dataset.cmd;
      if (panels[cmd] || cmd === 'removeFormat') return;
      const on = cmd === 'heading' ? isHeading() : document.queryCommandState(cmd);
      btn.classList.toggle('is-active', on);
      btn.setAttribute('aria-pressed', String(on));
    });

    // size: tooltip + tick in list
    const size = App.fontSize.current(editor);
    bar.querySelector('[data-cmd="size"]').dataset.tooltip = `Text size: ${App.fontSize.NAMES[size]}`;
    panels.size.querySelectorAll('[data-text-size]').forEach((o) =>
      o.setAttribute('aria-pressed', String(o.dataset.textSize === size)));

    // colour: bar under the "A" + tick in swatches
    const color = App.textColor.current(editor);
    const colorBtn = bar.querySelector('[data-cmd="color"]');
    colorBtn.style.setProperty('--current', App.textColor.css(color));
    colorBtn.dataset.tooltip = `Text colour: ${App.textColor.nameOf(color)}`;
    colorPalette.set(color);

    bar.hidden = false;
    position();
  }

  function build() {
    bar = document.createElement('div');
    bar.className = 'format-bar';
    bar.setAttribute('role', 'toolbar');
    bar.setAttribute('aria-label', 'Text formatting');
    bar.hidden = true;

    BUTTONS.forEach((b) => {
      let el;
      if (b.sep) {
        el = document.createElement('span');
        el.className = 'format-sep';
      } else {
        el = document.createElement('button');
        el.className = 'format-btn';
        el.dataset.cmd = b.cmd;
        el.innerHTML = b.icon;
        el.setAttribute('aria-label', b.label);
        el.dataset.tooltip = b.keys ? `${b.label}  ${b.keys}` : b.label;
        if (b.panel) el.setAttribute('aria-expanded', 'false');
      }
      if (b.blocksOnly) el.dataset.blocksOnly = '';
      bar.append(el);
    });

    panels.size = buildSizePanel();
    panels.color = buildColorPanel();
    bar.append(panels.size, panels.color);

    // keep the text selected while clicking the bar
    bar.addEventListener('mousedown', (e) => e.preventDefault());
    bar.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-cmd]');
      if (btn) run(btn.dataset.cmd);
    });

    document.body.append(bar);
  }

  function init() {
    build();
    document.execCommand('styleWithCSS', false, false); // use <b>, <i>… instead of inline styles

    document.addEventListener('selectionchange', () => requestAnimationFrame(update));
    document.getElementById('viewport').addEventListener('scroll', () => { if (!bar.hidden) update(); });
    window.addEventListener('resize', () => { if (!bar.hidden) update(); });

    // keyboard shortcuts, handled here so they behave the same in every browser
    const SHORTCUTS = { b: 'bold', i: 'italic', u: 'underline' };
    document.addEventListener('keydown', (e) => {
      if (!(e.ctrlKey || e.metaKey) || e.altKey) return;
      const field = e.target.closest?.('[data-rich]');
      if (!field) return;
      const key = e.key.toLowerCase();

      // Ctrl+Shift+> / < : bigger / smaller text
      if (e.shiftKey && (key === '>' || key === '.' || key === '<' || key === ',')) {
        e.preventDefault();
        if (!window.getSelection().isCollapsed) App.fontSize.step(field, key === '>' || key === '.' ? 1 : -1);
        return update();
      }

      const cmd = e.shiftKey ? (key === 'x' ? 'strikeThrough' : null) : SHORTCUTS[key];
      if (!cmd) return;
      e.preventDefault();
      run(cmd);
    });
  }

  return { init };
})();
