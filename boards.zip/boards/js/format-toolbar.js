// format-toolbar.js — the floating bar that appears when you select text in a card
window.App = window.App || {};

App.formatToolbar = (() => {
  const isMac = /Mac|iPhone|iPad/.test(navigator.platform);
  const mod = isMac ? '⌘' : 'Ctrl+';

  const BUTTONS = [
    { cmd: 'bold', label: 'Bold', keys: `${mod}B`, icon: '<b>B</b>' },
    { cmd: 'italic', label: 'Italic', keys: `${mod}I`, icon: '<i style="font-family:Georgia,serif">I</i>' },
    { cmd: 'underline', label: 'Underline', keys: `${mod}U`, icon: '<u>U</u>' },
    { cmd: 'strikeThrough', label: 'Strikethrough', keys: `${mod}Shift+X`, icon: '<s>S</s>' },
    { sep: true, blocksOnly: true },
    { cmd: 'heading', label: 'Heading', blocksOnly: true, icon: '<b>H</b>' },
    {
      cmd: 'insertUnorderedList', label: 'Bullet list', blocksOnly: true,
      icon: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M6 4h8M6 8h8M6 12h8"/><circle cx="2.5" cy="4" r=".9" fill="currentColor"/><circle cx="2.5" cy="8" r=".9" fill="currentColor"/><circle cx="2.5" cy="12" r=".9" fill="currentColor"/></svg>',
    },
    { sep: true },
    {
      cmd: 'removeFormat', label: 'Clear formatting',
      icon: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3 3h8M7 3L5 13M10 9l4 4M14 9l-4 4"/></svg>',
    },
  ];

  let bar;

  const isHeading = () => /h3/i.test(document.queryCommandValue('formatBlock'));

  function activeEditor() {
    const sel = window.getSelection();
    if (!sel.rangeCount || sel.isCollapsed) return null;
    const node = sel.anchorNode;
    const el = (node.nodeType === 1 ? node : node.parentElement)?.closest('[data-rich]');
    return el && el.contains(sel.focusNode) ? el : null;
  }

  function run(cmd) {
    if (cmd === 'heading') {
      document.execCommand('formatBlock', false, isHeading() ? '<div>' : '<h3>');
    } else if (cmd === 'removeFormat') {
      document.execCommand('removeFormat');
      if (isHeading()) document.execCommand('formatBlock', false, '<div>');
    } else {
      document.execCommand(cmd);
    }
    update();
  }

  function position() {
    const rect = window.getSelection().getRangeAt(0).getBoundingClientRect();
    const w = bar.offsetWidth;
    const h = bar.offsetHeight;
    let top = rect.top - h - 8;
    if (top < 8) top = rect.bottom + 8;
    const left = Math.min(Math.max(8, rect.left + rect.width / 2 - w / 2), window.innerWidth - w - 8);
    bar.style.top = `${top}px`;
    bar.style.left = `${left}px`;
  }

  function update() {
    const editor = activeEditor();
    if (!editor) { bar.hidden = true; return; }

    const allowBlocks = editor.dataset.rich === 'blocks';
    bar.querySelectorAll('[data-blocks-only]').forEach((b) => { b.hidden = !allowBlocks; });
    bar.querySelectorAll('[data-cmd]').forEach((btn) => {
      const cmd = btn.dataset.cmd;
      let on = false;
      if (cmd === 'heading') on = isHeading();
      else if (cmd !== 'removeFormat') on = document.queryCommandState(cmd);
      btn.classList.toggle('is-active', on);
      if (cmd !== 'removeFormat') btn.setAttribute('aria-pressed', String(on));
    });

    bar.hidden = false;
    position();
  }

  function build() {
    bar = document.createElement('div');
    bar.className = 'format-bar';
    bar.setAttribute('role', 'toolbar');
    bar.setAttribute('aria-label', 'Text formatting');
    bar.hidden = true;

    BUTTONS.forEach((b) => {
      let el;
      if (b.sep) {
        el = document.createElement('span');
        el.className = 'format-sep';
      } else {
        el = document.createElement('button');
        el.className = 'format-btn';
        el.dataset.cmd = b.cmd;
        el.innerHTML = b.icon;
        el.setAttribute('aria-label', b.label);
        el.dataset.tooltip = b.keys ? `${b.label}  ${b.keys}` : b.label;
      }
      if (b.blocksOnly) el.dataset.blocksOnly = '';
      bar.append(el);
    });

    // keep the text selected while clicking the bar
    bar.addEventListener('mousedown', (e) => e.preventDefault());
    bar.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-cmd]');
      if (btn) run(btn.dataset.cmd);
    });

    document.body.append(bar);
  }

  function init() {
    build();
    document.execCommand('styleWithCSS', false, false); // use <b>, <i>… instead of inline styles

    document.addEventListener('selectionchange', () => requestAnimationFrame(update));
    document.getElementById('viewport').addEventListener('scroll', () => { if (!bar.hidden) update(); });
    window.addEventListener('resize', () => { if (!bar.hidden) update(); });

    // keyboard shortcuts, handled here so they behave the same in every browser
    const SHORTCUTS = { b: 'bold', i: 'italic', u: 'underline' };
    document.addEventListener('keydown', (e) => {
      if (!(e.ctrlKey || e.metaKey) || e.altKey || !e.target.closest?.('[data-rich]')) return;
      const key = e.key.toLowerCase();
      const cmd = e.shiftKey ? (key === 'x' ? 'strikeThrough' : null) : SHORTCUTS[key];
      if (!cmd) return;
      e.preventDefault();
      run(cmd);
    });
  }

  return { init };
})();
