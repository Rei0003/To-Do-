// media-import.js — create media cards by dropping files or links onto the board, or pasting them
window.App = window.App || {};

App.mediaImport = {
  init() {
    const canvas = document.getElementById('canvas');
    const hasFiles = (e) => e.dataTransfer?.types.includes('Files');
    const hasLink = (e) => e.dataTransfer?.types.includes('text/uri-list');
    const inTextField = (e) => e.target.closest?.('input, textarea, [contenteditable="true"]');

    // stop the browser from opening a file/link that misses the board (and losing your page)
    // files dropped anywhere are handled by the board (and never opened by the browser);
    // links dropped into a text field just insert the link text
    window.addEventListener('dragover', (e) => {
      if (hasFiles(e) || (hasLink(e) && !inTextField(e))) e.preventDefault();
    });
    window.addEventListener('drop', (e) => {
      if (hasFiles(e) || (hasLink(e) && !inTextField(e))) e.preventDefault();
    });

    canvas.addEventListener('dragover', (e) => {
      if (!(hasFiles(e) || (hasLink(e) && !inTextField(e)))) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
    });

    canvas.addEventListener('drop', (e) => {
      if (!hasFiles(e) && inTextField(e)) return; // dropping a link into text just inserts the text
      const p = App.board.toCanvasPoint(e.clientX, e.clientY);
      // dropped on a to-do list (or one of its tasks, or a calendar day…)? attach it there
      const target = App.nesting.dropTargetOf(e.target, 'media');
      const parent = target?.card.dataset.id;
      const item = target?.item;

      if (hasFiles(e)) {
        e.preventDefault();
        [...e.dataTransfer.files].forEach((file, i) => {
          const point = { x: p.x - 20 + i * 28, y: p.y - 14 + i * 28 };
          // images/video/audio -> media card; anything else (PDF, Word…) -> file card
          const type = App.cardTypes.media.kindOf(file) ? 'media' : 'file';
          const t = App.nesting.dropTargetOf(e.target, type);
          App.mediaImport.addFromFile(file, point, t?.card.dataset.id, t?.item);
        });
      } else if (hasLink(e)) {
        // e.g. an image dragged in from another browser tab
        e.preventDefault();
        const url = e.dataTransfer.getData('text/uri-list').split('\n').find((l) => l && !l.startsWith('#'));
        App.mediaImport.addFromLink(url, { x: p.x - 20, y: p.y - 14 }, parent, item);
      }
    });

    // Ctrl/Cmd + V while not typing: a screenshot/file, or a link to an image/video/YouTube
    document.addEventListener('paste', (e) => {
      if (inTextField(e)) return;
      const files = [...(e.clipboardData?.files || [])];
      if (files.length) {
        e.preventDefault();
        files.forEach((file) => App.mediaImport.addFromFile(file));
        return;
      }
      const text = (e.clipboardData?.getData('text/plain') || '').trim();
      const link = App.mediaLinks.parse(text);
      if (link && !link.guessed) { // links we're sure are media -> media card
        e.preventDefault();
        App.mediaImport.addFromLink(link.url);
      } else if (link && App.cardTypes.link.normalize(text) === link.url) { // any other web page -> link card
        e.preventDefault();
        App.mediaImport.addFromLink(link.url);
      }
    });
  },

  // extra data to put the new card inside a list / task
  nestData(parent, parentItem) {
    return { ...(parent && { parent }), ...(parent && parentItem && { parentItem }) };
  },

  async addFromFile(file, point, parent = null, parentItem = null) {
    if (App.access && !App.access.canAdd(parent)) return; // not allowed on this shared board
    const kind = App.cardTypes.media.kindOf(file);
    try {
      const mediaId = await App.mediaStore.put(file);
      if (kind) {
        App.board.addCard('media', point, { mediaId, kind, name: file.name, ...this.nestData(parent, parentItem) });
      } else { // PDF, Word, anything else: a File card
        App.board.addCard('file', point, {
          mediaId, name: file.name, size: file.size, fileType: file.type, ...this.nestData(parent, parentItem),
        });
      }
    } catch (err) {
      alert(`“${file.name}” couldn’t be added. It may be too large for browser storage.`);
    }
  },

  addFromLink(text, point, parent = null, parentItem = null) {
    if (App.access && !App.access.canAdd(parent)) return;
    const link = App.mediaLinks.parse(text);
    if (!link) return;
    // a web page (not a picture, video or sound we recognise) becomes a link card with a preview
    if (link.guessed) {
      App.board.addCard('link', point, { url: link.url, preview: null, ...this.nestData(parent, parentItem) });
      return;
    }
    App.board.addCard('media', point, {
      ...link, name: App.mediaLinks.domainOf(link.url), ...this.nestData(parent, parentItem),
    });
  },
};
