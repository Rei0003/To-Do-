// media-import.js — drop image/video files onto the board, or paste them, to create media cards
window.App = window.App || {};

App.mediaImport = {
  init() {
    const canvas = document.getElementById('canvas');
    const hasFiles = (e) => e.dataTransfer?.types.includes('Files');

    // stop the browser from opening a file that misses the board (and losing your page)
    window.addEventListener('dragover', (e) => { if (hasFiles(e)) e.preventDefault(); });
    window.addEventListener('drop', (e) => { if (hasFiles(e)) e.preventDefault(); });

    canvas.addEventListener('dragover', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
    });

    canvas.addEventListener('drop', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      const p = App.board.toCanvasPoint(e.clientX, e.clientY);
      // dropped on a to-do list? attach the files inside it
      const parentEl = e.target.closest('.card');
      const parent = App.nesting.accepts(parentEl, 'media') ? parentEl.dataset.id : null;
      [...e.dataTransfer.files].forEach((file, i) =>
        App.mediaImport.addFromFile(file, { x: p.x - 20 + i * 28, y: p.y - 14 + i * 28 }, parent));
    });

    // Ctrl/Cmd + V an image (e.g. a screenshot) while not typing
    document.addEventListener('paste', (e) => {
      if (e.target.closest?.('input, textarea, [contenteditable="true"]')) return;
      const files = [...(e.clipboardData?.files || [])];
      if (!files.length) return;
      e.preventDefault();
      files.forEach((file) => App.mediaImport.addFromFile(file));
    });
  },

  async addFromFile(file, point, parent = null) {
    const kind = App.cardTypes.media.kindOf(file);
    if (!kind) return;
    try {
      const mediaId = await App.mediaStore.put(file);
      App.board.addCard('media', point, { mediaId, kind, name: file.name, ...(parent && { parent }) });
    } catch (err) {
      alert(`“${file.name}” couldn’t be added. It may be too large for browser storage.`);
    }
  },
};
