// screens.js — the screens around the board: log in / register, "Your boards", and the account menu.
window.App = window.App || {};

App.screens = (() => {
  const BRAND = `<svg class="brand" viewBox="0 0 28 28" aria-hidden="true">
    <rect x="3" y="3" width="13" height="16" rx="2.5" fill="currentColor"/>
    <rect x="12" y="9" width="13" height="16" rx="2.5" fill="none" stroke="currentColor" stroke-width="2"/></svg>`;
  const TILE_COLORS = ['var(--c-blue)', 'var(--c-green)', 'var(--c-purple)', 'var(--c-pink)', 'var(--c-yellow)', 'var(--tc-orange)'];
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  // "just now", "5 min ago", "yesterday", "3 Oct"
  function ago(seconds) {
    const d = Math.max(0, Date.now() / 1000 - seconds);
    if (d < 60) return 'just now';
    if (d < 3600) return `${Math.floor(d / 60)} min ago`;
    if (d < 86400) return `${Math.floor(d / 3600)} h ago`;
    if (d < 172800) return 'yesterday';
    return new Date(seconds * 1000).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
  }
  const colorFor = (id) => TILE_COLORS[[...String(id)].reduce((a, c) => a + c.charCodeAt(0), 0) % TILE_COLORS.length];

  // ---------- log in / create account ----------
  function auth(el, { tab = 'login', server }) {
    el.innerHTML = `
      <div class="auth">
        <div class="auth-card">
          <div class="auth-brand">${BRAND}<span>Boards</span></div>
          ${server ? `
          <div class="auth-tabs" role="tablist">
            <button role="tab" data-tab="login">Log in</button>
            <button role="tab" data-tab="register">Create account</button>
          </div>
          <form class="auth-form" novalidate>
            <label class="auth-field" data-only="register"><span>Name</span>
              <input name="name" autocomplete="name" maxlength="60"></label>
            <label class="auth-field"><span>Email</span>
              <input name="email" type="email" autocomplete="email" required></label>
            <label class="auth-field"><span>Password</span>
              <input name="password" type="password" required minlength="8">
              <small data-only="register">At least 8 characters</small></label>
            <p class="auth-error" role="alert" hidden></p>
            <button class="btn-primary auth-submit" type="submit"></button>
          </form>
          <div class="auth-or"><span>or</span></div>` : `
          <p class="auth-note"><strong>Accounts need the server.</strong> Start it (see the README: XAMPP, or
            <code>php -S localhost:8000 server.php</code>) and open the app through it to log in.</p>`}
          <button class="auth-local" data-local>
            <strong>Use without an account</strong>
            <span>Your boards are kept in this browser only</span>
          </button>
        </div>
      </div>`;

    el.querySelector('[data-local]').addEventListener('click', () => {
      App.session.useLocal();
      location.hash = '#/boards';
    });
    if (!server) return;

    const form = el.querySelector('form');
    const error = el.querySelector('.auth-error');
    const submit = el.querySelector('.auth-submit');
    function setTab(t) {
      tab = t;
      el.querySelectorAll('[data-tab]').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.tab === t)));
      el.querySelectorAll('[data-only="register"]').forEach((x) => { x.hidden = t !== 'register'; });
      form.password.autocomplete = t === 'register' ? 'new-password' : 'current-password';
      submit.textContent = t === 'register' ? 'Create account' : 'Log in';
      error.hidden = true;
      (t === 'register' ? form.name : form.email).focus();
    }
    el.querySelectorAll('[data-tab]').forEach((b) => b.addEventListener('click', () => setTab(b.dataset.tab)));

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      error.hidden = true;
      const email = form.email.value.trim();
      const password = form.password.value;
      if (tab === 'register' && !form.name.value.trim()) return showError('Please enter your name.');
      if (!email || !email.includes('@')) return showError('Please enter your email address.');
      if (password.length < 8 && tab === 'register') return showError('The password needs at least 8 characters.');
      submit.disabled = true;
      submit.textContent = tab === 'register' ? 'Creating account…' : 'Logging in…';
      try {
        if (tab === 'register' && App.session.verifyEmail) {
          // step 2: check the emailed code
          const res = await App.session.registerStart(form.name.value.trim(), email, password);
          verifyStep(el, res, { name: form.name.value.trim(), email });
          return;
        }
        if (tab === 'register') {
          await App.session.register(form.name.value.trim(), email, password);
          await App.boards.create('My first board', App.state.starterBoard()); // something to start with
        } else {
          await App.session.login(email, password);
        }
        location.hash = '#/boards';
      } catch (err) {
        showError(err.message);
        submit.disabled = false;
        submit.textContent = tab === 'register' ? 'Create account' : 'Log in';
      }
    });
    function showError(msg) { error.textContent = msg; error.hidden = false; }
    setTab(tab);
  }

  // ---------- registering: "check your email" + the 6-digit code ----------
  function verifyStep(el, res, { name, email }) {
    const card = el.querySelector('.auth-card');
    card.innerHTML = `
      <div class="auth-brand">${BRAND}<span>Boards</span></div>
      <div class="verify">
        <div class="verify-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3.5 6.5L12 13l8.5-6.5"/></svg></div>
        <h2>Check your email</h2>
        <p class="verify-text">We sent a 6-digit code to <strong>${esc(res.email)}</strong>. Type it below to finish creating your account.</p>
        ${res.dev_code ? `<p class="verify-dev"><strong>Development mode:</strong> email isn’t set up on this server yet, so here’s your code:
          <button class="verify-dev-code" type="button" data-fill>${esc(res.dev_code)}</button></p>` : ''}
        <form class="verify-form" novalidate>
          <div class="code-boxes" role="group" aria-label="6-digit code">
            ${Array.from({ length: 6 }, (_, i) => `<input inputmode="numeric" maxlength="1" autocomplete="${i ? 'off' : 'one-time-code'}" aria-label="Digit ${i + 1}">`).join('')}
          </div>
          <p class="auth-error" role="alert" hidden></p>
          <button class="btn-primary auth-submit" type="submit">Confirm and create account</button>
        </form>
        <p class="verify-links">
          <button type="button" class="verify-link" data-resend></button>
          <span>·</span>
          <button type="button" class="verify-link" data-back>Use a different email</button>
        </p>
        <p class="verify-small">The code works for ${res.minutes || 15} minutes. Can’t find it? Check your spam folder.</p>
      </div>`;
    const boxes = [...card.querySelectorAll('.code-boxes input')];
    const error = card.querySelector('.auth-error');
    const submit = card.querySelector('.auth-submit');
    const resend = card.querySelector('[data-resend]');
    const showError = (msg) => { error.textContent = msg; error.hidden = !msg; };
    const code = () => boxes.map((b) => b.value).join('');

    // typing, deleting and pasting across the six boxes
    function fill(text, from = 0) {
      const digits = String(text).replace(/\D/g, '').slice(0, 6 - from).split('');
      digits.forEach((d, i) => { boxes[from + i].value = d; });
      boxes[Math.min(5, from + digits.length)].focus();
      if (code().length === 6) send();
    }
    boxes.forEach((box, i) => {
      box.addEventListener('input', () => {
        const v = box.value.replace(/\D/g, '');
        if (v.length > 1) { fill(v, i); return; }
        box.value = v;
        if (v && i < 5) boxes[i + 1].focus();
        if (code().length === 6) send();
      });
      box.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace' && !box.value && i > 0) { boxes[i - 1].value = ''; boxes[i - 1].focus(); e.preventDefault(); }
        if (e.key === 'ArrowLeft' && i > 0) boxes[i - 1].focus();
        if (e.key === 'ArrowRight' && i < 5) boxes[i + 1].focus();
      });
      box.addEventListener('paste', (e) => { e.preventDefault(); fill(e.clipboardData.getData('text'), i); });
      box.addEventListener('focus', () => box.select());
    });
    card.querySelector('[data-fill]')?.addEventListener('click', (e) => fill(e.target.textContent, 0));

    let busy = false;
    async function send() {
      if (busy || code().length !== 6) return;
      busy = true;
      showError('');
      submit.disabled = true;
      submit.textContent = 'Checking…';
      try {
        await App.session.verifyCode(email, code());
        await App.boards.create('My first board', App.state.starterBoard()); // something to start with
        location.hash = '#/boards';
      } catch (err) {
        showError(err.message);
        boxes.forEach((b) => { b.value = ''; });
        boxes[0].focus();
        submit.disabled = false;
        submit.textContent = 'Confirm and create account';
      } finally { busy = false; }
    }
    card.querySelector('.verify-form').addEventListener('submit', (e) => {
      e.preventDefault();
      if (code().length !== 6) { showError('Please type all 6 digits.'); return; }
      send();
    });

    // "Send a new code" (after a short wait)
    let wait = res.resend_in || 60;
    let timer = 0;
    const tickDown = () => {
      clearInterval(timer);
      const paint = () => {
        resend.disabled = wait > 0;
        resend.textContent = wait > 0 ? `Send a new code in ${wait}s` : 'Send a new code';
      };
      paint();
      timer = setInterval(() => {
        wait--;
        paint();
        if (wait <= 0 || !resend.isConnected) clearInterval(timer);
      }, 1000);
    };
    tickDown();
    resend.addEventListener('click', async () => {
      try {
        const r = await App.session.resendCode(email);
        showError('');
        const dev = card.querySelector('.verify-dev-code');
        if (dev && r.dev_code) dev.textContent = r.dev_code;
        card.querySelector('.verify-text').innerHTML = `We sent a <strong>new</strong> code to <strong>${esc(r.email)}</strong>.`;
        wait = r.resend_in || 60;
        tickDown();
        boxes.forEach((b) => { b.value = ''; });
        boxes[0].focus();
      } catch (err) { showError(err.message); }
    });
    card.querySelector('[data-back]').addEventListener('click', () => {
      clearInterval(timer);
      auth(el, { tab: 'register', server: true });
      const form = el.querySelector('.auth-form');
      form.name.value = name;
      form.email.value = email;
      form.email.focus();
      form.email.select();
    });
    boxes[0].focus();
  }

  // ---------- account menu (top bar and home screen) ----------
  let menu = null;
  function closeMenu() {
    menu?.remove();
    menu = null;
    document.removeEventListener('pointerdown', outside, true);
  }
  function outside(e) { if (menu && !menu.contains(e.target) && !e.target.closest('[data-account]')) closeMenu(); }
  function openAccountMenu(anchor) {
    if (menu) return closeMenu();
    App.tooltip?.hide();
    const u = App.session.user;
    menu = document.createElement('div');
    menu.className = 'account-menu draw-menu draw-panel';
    menu.innerHTML = u
      ? `<button class="account-who account-who-btn" data-m="profile"><span class="account-pic"></span>
           <span class="account-who-text"><strong>${esc(u.name)}</strong><span>${esc(u.email)}</span></span></button><hr>
         <button data-m="profile">Profile &amp; picture…</button>
         <button data-m="boards">All boards</button>
         <button data-m="team">Team activity</button>
         <button data-m="settings">Settings…</button>
         <button data-m="logout" class="is-danger">Log out</button>`
      : `<div class="account-who"><strong>Not logged in</strong><span>Boards are saved in this browser</span></div><hr>
         <button data-m="boards">All boards</button>
         <button data-m="settings">Settings…</button>
         ${App.session.server ? '<button data-m="login">Log in or create an account</button>' : ''}`;
    menu.addEventListener('click', async (e) => {
      const m = e.target.closest('[data-m]')?.dataset.m;
      if (!m) return;
      closeMenu();
      if (m === 'boards') location.hash = '#/boards';
      if (m === 'profile') App.profile.open();
      if (m === 'team') location.hash = '#/team';
      if (m === 'settings') App.settings.open();
      if (m === 'login') location.hash = '#/login';
      if (m === 'logout') {
        await App.storage.flush();
        await App.session.logout();
        location.hash = '#/login';
      }
    });
    if (u) menu.querySelector('.account-pic')?.append(App.people.avatar(u.email, 36));
    document.body.append(menu);
    const r = anchor.getBoundingClientRect();
    menu.style.top = `${r.bottom + 6}px`;
    menu.style.left = `${Math.max(8, Math.min(r.right - menu.offsetWidth, window.innerWidth - menu.offsetWidth - 8))}px`;
    document.addEventListener('pointerdown', outside, true);
  }
  // the round button with your initial
  function accountButton(btn) {
    const u = App.session.user;
    btn.dataset.account = '';
    btn.textContent = u ? (u.name.trim()[0] || '?').toUpperCase() : '';
    if (u?.avatar) {
      const img = document.createElement('img');
      img.alt = '';
      img.src = u.avatar;
      img.onerror = () => img.remove();
      btn.append(img);
    }
    btn.classList.toggle('is-local', !u);
    btn.setAttribute('aria-label', u ? `Account: ${u.name}` : 'Not logged in');
    btn.dataset.tooltip = u ? `${u.name}\n${u.email}` : 'Not logged in\n(boards are saved in this browser)';
    if (!btn.dataset.wired) {
      btn.dataset.wired = '1';
      btn.addEventListener('click', () => openAccountMenu(btn));
    }
  }

  // ---------- "Your boards" ----------
  async function home(el) {
    const u = App.session.user;
    el.innerHTML = `
      <div class="home">
        <header class="home-head">
          <div class="home-brand">${BRAND}<span>Boards</span></div>
          <span class="home-spacer"></span>
          ${u ? '<a class="file-btn home-team-link" href="#/team">Team activity</a>' : ''}
          <button class="theme-toggle home-theme" aria-label="Switch theme" data-tooltip="Light / dark">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/></svg></button>
          <button class="account-btn"></button>
        </header>
        <main class="home-body">
          <div class="home-title"><h1>Your boards</h1>
            <p>${u ? `Saved in your account · ${esc(u.email)}` : 'Saved in this browser'}</p></div>
          <div class="home-banners"></div>
          <section class="home-tasks" hidden></section>
          <div class="board-grid" aria-busy="true"><p class="home-loading">Loading boards…</p></div>
        </main>
      </div>`;
    accountButton(el.querySelector('.account-btn'));
    el.querySelector('.home-theme').addEventListener('click', () => App.theme.toggle());

    const banners = el.querySelector('.home-banners');
    // using the app without an account
    if (!u) {
      const b = document.createElement('div');
      b.className = 'home-banner';
      b.innerHTML = App.session.server
        ? '<p><strong>Not logged in.</strong> Boards are only saved in this browser. Create an account to use them on any computer.</p><a class="file-btn" href="#/login">Log in or create an account</a>'
        : '<p><strong>Boards are saved in this browser.</strong> To use accounts, open the app through the PHP server (see the README).</p>';
      banners.append(b);
    }
    // logged in, and this browser still has boards from before
    const importKey = u ? `boards.imported.${u.id}` : null;
    if (u && !localStorage.getItem(importKey) && App.boards.localCount() > 0) {
      const b = document.createElement('div');
      b.className = 'home-banner home-banner--import';
      const n = App.boards.localCount();
      b.innerHTML = `<p><strong>This browser has ${n} board${n === 1 ? '' : 's'} from before you logged in.</strong> Copy them into your account (with their pictures and files)?</p>
        <div class="home-banner-actions"><button class="file-btn" data-imp="no">Not now</button><button class="confirm-pop-btn btn-primary" data-imp="yes">Copy to my account</button></div>`;
      b.addEventListener('click', async (e) => {
        const a = e.target.closest('[data-imp]')?.dataset.imp;
        if (a === 'no') { localStorage.setItem(importKey, 'skipped'); b.remove(); }
        if (a === 'yes') {
          b.innerHTML = '<p>Copying your boards… <span class="imp-progress"></span></p>';
          try {
            await App.boards.importLocalBoards((done, total) => { b.querySelector('.imp-progress').textContent = `${done} of ${total}`; });
            localStorage.setItem(importKey, 'done');
            home(el);
          } catch (err) {
            b.innerHTML = `<p>Copying stopped: ${esc(err.message)}</p>`;
          }
        }
      });
      banners.append(b);
    }

    // tasks other people (or you) assigned to you, on any board
    if (u) showAssigned(el.querySelector('.home-tasks'));

    const grid = el.querySelector('.board-grid');
    let boards = [];
    let shared = [];
    try {
      ({ boards, shared } = await App.boards.list());
    } catch (err) {
      if (err.status === 401) { location.hash = '#/login'; return; }
      grid.innerHTML = `<p class="home-loading">Couldn’t load your boards: ${esc(err.message)}</p>`;
      return;
    }
    grid.removeAttribute('aria-busy');
    const ROLE = { edit: 'Can edit', view: 'Can view', cards: 'Can edit some cards' };
    const tiles = boards.map((b) => `
      <div class="board-tile" data-id="${esc(b.id)}" style="--tile:${colorFor(b.id)}">
        <a class="board-open" href="#/board/${esc(b.id)}">
          <span class="board-band"></span>
          <span class="board-name">${esc(b.title || 'Untitled board')}</span>
          <span class="board-meta">${b.cards ?? 0} card${b.cards === 1 ? '' : 's'} · edited ${ago(b.updated_at)}${b.members ? ` · shared with ${b.members}` : ''}</span>
        </a>
        <button class="board-more" aria-label="Board options" data-tooltip="Rename, duplicate, delete">
          <svg viewBox="0 0 16 16" fill="currentColor"><circle cx="3.5" cy="8" r="1.3"/><circle cx="8" cy="8" r="1.3"/><circle cx="12.5" cy="8" r="1.3"/></svg></button>
      </div>`).join('');
    grid.innerHTML = `
      <button class="board-tile board-new"><span class="board-plus">+</span><span>New board</span></button>
      ${tiles}`;

    // boards other people shared with you
    if (shared.length) {
      const section = document.createElement('section');
      section.className = 'home-shared';
      section.innerHTML = `<h2>Shared with you</h2><div class="board-grid">${shared.map((b) => `
        <div class="board-tile is-shared" data-id="${esc(b.id)}" style="--tile:${colorFor(b.id)}">
          <a class="board-open" href="#/board/${esc(b.id)}">
            <span class="board-band"><span class="board-role">${ROLE[b.role] || ''}</span></span>
            <span class="board-name">${esc(b.title || 'Untitled board')}</span>
            <span class="board-meta">From ${esc(b.owner)} · edited ${ago(b.updated_at)}</span>
          </a>
          <button class="board-more" aria-label="Board options" data-tooltip="Leave board">
            <svg viewBox="0 0 16 16" fill="currentColor"><circle cx="3.5" cy="8" r="1.3"/><circle cx="8" cy="8" r="1.3"/><circle cx="12.5" cy="8" r="1.3"/></svg></button>
        </div>`).join('')}</div>`;
      grid.after(section);
      section.addEventListener('click', (e) => {
        const more = e.target.closest('.board-more');
        if (!more) return;
        const board = shared.find((b) => b.id === more.closest('.board-tile').dataset.id);
        App.confirmPopover.open(more, {
          title: `Leave “${board.title}”?`,
          message: `${board.owner} would have to invite you again.`,
          confirmLabel: 'Leave board',
          onConfirm: async () => {
            try { await App.boards.members.remove(board.id, App.session.user.email); home(el); } catch (err) { alertBanner(err.message); }
          },
        });
      });
    }

    grid.querySelector('.board-new').addEventListener('click', async () => {
      try {
        const b = await App.boards.create('Untitled board');
        location.hash = `#/board/${b.id}`;
      } catch (err) { alertBanner(err.message); }
    });

    grid.addEventListener('click', (e) => {
      const more = e.target.closest('.board-more');
      if (!more) return;
      const tile = more.closest('.board-tile');
      boardMenu(more, tile, boards.find((b) => b.id === tile.dataset.id));
    });

    function alertBanner(msg) {
      const b = document.createElement('div');
      b.className = 'home-banner home-banner--error';
      b.textContent = msg;
      banners.append(b);
      setTimeout(() => b.remove(), 6000);
    }

    // rename / duplicate / delete one board
    function boardMenu(anchor, tile, board) {
      closeMenu();
      menu = document.createElement('div');
      menu.className = 'draw-menu draw-panel';
      menu.innerHTML = `<button data-b="open">Open</button><button data-b="rename">Rename</button>
        <button data-b="duplicate">Duplicate</button><hr><button data-b="delete" class="is-danger">Delete…</button>`;
      document.body.append(menu);
      const r = anchor.getBoundingClientRect();
      menu.style.top = `${r.bottom + 4}px`;
      menu.style.left = `${Math.min(r.left, window.innerWidth - menu.offsetWidth - 8)}px`;
      document.addEventListener('pointerdown', outside, true);
      menu.addEventListener('click', async (e) => {
        const a = e.target.closest('[data-b]')?.dataset.b;
        if (!a) return;
        closeMenu();
        try {
          if (a === 'open') location.hash = `#/board/${board.id}`;
          if (a === 'duplicate') { await App.boards.duplicate(board.id); home(el); }
          if (a === 'rename') renameTile(tile, board);
          if (a === 'delete') {
            App.confirmPopover.open(anchor, {
              title: `Delete “${board.title || 'Untitled board'}”?`,
              message: 'Everything on it is deleted too. This can’t be undone.',
              confirmLabel: 'Delete board',
              onConfirm: async () => {
                try { await App.boards.remove(board.id); home(el); } catch (err) { alertBanner(err.message); }
              },
            });
          }
        } catch (err) { alertBanner(err.message); }
      });
    }

    function renameTile(tile, board) {
      const name = tile.querySelector('.board-name');
      const input = document.createElement('input');
      input.className = 'board-rename';
      input.value = board.title || '';
      input.maxLength = 200;
      name.replaceWith(input);
      input.focus();
      input.select();
      let done = false;
      const finish = async (keep) => {
        if (done) return;
        done = true;
        const title = input.value.trim() || 'Untitled board';
        if (keep && title !== board.title) {
          try { await App.boards.rename(board.id, title); } catch (err) { alertBanner(err.message); }
        }
        home(el);
      };
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') finish(true);
        if (e.key === 'Escape') finish(false);
      });
      input.addEventListener('blur', () => finish(true));
      // stop the link from opening while typing
      input.addEventListener('click', (e) => e.preventDefault());
    }
  }

  async function showAssigned(section) {
    let tasks = [];
    try { tasks = await App.boards.assigned(); } catch { return; }
    if (!tasks.length) { section.hidden = true; return; }
    section.hidden = false;
    section.innerHTML = `<h2>Assigned to you <span class="home-count">${tasks.length}</span></h2><ul class="task-list"></ul>`;
    const ul = section.querySelector('ul');
    tasks.forEach((t) => {
      const li = document.createElement('li');
      li.className = 'task-row';
      li.innerHTML = `
        <a class="task-link" href="#/board/${esc(t.board)}">
          <span class="task-text"></span>
          <span class="task-where"></span>
        </a>`;
      li.querySelector('.task-text').textContent = t.text || 'Untitled task';
      li.querySelector('.task-where').textContent = `${t.list || 'To-do list'} · ${t.board_title}`;
      if (t.due) {
        const chip = document.createElement('span');
        chip.className = 'due-chip';
        chip.dataset.status = App.dueDate.status(t.due);
        chip.textContent = App.dueDate.label(t.due);
        li.querySelector('.task-link').after(chip);
      }
      if (t.priority && t.priority !== 'none') li.dataset.priority = t.priority;
      // stage: To do → In progress → Done (done tasks leave the list)
      const chip = App.taskStatus.chip(t.status);
      li.querySelector('.task-where').prepend(chip);
      li.prepend(App.taskStatus.button(t.status || 'todo', {
        onChange: async (to) => {
          await App.boards.toggleTask(t.board, t.card, t.item, to === 'done', to);
          li.classList.toggle('is-done', to === 'done');
          li.classList.toggle('is-doing', to === 'doing');
          chip.hidden = to !== 'doing';
          if (to === 'done') setTimeout(() => { li.remove(); if (!ul.children.length) section.hidden = true; }, 900);
          return true;
        },
      }));
      li.classList.toggle('is-doing', t.status === 'doing');
      ul.append(li);
    });
  }

  return { auth, home, accountButton, closeMenu };
})();
