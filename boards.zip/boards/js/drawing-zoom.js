// drawing-zoom.js — zooming and panning inside a drawing canvas.
//  • Ctrl/⌘ + scroll (or trackpad pinch): zoom around the mouse
//  • −  100%  +  buttons in the canvas's toolbar (click the % to reset)
//  • Hand tool, middle-mouse drag, or hold Space + drag: move around the drawing
//  • Scroll wheel while zoomed: move up/down (Shift + scroll: sideways)
//  • Ctrl/⌘ + = / − / 0 while the canvas is focused
// The view (zoom + offset) is saved per canvas in card.view.
window.App = window.App || {};

App.drawingZoom = (() => {
  const MIN = 0.25;
  const MAX = 6;
  const STEP = 1.25;
  const clamp = (z) => Math.min(MAX, Math.max(MIN, z));
  const round = (v, d = 1) => Math.round(v * 10 ** d) / 10 ** d;

  const ICONS = {
    minus: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3.5 8h9"/></svg>',
    plus: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3.5 8h9M8 3.5v9"/></svg>',
  };

  /**
   * card      the drawing card's data
   * surface   the element you draw on
   * getScale  () => the canvas's size scaling (from drawing.js)
   * redraw    () => repaint the drawing
   */
  function attach({ card, surface, getScale, redraw }) {
    const view = { zoom: card.view?.z || 1, x: card.view?.x || 0, y: card.view?.y || 0 };
    let saveTimer = 0;
    let spaceHeld = false;
    let pan = null;
    let frame = 0;

    // ---- controls: −  100%  + ----
    const controls = document.createElement('div');
    controls.className = 'draw-group draw-zoom';
    controls.innerHTML = `
      <button class="draw-btn" data-zoom="out" aria-label="Zoom out" data-tooltip="Zoom out  Ctrl+−">${ICONS.minus}</button>
      <button class="draw-zoom-label" data-zoom="reset" aria-label="Reset zoom" data-tooltip="Reset to 100%  Ctrl+0">100%</button>
      <button class="draw-btn" data-zoom="in" aria-label="Zoom in" data-tooltip="Zoom in  Ctrl+=">${ICONS.plus}</button>`;
    const label = controls.querySelector('[data-zoom="reset"]');
    const outBtn = controls.querySelector('[data-zoom="out"]');
    const inBtn = controls.querySelector('[data-zoom="in"]');

    const k = () => getScale() * view.zoom; // total: reference units -> screen px
    const isMoved = () => view.zoom !== 1 || view.x !== 0 || view.y !== 0;

    function persist() {
      clearTimeout(saveTimer);
      saveTimer = setTimeout(() => {
        card.view = { z: round(view.zoom, 3), x: round(view.x), y: round(view.y) };
        App.state.updateCard(card.id, { view: card.view });
      }, 250);
    }

    function update() {
      label.textContent = `${Math.round(view.zoom * 100)}%`;
      outBtn.disabled = view.zoom <= MIN;
      inBtn.disabled = view.zoom >= MAX;
      surface.classList.toggle('is-zoomed', isMoved());
      if (!frame) frame = requestAnimationFrame(() => { frame = 0; redraw(); });
      persist();
    }

    // zoom so the point under (cx, cy) — relative to the surface — stays put
    function zoomAt(newZoom, cx, cy) {
      newZoom = clamp(newZoom);
      if (newZoom === view.zoom) return;
      const k1 = k();
      const wx = (cx - view.x) / k1;
      const wy = (cy - view.y) / k1;
      view.zoom = newZoom;
      const k2 = k();
      view.x = cx - wx * k2;
      view.y = cy - wy * k2;
      update();
    }
    const zoomCentre = (factor) => zoomAt(view.zoom * factor, surface.clientWidth / 2, surface.clientHeight / 2);

    function reset() {
      view.zoom = 1;
      view.x = 0;
      view.y = 0;
      update();
    }

    controls.addEventListener('click', (e) => {
      const which = e.target.closest('[data-zoom]')?.dataset.zoom;
      if (which === 'in') zoomCentre(STEP);
      if (which === 'out') zoomCentre(1 / STEP);
      if (which === 'reset') reset();
    });

    // ---- mouse wheel / trackpad ----
    surface.addEventListener('wheel', (e) => {
      const r = surface.getBoundingClientRect();
      const lineScale = e.deltaMode === 1 ? 33 : 1; // some mice scroll in lines
      if (e.ctrlKey || e.metaKey) { // Ctrl+scroll and trackpad pinch
        e.preventDefault();
        zoomAt(view.zoom * Math.exp(-e.deltaY * lineScale * 0.0025), e.clientX - r.left, e.clientY - r.top);
        return;
      }
      if (!isMoved()) return; // not zoomed: let the page scroll as normal
      e.preventDefault();
      if (e.shiftKey) view.x -= (e.deltaY || e.deltaX) * lineScale;
      else { view.x -= e.deltaX * lineScale; view.y -= e.deltaY * lineScale; }
      update();
    }, { passive: false });

    // ---- dragging the view around ----
    function startPan(e) {
      e.preventDefault();
      e.stopPropagation();
      surface.focus({ preventScroll: true });
      surface.setPointerCapture(e.pointerId);
      pan = { id: e.pointerId, x: e.clientX, y: e.clientY, vx: view.x, vy: view.y };
      surface.classList.add('is-panning');
    }
    surface.addEventListener('pointermove', (e) => {
      if (!pan || e.pointerId !== pan.id) return;
      view.x = pan.vx + e.clientX - pan.x;
      view.y = pan.vy + e.clientY - pan.y;
      update();
    });
    const endPan = (e) => {
      if (!pan || e.pointerId !== pan.id) return;
      pan = null;
      surface.classList.remove('is-panning');
    };
    surface.addEventListener('pointerup', endPan);
    surface.addEventListener('pointercancel', endPan);

    // ---- keyboard (while the canvas is focused) ----
    surface.addEventListener('keydown', (e) => {
      if (e.key === ' ' && !e.repeat) {
        e.preventDefault();
        spaceHeld = true;
        surface.classList.add('is-space');
        return;
      }
      if (!(e.ctrlKey || e.metaKey)) return;
      if (e.key === '=' || e.key === '+') { e.preventDefault(); zoomCentre(STEP); }
      if (e.key === '-' || e.key === '_') { e.preventDefault(); zoomCentre(1 / STEP); }
      if (e.key === '0') { e.preventDefault(); reset(); }
    });
    const releaseSpace = () => { spaceHeld = false; surface.classList.remove('is-space'); };
    surface.addEventListener('keyup', (e) => { if (e.key === ' ') releaseSpace(); });
    surface.addEventListener('blur', releaseSpace);

    label.textContent = `${Math.round(view.zoom * 100)}%`;
    outBtn.disabled = view.zoom <= MIN;
    inBtn.disabled = view.zoom >= MAX;
    surface.classList.toggle('is-zoomed', isMoved());

    return {
      controls,
      view,
      k,
      startPan,
      isPanning: () => !!pan,
      spaceHeld: () => spaceHeld,
    };
  }

  return { attach };
})();
