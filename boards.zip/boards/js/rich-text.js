// rich-text.js — editable text fields that keep formatting (bold, italic, headings…).
// Every note, task, list title and caption is built with App.richText.create().
window.App = window.App || {};

App.richText = (() => {
  // tags we keep; anything else is unwrapped to plain text
  const BLOCK_TAGS = new Set(['B', 'STRONG', 'I', 'EM', 'U', 'S', 'STRIKE', 'DEL', 'BR', 'H3', 'UL', 'OL', 'LI', 'DIV', 'P']);
  const INLINE_TAGS = new Set(['B', 'STRONG', 'I', 'EM', 'U', 'S', 'STRIKE', 'DEL', 'BR']);
  const DROP_TAGS = new Set(['SCRIPT', 'STYLE', 'IFRAME', 'OBJECT', 'EMBED', 'TEMPLATE']);

  // plain text -> safe HTML (used for old cards saved before formatting existed)
  function fromText(text = '') {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML.replace(/\n/g, '<br>');
  }

  // strips anything that isn't simple formatting, plus all attributes (styles, onclick…)
  function sanitize(html = '', { blocks = true } = {}) {
    const allowed = blocks ? BLOCK_TAGS : INLINE_TAGS;
    const tpl = document.createElement('template');
    tpl.innerHTML = html;

    (function clean(node) {
      [...node.childNodes].forEach((child) => {
        if (child.nodeType === Node.TEXT_NODE) return;
        if (child.nodeType !== Node.ELEMENT_NODE) return child.remove();
        if (DROP_TAGS.has(child.tagName)) return child.remove();
        clean(child);
        if (!allowed.has(child.tagName)) return child.replaceWith(...child.childNodes);
        [...child.attributes].forEach((attr) => child.removeAttribute(attr.name));
      });
    })(tpl.content);

    return tpl.innerHTML;
  }

  /**
   * options:
   *  html         starting content
   *  placeholder  grey hint shown when empty
   *  multiline    false = single line (Enter calls onEnter instead of a new line)
   *  onChange     (html, plainText) => {}
   */
  function create({ className = '', placeholder = '', html = '', multiline = true, onChange, onEnter }) {
    const blocks = multiline;
    const el = document.createElement('div');
    el.className = `rich ${className}`.trim();
    el.contentEditable = 'true';
    el.dataset.rich = blocks ? 'blocks' : 'inline';
    el.dataset.placeholder = placeholder;
    el.innerHTML = sanitize(html, { blocks });

    el.addEventListener('input', () => {
      // empty it fully so the placeholder comes back
      if (el.innerText.trim() === '' && !el.querySelector('li')) el.innerHTML = '';
      onChange?.(sanitize(el.innerHTML, { blocks }), el.innerText.trim());
    });

    // pasting brings in plain text only, so styles from other sites don't leak in
    el.addEventListener('paste', (e) => {
      e.preventDefault();
      let text = e.clipboardData.getData('text/plain');
      if (!multiline) text = text.replace(/\s*\n\s*/g, ' ');
      document.execCommand('insertText', false, text);
    });

    if (!multiline) {
      el.addEventListener('keydown', (e) => {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        onEnter?.();
      });
    }

    return el;
  }

  return { create, sanitize, fromText };
})();
