// drag.js — moving cards around the board with mouse, pen or touch
window.App = window.App || {};

App.drag = {
  attach(canvas) {
    let active = null;

    canvas.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return; // right/middle button is for panning
      const cardEl = e.target.closest('.card');
      if (!cardEl) return;

      // any click on a card brings it to the front
      cardEl.style.zIndex = App.state.bringToFront(cardEl.dataset.id);

      const handle = e.target.closest('[data-drag-handle]');
      if (!handle || e.target.closest('button')) return;

      active = {
        el: cardEl,
        id: cardEl.dataset.id,
        startX: e.clientX,
        startY: e.clientY,
        originX: cardEl.offsetLeft,
        originY: cardEl.offsetTop,
      };
      cardEl.classList.add('is-dragging');
      handle.setPointerCapture(e.pointerId);
      e.preventDefault();
    });

    canvas.addEventListener('pointermove', (e) => {
      if (!active) return;
      const x = Math.max(0, active.originX + e.clientX - active.startX);
      const y = Math.max(0, active.originY + e.clientY - active.startY);
      active.el.style.left = `${x}px`;
      active.el.style.top = `${y}px`;
    });

    const end = () => {
      if (!active) return;
      active.el.classList.remove('is-dragging');
      App.state.updateCard(active.id, { x: active.el.offsetLeft, y: active.el.offsetTop });
      active = null;
    };
    canvas.addEventListener('pointerup', end);
    canvas.addEventListener('pointercancel', end);
  },
};
