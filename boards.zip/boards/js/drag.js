// drag.js — moving cards around the board with mouse, pen or touch.
// Dropping a card onto a card that accepts it (see nesting.js) puts it inside.
window.App = window.App || {};

App.drag = (() => {
  let active = null;

  // start dragging `cardEl` from pointer event `e` (also used by nesting.js)
  function begin(cardEl, e) {
    active = {
      el: cardEl,
      id: cardEl.dataset.id,
      type: cardEl.dataset.type,
      startX: e.clientX,
      startY: e.clientY,
      originX: cardEl.offsetLeft,
      originY: cardEl.offsetTop,
      target: null,
    };
    cardEl.style.zIndex = App.state.bringToFront(active.id);
    cardEl.classList.add('is-dragging');
    try { cardEl.setPointerCapture(e.pointerId); } catch { /* pointer already released */ }
  }

  function attach(canvas) {
    canvas.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return; // right/middle button is for panning
      const cardEl = e.target.closest('.card');
      if (!cardEl) return;

      // any click on a card brings it to the front
      cardEl.style.zIndex = App.state.bringToFront(cardEl.dataset.id);

      const handle = e.target.closest('[data-drag-handle]');
      if (!handle || e.target.closest('button')) return;

      begin(cardEl, e);
      e.preventDefault();
    });

    canvas.addEventListener('pointermove', (e) => {
      if (!active) return;
      const x = Math.max(0, active.originX + e.clientX - active.startX);
      const y = Math.max(0, active.originY + e.clientY - active.startY);
      active.el.style.left = `${x}px`;
      active.el.style.top = `${y}px`;
      App.wires.schedule(); // keep connected wires attached

      // is there a card underneath that this one can go inside?
      active.target = App.nesting.findTarget(e, active.type, active.el);
      App.nesting.highlight(active.target);
      active.el.classList.toggle('is-over-nest', !!active.target); // see-through so you can aim at a task
    });

    const end = () => {
      if (!active) return;
      const { el, id, target } = active;
      active = null;
      el.classList.remove('is-dragging', 'is-over-nest');
      App.nesting.highlight(null);

      if (target) App.state.nestCard(id, target.card.dataset.id, target.item);
      else App.state.updateCard(id, { x: el.offsetLeft, y: el.offsetTop });
    };
    canvas.addEventListener('pointerup', end);
    canvas.addEventListener('pointercancel', end);
  }

  return { attach, begin };
})();
