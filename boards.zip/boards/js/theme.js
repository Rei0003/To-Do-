// theme.js — light/dark mode. Loaded in <head> so the page never flashes the wrong theme.
window.App = window.App || {};

App.theme = (() => {
  const KEY = 'boards.theme';
  const root = document.documentElement;
  const systemDark = window.matchMedia('(prefers-color-scheme: dark)');

  const saved = () => {
    try { return localStorage.getItem(KEY); } catch { return null; }
  };

  const isDark = () => {
    const choice = root.dataset.theme;
    return choice ? choice === 'dark' : systemDark.matches;
  };

  function apply() {
    const choice = saved();
    if (choice) root.dataset.theme = choice;
    else delete root.dataset.theme;
    root.classList.toggle('is-dark', isDark());
  }

  function set(theme) {
    try { localStorage.setItem(KEY, theme); } catch {}
    apply();
  }

  apply();
  systemDark.addEventListener('change', apply);

  return {
    isDark,
    set,
    toggle: () => set(isDark() ? 'light' : 'dark'),

    init() {
      const btn = document.getElementById('theme-toggle');
      const label = () => btn.setAttribute('aria-label', isDark() ? 'Switch to light mode' : 'Switch to dark mode');
      label();
      btn.addEventListener('click', () => { App.theme.toggle(); label(); });
      systemDark.addEventListener('change', label);
    },
  };
})();
