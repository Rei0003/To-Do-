// settings.js — the Settings window (from the account menu). For now: click sounds.
window.App = window.App || {};

App.settings = (() => {
  let modal = null;
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const PLAY = '<svg viewBox="0 0 16 16" fill="currentColor"><path d="M5 3.2v9.6a.6.6 0 0 0 .9.5l7.6-4.8a.6.6 0 0 0 0-1L5.9 2.7a.6.6 0 0 0-.9.5z"/></svg>';

  function close() {
    modal?.remove();
    modal = null;
    document.removeEventListener('keydown', onKey, true);
  }
  function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } }

  function open() {
    close();
    App.tooltip?.hide();
    modal = document.createElement('div');
    modal.className = 'fv settings-modal';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-label', 'Settings');
    modal.innerHTML = `
      <div class="settings-window">
        <header class="share-head">
          <h2>Settings</h2>
          <button class="fv-close" data-x="close" aria-label="Close">
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg></button>
        </header>
        <section class="settings-section">
          <h3>Click sound</h3>
          <p class="settings-hint">A sound each time you click. Off unless you choose one.</p>
          <div class="sound-options" role="radiogroup" aria-label="Click sound"></div>
          <label class="sound-volume"><span>Volume</span>
            <input type="range" min="0" max="1" step="0.05" aria-label="Click sound volume"><output></output></label>
          <p class="share-msg" role="status" hidden></p>
          <p class="settings-note">Saved in this browser.</p>
        </section>
      </div>`;
    modal.addEventListener('click', (e) => { if (e.target === modal || e.target.closest('[data-x="close"]')) close(); });
    document.addEventListener('keydown', onKey, true);
    document.body.append(modal);

    const box = modal.querySelector('.sound-options');
    const volume = modal.querySelector('.sound-volume input');
    const out = modal.querySelector('.sound-volume output');
    const msg = modal.querySelector('.share-msg');
    const say = (text, error) => { msg.textContent = text; msg.hidden = !text; msg.classList.toggle('is-error', !!error); };

    function draw() {
      const s = App.clickSounds.settings;
      box.innerHTML = App.clickSounds.SOUNDS.map((o) => {
        const isCustom = o.id === 'custom';
        const ready = !isCustom || s.customName;
        return `<div class="sound-option ${s.sound === o.id ? 'is-on' : ''}">
          <label class="sound-pick">
            <input type="radio" name="click-sound" value="${o.id}" ${s.sound === o.id ? 'checked' : ''} ${ready ? '' : 'disabled'}>
            <span class="sound-text"><strong>${o.label}</strong>
              <small>${isCustom && s.customName ? esc(s.customName) : o.hint}</small></span>
          </label>
          ${o.id !== 'none' && ready ? `<button class="sound-preview" data-preview="${o.id}" aria-label="Play ${o.label}" data-tooltip="Listen">${PLAY}</button>` : ''}
          ${isCustom ? `<label class="file-btn sound-import">${s.customName ? 'Replace…' : 'Import…'}
              <input type="file" accept="audio/*" hidden></label>
              ${s.customName ? '<button class="file-btn sound-remove" data-remove>Remove</button>' : ''}` : ''}
        </div>`;
      }).join('');
      volume.value = s.volume;
      volume.disabled = s.sound === 'none';
      out.textContent = `${Math.round(s.volume * 100)}%`;
    }
    draw();

    box.addEventListener('change', async (e) => {
      if (e.target.name === 'click-sound') {
        App.clickSounds.set({ sound: e.target.value });
        draw();
        if (e.target.value !== 'none') App.clickSounds.play(e.target.value);
        say('');
      }
      if (e.target.type === 'file') {
        const file = e.target.files[0];
        if (!file) return;
        try {
          const r = await App.clickSounds.importFile(file);
          draw();
          App.clickSounds.play('custom');
          say(`Using “${r.name}”${r.duration > 1.2 ? ' (only the first second plays on each click)' : ''}.`);
        } catch (err) { say(err.message, true); }
      }
    });
    box.addEventListener('click', async (e) => {
      const p = e.target.closest('[data-preview]');
      if (p) { e.preventDefault(); App.clickSounds.play(p.dataset.preview, Math.max(0.2, App.clickSounds.settings.volume)); }
      if (e.target.closest('[data-remove]')) {
        await App.clickSounds.removeCustom();
        draw();
        say('Your sound was removed.');
      }
    });
    volume.addEventListener('input', () => {
      App.clickSounds.set({ volume: Number(volume.value) });
      out.textContent = `${Math.round(volume.value * 100)}%`;
    });
    volume.addEventListener('change', () => App.clickSounds.play());
  }

  return { open, close };
})();
