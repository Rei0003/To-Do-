// access.js — what you may do on the open board.
//   owner / edit : everything (only the owner can delete the board or manage who has access)
//   view         : look only (play audio/video, open files, zoom, browse — but no changes)
//   cards        : edit only certain cards (and what's attached inside them); others are read-only
//                  or, if the owner chose so, not even sent to you
// The server enforces all of this too; here it just shapes the page so it's clear.
window.App = window.App || {};

App.access = (() => {
  let role = 'owner';
  let cards = new Set();
  let info = null;

  // controls in a read-only card that still work (they don't change anything)
  const STILL_WORK = [
    '.ap-play', '.file-main', '[data-file]', '.cal-nav', '.cal-today', '.cal-cell',
    '.draw-zoom button', '[data-draw-mode="hand"]', '[data-draw-action="more"]', '.bc-open',
  ].join(',');

  const canEditAll = () => role === 'owner' || role === 'edit';

  function canEditCard(id) {
    if (canEditAll()) return true;
    if (role !== 'cards') return false;
    const top = App.state.topOf(id);
    return !!top && cards.has(top.id);
  }

  // make a card read-only (and keep it that way when parts of it are redrawn)
  function lock(el) {
    el.classList.add('is-locked');
    const apply = () => {
      el.querySelectorAll('[contenteditable="true"]').forEach((x) => { x.contentEditable = 'false'; });
      el.querySelectorAll('input, select, textarea').forEach((x) => {
        x.disabled = !x.matches('[data-mine]'); // tasks assigned to you can still be ticked off
      });
      el.querySelectorAll('button').forEach((b) => { if (!b.matches(STILL_WORK)) b.disabled = true; });
    };
    apply();
    new MutationObserver(apply).observe(el, { childList: true, subtree: true });
  }

  return {
    // from the server when a board opens (null = your own board / no account)
    set(a) {
      info = a || null;
      role = a?.role || 'owner';
      cards = new Set(a?.cards || []);
      document.body.dataset.access = role;
    },
    get role() { return role; },
    get info() { return info; },
    canEditAll,
    canManage: () => role === 'owner',
    readOnly: () => role === 'view',
    canEditCard,
    // new cards: on the board itself only with full access; inside a card you may edit, also allowed
    canAdd: (parentId) => canEditAll() || (role === 'cards' && !!parentId && canEditCard(parentId)),
    // removing: full access, or attachments inside your cards (not the shared card itself)
    canDelete: (id) => canEditAll() || (role === 'cards' && !!App.state.getCard(id)?.parent && canEditCard(id)),
    allowedCards: () => [...cards],
    // called for every card drawn on the board
    decorate(el, card) {
      if (!canEditCard(card.id)) lock(el);
      else if (role === 'cards') el.classList.add('is-yours');
    },
  };
})();
