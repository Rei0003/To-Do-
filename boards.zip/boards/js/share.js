// share.js — inviting people to a board and choosing what they may do:
//   Can edit (everything) · Can view (read only) · Can edit chosen cards (pick them on the board,
//   optionally hiding every other card from that person).
// Members see the same window read-only, with a "Leave this board" button.
window.App = window.App || {};

App.share = (() => {
  const ROLES = [
    { id: 'edit', label: 'Can edit', hint: 'Everything on the board' },
    { id: 'view', label: 'Can view', hint: 'Look only, no changes' },
    { id: 'cards', label: 'Can edit chosen cards', hint: 'Only the cards you pick' },
  ];
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const roleLabel = (r) => ROLES.find((x) => x.id === r)?.label || r;

  let modal = null;
  let boardId = null;

  function close() {
    modal?.remove();
    modal = null;
    document.removeEventListener('keydown', onKey, true);
  }
  // (Escape closes a window opened on top first, e.g. Roles)
  function onKey(e) { if (e.key === 'Escape' && !App.cardPicker.active && !document.querySelector('.roles-modal')) { e.stopPropagation(); close(); } }

  // ---------- the window ----------
  async function open(id) {
    close();
    boardId = id;
    App.tooltip?.hide();
    modal = document.createElement('div');
    modal.className = 'fv share';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-label', 'Share board');
    modal.innerHTML = `<div class="share-window"><p class="share-loading">Loading…</p></div>`;
    modal.addEventListener('click', (e) => { if (e.target === modal) close(); });
    document.addEventListener('keydown', onKey, true);
    document.body.append(modal);
    await refresh();
  }

  // state of the invite form (kept while picking cards on the board)
  let draft = { email: '', role: 'edit', cards: [], hide: false, member_role: '' };
  // the custom-role dropdown (no role / the owner's roles / make a new one)
  const roleOptions = (roles, current) => `<option value="">No role</option>
    ${roles.map((r) => `<option value="${esc(r.id)}" ${r.id === current ? 'selected' : ''}>${esc(r.name)}</option>`).join('')}
    <option value="__new">＋ New role…</option>`;

  async function refresh(message) {
    let res;
    try { res = await App.boards.members.list(boardId); } catch (err) {
      modal.querySelector('.share-window').innerHTML = `<p class="share-loading">${esc(err.message)}</p>`;
      return;
    }
    const owner = res.you === 'owner';
    const title = App.state.get().title || 'Untitled board';
    const win = modal.querySelector('.share-window');
    win.innerHTML = `
      <header class="share-head">
        <h2>Share “${esc(title)}”</h2>
        ${owner ? '<button class="file-btn share-roles-btn" data-s="roles" data-tooltip="Create and edit your custom roles">Roles…</button>' : ''}
        <button class="fv-close" data-s="close" aria-label="Close">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg></button>
      </header>
      ${res.inherited_from ? `<p class="share-inherit">Everyone with access to <strong>${esc(res.inherited_from)}</strong> can also open this board (it’s inside it).</p>` : ''}
      ${owner ? `
      <form class="share-invite" novalidate>
        <div class="share-invite-row">
          <input type="email" name="email" placeholder="Email address" aria-label="Email address of the person to invite" autocomplete="off">
          <button class="confirm-pop-btn btn-primary" type="submit">Invite</button>
        </div>
        <div class="share-invite-row share-invite-options">
          <label><span>Role</span><select name="member_role" aria-label="Their role">${roleOptions(res.roles || [], draft.member_role)}</select></label>
          <label><span>Access</span><select name="role" aria-label="What they can do">
            ${ROLES.map((r) => `<option value="${r.id}">${r.label}</option>`).join('')}
          </select></label>
        </div>
        <div class="share-cards-row" hidden>
          <span class="share-cards-count"></span>
          <button type="button" class="file-btn" data-s="pick-new">Choose cards on the board…</button>
          <label class="share-hide"><input type="checkbox" name="hide"> Hide the other cards from them</label>
        </div>
        <p class="share-msg" role="status" hidden></p>
      </form>` : `<p class="share-note">Only ${esc(res.owner.name)} (the owner) can invite people or change access.</p>`}
      <ul class="share-people">
        <li class="share-person">
          <span class="share-avatar-slot" data-pic="${esc(res.owner.email)}"></span>
          <span class="share-who"><strong>${esc(res.owner.name)}</strong><span>${esc(res.owner.email)}</span></span>
          <span class="share-role-text">Owner</span>
        </li>
        ${res.members.map((m) => `
        <li class="share-person" data-email="${esc(m.email)}">
          ${m.name ? `<span class="share-avatar-slot" data-pic="${esc(m.email)}"></span>` : `<span class="share-avatar is-pending">${esc(m.email[0].toUpperCase())}</span>`}
          <span class="share-who"><strong>${esc(m.name || m.email)} ${owner ? '' : App.roles.badgeHtml(m.member_role, true)}</strong>
            <span>${m.name ? esc(m.email) : 'Invited — will get access when they create an account'}</span>
            ${m.role === 'cards' ? `<span class="share-cards-info">${m.cards.length} card${m.cards.length === 1 ? '' : 's'}${m.hide ? ' · can’t see the rest' : ''}
              ${owner ? '<button type="button" class="share-link" data-s="pick-member">Change</button>' : ''}</span>` : ''}
          </span>
          ${owner ? `<select data-s="member-role" class="share-member-role" data-color="${esc(m.member_role?.color || '')}" aria-label="${esc(m.name || m.email)}’s role">${roleOptions(res.roles || [], m.member_role?.id)}</select>
            <select data-s="role" aria-label="What ${esc(m.name || m.email)} can do">
              ${ROLES.map((r) => `<option value="${r.id}" ${r.id === m.role ? 'selected' : ''}>${r.label}</option>`).join('')}
            </select>
            <button class="card-btn" data-s="remove" aria-label="Remove ${esc(m.name || m.email)}" data-tooltip="Remove access">
              <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg></button>`
            : `<span class="share-role-text">${roleLabel(m.role)}</span>`}
        </li>`).join('')}
      </ul>
      ${res.inherited?.length ? `
      <p class="share-inherited-title">Also has access (invited to a board this one is inside)</p>
      <ul class="share-people share-inherited">${res.inherited.map((m) => `
        <li class="share-person">
          ${m.name ? `<span class="share-avatar-slot" data-pic="${esc(m.email)}"></span>` : `<span class="share-avatar is-pending">${esc(m.email[0].toUpperCase())}</span>`}
          <span class="share-who"><strong>${esc(m.name || m.email)} ${App.roles.badgeHtml(m.member_role, true)}</strong>
            <span>From “${esc(m.from)}”</span></span>
          <span class="share-role-text">${roleLabel(m.role)}</span>
        </li>`).join('')}</ul>` : ''}
      ${owner ? '' : '<button class="file-btn share-leave" data-s="leave">Leave this board</button>'}`;

    const members = res.members;
    // profile pictures (or initials)
    App.people.remember(res.owner.email, res.owner.avatar || null);
    [...res.members, ...(res.inherited || [])].forEach((m) => { if (m.name) App.people.remember(m.email, m.avatar || null); });
    win.querySelectorAll('[data-pic]').forEach((slot) => slot.replaceWith(App.people.avatar(slot.dataset.pic, 32)));
    win.querySelector('[data-s="close"]').addEventListener('click', close);

    if (!owner) {
      win.querySelector('[data-s="leave"]').addEventListener('click', async (e) => {
        App.confirmPopover.open(e.target, {
          title: 'Leave this board?',
          message: `${res.owner.name} would have to invite you again.`,
          confirmLabel: 'Leave board',
          onConfirm: async () => {
            await App.boards.members.remove(boardId, App.session.user.email);
            close();
            location.hash = '#/boards';
          },
        });
      });
      return;
    }

    win.querySelector('[data-s="roles"]')?.addEventListener('click', () => App.roles.manage(() => refresh()));

    // ----- invite form -----
    const form = win.querySelector('.share-invite');
    const msg = win.querySelector('.share-msg');
    const cardsRow = win.querySelector('.share-cards-row');
    const show = (text, error) => { msg.textContent = text; msg.hidden = !text; msg.classList.toggle('is-error', !!error); };
    if (message) show(message);
    form.email.value = draft.email;
    form.role.value = draft.role;
    form.hide.checked = draft.hide;
    const syncCards = () => {
      cardsRow.hidden = form.role.value !== 'cards';
      win.querySelector('.share-cards-count').textContent = draft.cards.length
        ? `${draft.cards.length} card${draft.cards.length === 1 ? '' : 's'} chosen` : 'No cards chosen yet';
    };
    syncCards();
    form.email.addEventListener('input', () => { draft.email = form.email.value; });
    form.role.addEventListener('change', () => { draft.role = form.role.value; syncCards(); });
    form.member_role.addEventListener('change', () => {
      if (form.member_role.value === '__new') {
        form.member_role.value = draft.member_role;
        App.roles.manage(() => refresh());
        return;
      }
      draft.member_role = form.member_role.value;
      // a role can suggest an access level
      const role = (res.roles || []).find((r) => r.id === draft.member_role);
      if (role?.access) { form.role.value = role.access; draft.role = role.access; syncCards(); }
    });
    form.hide.addEventListener('change', () => { draft.hide = form.hide.checked; });
    win.querySelector('[data-s="pick-new"]').addEventListener('click', () => {
      pick(draft.email || 'them', draft.cards, (ids) => { draft.cards = ids; });
    });
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = form.email.value.trim();
      if (!email.includes('@')) return show('Please enter their email address.', true);
      if (form.role.value === 'cards' && !draft.cards.length) return show('Choose at least one card they can edit.', true);
      try {
        const r = await App.boards.members.invite(boardId, { email, role: form.role.value, cards: draft.cards, hide: form.hide.checked, member_role: draft.member_role || null });
        draft = { email: '', role: 'edit', cards: [], hide: false, member_role: '' };
        await refresh(r.registered ? `${email} now has access.` : `Invited ${email}. They’ll get access when they create an account with this email.`);
        App.router.sharingChanged();
      } catch (err) { show(err.message, true); }
    });

    // ----- people already invited -----
    win.querySelector('.share-people').addEventListener('change', async (e) => {
      const roleSel = e.target.closest('[data-s="member-role"]');
      if (roleSel) {
        const who = members.find((x) => x.email === roleSel.closest('[data-email]').dataset.email);
        if (roleSel.value === '__new') { roleSel.value = who.member_role?.id || ''; App.roles.manage(() => refresh()); return; }
        await saveMember(who, { member_role: roleSel.value || null });
        App.people.load(boardId); // role badges elsewhere
        return;
      }
      const sel = e.target.closest('[data-s="role"]');
      if (!sel) return;
      const m = members.find((x) => x.email === sel.closest('[data-email]').dataset.email);
      if (sel.value === 'cards' && !m.cards.length) {
        // they need cards first
        pick(m.name || m.email, [], async (ids) => {
          if (!ids.length) { refresh(); return; }
          await saveMember(m, { role: 'cards', cards: ids, hide: false });
        });
        return;
      }
      await saveMember(m, { role: sel.value });
    });
    win.querySelector('.share-people').addEventListener('click', async (e) => {
      const li = e.target.closest('[data-email]');
      if (!li) return;
      const m = members.find((x) => x.email === li.dataset.email);
      if (e.target.closest('[data-s="pick-member"]')) {
        pick(m.name || m.email, m.cards, (ids, hide) => {
          if (ids.length) saveMember(m, { role: 'cards', cards: ids, hide });
        }, m.hide);
      }
      if (e.target.closest('[data-s="remove"]')) {
        try {
          await App.boards.members.remove(boardId, m.email);
          await refresh(`${m.name || m.email} no longer has access.`);
          App.router.sharingChanged();
        } catch (err) { show(err.message, true); }
      }
    });

    async function saveMember(m, changes) {
      try {
        await App.boards.members.invite(boardId, { email: m.email, role: m.role, cards: m.cards, hide: m.hide, member_role: m.member_role?.id || null, ...changes });
        await refresh('Saved.');
      } catch (err) { show(err.message, true); refresh(); }
    }
  }

  // hide the window while picking cards on the board, then come back
  function pick(name, initial, done, hide) {
    modal.hidden = true;
    App.cardPicker.start({
      name,
      initial,
      hide,
      onDone: (ids, hideOthers) => {
        modal.hidden = false;
        if (hideOthers !== undefined) {
          draft.hide = hideOthers;
          const box = modal.querySelector('input[name="hide"]');
          if (box) box.checked = hideOthers;
        }
        done(ids, hideOthers);
        refresh();
      },
      onCancel: () => { modal.hidden = false; },
    });
  }

  return { open, close };
})();

// ---------- picking cards on the board ----------
App.cardPicker = (() => {
  let picked = null;
  let bar = null;
  let opts = null;

  const cards = () => [...document.querySelectorAll('#canvas > .card')];

  function paint() {
    cards().forEach((el) => el.classList.toggle('is-picked', picked.has(el.dataset.id)));
    bar.querySelector('.pick-count').textContent = `${picked.size} chosen`;
    bar.querySelector('[data-p="done"]').disabled = picked.size === 0;
  }

  // clicking a card while picking only (un)picks it — nothing else happens
  function onPointer(e) {
    const card = e.target.closest('#canvas > .card');
    if (!card && !e.target.closest('#canvas')) return;
    e.preventDefault();
    e.stopPropagation();
    if (e.type !== 'pointerdown' || !card) return;
    if (picked.has(card.dataset.id)) picked.delete(card.dataset.id);
    else picked.add(card.dataset.id);
    paint();
  }
  function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); finish(false); } }

  function finish(ok) {
    document.removeEventListener('pointerdown', onPointer, true);
    document.removeEventListener('click', onPointer, true);
    document.removeEventListener('dblclick', onPointer, true);
    document.removeEventListener('keydown', onKey, true);
    cards().forEach((el) => el.classList.remove('is-picked'));
    delete document.body.dataset.picking;
    const hide = bar.querySelector('input').checked;
    bar.remove();
    bar = null;
    const o = opts;
    opts = null;
    if (ok) o.onDone([...picked], hide);
    else o.onCancel?.();
  }

  function start(options) {
    opts = options;
    picked = new Set(options.initial || []);
    document.body.dataset.picking = 'true';
    bar = document.createElement('div');
    bar.className = 'pick-bar';
    bar.innerHTML = `
      <p><strong>Click the cards <span class="pick-name"></span> can edit</strong> · <span class="pick-count"></span></p>
      <label class="share-hide"><input type="checkbox"> Hide the other cards from them</label>
      <button class="file-btn" data-p="cancel">Cancel</button>
      <button class="confirm-pop-btn btn-primary" data-p="done">Done</button>`;
    bar.querySelector('.pick-name').textContent = options.name;
    bar.querySelector('input').checked = !!options.hide;
    bar.addEventListener('click', (e) => {
      const a = e.target.closest('[data-p]')?.dataset.p;
      if (a) finish(a === 'done');
    });
    document.body.append(bar);
    document.addEventListener('pointerdown', onPointer, true);
    document.addEventListener('click', onPointer, true);
    document.addEventListener('dblclick', onPointer, true);
    document.addEventListener('keydown', onKey, true);
    paint();
  }

  return { start, get active() { return !!opts; } };
})();
