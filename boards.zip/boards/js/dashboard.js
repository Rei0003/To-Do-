// dashboard.js — the Dashboard view of a board: the same content, organised into widgets.
//   Overview numbers · Tasks (filter + tick off) · Coming up (due dates + calendar events)
//   Progress per list · Workload per person · Priorities · Charts · Media · Files · Recent comments
// Click anything to jump to its card on the canvas. Switch with Canvas / Dashboard in the top bar
// (remembered per board). It only shows what you can see, and only lets you change what you may.
window.App = window.App || {};

App.dashboard = (() => {
  let el;
  let view = 'canvas';
  let boardId = null;
  let taskFilter = 'open';
  let frame = 0;
  const chartHosts = new Map(); // chart card id -> its live chart element (kept between redraws)

  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const PRIORITY_ORDER = { urgent: 0, high: 1, medium: 2, low: 3, none: 4 };
  const PRIORITY_LABEL = { urgent: 'Urgent', high: 'High', medium: 'Medium', low: 'Low' };
  const TYPE_NAMES = { // [one, many]
    note: ['note', 'notes'], todo: ['to-do list', 'to-do lists'], media: ['media card', 'media cards'], drawing: ['canvas', 'canvases'],
    calendar: ['calendar', 'calendars'], table: ['table', 'tables'], chart: ['chart', 'charts'], file: ['file', 'files'], board: ['board', 'boards'], shape: ['shape', 'shapes'],
  };
  const typeName = (t, n) => (TYPE_NAMES[t] || [t, `${t}s`])[n === 1 ? 0 : 1];

  // ---------- dates ----------
  const pad = (n) => String(n).padStart(2, '0');
  const dayKey = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const dayOf = (key) => { const [y, m, d] = key.split('-').map(Number); return new Date(y, m - 1, d); };
  const today = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };
  const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
  const locale = (() => { const w = String(navigator.language || '').split('@')[0]; try { new Intl.DateTimeFormat(w); return w || undefined; } catch { return undefined; } })();
  const fmtDay = new Intl.DateTimeFormat(locale, { weekday: 'short', day: 'numeric', month: 'short' });

  // ---------- gathering the board's content ----------
  function gather() {
    const data = App.state.get();
    const cards = data.cards || [];
    const tasks = [];
    const lists = [];
    const events = [];
    cards.forEach((card) => {
      if (card.type === 'todo') {
        const items = card.items || [];
        lists.push({ card, total: items.length, done: items.filter((i) => i.done).length });
        items.forEach((item) => tasks.push({ card, item }));
      }
      if (card.type === 'calendar') (card.events || []).forEach((ev) => events.push({ card, ev }));
    });
    const t0 = today();
    const weekEnd = addDays(t0, 7);
    const dueDay = (t) => (t.item.due ? dayOf(t.item.due.split('T')[0]) : null);
    const open = tasks.filter((t) => !t.item.done);
    return {
      data, cards, tasks, lists, events,
      top: cards.filter((c) => !c.parent),
      open,
      overdue: open.filter((t) => t.item.due && App.dueDate.status(t.item.due) === 'overdue'),
      thisWeek: open.filter((t) => { const d = dueDay(t); return d && d >= t0 && d < weekEnd; }),
      charts: cards.filter((c) => c.type === 'chart'),
      media: cards.filter((c) => c.type === 'media' && (c.mediaId || c.url)),
      files: cards.filter((c) => c.type === 'file' && c.mediaId),
      boards: cards.filter((c) => c.type === 'board' && c.boardId),
    };
  }

  // tasks: overdue first, then by due date, then priority
  function sortTasks(list) {
    return list.slice().sort((a, b) => {
      const da = a.item.due || '9999';
      const db = b.item.due || '9999';
      if (da !== db) return da < db ? -1 : 1;
      return (PRIORITY_ORDER[a.item.priority || 'none'] - PRIORITY_ORDER[b.item.priority || 'none']);
    });
  }

  const listName = (card) => (card.title || '').trim() || 'To-do list';

  // ---------- small pieces ----------
  function widget(title, cls = '', extra = '') {
    const w = document.createElement('section');
    w.className = `dash-widget ${cls}`;
    w.innerHTML = `<header class="dash-widget-head"><h3>${title}</h3>${extra}</header><div class="dash-widget-body"></div>`;
    return w;
  }
  function bar(value, total, color) {
    const pct = total ? Math.round((value / total) * 100) : 0;
    return `<span class="dash-bar"><span style="width:${pct}%;${color ? `background:${color}` : ''}"></span></span>`;
  }
  function jumpLink(cardId, text) {
    return `<button class="dash-jump" data-jump="${esc(cardId)}">${esc(text)}</button>`;
  }

  // ---------- widgets ----------
  function overview(g, comments) {
    const w = widget('Overview', 'dash-overview');
    const totalTasks = g.tasks.length;
    const done = totalTasks - g.open.length;
    const pct = totalTasks ? Math.round((done / totalTasks) * 100) : 0;
    const openComments = comments.filter((c) => !c.parent && !c.resolved).length;
    const tiles = [
      { n: g.top.length, label: g.top.length === 1 ? 'card' : 'cards', sub: Object.entries(g.top.reduce((a, c) => ({ ...a, [c.type]: (a[c.type] || 0) + 1 }), {}))
        .sort((a, b) => b[1] - a[1]).slice(0, 3).map(([t, n]) => `${n} ${typeName(t, n)}`).join(' · ') },
      { n: `${pct}%`, label: 'tasks done', sub: `${done} of ${totalTasks}`, progress: totalTasks ? pct : null },
      { n: g.overdue.length, label: 'overdue', sub: g.overdue.length ? 'need attention' : 'nothing late', tone: g.overdue.length ? 'bad' : 'good', filter: 'overdue' },
      { n: g.thisWeek.length, label: 'due this week', sub: 'in the next 7 days', tone: g.thisWeek.length ? 'warn' : '' },
      { n: openComments, label: openComments === 1 ? 'open comment' : 'open comments', sub: openComments ? 'click to read' : 'all quiet', comments: true },
    ];
    w.querySelector('.dash-widget-body').innerHTML = tiles.map((t) => `
      <button class="dash-tile ${t.tone ? `is-${t.tone}` : ''}" ${t.filter ? `data-filter="${t.filter}"` : ''} ${t.comments ? 'data-open-comments' : ''}>
        <span class="dash-tile-n">${t.n}</span>
        <span class="dash-tile-label">${t.label}</span>
        ${t.progress !== undefined && t.progress !== null ? bar(t.progress, 100) : ''}
        <span class="dash-tile-sub">${esc(t.sub || '')}</span>
      </button>`).join('');
    return w;
  }

  function tasksWidget(g) {
    const filters = [['open', 'Open'], ['overdue', 'Overdue'], ['mine', 'Mine'], ['done', 'Done']]
      .filter(([f]) => f !== 'mine' || App.session.user);
    const w = widget('Tasks', 'dash-tasks', `<div class="dash-tabs" role="tablist">${filters.map(([f, label]) =>
      `<button role="tab" data-tf="${f}" aria-selected="${f === taskFilter}">${label}</button>`).join('')}</div>`);
    let list = { open: g.open, overdue: g.overdue, done: g.tasks.filter((t) => t.item.done), mine: g.open.filter((t) => App.people.isMe(t.item.assignee)) }[taskFilter] || g.open;
    list = taskFilter === 'done' ? list : sortTasks(list);
    const body = w.querySelector('.dash-widget-body');
    if (!g.tasks.length) {
      body.innerHTML = '<p class="dash-empty">No tasks yet. Add a To-do list on the canvas.</p>';
      return w;
    }
    if (!list.length) {
      body.innerHTML = `<p class="dash-empty">${{ open: 'Everything is done 🎉', overdue: 'Nothing is overdue.', mine: 'Nothing is assigned to you.', done: 'Nothing finished yet.' }[taskFilter]}</p>`;
      return w;
    }
    const ul = document.createElement('ul');
    ul.className = 'dash-task-list';
    list.slice(0, 60).forEach(({ card, item }) => {
      const li = document.createElement('li');
      li.className = `dash-task${item.done ? ' is-done' : ''}`;
      const may = !App.access || App.access.canEditCard(card.id) || App.people.isMe(item.assignee);
      li.innerHTML = `
        <input type="checkbox" ${item.done ? 'checked' : ''} ${may ? '' : 'disabled'} aria-label="Mark done" data-task="${esc(card.id)}|${esc(item.id)}">
        <span class="dash-task-main">
          <button class="dash-jump dash-task-text" data-jump="${esc(card.id)}"></button>
          <span class="dash-task-meta"><span class="dash-task-list-name"></span></span>
        </span>`;
      li.querySelector('.dash-task-text').textContent = item.text || 'Untitled task';
      const meta = li.querySelector('.dash-task-meta');
      meta.querySelector('.dash-task-list-name').textContent = listName(card);
      if (item.priority && item.priority !== 'none') {
        const p = document.createElement('span');
        p.className = 'prio-mark';
        p.dataset.level = item.priority;
        p.title = `${PRIORITY_LABEL[item.priority]} priority`;
        p.innerHTML = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 14V2.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M4 3h7.5L9.8 6l1.7 3H4z" fill="currentColor"/></svg>';
        meta.prepend(p);
      }
      if (item.assignee) {
        const chip = document.createElement('span');
        chip.className = 'assignee-chip';
        App.people.paintChip(chip, item.assignee);
        meta.append(chip);
      }
      if (item.due) {
        const due = document.createElement('span');
        due.className = 'due-chip';
        due.dataset.status = App.dueDate.status(item.due);
        due.textContent = App.dueDate.label(item.due);
        meta.append(due);
      }
      ul.append(li);
    });
    body.append(ul);
    if (list.length > 60) body.insertAdjacentHTML('beforeend', `<p class="dash-more">+ ${list.length - 60} more</p>`);
    return w;
  }

  function upcomingWidget(g) {
    const w = widget('Coming up', 'dash-upcoming', '<span class="dash-head-note">next 14 days</span>');
    const t0 = today();
    const end = addDays(t0, 14);
    const days = new Map();
    const add = (key, entry) => { if (!days.has(key)) days.set(key, []); days.get(key).push(entry); };
    // overdue tasks are shown together at the top
    const overdue = g.overdue.length;
    g.open.forEach((t) => {
      if (!t.item.due) return;
      const key = t.item.due.split('T')[0];
      const d = dayOf(key);
      if (d >= t0 && d < end) add(key, { kind: 'task', card: t.card, text: t.item.text, time: t.item.due.split('T')[1] || '', assignee: t.item.assignee });
    });
    g.events.forEach(({ card, ev }) => {
      const d = dayOf(ev.date);
      if (d >= t0 && d < end) add(ev.date, { kind: 'event', card, text: ev.title, time: ev.time || '', color: ev.color });
    });
    const body = w.querySelector('.dash-widget-body');
    const keys = [...days.keys()].sort();
    if (!keys.length && !overdue) {
      body.innerHTML = '<p class="dash-empty">Nothing due in the next two weeks. Give tasks a due date, or add events to a calendar.</p>';
      return w;
    }
    let html = overdue ? `<button class="dash-overdue-note" data-filter="overdue">⚠ ${overdue} overdue task${overdue === 1 ? '' : 's'}</button>` : '';
    keys.forEach((key) => {
      const d = dayOf(key);
      const diff = Math.round((d - t0) / 86400000);
      const label = diff === 0 ? 'Today' : diff === 1 ? 'Tomorrow' : fmtDay.format(d);
      const entries = days.get(key).sort((a, b) => (a.time || '99').localeCompare(b.time || '99'));
      html += `<div class="dash-day ${diff === 0 ? 'is-today' : ''}"><p class="dash-day-label">${label}</p><ul>${entries.map((e) => `
        <li class="dash-entry is-${e.kind}" style="${e.color ? `--ev:${App.colorCss(e.color)}` : ''}">
          <span class="dash-entry-dot"></span>
          ${e.time ? `<span class="dash-entry-time">${esc(e.time)}</span>` : ''}
          ${jumpLink(e.card.id, e.text || (e.kind === 'task' ? 'Untitled task' : 'Event'))}
          <span class="dash-entry-kind">${e.kind === 'task' ? 'task' : 'event'}${e.assignee ? ` · ${esc(App.people.nameOf(e.assignee))}` : ''}</span>
        </li>`).join('')}</ul></div>`;
    });
    body.innerHTML = html;
    return w;
  }

  function listsWidget(g) {
    const w = widget('Progress per list', 'dash-lists');
    w.querySelector('.dash-widget-body').innerHTML = g.lists.map(({ card, total, done }) => `
      <div class="dash-row">
        ${jumpLink(card.id, listName(card))}
        <span class="dash-row-n">${done}/${total}</span>
        ${bar(done, total, done === total && total ? 'var(--done)' : '')}
      </div>`).join('');
    return w;
  }

  function peopleWidget(g) {
    const counts = new Map();
    g.open.forEach((t) => { const k = t.item.assignee || ''; counts.set(k, (counts.get(k) || 0) + 1); });
    const max = Math.max(...counts.values());
    const rows = [...counts.entries()].sort((a, b) => (a[0] === '') - (b[0] === '') || b[1] - a[1]);
    const w = widget('Open tasks per person', 'dash-people');
    const body = w.querySelector('.dash-widget-body');
    rows.forEach(([email, n]) => {
      const row = document.createElement('div');
      row.className = 'dash-row dash-person';
      const who = document.createElement('span');
      who.className = 'dash-person-name';
      if (email) who.append(App.people.avatar(email, 20), document.createTextNode(App.people.nameOf(email)));
      else who.innerHTML = '<span class="person-avatar dash-nobody">?</span>Not assigned';
      row.append(who);
      row.insertAdjacentHTML('beforeend', `<span class="dash-row-n">${n}</span>${bar(n, max)}`);
      body.append(row);
    });
    return w;
  }

  function priorityWidget(g) {
    const w = widget('Open tasks by priority', 'dash-priority');
    const counts = { urgent: 0, high: 0, medium: 0, low: 0, none: 0 };
    g.open.forEach((t) => { counts[t.item.priority || 'none']++; });
    const max = Math.max(1, ...Object.values(counts));
    const colors = { urgent: 'var(--p-urgent)', high: 'var(--p-high)', medium: 'var(--p-medium)', low: 'var(--p-low)', none: 'var(--muted)' };
    w.querySelector('.dash-widget-body').innerHTML = Object.entries(counts).map(([p, n]) => `
      <div class="dash-row"><span class="dash-row-label">${PRIORITY_LABEL[p] || 'No priority'}</span>
        <span class="dash-row-n">${n}</span>${bar(n, max, colors[p])}</div>`).join('');
    return w;
  }

  // charts: the real chart cards, read-only, kept alive between redraws
  function chartsWidget(g) {
    const w = widget('Charts', 'dash-charts');
    const body = w.querySelector('.dash-widget-body');
    g.charts.forEach((card) => {
      let host = chartHosts.get(card.id);
      if (!host) {
        host = document.createElement('div');
        host.className = 'dash-chart';
        const inner = document.createElement('div');
        inner.className = 'dash-chart-inner';
        host.append(inner);
        App.cardTypes.chart.render(card, inner);
        host.querySelectorAll('input, button:not(.ch-legend-item)').forEach((x) => { x.tabIndex = -1; });
        chartHosts.set(card.id, host);
      }
      const open = document.createElement('button');
      open.className = 'dash-jump dash-chart-open';
      open.dataset.jump = card.id;
      open.textContent = card.chart?.title || 'Chart';
      const wrap = document.createElement('figure');
      wrap.className = 'dash-chart-wrap';
      wrap.append(open, host);
      body.append(wrap);
    });
    return w;
  }

  function mediaWidget(g) {
    const w = widget('Media', 'dash-media', `<span class="dash-head-note">${g.media.length}</span>`);
    const body = w.querySelector('.dash-widget-body');
    g.media.slice(0, 12).forEach((card) => {
      const tile = document.createElement('button');
      tile.className = 'dash-media-tile';
      tile.dataset.jump = card.id;
      tile.dataset.tooltip = card.caption || card.name || 'Media';
      const kind = card.kind;
      if (kind === 'image') {
        const img = document.createElement('img');
        img.alt = card.caption || card.name || '';
        img.loading = 'lazy';
        (card.url ? Promise.resolve(card.url) : App.mediaStore.getUrl(card.mediaId)).then((u) => { if (u) img.src = u; });
        tile.append(img);
      } else {
        tile.classList.add('is-icon');
        tile.innerHTML = `<span>${kind === 'audio' || kind === 'spotify' || kind === 'soundcloud' ? '♪' : '▶'}</span><small></small>`;
        tile.querySelector('small').textContent = card.caption || card.name || kind;
      }
      body.append(tile);
    });
    return w;
  }

  function filesWidget(g) {
    const w = widget('Files', 'dash-files');
    const body = w.querySelector('.dash-widget-body');
    g.files.forEach((card) => {
      const row = document.createElement('div');
      row.className = 'dash-file';
      const icon = document.createElement('span');
      icon.className = 'file-icon';
      icon.dataset.ext = App.fileIcons.groupOf({ name: card.name });
      icon.textContent = ((card.name || '').match(/\.([a-z0-9]+)$/i)?.[1] || 'file').slice(0, 4).toUpperCase();
      row.append(icon);
      row.insertAdjacentHTML('beforeend', `${jumpLink(card.id, card.name || 'File')}<button class="file-btn" data-open-file="${esc(card.id)}">Open</button>`);
      body.append(row);
    });
    return w;
  }

  // team stats for this board (and the boards inside it); loaded from the server
  let teamCache = null;
  function teamWidget() {
    const w = widget('Team', 'dash-team', '<a class="dash-link" href="#/team">All your boards →</a>');
    const body = w.querySelector('.dash-widget-body');
    const fill = (res) => body.replaceChildren(App.team.table(res, { compact: true }));
    if (teamCache?.board === boardId) fill(teamCache.res);
    else body.innerHTML = '<p class="dash-empty">Loading…</p>';
    App.team.fetchStats(boardId).then((res) => {
      teamCache = { board: boardId, res };
      if (body.isConnected) fill(res);
    }).catch((err) => { body.innerHTML = `<p class="dash-empty">${esc(err.message)}</p>`; });
    return w;
  }

  // boards inside this board
  function boardsWidget(g) {
    const w = widget('Boards inside', 'dash-boards');
    const body = w.querySelector('.dash-widget-body');
    g.boards.forEach((card) => {
      const a = document.createElement('a');
      a.className = 'dash-board';
      a.href = `#/board/${card.boardId}`;
      a.innerHTML = '<span class="dash-board-icon"></span><span class="dash-board-name"></span>';
      a.querySelector('.dash-board-name').textContent = card.title || 'Untitled board';
      body.append(a);
    });
    return w;
  }

  function commentsWidget(comments) {
    const tops = comments.filter((c) => !c.parent && !c.resolved).slice(-5).reverse();
    const w = widget('Recent comments', 'dash-comments', '<button class="dash-link" data-open-comments>Open comments</button>');
    const body = w.querySelector('.dash-widget-body');
    tops.forEach((c) => {
      const replies = comments.filter((x) => x.parent === c.id).length;
      const item = document.createElement('button');
      item.className = 'dash-comment';
      item.dataset.comment = c.id;
      const who = c.mine ? 'You' : (c.author?.name || 'You');
      item.innerHTML = '<span class="dash-comment-head"></span><span class="dash-comment-text"></span>';
      const head = item.firstChild;
      if (c.author?.email) head.append(App.people.avatar(c.author.email, 18));
      head.append(document.createTextNode(`${who}${replies ? ` · ${replies} repl${replies === 1 ? 'y' : 'ies'}` : ''}`));
      item.lastChild.textContent = c.text;
      body.append(item);
    });
    return w;
  }

  // ---------- drawing it all ----------
  async function render() {
    if (view !== 'dashboard' || !el) return;
    const g = gather();
    const comments = await App.comments.all();
    const scroll = el.scrollTop;
    const grid = document.createElement('div');
    grid.className = 'dash-grid';
    if (!g.top.length) {
      el.innerHTML = `<div class="dash-blank"><p><strong>This board is empty.</strong></p>
        <p>Add cards on the canvas — tasks, calendars, charts, files and comments show up here, organised.</p>
        <button class="confirm-pop-btn btn-primary" data-view-to="canvas">Go to the canvas</button></div>`;
      return;
    }
    grid.append(overview(g, comments));
    if (g.tasks.length) grid.append(tasksWidget(g));
    if (g.tasks.some((t) => t.item.due) || g.events.length) grid.append(upcomingWidget(g));
    if (g.lists.length > 1 || (g.lists.length === 1 && g.lists[0].total)) grid.append(listsWidget(g));
    if (g.open.some((t) => t.item.assignee)) grid.append(peopleWidget(g));
    if (g.open.some((t) => t.item.priority && t.item.priority !== 'none')) grid.append(priorityWidget(g));
    if (g.charts.length) grid.append(chartsWidget(g));
    if (g.media.length) grid.append(mediaWidget(g));
    if (g.files.length) grid.append(filesWidget(g));
    if (g.boards.length) grid.append(boardsWidget(g));
    if (comments.some((c) => !c.parent && !c.resolved)) grid.append(commentsWidget(comments));
    // how the people on this board are doing (owner and full editors, boards with an account)
    if (App.session.mode === 'server' && App.access.canEditAll() && (App.access.role === 'owner' || g.tasks.some((t) => t.item.assignee))) {
      grid.append(teamWidget());
    }
    // forget charts that were deleted
    [...chartHosts.keys()].forEach((id) => { if (!App.state.getCard(id)) chartHosts.delete(id); });
    el.replaceChildren(grid);
    el.scrollTop = scroll;
  }
  const renderSoon = () => {
    if (view !== 'dashboard' || frame) return;
    frame = requestAnimationFrame(() => { frame = 0; render(); });
  };

  // ---------- switching views ----------
  function setView(next, { remember = true } = {}) {
    view = next === 'dashboard' ? 'dashboard' : 'canvas';
    document.body.dataset.view = view;
    el.hidden = view !== 'dashboard';
    document.querySelectorAll('[data-view-to]').forEach((b) => {
      if (b.closest('.view-switch')) b.setAttribute('aria-pressed', String(b.dataset.viewTo === view));
    });
    if (remember && boardId) localStorage.setItem(`boards.view.${boardId}`, view);
    if (view === 'dashboard') { chartHosts.clear(); render(); }
  }

  // jump from the dashboard to a card on the canvas
  function jump(cardId) {
    setView('canvas');
    requestAnimationFrame(() => App.comments.jumpTo(cardId));
  }

  async function toggleTask(cardId, itemId, done) {
    const card = App.state.getCard(cardId);
    const item = card?.items?.find((i) => i.id === itemId);
    if (!item) return;
    if (!App.access || App.access.canEditCard(cardId)) {
      item.done = done;
      App.state.updateCard(cardId, { items: card.items });
      App.board.clear(); // redraw the canvas cards so they match
      App.state.load(App.state.get());
    } else if (App.people.isMe(item.assignee)) {
      try {
        await App.boards.toggleTask(App.storage.boardId, cardId, itemId, done);
        item.done = done;
      } catch { /* the board refresh will show the real state */ }
    }
    render();
  }

  function init() {
    el = document.createElement('section');
    el.className = 'dashboard';
    el.id = 'dashboard';
    el.hidden = true;
    el.setAttribute('aria-label', 'Dashboard');
    document.getElementById('viewport').after(el);

    document.addEventListener('click', (e) => {
      const to = e.target.closest('[data-view-to]');
      if (to) { setView(to.dataset.viewTo); return; }
      if (!el.contains(e.target)) return;
      const jumpBtn = e.target.closest('[data-jump]');
      if (jumpBtn) { jump(jumpBtn.dataset.jump); return; }
      const tab = e.target.closest('[data-tf]');
      if (tab) { taskFilter = tab.dataset.tf; render(); return; }
      const filter = e.target.closest('[data-filter]');
      if (filter) { taskFilter = filter.dataset.filter; render(); el.querySelector('.dash-tasks')?.scrollIntoView({ behavior: 'smooth', block: 'start' }); return; }
      if (e.target.closest('[data-open-comments]')) { App.comments.open(); return; }
      const c = e.target.closest('[data-comment]');
      if (c) { App.comments.show(c.dataset.comment); return; }
      const f = e.target.closest('[data-open-file]');
      if (f) {
        const card = App.state.getCard(f.dataset.openFile);
        App.fileViewer.open({ name: card.name, size: card.size, type: card.fileType },
          () => App.mediaStore.getBlob(card.mediaId), () => App.cardTypes.file.download(card));
      }
    });
    el.addEventListener('change', (e) => {
      const box = e.target.closest('[data-task]');
      if (!box) return;
      const [cardId, itemId] = box.dataset.task.split('|');
      toggleTask(cardId, itemId, box.checked);
    });
    // keep it up to date (your changes, other people's changes, finished uploads…)
    App.state.subscribe(renderSoon);
  }

  return {
    init,
    // the router tells us which board opened: show the view used last time on it
    setBoard(id) {
      boardId = id;
      taskFilter = 'open';
      chartHosts.clear();
      setView(id ? (localStorage.getItem(`boards.view.${id}`) || 'canvas') : 'canvas', { remember: false });
    },
    refresh: renderSoon,
    get view() { return view; },
  };
})();
