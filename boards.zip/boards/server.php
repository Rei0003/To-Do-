<?php
// server.php — for PHP's built-in web server:  php -S localhost:8000 server.php
// (XAMPP/Apache don't need this file.) It keeps the database and uploads private and
// lets everything else be served normally.
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if (preg_match('~^/api/(data|uploads)(/|$)|^/api/(config|config\.local|config\.local\.example|db|mailer|mail-test)\.php$|\.sql$~', $path)) {
    http_response_code(403);
    exit('Forbidden');
}
return false; // serve the requested file as usual
