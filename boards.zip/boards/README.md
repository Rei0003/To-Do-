# Boards — a Milanote-style task board (starter template)

Open `index.html` in a browser. No build step, no server needed.
Your board saves automatically to the browser: card data in localStorage, images and videos in IndexedDB (localStorage is too small for media).

## What it does
- Add notes and to-do lists from the left toolbar (click, or drag onto the board)
- Double-click empty space to drop a note
- Drag cards by their top edge; clicked cards come to the front
- Colour-tag cards, tick tasks off, see progress per list
- Rename the board in the top bar
- Resize image/video cards from the bottom-right corner (double-click it to reset, or focus it and use ← →)
- Format text: select text in any note, task, list title or caption to get a bar with bold, italic, underline, strikethrough, heading, bullet list and clear (Ctrl/⌘+B, I, U, Shift+X also work)
- Hover any icon, colour dot or priority flag for a tooltip
- Give tasks a priority (low, medium, high, urgent) with the flag next to each task
- Add images and videos: Media button, drop files onto the board, or paste a screenshot
- Dark mode: follows your system setting, or use the moon/sun button (your choice is remembered)

## File map
| File | Feature |
|---|---|
| `index.html` | Page structure, loads everything in order |
| `css/base.css` | Colours, fonts, page layout |
| `css/toolbar.css` | Left toolbar |
| `css/board.css` | Dotted canvas + empty state |
| `css/cards.css` | Card frame, note and to-do styles |
| `css/rich-text.css` | Formatted text + floating format bar |
| `css/confirm-popover.css` | Confirm/cancel box |
| `css/tooltip.css` | Tooltips |
| `css/priority.css` | Priority flags + picker menu |
| `css/media.css` | Image/video cards |
| `css/resize.css` | Resize handle |
| `css/theme.css` | Dark mode colours + toggle button |
| `js/rich-text.js` | Editable formatted text fields (+ safe HTML cleaning) |
| `js/format-toolbar.js` | Floating bold/italic/heading bar |
| `js/confirm-popover.js` | Small confirm/cancel box (used by Clear) |
| `js/tooltip.js` | Tooltips for anything with `data-tooltip` |
| `js/storage.js` | Save / load (localStorage) |
| `js/state.js` | Board data + add/update/remove cards |
| `js/cards/card-shell.js` | Shared card frame: drag bar, colour, delete |
| `js/cards/note.js` | Note card |
| `js/cards/todo.js` | To-do list card |
| `js/cards/priority.js` | Task priority levels + picker |
| `js/cards/media.js` | Image/video card |
| `js/media-store.js` | Stores image/video files (IndexedDB) |
| `js/media-import.js` | Drop/paste files onto the board |
| `js/drag.js` | Moving cards |
| `js/resize.js` | Resizing cards (any card type with `resizable: true`) |
| `js/board.js` | Rendering cards, adding new ones |
| `js/toolbar.js` | Toolbar click + drag-to-create |
| `js/title.js` | Board name |
| `js/theme.js` | Light/dark mode switching |
| `js/main.js` | Startup |

## Adding a new card type (e.g. a link or image card)
1. Create `js/cards/link.js` and register `App.cardTypes.link = { label, defaults(), render(card, body), focus(el), onRemove(card)? }` — copy `note.js` as a starting point.
2. Add `<script src="js/cards/link.js">` in `index.html` after `note.js`.
3. Add a toolbar button with `data-type="link"`.
4. Style it in `css/cards.css` under `.card--link`.

## Ideas for next steps
- Column cards that other cards can be dropped into
- Multiple boards (store an array of boards in `state.js`)
- Zoom with Ctrl + scroll
- Swap `storage.js` for a PHP/MySQL backend
