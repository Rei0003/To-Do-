# Boards — a Milanote-style board app

## Landing page
`landing.html` introduces the app (features, how it works, teams) with a live mock-up of a board, and
its buttons lead into the app (*Get started* → sign up, *Log in*, *Open the app*). It has its own
light/dark switch that shares the app's setting. To make it the first page people see on a website,
point your link at `landing.html` (or rename it to `index.html` and the app's `index.html` to
`app.html`, then update the links in `landing.html`).

## Running it
**Without accounts:** open `index.html` in a browser. Boards are saved in that browser
(you can still have several boards).

**With accounts (log in, boards saved on the server, use them on any computer):** run it through PHP.
- **XAMPP:** copy the `boards` folder into `C:\xampp\htdocs\`, start Apache, and open
  `http://localhost/boards/`.
- **PHP's built-in server:** in the `boards` folder run `php -S localhost:8000 server.php`
  and open `http://localhost:8000/`.

The first time, a SQLite database is created in `api/data/` automatically. Then register an account.
If you'd rather use MySQL (phpMyAdmin): create a database, run `api/schema.mysql.sql`, and change
`db_dsn` / `db_user` / `db_pass` in `api/config.php`.

Uploads: PHP allows only 2 MB per file by default. With XAMPP, `api/.htaccess` raises it to 64 MB;
otherwise set `upload_max_filesize` and `post_max_size` in `php.ini`. Your PHP needs the
`pdo_sqlite` extension (or `pdo_mysql`) enabled in `php.ini`.

**Confirming email addresses:** when someone registers, a 6-digit code is emailed to them and the
account is only created once they type it in (codes work for 15 minutes, 5 tries, a new code after a
minute). Out of the box the server is in **development mode** (`'mail' => ['mode' => 'log']` in
`api/config.php`): emails go to `api/data/mail.log` and the sign-up screen shows the code, so it works
without any setup.

To send **real email** (Gmail, free):
1. Turn on 2-Step Verification: https://myaccount.google.com/security
2. Create an app password: https://myaccount.google.com/apppasswords (name it "Boards"; Google shows
   16 letters)
3. Copy `api/config.local.example.php` to `api/config.local.php` and put in your Gmail address
   (`from_email` and `user`) and the 16 letters (`pass`). This private file overrides `config.php`;
   don't share it or hand it in.
4. In a terminal in the `boards` folder run `php api/mail-test.php you@gmail.com` (XAMPP:
   `C:\xampp\php\php.exe api\mail-test.php you@gmail.com`). It checks every setting, sends a test
   email, and says exactly what to fix if something's wrong.
Set `'verify_email' => false` to turn codes off.

For a real website, use HTTPS and move `api/data` and `api/uploads` outside the public folder
(change the paths in `api/config.php`).

## Phones and tablets
The app adapts to smaller screens. On **phones** the card tools move to a bar along the bottom (swipe it
sideways for more), the top bar keeps only what's needed (back, title, Canvas/Dashboard, a coloured
save dot — green saved, orange saving, red problem — comments, share and your account), and windows
like Share, Settings and the file reader fill the screen. **Swipe** on empty board space to scroll the
board; new cards start no wider than the screen. On **touch screens** the buttons that appear on hover
with a mouse are always visible (tap a task to see its buttons), targets are bigger, and long-press on
a task's circle chooses its stage on Android. Tablets keep the normal layout.

## What it does
- Add notes and to-do lists from the left toolbar (click, or drag onto the board)
- Double-click empty space to drop a note
- Drag cards by their top edge; clicked cards come to the front
- Colour-tag cards, tick tasks off, see progress per list
- Rename the board in the top bar
- Attaching cards: drag a card onto another card that accepts it (it turns green and says where it will go).
  **To-do lists** and **notes** accept every kind of card (lists also per task), **media** cards accept
  notes (e.g. a description), and **calendars** accept images/videos on a day (dropped elsewhere on the
  calendar they go on the selected day; days with attachments show a paperclip). Attachments can hold
  attachments too. Notes and lists can be made wider from their corner to give attachments more room. Hover an attachment to drag it out, move it to the board or delete it.
- Put images/videos inside a to-do list: drag a media card onto the list (it turns green), drop files on it, or drag the Media tool onto it. Drop onto a specific task to attach it to that task instead (deleting the task moves its attachments to the list). Hover an attachment to move it back to the board or delete it, or drag its grip out
- Connect cards with wires: hover a card, drag from a dot on its side and drop it on another card (or one of its dots). Wire starts always use the side facing the other card; wire ends do too unless dropped on a specific dot, which pins them. Hover a task in a to-do list to get dots for that single task, or drop a wire right onto a task. Click a wire to recolour it or delete it (Del)
- Move around the board by holding the right (or middle) mouse button and dragging
- Drawing canvases: the Canvas tool adds a white drawing canvas (a chalkboard in dark mode). Draw with mouse, pen or finger; pen/eraser, 7 colours, 3 sizes, undo (Ctrl+Z) and clear. Drawings scale with the canvas when you resize it (keeping their shape); the arrows button switches this off so resizing just adds space instead. Zoom inside a canvas with Ctrl/⌘ + scroll (or pinch), the − 100% + buttons, or Ctrl + = / − / 0; move around with the hand tool, middle-mouse drag, Space + drag, or the scroll wheel while zoomed. The paint-bucket button changes the canvas background: presets, a custom colour maker (colour square, hue slider, hex code) and recently used colours. The default ink switches between dark and chalk automatically so it stays readable. Resize it in both directions from the corner
- Resize image/video cards from the bottom-right corner (double-click it to reset, or focus it and use ← →)
- Format text: select text in any note, task, list title or caption to get a bar with bold, italic, underline, strikethrough, text size, text colour, heading, bullet list and clear (Ctrl/⌘+B, I, U, Shift+X and Shift+> / < for bigger/smaller text also work)
- Hover any icon, colour dot or priority flag for a tooltip
- Give tasks a "complete by" date and optional time with the clock button on a task (Today / Tomorrow / Next week, or pick a date). The chip under the task turns orange when it's due today and red when it's overdue; click it to change or remove the date
- Give tasks a priority (low, medium, high, urgent) with the flag next to each task
- Add images and videos: Media button (choose a file or paste a link), drop files or links onto the board, or paste a screenshot or a media link. Links can be images, videos, YouTube or Vimeo
- Audio in media cards: MP3, WAV, M4A, AAC, FLAC, OGG and OPUS files or links, shown with a player (play/pause, a waveform you can click or drag to jump around, time; arrow keys skip 5 s). Spotify and SoundCloud links show their own players. Only one sound plays at a time
- Dark mode: follows your system setting, or use the moon/sun button (your choice is remembered)

## File
The **File** tool adds a file card: choose or drop any file (you can also drop files straight onto the
board — images/video/audio become media cards, everything else becomes a file card). It shows the type,
name and size. **Click it** (or **Open**) to read it in a window over the board, or **Download** it.
Readable here: **PDF** (the browser's PDF viewer), **Word .docx** (headings, formatting, lists, tables,
links, pictures — converted by the built-in reader), text/Markdown/JSON/code, CSV/TSV (as a table),
images, audio and video. Other types (e.g. .xlsx, .zip) can be stored and downloaded. File cards can be
attached to lists, tasks, notes and calendar days, duplicated (with their own copy of the file) and wired.

## Chart
The **Chart** tool adds a chart (diagram): choose **bar**, **line**, **pie** or **doughnut** at the top.
Click **Data** to type your own labels and numbers (add rows and series, rename them, remove them).
Or click the data source button and pick a **Table** on the board: the chart then follows that table
live (first column = labels, header row = series names, the other columns = numbers; "4 500", "4,5",
"12%" and "€30" all count as numbers). Click a series in the legend (or its dot in the data panel) to
change its colour. Hover bars, points and slices to see their values. Resize the chart in both directions;
charts can be attached to lists and notes like other cards.

## Table
The **Table** tool adds a table (3 × 3 to start). Click the size button (e.g. "3 × 3") and hover the grid
to pick rows × columns, or type exact numbers (up to 100 × 26). The toolbar inserts rows above/below and
columns left/right of the cell you're in, deletes the current row/column, toggles a header row and sets
the cell colour. Hover the table for **+** buttons that add a row or column. **Tab / Shift+Tab** move
between cells (Tab in the last cell adds a row), **Enter** moves down, and the text formatting bar works
in cells. Paste a block copied from Excel or Google Sheets to fill several cells at once. Tables can be
attached to lists and notes, wired, coloured, duplicated and selected like other cards.

## Calendar
The **Calendar** tool adds a month calendar. Use ‹ › to change month and **Today** to jump back.
Click a day to see its events underneath; **double-click** a day to start adding one. Events have a
title, an optional time and a colour (click the dot to change it). Drag an event's grip, or its bar
in the grid, onto another day to move it. Arrow keys move between days. Make the card wider and the
days show event titles instead of dots. Weeks start on Monday; month and day names follow your
browser's language.

## Accounts and boards
- **Log in / Create account** (or "Use without an account" to keep boards in this browser only).
- **Your boards:** create, open, rename, duplicate and delete boards (⋯ on a board).
- On a board: **←** goes back to your boards, the top bar shows **Saved / Saving…**, and the round
  button is your account (log out there). Changes save automatically about a second after you stop.
- If the same board is changed in another tab or on another computer, a bar asks whether to
  **load the newer version** or **keep yours**.
- After logging in, boards made in this browser without an account can be **copied into your account**
  (with their pictures and files).
- Safety: passwords are stored hashed (`password_hash`), you stay logged in with a secure cookie,
  requests from other websites are refused, wrong passwords are limited to 5 per 15 minutes,
  and every board and file is only available to its owner. Uploaded web pages/scripts are only ever
  downloaded, never run.
- Saved custom colours and imported brushes stay in each browser.

## Sharing boards
Open a board and click **Share** (top right). Type someone's email and choose what they can do:
- **Can edit** — everything (only you can delete the board or change who has access)
- **Can view** — look only; they can still play audio/video, open files, zoom canvases and browse
  calendar months
- **Can edit chosen cards** — click **Choose cards on the board…**, click the cards they may edit,
  then **Done**. Tick **Hide the other cards from them** if they shouldn't see the rest at all.

Invite people who don't have an account yet: they get access as soon as they register with that email.
Change someone's access or remove them in the same window. Invited people find the board under
**Shared with you**, see a badge with their access (e.g. "View only"), and can leave a board.
Shared boards refresh every few seconds, so you see each other's changes.

All of this is enforced by the server, not just the page: viewers can't save, limited editors' changes
to other cards are ignored, hidden cards are never sent to them, and files on a shared board can only be
opened by people who can see the card they're on.

## Settings: click sounds
Open the account menu (round button, top right) → **Settings…**. Under **Click sound** choose
**None** (the default), **Soft tick**, **Pop**, or **Your own sound** (**Import…** an MP3, WAV, OGG,
M4A… up to 1 MB; only the first second plays on each click). ▶ previews a sound, and the slider sets
the volume. Only left clicks / taps make a sound. The built-in sounds are generated by the browser,
so no sound files are needed. Your choice and your own sound are saved in this browser.

## Custom roles
Give the people you invite a role that says who they are on your team — your own roles, like
*Junior dev*, *Designer* or *Client*. Create them with **Roles…** in the Share window (or **Your roles…**
on the Team activity page): a name, a colour, and optionally a **suggested access** level that's picked
automatically when you choose that role while inviting. Roles belong to your account, so you can use
them on all your boards, and the same person can have different roles on different boards.
Choose a role when inviting, or change it later next to the person in the Share window. Roles show as
coloured badges in the Share window, the "Assign to" list, on assigned tasks (hover), in comments and in
Team activity, which also has a **By role** summary (people, tasks done, average turnaround, open tasks).
Roles don't change what someone can do — that's still their access (Can edit / Can view / chosen cards).
Boards inside a shared board now also list the people invited to the board they're in (in the Share
window and when assigning tasks).

## Team activity
See how the people on your boards are doing with their tasks:
- On a board's **Dashboard**, the **Team** widget (owner and full editors) covers that board and the
  boards inside it.
- **Team activity** (on your boards page, or in the account menu) covers every board you own: headline
  numbers, then per person **tasks completed**, **average turnaround** (and median; hover for fastest and
  slowest), **on time** (finished tasks that had a due date), **open** and **overdue** tasks, and
  **Details** with their recently completed tasks.
Turnaround is the time from when a task was assigned to someone (or created, if it wasn't assigned to
them) until it was ticked off. The server records these times itself when boards are saved — when a task
was created, assigned and completed, and who completed it — so they can't be changed from a browser.
Tasks finished before this tracking existed aren't counted.

## Your profile and picture
Click the round account button → **Profile & picture…** (or click your name at the top of that menu).
**Upload picture** opens a cropper: drag the picture into place and zoom with the slider, mouse wheel
or +/- keys, then **Save picture**. It's saved as a 256×256 picture and shown in a circle everywhere you
appear — the account button, the Share window, assigned tasks, the "Assign to" list, comments and the
dashboard (people without a picture show their initial). **Remove** takes it away again. You can also
change your **name** there. The server checks that uploads really are PNG, JPG or WebP pictures, and
pictures are only shown to logged-in users. Existing databases get the new column automatically
(MySQL: see `schema.mysql.sql`).

## Link cards
The **Link** tool adds a card for a web address: paste a link (e.g. `bmw.com` — `https://` is added
for you) and it shows a preview with the page's picture, title, description, the site's icon and name.
Click it to open the link in a new tab; hover for **Change the link** and **Refresh the preview**.
Pasting or dropping a web page link onto the board also makes a link card (pictures, videos, sounds,
YouTube, Spotify and SoundCloud links still become media cards). Previews are fetched by the server
(`api/link-preview.php`, needs PHP's curl extension, which XAMPP has) and saved on the card. For safety
the server only fetches public websites — never this computer or your home/school network — follows at
most 3 redirects, reads at most 1 MB and gives up after a few seconds. Without the server the card
shows the site's address only.

## Shape cards
The **Shape** tool adds a shape straight onto the board (no card behind it): rectangle, rounded
rectangle, ellipse, triangle, diamond, line or arrow. Hover it and click the style button (top right)
to change the shape, the fill (outline / filled / soft fill), the colour (presets, saved or custom) and
the thickness; lines and arrows can point in 8 directions. **Double-click** a shape to write inside it
(the formatting bar works; on solid fills the text turns white). Resize from the corner, drag by the bar
that appears above it, and connect shapes with wires like any card — handy for flowcharts. Shapes can
also go into lists and notes, and follow the same sharing permissions as other cards.

## Boards inside boards
The **Board** tool adds a card that is a board of its own. Name it right on the card (that renames the
board inside), and **click it to go inside**. The card shows a small map of the inner board's layout
and how many cards it has. Inside, the top bar shows where you are (*Car projects › E34 build*) and
**←** goes up one level. Boards inside boards only appear inside their parent, not on "Your boards".
Duplicating a board card copies the whole board inside it (and boards inside that); deleting one asks
first and deletes the inner board too. Board cards can also be put in lists and notes.
Sharing passes down: everyone with access to a board has the same access to the boards inside it
(limited editors can edit inside boards whose card they may edit; hidden ones stay hidden).
Existing databases get the new `parent_id` column automatically (MySQL: see `schema.mysql.sql`).

## Dashboard view
Use **Canvas / Dashboard** in a board's top bar to switch views (remembered per board in each browser).
The dashboard shows the board's content organised into widgets:
**Overview** (cards, % of tasks done, overdue, due this week, open comments — click the overdue or
comments tiles), **Tasks** from every list (Open / Overdue / Mine / Done; tick them off right there),
**Coming up** (task due dates and calendar events for the next 14 days, day by day), **Progress per
list**, **Open tasks per person**, **Open tasks by priority**, the board's **Charts** (live), a **Media**
gallery, **Files** (open them directly) and **Recent comments**. Click any item to jump to its card on
the canvas. Widgets only appear when the board has something for them, and the dashboard follows the
same permissions as the canvas (e.g. viewers can only tick off tasks assigned to them).

## Comments
The speech-bubble button in the board's top bar opens the **Comments** panel on the right. The red
number counts **new comments and replies from other people since you last opened the panel** (your
own don't count); opening the panel clears it, and what's new is marked **New**. Each person has
their own count. Write a comment and press **Comment** (or Ctrl+Enter).
Click a card first to make the comment **about that card** — the comment then shows the card's name,
and clicking it scrolls to the card and makes it flash (× makes it about the whole board instead).
**Reply** to comments, **resolve** finished conversations (✓; "Show resolved" brings them back), and
edit or delete your own (the board's owner can delete any). Links in comments are clickable.
Everyone with access can comment, viewers included; people with hidden cards don't see comments about
those cards. New comments appear automatically every few seconds. Without an account, comments are
kept in this browser.

## Task stages
Every task has a stage: **To do** (empty circle) → **In progress** (orange half circle, with an
"In progress" label) → **Done** (green tick, crossed out). **Click** the circle to move to the next
stage; **right-click** it (or Shift+click) to choose a stage directly, e.g. back from Done to In progress.
A list's progress bar shows done in green and in progress in orange. Stages work on the dashboard
(with an **In progress** filter), in *Assigned to you* and in Team activity (open tasks show how many are
in progress). The person a task is assigned to can change its stage even with view-only access. The
server records when a task moved to In progress, alongside when it was assigned and finished. Tasks
that were ticked before stages existed count as Done.

## Assigning tasks
On a board with an account, hover a task and click the person button to **assign it** to someone on
the board: you, or anyone it's shared with (also people invited who haven't signed up yet). The task
shows their avatar and name — or **You** — next to its priority and due date; click that to reassign
or unassign. The person a task is assigned to can **always tick it off**, even if they can only view
the list (the server allows exactly that one change, for exactly that person). Your boards page shows
**Assigned to you**: open tasks assigned to you on every board, soonest due first, with a checkbox to
complete them and a link to the board.

## Selecting several cards
- **Shift-** or **Ctrl/⌘-click** a card to add it to the selection (click again to remove it)
- **Drag on an empty part of the board** to draw a selection box (hold Shift to add to what's selected)
- Drag any selected card's top bar to **move them all together**
- The bar at the top: **Duplicate**, **Delete**, deselect
- Keys: **Delete/Backspace**, **Ctrl/⌘ + D** duplicate, **Ctrl/⌘ + A** select all, **Esc** deselect

Every card also has a **Duplicate** button in its top-right corner. Copies include everything inside
them (attached images, tasks, drawings, layers) and get their own copies of stored files.

## Colours
Every colour choice (card colour, wire colour, text colour, pen colour, board background) shows the
preset colours followed by your **saved custom colours**. Click **+** to make a new one with the
colour maker (colour square, hue, **opacity** and hex code) — it's saved and shows up in every colour
row. When a row gets long, arrows appear at both ends and the mouse wheel scrolls it. Right-click a
saved colour to remove it.

## Drawing canvases: sliders and download
The **thickness** slider sets the pen size (1–40 px) and the **opacity** slider makes the pen
see-through. The download button saves the whole drawing as **PNG** (with or without background) or
**JPG**.

## Canvas toolbar and shapes
The canvas toolbar is one row: **tools** (Draw `B`, Eraser `E`, Shapes `U`, Move `H`, Eyedropper `I`),
the **colour** swatch (opens the colour row), the **pen** button (thickness, opacity and brushes; `[` `]`
change the size), then zoom, undo and **⋯** for layers, background colour, scaling, mirroring,
download and clear. Click **Shapes** once to use it, again to pick a shape: rectangle, ellipse,
triangle, diamond, line or arrow — as an outline, filled or with a soft fill. Hold **Shift** for squares,
circles and lines at 15° steps. Shapes use the current colour, thickness and opacity, and work with
layers, mirrors, undo and downloads.

## Canvas brushes
The brush button (next to the draw button) opens **Brushes**: Pen, Pencil, Soft brush, Calligraphy,
Chalk and Spray. **Import…** turns PNG/JPG images into brushes (transparent parts — or light parts of an
image without transparency — don't paint), or loads a `.brush.json` file. You can also drop images onto
the Brushes box. Imported brushes have settings (angle: fixed / follow the line / random, spacing, flow,
scatter, size and angle jitter, stamps per step, size), a name, **Export** (to `.brush.json`, to share or
back up) and **Remove** (drawings already made with it keep their look). Brushes work with colours,
thickness, opacity, layers, mirrors and downloads, and every line keeps its exact look.

## Canvas eyedropper and mirroring
- **Eyedropper** (canvas toolbar, or **Alt + click** while drawing): click the drawing to use that colour
  for the pen. In the background colour box, **Pick from canvas** does the same for the background.
  In Chrome/Edge the custom colour maker also has an eyedropper that picks from anywhere on screen.
- **Mirror** (the two-triangles button): make a canvas show another canvas live, as it's drawn on.
  Flip it left↔right or upside down, zoom around it, or download it. **Stop mirroring** brings back the
  canvas's own drawing (it's kept while mirroring).
- If the original uses layers, the mirror's **layers button** chooses what the mirror shows, separately
  from the original: *Same as the original*, *All layers together*, or *Only the ones I tick*. Handy for
  working on one layer in the original while the mirror shows the whole picture.

## Canvas layers (optional)
Layers are **off** by default. Click the layers button (stacked squares) on a canvas to switch them
on — what you've already drawn becomes "Layer 1". In the floating panel you can add, duplicate,
rename (double-click), hide/show, reorder and delete layers, and set each layer's opacity. You always
draw on the highlighted layer, and the eraser only erases on that layer. Click the button again to
hide/show the panel. "Turn off layers" merges the visible layers back into one drawing.

## File map
| File | Feature |
|---|---|
| `index.html` | Page structure, loads everything in order |
| `css/base.css` | Colours, fonts, page layout |
| `css/toolbar.css` | Left toolbar |
| `css/board.css` | Dotted canvas + empty state |
| `css/cards.css` | Card frame, note and to-do styles |
| `css/rich-text.css` | Formatted text + floating format bar |
| `css/confirm-popover.css` | Confirm/cancel box |
| `css/tooltip.css` | Tooltips |
| `css/priority.css` | Priority flags + picker menu |
| `css/media.css` | Image/video cards |
| `css/nesting.css` | Attachments + drop-target highlight |
| `css/wires.css` | Connection dots + wire styles |
| `css/pan.css` | Grab cursor while moving the board |
| `css/dashboard.css` | Canvas / Dashboard switch and dashboard widgets |
| `css/comments.css` | Comments button and panel |
| `css/share.css` | Share window, read-only cards, access badges |
| `css/screens.css` | Log in, your boards, account menu |
| `landing.html`, `css/landing.css` | The landing page |
| `css/responsive.css` | Phones, tablets and touch screens |
| `css/selection.css` | Selected cards, selection box, selection bar |
| `css/palette.css` | Colour rows, custom colour box, opacity slider |
| `css/color-picker.css` | Colour maker + background popover |
| `css/link.css` | Link cards |
| `css/shape.css` | Shape cards |
| `css/board-card.css` | Board card + breadcrumbs |
| `css/file.css` | File card + reading window |
| `css/chart.css` | Chart card |
| `css/table.css` | Table card |
| `css/calendar.css` | Calendar card |
| `css/drawing.css` | Drawing canvas + its tools |
| `css/resize.css` | Resize handle |
| `css/theme.css` | Dark mode colours + toggle button |
| `js/rich-text.js` | Editable formatted text fields (+ safe HTML cleaning) |
| `js/text-style.js` | Shared code for coloured/sized text spans |
| `js/text-color.js` | Text colours (works with dark mode) |
| `js/font-size.js` | Text sizes |
| `js/format-toolbar.js` | Floating bold/italic/heading bar |
| `js/confirm-popover.js` | Small confirm/cancel box (used by Clear) |
| `js/tooltip.js` | Tooltips for anything with `data-tooltip` |
| `js/storage.js` | Autosaving the open board (instantly in the browser, after a pause to the server) |
| `js/api.js` | Talking to the PHP server |
| `js/session.js` | Logged in, or "this browser only" |
| `js/boards-repo.js` | Boards in the browser or in your account (list, open, save, rename, duplicate, delete, copy into account) |
| `js/access.js` | What you may do on the open board (locks read-only cards) |
| `js/dashboard.js` | The Dashboard view (widgets built from the board's cards) |
| `js/click-sounds.js` | Click sounds (Soft tick, Pop, your own) |
| `js/settings.js` | The Settings window |
| `js/roles.js` | Role badges + the Your roles window |
| `js/team.js` | Team activity page + the dashboard's Team widget |
| `js/profile.js` | Profile window + picture cropper |
| `js/comments.js` | The Comments panel |
| `js/people.js` | People on the board: names, avatars, choosing who a task is assigned to |
| `js/share.js` | Share window + choosing cards on the board |
| `js/screens.js` | Log in / register, "Your boards", account menu |
| `js/router.js` | Which screen shows (`#/login`, `#/boards`, `#/board/<id>`) |
| `api/config.local.example.php` | Template for your private settings (email password) |
| `api/mail-test.php` | Command-line email check: `php api/mail-test.php you@gmail.com` |
| `api/link-preview.php` | Fetches link previews (public websites only) |
| `api/mailer.php` | Sending email (development log, SMTP, or mail()) |
| `api/auth.php` | Register, log in, log out, who am I |
| `api/boards.php` | Saving and loading boards |
| `api/files.php` | Uploading and streaming files |
| `api/roles.php` | Your custom roles (create, rename, recolour, delete) |
| `api/team.php` | Team activity: tasks completed, turnaround, on-time rate per person |
| `api/profile.php`, `api/avatar.php` | Your name and profile picture; showing pictures |
| `api/comments.php` | Board comments: write, reply, resolve, edit, delete |
| `api/members.php` | Inviting people and their access (edit / view / chosen cards) |
| `api/db.php`, `api/config.php` | Database, sessions, settings |
| `server.php` | Router for `php -S` (keeps the database and uploads private) |
| `js/state.js` | Board data + add/update/remove cards |
| `js/cards/card-shell.js` | Shared card frame: drag bar, colour, delete |
| `js/cards/note.js` | Note card |
| `js/cards/todo.js` | To-do list card |
| `js/task-status.js` | Task stages: To do / In progress / Done (the shared button) |
| `js/cards/due-date.js` | "Complete by" dates/times for tasks |
| `js/cards/priority.js` | Task priority levels + picker |
| `js/audio-player.js` | Audio player with waveform for media cards |
| `js/cards/media.js` | Image/video card |
| `js/saved-colors.js` | Saved custom colours (shared everywhere) |
| `js/color-picker.js` | Reusable custom colour maker (with opacity) |
| `js/color-popover.js` | "Custom colour" box with Save & use |
| `js/palette.js` | Scrollable colour row: presets + saved colours + "+" (arrows, wheel) |
| `js/board-background.js` | Background colour popover for drawing canvases |
| `js/canvas-mirror.js` | "Mirror a canvas" picker |
| `js/brushes.js` | Brush engine: built-in brushes, stamping, importing/exporting brushes |
| `js/brush-picker.js` | The Brushes box (pick, import, brush settings) |
| `js/drawing-layers.js` | Optional layers for canvases (panel + merge) |
| `js/drawing-export.js` | Download a drawing as PNG / JPG |
| `js/drawing-zoom.js` | Zoom + pan inside drawing canvases |
| `js/cards/link.js` | Link card with a preview |
| `js/cards/shape.js` | Shape card (rectangle, ellipse, triangle, diamond, line, arrow) |
| `js/cards/board-card.js` | Board card (a board inside a board) |
| `js/cards/file.js` | File card (any file: open or download) |
| `js/file-viewer.js` | Reading window for files (PDF, Word, text, CSV, media) |
| `js/docx-reader.js` | Built-in Word (.docx) to HTML converter |
| `js/cards/chart.js` | Chart card (bar / line / pie / doughnut, own data or from a table) |
| `js/cards/table.js` | Table card (size picker, rows/columns, cell colours) |
| `js/cards/calendar.js` | Calendar card (month view + events) |
| `js/cards/drawing.js` | Drawing canvas card (whiteboard / chalkboard) |
| `js/media-links.js` | Recognises image/video/YouTube/Vimeo links |
| `js/media-store.js` | Stores image/video files (IndexedDB) |
| `js/media-import.js` | Drop/paste files and links onto the board |
| `js/drag.js` | Moving cards (and dropping them into other cards; selected cards move together) |
| `js/selection.js` | Multi-select: shift/ctrl-click, selection box, bar, shortcuts |
| `js/duplicate.js` | Duplicating cards (with their attachments and files) |
| `js/nesting.js` | Cards inside cards: attachments, pop-out, drag-out |
| `js/wires.js` | Wires connecting cards (dots, drawing, colours, delete) |
| `js/pan.js` | Right/middle-drag to move around the board |
| `js/resize.js` | Resizing cards (`resizable: true` = width, `'both'` = width + height) |
| `js/board.js` | Rendering cards, adding new ones |
| `js/toolbar.js` | Toolbar click + drag-to-create |
| `js/title.js` | Board name |
| `js/theme.js` | Light/dark mode switching |
| `js/main.js` | Startup |

## Adding a new card type (e.g. a link or image card)
1. Create `js/cards/link.js` and register `App.cardTypes.link = { label, defaults(), render(card, body), focus(el), onRemove(card)? }` — copy `note.js` as a starting point.
2. Add `<script src="js/cards/link.js">` in `index.html` after `note.js`.
3. Add a toolbar button with `data-type="link"`.
4. Style it in `css/cards.css` under `.card--link`.

## Ideas for next steps
- Column cards that other cards can be dropped into
- Multiple boards (store an array of boards in `state.js`)
- Zoom with Ctrl + scroll
- Swap `storage.js` for a PHP/MySQL backend

## Note on YouTube/Vimeo links
Some browsers block YouTube players on pages opened straight from a file (`file://`). If a YouTube
card shows a player error, open the project through a local server instead, for example the
"Live Server" extension in VS Code, or `python -m http.server` in the project folder and then
`http://localhost:8000`.
