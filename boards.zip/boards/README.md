# Boards — a Milanote-style task board (starter template)

Open `index.html` in a browser. No build step, no server needed.
Your board saves automatically to the browser (localStorage).

## What it does
- Add notes and to-do lists from the left toolbar (click, or drag onto the board)
- Double-click empty space to drop a note
- Drag cards by their top edge; clicked cards come to the front
- Colour-tag cards, tick tasks off, see progress per list
- Rename the board in the top bar

## File map
| File | Feature |
|---|---|
| `index.html` | Page structure, loads everything in order |
| `css/base.css` | Colours, fonts, page layout |
| `css/toolbar.css` | Left toolbar |
| `css/board.css` | Dotted canvas + empty state |
| `css/cards.css` | Card frame, note and to-do styles |
| `js/storage.js` | Save / load (localStorage) |
| `js/state.js` | Board data + add/update/remove cards |
| `js/cards/card-shell.js` | Shared card frame: drag bar, colour, delete |
| `js/cards/note.js` | Note card |
| `js/cards/todo.js` | To-do list card |
| `js/drag.js` | Moving cards |
| `js/board.js` | Rendering cards, adding new ones |
| `js/toolbar.js` | Toolbar click + drag-to-create |
| `js/title.js` | Board name |
| `js/main.js` | Startup |

## Adding a new card type (e.g. a link or image card)
1. Create `js/cards/link.js` and register `App.cardTypes.link = { label, defaults(), render(card, body), focus(el) }` — copy `note.js` as a starting point.
2. Add `<script src="js/cards/link.js">` in `index.html` after `note.js`.
3. Add a toolbar button with `data-type="link"`.
4. Style it in `css/cards.css` under `.card--link`.

## Ideas for next steps
- Column cards that other cards can be dropped into
- Multiple boards (store an array of boards in `state.js`)
- Zoom with Ctrl + scroll
- Swap `storage.js` for a PHP/MySQL backend
