# Boards — a Milanote-style task board (starter template)

Open `index.html` in a browser. No build step, no server needed.
Your board saves automatically to the browser: card data in localStorage, images and videos in IndexedDB (localStorage is too small for media).

## What it does
- Add notes and to-do lists from the left toolbar (click, or drag onto the board)
- Double-click empty space to drop a note
- Drag cards by their top edge; clicked cards come to the front
- Colour-tag cards, tick tasks off, see progress per list
- Rename the board in the top bar
- Attaching cards: drag a card onto another card that accepts it (it turns green and says where it will go).
  **To-do lists** and **notes** accept every kind of card (lists also per task), **media** cards accept
  notes (e.g. a description), and **calendars** accept images/videos on a day (dropped elsewhere on the
  calendar they go on the selected day; days with attachments show a paperclip). Attachments can hold
  attachments too. Notes and lists can be made wider from their corner to give attachments more room. Hover an attachment to drag it out, move it to the board or delete it.
- Put images/videos inside a to-do list: drag a media card onto the list (it turns green), drop files on it, or drag the Media tool onto it. Drop onto a specific task to attach it to that task instead (deleting the task moves its attachments to the list). Hover an attachment to move it back to the board or delete it, or drag its grip out
- Connect cards with wires: hover a card, drag from a dot on its side and drop it on another card (or one of its dots). Wire starts always use the side facing the other card; wire ends do too unless dropped on a specific dot, which pins them. Hover a task in a to-do list to get dots for that single task, or drop a wire right onto a task. Click a wire to recolour it or delete it (Del)
- Move around the board by holding the right (or middle) mouse button and dragging
- Drawing canvases: the Canvas tool adds a white drawing canvas (a chalkboard in dark mode). Draw with mouse, pen or finger; pen/eraser, 7 colours, 3 sizes, undo (Ctrl+Z) and clear. Drawings scale with the canvas when you resize it (keeping their shape); the arrows button switches this off so resizing just adds space instead. Zoom inside a canvas with Ctrl/⌘ + scroll (or pinch), the − 100% + buttons, or Ctrl + = / − / 0; move around with the hand tool, middle-mouse drag, Space + drag, or the scroll wheel while zoomed. The paint-bucket button changes the canvas background: presets, a custom colour maker (colour square, hue slider, hex code) and recently used colours. The default ink switches between dark and chalk automatically so it stays readable. Resize it in both directions from the corner
- Resize image/video cards from the bottom-right corner (double-click it to reset, or focus it and use ← →)
- Format text: select text in any note, task, list title or caption to get a bar with bold, italic, underline, strikethrough, text size, text colour, heading, bullet list and clear (Ctrl/⌘+B, I, U, Shift+X and Shift+> / < for bigger/smaller text also work)
- Hover any icon, colour dot or priority flag for a tooltip
- Give tasks a "complete by" date and optional time with the clock button on a task (Today / Tomorrow / Next week, or pick a date). The chip under the task turns orange when it's due today and red when it's overdue; click it to change or remove the date
- Give tasks a priority (low, medium, high, urgent) with the flag next to each task
- Add images and videos: Media button (choose a file or paste a link), drop files or links onto the board, or paste a screenshot or a media link. Links can be images, videos, YouTube or Vimeo
- Audio in media cards: MP3, WAV, M4A, AAC, FLAC, OGG and OPUS files or links, shown with a player (play/pause, a waveform you can click or drag to jump around, time; arrow keys skip 5 s). Spotify and SoundCloud links show their own players. Only one sound plays at a time
- Dark mode: follows your system setting, or use the moon/sun button (your choice is remembered)

## File
The **File** tool adds a file card: choose or drop any file (you can also drop files straight onto the
board — images/video/audio become media cards, everything else becomes a file card). It shows the type,
name and size. **Click it** (or **Open**) to read it in a window over the board, or **Download** it.
Readable here: **PDF** (the browser's PDF viewer), **Word .docx** (headings, formatting, lists, tables,
links, pictures — converted by the built-in reader), text/Markdown/JSON/code, CSV/TSV (as a table),
images, audio and video. Other types (e.g. .xlsx, .zip) can be stored and downloaded. File cards can be
attached to lists, tasks, notes and calendar days, duplicated (with their own copy of the file) and wired.

## Chart
The **Chart** tool adds a chart (diagram): choose **bar**, **line**, **pie** or **doughnut** at the top.
Click **Data** to type your own labels and numbers (add rows and series, rename them, remove them).
Or click the data source button and pick a **Table** on the board: the chart then follows that table
live (first column = labels, header row = series names, the other columns = numbers; "4 500", "4,5",
"12%" and "€30" all count as numbers). Click a series in the legend (or its dot in the data panel) to
change its colour. Hover bars, points and slices to see their values. Resize the chart in both directions;
charts can be attached to lists and notes like other cards.

## Table
The **Table** tool adds a table (3 × 3 to start). Click the size button (e.g. "3 × 3") and hover the grid
to pick rows × columns, or type exact numbers (up to 100 × 26). The toolbar inserts rows above/below and
columns left/right of the cell you're in, deletes the current row/column, toggles a header row and sets
the cell colour. Hover the table for **+** buttons that add a row or column. **Tab / Shift+Tab** move
between cells (Tab in the last cell adds a row), **Enter** moves down, and the text formatting bar works
in cells. Paste a block copied from Excel or Google Sheets to fill several cells at once. Tables can be
attached to lists and notes, wired, coloured, duplicated and selected like other cards.

## Calendar
The **Calendar** tool adds a month calendar. Use ‹ › to change month and **Today** to jump back.
Click a day to see its events underneath; **double-click** a day to start adding one. Events have a
title, an optional time and a colour (click the dot to change it). Drag an event's grip, or its bar
in the grid, onto another day to move it. Arrow keys move between days. Make the card wider and the
days show event titles instead of dots. Weeks start on Monday; month and day names follow your
browser's language.

## Selecting several cards
- **Shift-** or **Ctrl/⌘-click** a card to add it to the selection (click again to remove it)
- **Drag on an empty part of the board** to draw a selection box (hold Shift to add to what's selected)
- Drag any selected card's top bar to **move them all together**
- The bar at the top: **Duplicate**, **Delete**, deselect
- Keys: **Delete/Backspace**, **Ctrl/⌘ + D** duplicate, **Ctrl/⌘ + A** select all, **Esc** deselect

Every card also has a **Duplicate** button in its top-right corner. Copies include everything inside
them (attached images, tasks, drawings, layers) and get their own copies of stored files.

## Colours
Every colour choice (card colour, wire colour, text colour, pen colour, board background) shows the
preset colours followed by your **saved custom colours**. Click **+** to make a new one with the
colour maker (colour square, hue, **opacity** and hex code) — it's saved and shows up in every colour
row. When a row gets long, arrows appear at both ends and the mouse wheel scrolls it. Right-click a
saved colour to remove it.

## Drawing canvases: sliders and download
The **thickness** slider sets the pen size (1–40 px) and the **opacity** slider makes the pen
see-through. The download button saves the whole drawing as **PNG** (with or without background) or
**JPG**.

## Canvas brushes
The brush button (next to the draw button) opens **Brushes**: Pen, Pencil, Soft brush, Calligraphy,
Chalk and Spray. **Import…** turns PNG/JPG images into brushes (transparent parts — or light parts of an
image without transparency — don't paint), or loads a `.brush.json` file. You can also drop images onto
the Brushes box. Imported brushes have settings (angle: fixed / follow the line / random, spacing, flow,
scatter, size and angle jitter, stamps per step, size), a name, **Export** (to `.brush.json`, to share or
back up) and **Remove** (drawings already made with it keep their look). Brushes work with colours,
thickness, opacity, layers, mirrors and downloads, and every line keeps its exact look.

## Canvas eyedropper and mirroring
- **Eyedropper** (canvas toolbar, or **Alt + click** while drawing): click the drawing to use that colour
  for the pen. In the background colour box, **Pick from canvas** does the same for the background.
  In Chrome/Edge the custom colour maker also has an eyedropper that picks from anywhere on screen.
- **Mirror** (the two-triangles button): make a canvas show another canvas live, as it's drawn on.
  Flip it left↔right or upside down, zoom around it, or download it. **Stop mirroring** brings back the
  canvas's own drawing (it's kept while mirroring).
- If the original uses layers, the mirror's **layers button** chooses what the mirror shows, separately
  from the original: *Same as the original*, *All layers together*, or *Only the ones I tick*. Handy for
  working on one layer in the original while the mirror shows the whole picture.

## Canvas layers (optional)
Layers are **off** by default. Click the layers button (stacked squares) on a canvas to switch them
on — what you've already drawn becomes "Layer 1". In the floating panel you can add, duplicate,
rename (double-click), hide/show, reorder and delete layers, and set each layer's opacity. You always
draw on the highlighted layer, and the eraser only erases on that layer. Click the button again to
hide/show the panel. "Turn off layers" merges the visible layers back into one drawing.

## File map
| File | Feature |
|---|---|
| `index.html` | Page structure, loads everything in order |
| `css/base.css` | Colours, fonts, page layout |
| `css/toolbar.css` | Left toolbar |
| `css/board.css` | Dotted canvas + empty state |
| `css/cards.css` | Card frame, note and to-do styles |
| `css/rich-text.css` | Formatted text + floating format bar |
| `css/confirm-popover.css` | Confirm/cancel box |
| `css/tooltip.css` | Tooltips |
| `css/priority.css` | Priority flags + picker menu |
| `css/media.css` | Image/video cards |
| `css/nesting.css` | Attachments + drop-target highlight |
| `css/wires.css` | Connection dots + wire styles |
| `css/pan.css` | Grab cursor while moving the board |
| `css/selection.css` | Selected cards, selection box, selection bar |
| `css/palette.css` | Colour rows, custom colour box, opacity slider |
| `css/color-picker.css` | Colour maker + background popover |
| `css/file.css` | File card + reading window |
| `css/chart.css` | Chart card |
| `css/table.css` | Table card |
| `css/calendar.css` | Calendar card |
| `css/drawing.css` | Drawing canvas + its tools |
| `css/resize.css` | Resize handle |
| `css/theme.css` | Dark mode colours + toggle button |
| `js/rich-text.js` | Editable formatted text fields (+ safe HTML cleaning) |
| `js/text-style.js` | Shared code for coloured/sized text spans |
| `js/text-color.js` | Text colours (works with dark mode) |
| `js/font-size.js` | Text sizes |
| `js/format-toolbar.js` | Floating bold/italic/heading bar |
| `js/confirm-popover.js` | Small confirm/cancel box (used by Clear) |
| `js/tooltip.js` | Tooltips for anything with `data-tooltip` |
| `js/storage.js` | Save / load (localStorage) |
| `js/state.js` | Board data + add/update/remove cards |
| `js/cards/card-shell.js` | Shared card frame: drag bar, colour, delete |
| `js/cards/note.js` | Note card |
| `js/cards/todo.js` | To-do list card |
| `js/cards/due-date.js` | "Complete by" dates/times for tasks |
| `js/cards/priority.js` | Task priority levels + picker |
| `js/audio-player.js` | Audio player with waveform for media cards |
| `js/cards/media.js` | Image/video card |
| `js/saved-colors.js` | Saved custom colours (shared everywhere) |
| `js/color-picker.js` | Reusable custom colour maker (with opacity) |
| `js/color-popover.js` | "Custom colour" box with Save & use |
| `js/palette.js` | Scrollable colour row: presets + saved colours + "+" (arrows, wheel) |
| `js/board-background.js` | Background colour popover for drawing canvases |
| `js/canvas-mirror.js` | "Mirror a canvas" picker |
| `js/brushes.js` | Brush engine: built-in brushes, stamping, importing/exporting brushes |
| `js/brush-picker.js` | The Brushes box (pick, import, brush settings) |
| `js/drawing-layers.js` | Optional layers for canvases (panel + merge) |
| `js/drawing-export.js` | Download a drawing as PNG / JPG |
| `js/drawing-zoom.js` | Zoom + pan inside drawing canvases |
| `js/cards/file.js` | File card (any file: open or download) |
| `js/file-viewer.js` | Reading window for files (PDF, Word, text, CSV, media) |
| `js/docx-reader.js` | Built-in Word (.docx) to HTML converter |
| `js/cards/chart.js` | Chart card (bar / line / pie / doughnut, own data or from a table) |
| `js/cards/table.js` | Table card (size picker, rows/columns, cell colours) |
| `js/cards/calendar.js` | Calendar card (month view + events) |
| `js/cards/drawing.js` | Drawing canvas card (whiteboard / chalkboard) |
| `js/media-links.js` | Recognises image/video/YouTube/Vimeo links |
| `js/media-store.js` | Stores image/video files (IndexedDB) |
| `js/media-import.js` | Drop/paste files and links onto the board |
| `js/drag.js` | Moving cards (and dropping them into other cards; selected cards move together) |
| `js/selection.js` | Multi-select: shift/ctrl-click, selection box, bar, shortcuts |
| `js/duplicate.js` | Duplicating cards (with their attachments and files) |
| `js/nesting.js` | Cards inside cards: attachments, pop-out, drag-out |
| `js/wires.js` | Wires connecting cards (dots, drawing, colours, delete) |
| `js/pan.js` | Right/middle-drag to move around the board |
| `js/resize.js` | Resizing cards (`resizable: true` = width, `'both'` = width + height) |
| `js/board.js` | Rendering cards, adding new ones |
| `js/toolbar.js` | Toolbar click + drag-to-create |
| `js/title.js` | Board name |
| `js/theme.js` | Light/dark mode switching |
| `js/main.js` | Startup |

## Adding a new card type (e.g. a link or image card)
1. Create `js/cards/link.js` and register `App.cardTypes.link = { label, defaults(), render(card, body), focus(el), onRemove(card)? }` — copy `note.js` as a starting point.
2. Add `<script src="js/cards/link.js">` in `index.html` after `note.js`.
3. Add a toolbar button with `data-type="link"`.
4. Style it in `css/cards.css` under `.card--link`.

## Ideas for next steps
- Column cards that other cards can be dropped into
- Multiple boards (store an array of boards in `state.js`)
- Zoom with Ctrl + scroll
- Swap `storage.js` for a PHP/MySQL backend

## Note on YouTube/Vimeo links
Some browsers block YouTube players on pages opened straight from a file (`file://`). If a YouTube
card shows a player error, open the project through a local server instead, for example the
"Live Server" extension in VS Code, or `python -m http.server` in the project folder and then
`http://localhost:8000`.
