<?php

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if (preg_match('~^/api/(data|uploads)(/|$)|^/api/(config|db)\.php$|\.sql$~', $path)) {
    http_response_code(403);
    exit('Forbidden');
}
return false;
